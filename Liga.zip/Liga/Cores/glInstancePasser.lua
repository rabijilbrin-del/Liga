local glInstancePasser = {}

function glInstancePasser:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.Instance = nil
  return o
end

function glInstancePasser:getInstance(instance)
  self.Instance = instance
end

function glInstancePasser:loadInstance()
  return self.Instance
end

return glInstancePasser
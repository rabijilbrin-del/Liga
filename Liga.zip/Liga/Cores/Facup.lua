local Facup = {}
function Facup:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  return o
end

function Facup:tts()
  local buttonYes = {
    icon = "$FooterIconNo",
    label = "View Squad",
    clickEvents = {
      "evt_hide_popup",
      "evt_squad"
    }
  }
  local popupData = {
    title = "WELCOME MR MANAGER",
    message = "You have being appointed as " .. self.loc.LocalizeString("TeamName_Abbr15_" .. currentSelectedTeamID) .. " new Head Coach, \n View your squad.",
    buttons = {buttonYes}
  }
  self.nav.Event(nil, "evt_show_popup", popupData)
end

function Facup:finalize()
end

return Facupl
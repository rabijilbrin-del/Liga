--[[
  background_scheduler.lua
  -----------------------
  Run functions as 'background jobs' in games/mods.
  - Each job runs a little bit per frame/tick (using coroutines)
  - Never blocks the main game loop; low priority
  - Good for transfers, AI, batch work, etc.

  Usage:
    local scheduler = require("background_scheduler")
    scheduler.addJob(function()
      for i=1,1000 do
        someHeavyTransferLogic(i)
        scheduler.yield() -- yield so the game can breathe
      end
    end)

    -- In your main update/tick loop:
    function update()
      scheduler.step() -- call each frame/tick
    end

    -- You can add as many jobs as you want!
--]]

local scheduler = {}
scheduler._jobs = {}

function scheduler.addJob(fn, ...)
  assert(type(fn) == "function" or type(fn) == "thread", "addJob expects a function or coroutine")
  local co = type(fn) == "thread" and fn or coroutine.create(fn)
  table.insert(scheduler._jobs, {co = co, args = {...}})
  return co
end

function scheduler.yield(...)
  return coroutine.yield(...)
end

-- Run one 'slice' of each job. Call every frame/tick.
-- Optional: set maxJobsPerTick and/or maxTimePerTick (in seconds)
function scheduler.step(maxJobsPerTick, maxTimePerTick)
  local start = os.clock()
  local i, n = 1, #scheduler._jobs
  local jobsRun = 0
  while i <= #scheduler._jobs do
    if maxJobsPerTick and jobsRun >= maxJobsPerTick then break end
    if maxTimePerTick and (os.clock() - start) > maxTimePerTick then break end
    local job = scheduler._jobs[i]
    if coroutine.status(job.co) == "dead" then
      table.remove(scheduler._jobs, i)
      n = n - 1
    else
      local ok, err = coroutine.resume(job.co, table.unpack(job.args))
      if not ok then
        print("[scheduler] Job error:", err)
        table.remove(scheduler._jobs, i)
        n = n - 1
      else
        i = i + 1
      end
      jobsRun = jobsRun + 1
    end
  end
end

function scheduler.clear()
  scheduler._jobs = {}
end

function scheduler.count()
  return #scheduler._jobs
end

return scheduler
-- Mod By MVN PROD --
-- League Mode Division --

local Liga = {}
local bndMatchList = "bnd_match_list"
local ACT_ADVANCE = "act_advance"
local ACT_NEXT = "act_next"
local ACT_PREVIOUS = "act_decrease"
local ACT_SUBMIT = "act_submit"

ligaId = 1
if not round then
  round = 1
else 
  round = round
end

bnd_fontColor = "0xED1400"

if not selectedteam then
  selectedteam = 1
else 
  selectedteam = selectedteam
end

currentMatch = {
  HomeTeamID = 0,
  AwayTeamID = 0,
  HomeKitIndex = 0,
  AwayKitIndex = 1
}

-- Global table to store scout assignments for access by other scripts
ScoutAssignments = ScoutAssignments or {}

-- Dev2
local rivalListData = {}
local matchesPlayed = 0  -- Counter to track the number of matches played

function Liga:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.services = {
    settingsService = o.api("SettingsService"),
    SquadManagementService = o.api("SquadMgtService")
  }

  o.currentOptions = o.services.settingsService.GetCurrentOptions()
  currentRowIndex = currentRowIndex or 1 -- Default to first row
  o:Init()
  
  o.im.Subscribe(bndMatchList, function()
     o:publishMatchRows()
  end)
  
  o.im.Subscribe("bnd_match_label", function()
    o:publishMatchLabel()
  end)
  
  o.im.Subscribe("bnd_scout", function()
    o:displayImg()
  end)
  
  o.im.Subscribe("bnd_point_label", function()
    o:publishMatchLabel()
  end)
  
  o.im.Subscribe("bnd_finish_label", function()
    o:publishFinishLabel()
  end)
  
  o.im.Subscribe("bnd_team_label", function()
    o:publishLabel()
  end)
  
  o.im.Subscribe("bnd_matchup_label", function()
    o:publishFinishLabel()
  end)
  
  o.im.Subscribe("bnd_matchday_label", function()
    o:publishLabel()
  end)
  
  o.im.Subscribe("bnd_league_label", function()
    o:publishFinishLabel()
  end)
  
  o.im.Subscribe("bnd_fontColor", function()
  end)
  
  o.im.Subscribe("bnd_advance_label", function()
    o:publishFinishLabel()
  end)
  
  o.im.Subscribe("bnd_month_label", function()
    o:publishFinishLabel()
  end)
  
  o.im.RegisterAction(ACT_ADVANCE, function(actionName, data)
    if data then
      o:PlayMatch(data)
    end
  end)
  o.im.RegisterAction(ACT_NEXT, function(actionName, data)
    o:toggleNext()
  end)
  o.im.RegisterAction(ACT_PREVIOUS, function(actionName, data)
    o:togglePrevious()
  end)
  o.im.RegisterAction(ACT_SUBMIT, function(actionName, data)
    o:getScoutAssignment()
  end)

  return o
end

------------------------------------------------------------------------------------------

function Liga:Init()
  local LigaGroupingList = LigaGrouping[ligaId]
  for i = 1, table.getn(LigaGroupingList) do
    local obj = {
      homeID = LigaGroupingList[i][1],
      awayID = LigaGroupingList[i][2],
      homeScore = LigaGroupingList[i][4],
      awayScore = LigaGroupingList[i][5],
      data = {}
    }
    table.insert(rivalListData, obj)
  end
end

------------------------------------------------------------------------------------------

function Liga:displayImg()
  self.im.Publish("bnd_scout", "$Europe")
end

function Liga:togglePrevious()
    self:publishMatchRows()
end

function Liga:toggleNext()
    self:publishMatchRows()
end

function Liga:publishLabel()
    self.im.Publish("bnd_matchday_label", "Match Revenue")
end

function Liga:publishMatchRows()
    local filteredRivalListData = {}
    matchRevenueNotif = "cleared"
    GLOBAL_FUNDS = GLOBAL_FUNDS + revenue.totalRevenue
    
    local revenueData = {
        {Revhead = "Prize Money", Revdetail = "€" .. tostring(revenue.prizeMoney)},
        {Revhead = "Gate Receipt", Revdetail = "€" .. tostring(revenue.gateReceipts)},
        {Revhead = "Sponsorship", Revdetail = "€" .. tostring(revenue.sponsorships)},
        {Revhead = "Merchandise", Revdetail = "€" .. tostring(revenue.merchandise)},
        {Revhead = "Total", Revdetail = "€".. tostring(GLOBAL_FUNDS)}
    }
    
    for i = 1, 5 do
        local v = {}
        v.data = {}
        v.data.Revhead = revenueData[i].Revhead .. " :"
        v.data.Revdetail = revenueData[i].Revdetail
        v.data.clickAction = "act_advance"
        table.insert(filteredRivalListData, v)
    end
    self.im.Publish(bndMatchList, filteredRivalListData)
end

function Liga:PlayMatch(data)
    currentRowIndex = data.id + 1
    self:publishLabel()
    self:publishMatchRows()
end

function Liga:getScoutAssignment()
    local assignment = {
        ["Ticket Sales"] = "0",
        ["Concessions"] = "0",
        ["Merchandise"] = "0",
        ["Parking"] = "0",
        ["Total"] = tostring(GLOBAL_FUNDS)
    }
    
    ScoutAssignments = ScoutAssignments or {}
    ScoutAssignments = assignment
    
    print("Revenue Assignment Stored for ligaId " .. tostring(ligaId) .. ":")
    for k, v in pairs(assignment) do
        print(k .. ": " .. tostring(v))
    end
    
    self.nav.Event(nil, "evt_back")
end

function Liga:finalize()
  self.im.UnregisterAction(ACT_ADVANCE)
  self.im.UnregisterAction(ACT_NEXT)
  self.im.UnregisterAction(ACT_PREVIOUS)
  self.im.UnregisterAction(ACT_SUBMIT)
  self.im.Unsubscribe("bnd_match_list")
  self.im.Unsubscribe("bnd_matchday_label")
  self.im.Unsubscribe("bnd_point_label")
  self.im.Unsubscribe("bnd_scout")
  self.im.Unsubscribe("bnd_matchup_label")
  self.im.Unsubscribe("bnd_matchdate_label")
  self.im.Unsubscribe("bnd_league_label")
  self.im.Unsubscribe("bnd_advance_label")
  self.im.Unsubscribe("bnd_month_label")
  self.im.Unsubscribe("bnd_finish_label")
  rivalListData = {}
end

return Liga

-- Thanks : Ma'ruf Id & Laosiji --
-- @mvnprod.official - Remain Be Creative --
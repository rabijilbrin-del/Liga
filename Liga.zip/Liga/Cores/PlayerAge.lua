local PlayerAge = {}

function PlayerAge:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.services = {SquadManagementService = o.api("SquadMgtService")}  
  return o
end

function computeTransferValue(age, rating, position, playerIndex, replacementCount, daysLeftInWindow)
  local MAX_VALUE = 200000000  
  local MIN_VALUE = 250000   
  local threshold = 3

  
  local base
  if rating < 60 then
    base = 250000 + (rating - 50) * 25000  
  elseif rating < 70 then
    base = 500000 + (rating - 60) * 100000 
  elseif rating < 80 then
    base = 2000000 + (rating - 70) * 400000 
  elseif rating < 85 then
    base = 6000000 + (rating - 80) * 2000000
  else
    base = 16000000 + (rating - 85) * 4000000 
  end

  
  local ageFactor = 1.0
  if rating >= 75 then
    if age <= 20 then ageFactor = 1.8
    elseif age <= 23 then ageFactor = 1.5
    elseif age <= 26 then ageFactor = 1.3
    elseif age <= 29 then ageFactor = 1.1
    elseif age <= 32 then ageFactor = 1.0
    else ageFactor = math.max(0.4, 0.7 - (age - 32) * 0.05) end
  end

  
  local positionMultipliers = {
    ["GK"] = 1.0, ["LB"] = 1.05, ["RB"] = 1.05, ["CB"] = 1.1,
    ["LWB"] = 1.1, ["RWB"] = 1.1, ["CDM"] = 1.2, ["CM"] = 1.3,
    ["RM"] = 1.4, ["LM"] = 1.4, ["CAM"] = 1.6, ["RW"] = 1.7, ["LW"] = 1.7,
    ["ST"] = 1.8, ["CF"] = 1.8
  }
  local positionFactor = positionMultipliers[position] or 1.0

  
  local contractFactor
  if age < 25 then contractFactor = 1.1
  elseif age <= 30 then contractFactor = 1.0
  else contractFactor = 0.9 end

  
  local marketFactor = (daysLeftInWindow < 7) and 1.1 or 1.0

  
  local clubFactor = 1.0
  if playerIndex <= 11 then
    clubFactor = 1.15 
  else
    clubFactor = math.max(0.7, 1.0 - (playerIndex - 11) * 0.05)
  end
  if replacementCount > 2 then
    clubFactor = clubFactor * 0.9
  end

  
  local finalValue = base * ageFactor * positionFactor * contractFactor * marketFactor * clubFactor
  finalValue = math.min(finalValue, MAX_VALUE)
  finalValue = math.max(finalValue, MIN_VALUE)

  
  if finalValue >= 1000000 then
    finalValue = math.floor(finalValue / 1000000 + 0.5) * 1000000
  else
    finalValue = math.floor(finalValue / 100000 + 0.5) * 100000
  end

  
  local minFraction = 0.75
  local minAcceptableValue = math.max(MIN_VALUE, finalValue * minFraction)
  if minAcceptableValue >= 1000000 then
    minAcceptableValue = math.floor(minAcceptableValue / 1000000 + 0.5) * 1000000
  else
    minAcceptableValue = math.floor(minAcceptableValue / 100000 + 0.5) * 100000
  end

  return (finalValue * threshold), (minAcceptableValue * threshold)
end

function daysLeftInTransferWindow(dateStr)
    dateStr = dateStr or "15/03/25"
    local day, month, year = dateStr:match("(%d%d)/(%d%d)/(%d%d)")
    if not day then return 0 end
    
    day, month, year = tonumber(day), tonumber(month), tonumber(year)
    local fullYear = 2000 + year
    local daysInMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
    local currentDayOfYear = day
    for i = 1, month - 1 do currentDayOfYear = currentDayOfYear + daysInMonth[i] end
    
    local summerDeadlineDay, winterDeadlineDay = 242, 30
    local summerYear = currentDayOfYear <= summerDeadlineDay and fullYear or fullYear + 1
    local winterYear = fullYear
    local daysToSummer = fullYear == summerYear and summerDeadlineDay - currentDayOfYear or (365 - currentDayOfYear) + summerDeadlineDay + (summerYear - fullYear - 1) * 365
    local daysToWinter = currentDayOfYear <= winterDeadlineDay and winterDeadlineDay - currentDayOfYear or (365 - currentDayOfYear) + winterDeadlineDay + (winterYear == fullYear and 0 or 365)
    return math.min(math.max(0, daysToSummer), math.max(0, daysToWinter))
end

function playerReplacementCount(teamID, position, squad)
  -- Ensure teamID and position are provided
  if not teamID or not position then
    print("[playerReplacementCount] Error: teamID or position missing")
    return 0  -- Default to 0 replacements if inputs are invalid
  end

  -- Fetch the current lineup
  local players = squad or getCachedTeamPlayers(teamID)
  local replacementCount = 0

  -- Check if lineup data is valid
  if not players or type(players) ~= "table" then
    print("[playerReplacementCount] Warning: No valid player data for teamID " .. teamID)
    return 0
  end

  -- Count replacements among substitutes (index 12+)
  for index = 12, #players do
    local player = players[index]
    if player and player.position == position then
      replacementCount = replacementCount + 1
    end
  end

  return replacementCount
end

function getPlayerInfo(playerID, teamID, squad)
  local players = squad or getCachedTeamPlayers(teamID)
  if players then
    for index, player in ipairs(players) do
      if player.CARD_ID == playerID then
        return { index = index, position = player.position, rating = player.rating, teamID = player.teamID, stats1 = player.stat1, stats2 = player.stat2, stats3 = player.stat3, stats4 = player.stat4, stats5 = player.stat5, stats6 = player.stat6, name = player.playerName}
      end
    end
  end
  return nil
end

function PlayerAge:finalize()
  -- Finalization logic, if any
end

return PlayerAge
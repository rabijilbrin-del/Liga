local tabsData = {}
local mode = nil
tabsData.data = {}
tabsData.tabs = {}

local careerModeTabs = { "Central", "Squad", "Transfers", "Office", "Customise" }
local tourneyModeTabs = { "Central", "Squad", "Office", "Customise" }

tabsData.MAX_TABS = 7
tabsData.tabs["career"] = careerModeTabs
tabsData.tabs["tournament"] = tourneyModeTabs

tabsData.data["career"] = {
	["Tab2"] = {
						[1] = {name = "Team Management",
								imgSrc = "$Icon_Team_Cup",
								subInfo = "",
								desc = "",
								event = "evt_squad"},						
						[2] = {name = "Squad Hub",
								imgSrc = "$Icon_Team_Cup",
								subInfo = "View your players",
								desc = "",
								event = "evt_teamhub"
								}
						
					},
	["Tab3"] = {
						[1] = {name = "Search Players",
								imgSrc = "$FooterIconSearch",
								subInfo = "",
								desc = "Search for a specific player you want to buy, loan or scout",
								event = "evt_searching"},
						[2] = {name = "Global Transfer Network",
								imgSrc = "$Enter_Scouts",
								subInfo = "",
								desc = "",
								displayStats = false,
								event = "evt_gtn"},
						[3] = {name = "Transfer Hub",
								imgSrc = "$THubIcon",
								subInfo = "View Team Transfer Activity",
								desc = "",
								event = "evt_transferhub"}
					},
     ["Tab4"] = {
						[1] = {name = "Calendar",
								imgSrc = "$calendaricon",
								subInfo = "",
								desc = "View your team's upcoming schedule",
								event = "evt_calendar"},
						[2] = {name = "Team Stats",
								imgSrc = "",
								subInfo = "View team stats",
								desc = "",
								displayStats = true,
								statType = "Team",
								event = "evt_table"},
					    [3] = {name = "Budget Overview",
								imgSrc = "",
								subInfo = "View team budget",
								desc = "",
								displayBudget = true,
								event = ""},
						[4] = {name = "Fixtures",
								imgSrc = "$fixturesicon",
								subInfo = "",
								desc = "",
								event = "evt_fixtures"}
					},	
    ["Tab5"] = {
						[1] = {name = "Settings",
									imgSrc = "$Icon_Setting_Cup",
									subInfo = "",
									desc = "",
									event = "evt_to_settings_customize"},
						[2] = {name = "Player Stats",
								imgSrc = "",
								subInfo = "View players stats",
								desc = "",
								displayStats = true,
								statType = "Player",
								event = "evt_goalscorer"},
								[3] = {name = "Save",
								imgSrc = "$icon_save",
								subInfo = "Save career progress",
								desc = "",
								event = (function(self) self.serializer:saveProgress() end)}
					}
	}
	
	tabsData.data["tournament"] = {
	["Tab2"] = {
						[1] = {name = "Team Management",
								imgSrc = "$Icon_Team_Cup",
								subInfo = "",
								desc = "",
								event = "evt_squad"},						
						[2] = {name = "Squad Hub",
								imgSrc = "$Icon_Team_Cup",
								subInfo = "View your players",
								desc = "",
								event = "evt_teamhub"
								}
						
					},		
     ["Tab3"] = {
						[1] = {name = "Calendar",
								imgSrc = "$calendaricon",
								subInfo = "",
								desc = "View your team's upcoming schedule",
								event = "evt_calendar"},
						[2] = {name = "Team Stats",
								imgSrc = "",
								subInfo = "View team stats",
								desc = "",
								displayStats = true,
								statType = "Team",
								event = "evt_table"},
						[3] = {name = "Fixtures",
								imgSrc = "$fixturesicon",
								subInfo = "",
								desc = "",
								event = "evt_fixtures"}
					},	
    ["Tab4"] = {
						[1] = {name = "Settings",
									imgSrc = "$Icon_Setting_Cup",
									subInfo = "",
									desc = "",
									event = "evt_to_settings_customize"},
						[2] = {name = "Player Stats",
								imgSrc = "",
								subInfo = "View players stats",
								desc = "",
								displayStats = true,
								statType = "Player",
								event = "evt_goalscorer"},
								[3] = {name = "Save",
								imgSrc = "$icon_save",
								subInfo = "Save career progress",
								desc = "",
								event = (function(self) self.serializer:saveProgress() end)}
					}
	}
	
return tabsData
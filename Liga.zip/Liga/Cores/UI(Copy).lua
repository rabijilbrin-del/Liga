local tabsData = ...
local publish = nil
local subscribe= nil
-- UI configuration constants
local UIConfig = {
    axisXConfigs = {-470, -60, 350, 760, 1170, 1580, 1990}, -- Button X positions
    tabXConfig = { 255, 355, 445, 570, 660 }, -- Tab name X positions
    btnTabsXConfig = {-470, -60, 350, 760, 1170, 1580, 1990},
    tabNames = { "Central", "Squad", "Transfers", "Office", "Customise" },
    swipeDistance = 380, -- Pixel distance per swipe
    maxDescLength = 36, -- Max line length for descriptions
    maxTabs = tabsData.MAX_TABS or 7 -- Fallback to tabsData.MAX_TABS
}

-- Binding definitions with defaults
local bndTable = {
    btnvisible = { count = 7, type = "bool", default = false },
    btnIcon = { count = 7, type = "string", default = "" },
    rectColor = { count = 1, type = "stringColor", default = "0x120019" },
    btnDesc = { count = 7, type = "string", default = "" },
    btnSubName = { count = 7, type = "string", default = "" },
    btnName = { count = 7, type = "string", default = "" },
    teampoint = { count = 4, type = "string", default = "" },
    teamcrest = { count = 4, type = "object", default = {} },
    teamname = { count = 4, type = "string", default = "" },
    statsVisible = { count = 1, type = "bool", default = false },
    isTab1 = { count = 1, type = "bool", default = true },
    isNotTab1 = { count = 1, type = "bool", default = false },
    selectedbtn = { count = 7, type = "bool", default = false },
    tabName = { count = 1, type = "string", default = UIConfig.tabNames[1] },
    tabNamePosX = { count = 1, type = "int", default = UIConfig.tabXConfig[1] },
    clickBtnPosX = { count = 1, type = "int", default = UIConfig.axisXConfigs[1] },
    btnEventName = { count = 1, type = "string", default = "" },
    tabsPosX = { count = 1, type = "int", default = 0 },
    btnX = { count = 7, type = "int", default = 3000 },
    btnheight = { count = 7, type = "int", default = 400 },
    highlightbtn = { count = 1, type = "int", default = -470 }    
}

-- Event handlers
local eventHandlers = {
    tabClick = function(self, data)
        local tabData = self.UIData[self.selectedTab]
        if data.data and tabData and tabData.name then
            self:publishIfChanged("clickBtnPosX", data.data)
            self:publishIfChanged("highlightbtn", data.data)
            self:publishIfChanged("btnEventName", "Enter " .. tabData.name)
            self:publishIfChanged("btnheight" .. self.previousSelectedTab, 400)
            self:publishIfChanged("btnheight" .. self.selectedTab, 410)            
        end
    end,
    swipeAction = function(self, data)
        if data.data then
            self:publishIfChanged("tabsPosX", data.data)
        end
    end
}

local UI = {}
UI.__index = UI

function UI:new(init)
    local o = init or {}
    setmetatable(o, self)
    o.im = init.im 
    publish = o.im.Publish
    subscribe= o.im.Subscribe
    o.nav = init.nav 
    o.currentTab = 1
    o.selectedTab = 1
    o.tabsNum = 0
    o.swipeTabs = init.swipeTabs
    o.animateTabButtons = init.animateTabButtons
    o.tabX = 0
    o.swipeIndex = 1
    o.previousSelectedTab = 0
    o.swipeX = 0
    o.UIData = {}
    o.lastPublished = {} -- Cache for change detection
    o.formattedDescs = {} -- Cache for formatted descriptions
    o:_validateConfig()
    return o
end

function UI:_validateConfig()
    -- Validate tabsData and UIConfig
    if not tabsData.data then
        return
    end
    for i = 2, #UIConfig.tabNames do
        if not tabsData.data["Tab" .. i] then
            return
        end
    end
    if #UIConfig.axisXConfigs < UIConfig.maxTabs then
        return
    end
end

function UI:publishIfChanged(bnd, value)
    local key = "bnd_" .. bnd
    if self.lastPublished[key] == nil or self.lastPublished[key] ~= value then
        publish(key, value)
        self.lastPublished[key] = value
    end
end

function UI:setupBnds()
    for name, bnd in pairs(bndTable) do
        for idx = 1, bnd.count do
            local bndName = "bnd_" .. name .. (bnd.count > 1 and idx or "")
            subscribe(bndName, function()
                self:publishDisplay(name, idx, bnd.type, bnd.default)
            end)
        end
    end
end

function UI:setupActions()
    for i = 1, #UIConfig.tabNames do
        self.im.RegisterAction("act_toTab" .. i, function()
            self:handleNav(i)
        end)
    end
    self.im.RegisterAction("act_btnEvent", function()
        self:tabClickHandler()
    end)
    self.im.RegisterAction("act_swipeLeft", function()
        self:swipeActionHandler(-1)
    end)
    self.im.RegisterAction("act_swipeRight", function()
        self:swipeActionHandler(1)
    end)
    self.im.RegisterDataAction("bnd_swipe", "act_swipetest", function(bindingName, actionName, panEvent)
    local panX = panEvent.panX * -1
    local X = panX > 0 and 30 or -30
    self.swipeX = panX + self.swipeX + X    
    self:swipeAction(self.swipeX)    
  end)
    for i = 1, UIConfig.maxTabs do
        self.im.RegisterAction("act_btn" .. i, function()
            self:btnClickAction(i)
        end)
    end
end

function UI:getMaxSwipe()
  local maxSwipe = (self.tabsNum - 3) * 380
  return maxSwipe
end

function UI:swipeAction(X)
local swipeX = X
if self.tabsNum < 4 then
  return
end
local maxSwipe = self:getMaxSwipe()
local minSwipe = 0.0
  if swipeX > maxSwipe then
    self:publishIfChanged("tabsPosX", maxSwipe * -1)
    self.swipeX = maxSwipe
  elseif swipeX < minSwipe then
    self:publishIfChanged("tabsPosX", minSwipe)
    self.swipeX = minSwipe
  else
    self:publishIfChanged("tabsPosX", swipeX * -1)
  end
end

function UI:swipeActionHandler(direction)
    local maxSwipeIdx = math.max(1, self.tabsNum - 2)
    local newSwipeIndex = self.swipeIndex + direction
    if newSwipeIndex >= 1 and newSwipeIndex <= maxSwipeIdx then
        self.swipeIndex = newSwipeIndex
        local startX = self.tabX
        local targetX = -UIConfig.swipeDistance * (self.swipeIndex - 1)
        self.tabX = targetX -- Update tabX for consistency
        print("UI:swipeActionHandler: Calling swipeTabs with startX=" .. startX .. ", targetX=" .. targetX)
        if self.swipeTabs then
            self.swipeTabs(startX, targetX, function()
                print("UI: Swipe animation completed, ensuring tabsPosX=" .. targetX)
                self:publishIfChanged("tabsPosX", targetX)
            end)
        else
            print("UI: Warning: swipeTabs function not provided, using instant swipe")
            self:publishIfChanged("tabsPosX", targetX)
        end
    else
        print("UI: Swipe ignored, newSwipeIndex=" .. newSwipeIndex .. " out of bounds [1, " .. maxSwipeIdx .. "]")
    end
end

function UI:formatString(sentence)
    if not sentence or sentence == "" then return "" end
    if self.formattedDescs[sentence] then
        return self.formattedDescs[sentence]
    end
    local words = {}
    local lineLength = 0
    for word in sentence:gmatch("%S+") do
        if lineLength == 0 then
            table.insert(words, word)
            lineLength = #word
        elseif lineLength + 1 + #word <= UIConfig.maxDescLength then
            table.insert(words, " ")
            table.insert(words, word)
            lineLength = lineLength + 1 + #word
        else
            table.insert(words, "\n")
            table.insert(words, word)
            lineLength = #word
        end
    end
    local result = table.concat(words)
    self.formattedDescs[sentence] = result
    return result
end

function UI:btnClickAction(btnIdx)
    if btnIdx < 1 or btnIdx > UIConfig.maxTabs then return end
    self.previousSelectedTab = self.selectedTab or 0
    self.selectedTab = btnIdx
    self:handleTabUI({ type = "tabClick", data = UIConfig.axisXConfigs[btnIdx] })
end

function UI:_displayTabElements()
    self:publishIfChanged("isTab1", self.currentTab == 1)
    self:publishIfChanged("isNotTab1", self.currentTab ~= 1)
    self:publishIfChanged("tabName", UIConfig.tabNames[self.currentTab] or "Unknown")
    self:publishIfChanged("tabNamePosX", UIConfig.tabXConfig[self.currentTab] or 0)
    self:handleTabUI()
end

function UI:tabClickHandler()
    local tabData = self.UIData[self.selectedTab]
    if tabData and tabData.event and tabData.event ~= "" then
        self.nav.Event(nil, tabData.event)
    end
end

function UI:handleNav(tab)
    if tab < 1 or tab > #UIConfig.tabNames then        
        return
    end
    if tab == self.currentTab then return end
    
    local direction = tab > self.currentTab and 1 or -1
    local oldTabsNum = self.tabsNum
    local oldUIData = self.UIData
    print("UI:handleNav: Switching to tab " .. tab .. ", direction=" .. (direction == 1 and "left-to-right" or "right-to-left") .. ", oldTabsNum=" .. oldTabsNum)
    
    self.currentTab = tab
    self.tabX = 0
    self.previousSelectedTab = 0
    self:_displayTabElements()
    self:handleTabUI({ type = "tabSwitch", direction = direction, oldTabsNum = oldTabsNum, oldUIData = oldUIData })
end

function UI:handleTabUI(data)
    if self.currentTab == 1 then        
        return
    end

    if data and eventHandlers[data.type] then
        eventHandlers[data.type](self, data)
        return
    end

    self.UIData = tabsData.data["Tab" .. self.currentTab] or {}
    self.tabsNum = math.min(#self.UIData, UIConfig.maxTabs)
    
    local direction = data and data.direction or 1
    local fadeInStartX = direction == 1 and 3000 or -3000
    local fadeOutX = direction == 1 and -3000 or 3000
    local oldTabsNum = data and data.oldTabsNum or self.tabsNum
    local oldUIData = data and data.oldUIData or self.UIData
    self.selectedTab = direction == 1 and 1 or self.tabsNum
    
    -- Set tabsPosX for new tab
    self.swipeIndex = 1
    local tabsPosX = self.tabsNum == 3 and 300 or self.tabsNum == 2 and 420 or self.tabsNum == 1 and 500 or 0
    if direction == -1 then
        local maxSwipeIdx = math.max(1, self.tabsNum - 2)
        tabsPosX = -UIConfig.swipeDistance * (maxSwipeIdx - 1)
        self.swipeIndex = self:getMaxSwipe()
        print("UI:handleTabUI: Setting tabsPosX to last swipe index position=" .. tabsPosX .. " for maxSwipeIdx=" .. maxSwipeIdx)
    else
        print("UI:handleTabUI: Setting tabsPosX to 0")
    end
    self:publishIfChanged("tabsPosX", self.tabsNum == 3 and 60 or self.tabsNum == 2 and 260 or self.tabsNum == 1 and 400 or tabsPosX)
    
    -- Set initial positions and properties for old tab buttons
    self:publishIfChanged("highlightbtn", 3000)
    for i = 1, oldTabsNum do
        local tabData = oldUIData[i] or {}
        local bndName = "btnX" .. i
        print("Setting initial bnd_" .. bndName .. " to " .. UIConfig.btnTabsXConfig[i])
        self.lastPublished["bnd_" .. bndName] = nil
        self.im.Publish("bnd_" .. bndName, UIConfig.btnTabsXConfig[i])
        self:publishIfChanged("btnvisible" .. i, true)
        self:publishIfChanged("btnName" .. i, tabData.name or "")
        self:publishIfChanged("btnSubName" .. i, tabData.subInfo or "")
        self:publishIfChanged("btnIcon" .. i, tabData.imgSrc or "")
        self:publishIfChanged("btnDesc" .. i, self:formatString(tabData.desc or ""))
        if i == 2 then
            self:publishIfChanged("statsVisible", tabData.displayStats or false)
        end
    end
    for i = oldTabsNum + 1, UIConfig.maxTabs do
        self:publishIfChanged("btnvisible" .. i, false)
    end

    -- Animate buttons: fade out old tab, then fade in new tab
    if self.animateTabButtons then
        print("UI:handleTabUI: Starting fade-out animation with oldTabsNum=" .. oldTabsNum .. ", fadeOutX=" .. fadeOutX)
        self.animateTabButtons(oldTabsNum, UIConfig.btnTabsXConfig, direction, "fadeOut", fadeOutX, function()
            print("UI:handleTabUI: Fade-out completed, updating new tab properties and starting fade-in")
            -- Publish new tab button properties
            for i = 1, self.tabsNum do
                local tabData = self.UIData[i] or {}
                local bndName = "btnX" .. i
                print("Resetting bnd_" .. bndName .. " to " .. fadeInStartX .. " for fade-in")
                self.lastPublished["bnd_" .. bndName] = nil
                self.im.Publish("bnd_" .. bndName, fadeInStartX)                
                self:publishIfChanged("btnvisible" .. i, true)
                self:publishIfChanged("btnheight" .. i, i == self.selectedTab and 410 or 400)
                self:publishIfChanged("btnName" .. i, tabData.name or "")
                self:publishIfChanged("btnSubName" .. i, tabData.subInfo or "")
                self:publishIfChanged("btnIcon" .. i, tabData.imgSrc or "")
                self:publishIfChanged("btnDesc" .. i, self:formatString(tabData.desc or ""))
                if i == 2 then
                    self:publishIfChanged("statsVisible", tabData.displayStats or false)
                end
            end
            for i = self.tabsNum + 1, UIConfig.maxTabs do
                self:publishIfChanged("btnvisible" .. i, false)
            end
            self:publishIfChanged("clickBtnPosX", UIConfig.axisXConfigs[self.selectedTab] or UIConfig.axisXConfigs[1])          
            self:publishIfChanged("btnEventName", self.UIData[self.selectedTab] and "Enter " .. (self.UIData[self.selectedTab].name or "") or "")
            -- Start fade-in
            self.animateTabButtons(self.tabsNum, UIConfig.btnTabsXConfig, direction, "fadeIn", fadeInStartX, function()
                print("UI: Button animations completed")
                for i = 1, self.tabsNum do
                    self:publishIfChanged("btnX" .. i, UIConfig.btnTabsXConfig[i])
                end
                self:publishIfChanged("highlightbtn", UIConfig.axisXConfigs[self.selectedTab] or UIConfig.axisXConfigs[1])
            end)
        end)
    else
        print("UI: Warning: animateTabButtons not provided, setting btnX instantly")
        for i = 1, self.tabsNum do
            self:publishIfChanged("btnX" .. i, UIConfig.btnTabsXConfig[i])
            local tabData = self.UIData[i] or {}
            self:publishIfChanged("btnvisible" .. i, true)
            self:publishIfChanged("selectedbtn" .. i, i == self.selectedTab)
            self:publishIfChanged("btnName" .. i, tabData.name or "")
            self:publishIfChanged("btnSubName" .. i, tabData.subInfo or "")
            self:publishIfChanged("btnIcon" .. i, tabData.imgSrc or "")
            self:publishIfChanged("btnDesc" .. i, self:formatString(tabData.desc or ""))
            if i == 2 then
                self:publishIfChanged("statsVisible", tabData.displayStats or false)
            end
        end
        for i = self.tabsNum + 1, UIConfig.maxTabs do
            self:publishIfChanged("btnvisible" .. i, false)
        end
        self:publishIfChanged("clickBtnPosX", UIConfig.axisXConfigs[self.selectedTab] or UIConfig.axisXConfigs[1])
        self:publishIfChanged("btnEventName", self.UIData[self.selectedTab] and "Enter " .. (self.UIData[self.selectedTab].name or "") or "")
    end
end

function UI:publishDisplay(name, idx, bndType, default)
    local bndName = name .. (bndTable[name].count > 1 and idx or "")
    self:publishIfChanged(bndName, default)
end

function UI:reset()
    self.currentTab = 1
    self.selectedTab = 1
    self.tabX = 0
    self.swipeIndex = 1
    self.UIData = {}
    self.lastPublished = {}
    self.formattedDescs = {}
    self:_displayTabElements()
end

return UI
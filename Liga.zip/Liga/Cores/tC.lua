-- @anonu143@gmail, DavunPes(YT)
-- Transfer player core, for dealing with player swaps and player object transfer
-- ©DavunPes
local tC = {}

function tC:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.services = {SquadManagementService = o.api("SquadMgtService")}  
  return o
end

-- @! swaps player index in squad if in xi else skips the process
function swapPlayersInTeam(teamPlayers, cardIDToSwap)
    local playerToSwap, playerToSwapIndex, playerPositionToMatch = nil, nil, nil
    
    for index, player in ipairs(teamPlayers) do
        if player.CARD_ID == cardIDToSwap then
            playerToSwap, playerToSwapIndex, playerPositionToMatch = player, index, player.position
            break
        end
    end

    if not playerToSwap then
        print("[TeamManagementModel]: Player with CARD_ID " .. cardIDToSwap .. " not found in team")
        return false
    end

    if playerToSwapIndex > 11 then
        print("[TeamManagementModel]: Player " .. cardIDToSwap .. " is already a reserve, no swap needed")
        return true
    end

    for index = 12, #teamPlayers do
        local player = teamPlayers[index]
        if player.position == playerPositionToMatch then
            teamPlayers[playerToSwapIndex], teamPlayers[index] = teamPlayers[index], teamPlayers[playerToSwapIndex]
            print("[TeamManagementModel]: Swapped player " .. cardIDToSwap .. " with player " .. teamPlayers[playerToSwapIndex].CARD_ID .. " in teamID " .. teamID)
            return true
        end
    end

    print("[TeamManagementModel]: No reserve player found with position " .. playerPositionToMatch .. " to swap with CARD_ID " .. cardIDToSwap)
    return false
end

--@! Moves player object from sourceTeam to targetTeam
function transferPlayer(playerID, sourceTeamID, targetTeamID)
    if transferredPlayers[playerID] then
        print("[TeamManagementModel]: Player " .. playerID .. " has already been transferred.")
        return
    end

    local sourceTeamPlayers = self.services.SquadManagementService.GetCurrentPlayerLineup(0, sourceTeamID, 0)
    if not sourceTeamPlayers or #sourceTeamPlayers == 0 then
        error("[TeamManagementModel]: No players found for source teamID " .. sourceTeamID)
    end

    if sourceTeamID == currentSelectedTeamID then
        local swapSuccess = swapPlayersInTeam(sourceTeamPlayers, playerID)
        if not swapSuccess then
            print("[TeamManagementModel]: Could not swap player " .. playerID .. " to reserves, proceeding with direct removal")
        end
    end
    
    local playerToTransfer, playerIndex = nil, nil
    for index, player in ipairs(sourceTeamPlayers) do
        if player.CARD_ID == playerID then
            playerToTransfer = player
            playerIndex = index
            break
        end
    end
    if not playerToTransfer then
        print("[TeamManagementModel]: Player " .. playerID .. " not found in teamID " .. sourceTeamID)
        return
    end

    table.remove(sourceTeamPlayers, playerIndex)
    print("[TeamManagementModel]: Removed player " .. playerID .. " from index " .. playerIndex .. " in teamID " .. sourceTeamID)

    local updatedSourceTeamPlayerIDs = {}
    for _, player in ipairs(sourceTeamPlayers) do
        if player then
            table.insert(updatedSourceTeamPlayerIDs, player.CARD_ID)
        end
    end
    self.services.SquadManagementService.SetCurrentPlayerLineup(0, sourceTeamID, 0, 0, updatedSourceTeamPlayerIDs)

    local targetTeamPlayers = self.services.SquadManagementService.GetCurrentPlayerLineup(0, targetTeamID, 0)
    if not targetTeamPlayers or #targetTeamPlayers == 0 then
        targetTeamPlayers = {}
        print("[TeamManagementModel]: Target teamID " .. targetTeamID .. " has no players, initializing empty squad.")
    end

    playerToTransfer.teamID = targetTeamID
    table.insert(targetTeamPlayers, playerToTransfer)
    
    local updatedTargetTeamPlayerIDs = {}
    for _, player in ipairs(targetTeamPlayers) do
        table.insert(updatedTargetTeamPlayerIDs, player.CARD_ID)
    end
    self.services.SquadManagementService.SetCurrentPlayerLineup(0, targetTeamID, 0, 0, updatedTargetTeamPlayerIDs)

    if targetTeamID == teamID then
        players = targetTeamPlayers
    end
    if sourceTeamID == teamID then
        players = sourceTeamPlayers
    end

    transferredPlayers[playerID] = true
    print("[TeamManagementModel]: Player " .. playerID .. " successfully transferred from teamID " .. sourceTeamID .. " to teamID " .. targetTeamID)
end

return tC
local tabsData, UIManager, sessionVars = ...

local publish = nil
local subscribe = nil
local lastAccessedTab = nil
local lastSelectedTabButton = nil

local bndsToLoad = {
    ["btnX"] = true,
    ["btnvisible"] = true,
    ["btnName"] = true,
    ["btnSubName"] = true,
    ["btnIcon"] = true,
    ["btnDesc"] = true,
    ["statsVisible"] = true,
    ["budgetVisible"] = true,
    ["teamstatsVisible"] = true,
    ["playerstatsVisible"] = true,
    ["isTab1"] = true,
    ["isNotTab1"] = true,
    ["tabName"] = true,
    ["tabNamePosX"] = true,
    ["clickBtnPosX"] = true,
    ["btnEventName"] = true,
    ["tabsPosX"] = true,
    ["highlightbtn"] = true,
    ["btnheight"] = true
}

local baseUIConfig = {
    axisXConfigs     = {-470, -60, 350, 760, 1170, 1580, 1990},
    tabXConfig       = {255, 355, 445, 570, 660},
    btnTabsXConfig   = {-470, -60, 350, 760, 1170, 1580, 1990},
    swipeDistance    = 380,
    maxDescLength    = 36,
}

local baseBndTable = {
    btnvisible       = { count = 7, type = "bool",   default = false },
    btnIcon          = { count = 7, type = "string", default = "" },
    btnDesc          = { count = 7, type = "string", default = "" },
    btnSubName       = { count = 7, type = "string", default = "" },
    btnName          = { count = 7, type = "string", default = "" },
    objvalue         = { count = 4, type = "string", default = "" },
    objimg           = { count = 4, type = "object", default = {} },
    objname          = { count = 4, type = "string", default = "" },
    statsVisible     = { count = 1, type = "bool",   default = false },
    budgetVisible    = { count = 1, type = "bool",   default = false },
    budgetshade      = { count = 1, type = "string", default = "" },
    budgetvalue      = { count = 1, type = "string", default = "" },
    teamstatsVisible = { count = 1, type = "bool",   default = false },
    playerstatsVisible = { count = 1, type = "bool", default = false },
    isTab1           = { count = 1, type = "bool",   default = true  },
    isNotTab1        = { count = 1, type = "bool",   default = false },
    tabName          = { count = 1, type = "string", default = "Central" },
    tabNames         = { count = 5, type = "array",  default = { "Central", "Squad", "Transfers", "Office", "Customise" } },
    tabNamesStr         = { count = 5, type = "string",  default = { "Central", "Squad", "Transfers", "Office", "Customise" } },
    tabNamePosX      = { count = 1, type = "int",    default = baseUIConfig.tabXConfig[1] },
    clickBtnPosX     = { count = 1, type = "int",    default = baseUIConfig.axisXConfigs[1] },
    btnEventName     = { count = 1, type = "string", default = "" },
    tabsPosX         = { count = 1, type = "int",    default = 0 },
    btnX             = { count = 7, type = "int",    default = 3000 },
    btnheight        = { count = 7, type = "int",    default = 400 },
    highlightbtn     = { count = 1, type = "int",    default = -470 },
    displayScreen    = { count = 1, type = "bool",   default = true }
}

local eventHandlers = {
    tabClick = function(self, data)
        local tabData = self.UIData[self.selectedTab]
        if data.data and tabData and tabData.name then
            self:publishIfChanged("clickBtnPosX", data.data)
            self:publishIfChanged("highlightbtn", data.data)
            self:publishIfChanged("btnEventName", "Enter " .. tabData.name)
            self:publishIfChanged("btnheight" .. self.previousSelectedTab, 400)
            self:publishIfChanged("btnheight" .. self.selectedTab, 410)
        end
    end,
    swipeAction = function(self, data)
        if data.data then
            self:publishIfChanged("tabsPosX", data.data)
        end
    end
}

local UI = {}
UI.__index = UI

function UI:new(init)
    local o = init or {}
    setmetatable(o, self)

    o.im = init.im
    publish = o.im.Publish
    subscribe = o.im.Subscribe
    o.nav = init.nav
    o.screenflow = init.screenflow
    o.currentTab = 1
    o.selectedTab = 1
    o.tabsNum = 0
    o.swipeTabs = init.swipeTabs
    o.animateTabButtons = init.animateTabButtons
    o.TeamStats = init.TeamStats
    o.playerStats = init.playerData
    o.serializer = init.serializer
    o.tabX = 0
    o.swipeIndex = 1
    o.previousSelectedTab = 0
    o.swipeX = 0
    o.UIData = {}
    o.lastPublished = {}
    o.formattedDescs = {}

    local mode = "default"
    if sessionVars.get("InCareerMode") then mode = "career" end
    if sessionVars.get("InTourneyMode") then mode = "tournament" end

    o.activeData = (tabsData.data and tabsData.data[mode]) or {}
    o.activeTabs = (tabsData.tabs and tabsData.tabs[mode]) or (tabsData.tabs or {"Central", "Squad", "Transfers", "Office", "Customise"})

    o.UIConfig = {
        axisXConfigs   = baseUIConfig.axisXConfigs,
        tabXConfig     = baseUIConfig.tabXConfig,
        btnTabsXConfig = baseUIConfig.btnTabsXConfig,
        tabNames       = o.activeTabs,
        swipeDistance  = baseUIConfig.swipeDistance,
        maxDescLength  = baseUIConfig.maxDescLength,
        maxTabs        = tabsData.MAX_TABS or 7
    }

    o.bndTable = {}
    for k, v in pairs(baseBndTable) do
        o.bndTable[k] = {count = v.count, type = v.type, default = v.default}
    end

    o.bndTable.tabName.default     = o.UIConfig.tabNames[1] or "Central"
    o.bndTable.tabNames.default    = o.UIConfig.tabNames
    o.bndTable.tabNamesStr.default    = o.UIConfig.tabNames
    o.bndTable.tabNames.count      = #o.UIConfig.tabNames
    o.bndTable.tabNamesStr.count      = #o.UIConfig.tabNames
    o.bndTable.tabNamePosX.default = o.UIConfig.tabXConfig[1] or 255

    o:_validateConfig()
    o:setupBnds()
    o:setupActions()

    return o
end

function UI:_validateConfig()
    if not self.activeData then return end
    for i = 2, #self.UIConfig.tabNames do
        if not self.activeData["Tab" .. i] then return end
    end
    if #self.UIConfig.axisXConfigs < self.UIConfig.maxTabs then return end
end

function UI:publishIfChanged(bnd, value)
    local key = "bnd_" .. bnd
    if self.lastPublished[key] == nil or self.lastPublished[key] ~= value then
        publish(key, value)
        self.lastPublished[key] = value
    end
end

function UI:publishBudget(callback, name)
    local function formatFunds(funds)
        if funds >= 1e6 then
            local m = funds / 1e6
            return m < 10 and ("£%.2fM"):format(m) or ("£%.1fM"):format(m):gsub("%.0M", "M")
        elseif funds >= 1e3 then
            return ("£%dK"):format(funds / 1e3)
        else
            return "£" .. funds
        end
    end

    if name == "budgetshade" then
        local shade = GLOBAL_FUNDS[currentSelectedTeamID] < 50000000 and "0xFF0017" or "0x00E61C"
        callback(name, shade)
    elseif name == "budgetvalue" then
        local funds = GLOBAL_FUNDS[currentSelectedTeamID]
        callback(name, formatFunds(funds))
    end
end

function UI:publishTabSpecialContent()
    local MAX_STATS = 4
    local tabData = self.UIData or {}

    self:publishIfChanged("statsVisible",      false)
    self:publishIfChanged("playerstatsVisible", false)
    self:publishIfChanged("teamstatsVisible",   false)
    self:publishIfChanged("budgetVisible",      false)

    for _, btn in ipairs(tabData) do
        if btn.displayBudget then
            self:publishBudget(function(b, v) self:publishIfChanged(b, v) end, "budgetshade")
            self:publishBudget(function(b, v) self:publishIfChanged(b, v) end, "budgetvalue")
            self:publishIfChanged("budgetVisible", true)
        end

        if btn.displayStats then
            local publisher = (btn.statType == "Player") and self.playerStats or self.TeamStats

            publisher:publishStats(function(b, v) self:publishIfChanged(b, v) end, "objvalue", MAX_STATS)
            publisher:publishStats(function(b, v) self:publishIfChanged(b, v) end, "objimg",   MAX_STATS)
            publisher:publishStats(function(b, v) self:publishIfChanged(b, v) end, "objname",  MAX_STATS)

            if btn.statType == "Player" then
                self:publishIfChanged("playerstatsVisible", true)
                self:publishIfChanged("teamstatsVisible",   false)
            else
                self:publishIfChanged("teamstatsVisible",   true)
                self:publishIfChanged("playerstatsVisible", false)
            end

            self:publishIfChanged("statsVisible", true)
        end
    end
end

function UI:setupBnds()
    for name, bnd in pairs(self.bndTable) do
        if lastAccessedTab and lastAccessedTab ~= 1 and bndsToLoad[name] then
            self:loadBnd(name)
        elseif self.screenflow == "cmNew" then
            self:loadBnd(name)
        else
            for idx = 1, bnd.count do
                local bndName = "bnd_" .. name .. (bnd.count > 1 and idx or "")
                subscribe(bndName, function()
                    if name == "isTab1" then
                        self:publishIfChanged("isTab1", self.currentTab == 1 and self.screenflow ~= "cmNew")
                    elseif name == "isNotTab1" then
                        self:publishIfChanged("isNotTab1", self.currentTab ~= 1 or self.screenflow == "cmNew")
                    elseif name == "tabNames" and bnd.count > 1 then
                        self:publishDisplay(name, idx, bnd.type, bnd.default[idx] or "")
                    elseif name == "budgetshade" or name == "budgetvalue" then
                        self:publishBudget(function(b, v) self:publishIfChanged(b, v) end, name)
                    elseif name == "objname" or name == "objvalue" or name == "objimg" then
                        -- FIX: Safeguarded string concatenation if lastAccessedTab is nil
                        local td = self.activeData["Tab" .. tostring(lastAccessedTab or 1)]
                        local pub = (td and td[2] and td[2].statType == "Player") and self.playerStats or self.TeamStats
                        pub:publishStats(function(b, v) self:publishIfChanged(b, v) end, name, bnd.count)
                    else
                        if (bnd.count > 1) and (type(bnd.default) == "table") and (bnd.type == "string") then
                          self:publishDisplay(name, idx, bnd.type, bnd.default[idx] or "")
                        else
                          self:publishDisplay(name, idx, bnd.type, bnd.default)
                        end
                    end
                end)
            end
        end
    end
end

function UI:loadBnd(name)
    local bnd = self.bndTable[name]
    if not bnd then return end

    if self.screenflow == "cmNew" then
        self.currentTab = 2
        self.selectedTab = lastSelectedTabButton or 1
        self.UIData = self.activeData["cmNew"] or {}
        self.tabsNum = 2
        self.im.Subscribe("bnd_isNotDateSim", function()
            self:publishIfChanged("isNotDateSim", false)
        end)
    elseif lastAccessedTab and lastAccessedTab ~= 1 then
        self.currentTab = lastAccessedTab
        self.selectedTab = lastSelectedTabButton or 1
        self.UIData = self.activeData["Tab" .. self.currentTab] or {}
        self.tabsNum = math.min(#self.UIData, self.UIConfig.maxTabs)
    end

    for idx = 1, bnd.count do
        local bndName = "bnd_" .. name .. (bnd.count > 1 and idx or "")
        subscribe(bndName, function()
            if name == "btnX" then
                for i = 1, self.tabsNum do
                    local td = self.UIData[i] or {}
                    self.lastPublished["bnd_btnX" .. i] = nil
                    self.im.Publish("bnd_btnX" .. i, self.UIConfig.btnTabsXConfig[i])
                    self:publishIfChanged("btnvisible" .. i, true)
                    self:publishIfChanged("btnName" .. i, td.name or "")
                    self:publishIfChanged("btnSubName" .. i, td.subInfo or "")
                    self:publishIfChanged("btnIcon" .. i, td.imgSrc or "")
                    self:publishIfChanged("btnDesc" .. i, self:formatString(td.desc or ""))
                    self:publishIfChanged("btnheight" .. i, i == self.selectedTab and 410 or 400)
                end
                for i = self.tabsNum + 1, self.UIConfig.maxTabs do
                    self:publishIfChanged("btnvisible" .. i, false)
                end
            elseif name == "isTab1" then
                self:publishIfChanged("isTab1", self.currentTab == 1 and self.screenflow ~= "cmNew")
            elseif name == "isNotTab1" then
                self:publishIfChanged("isNotTab1", self.currentTab ~= 1 or self.screenflow == "cmNew")
            elseif name == "tabName" then
                self:publishIfChanged("tabName", self.screenflow == "cmNew" and "cmNew" or (self.UIConfig.tabNames[self.currentTab] or "Unknown"))
            elseif name == "tabNamePosX" then
                self:publishIfChanged("tabNamePosX", self.UIConfig.tabXConfig[self.currentTab] or 0)
            elseif name == "clickBtnPosX" then
                self:publishIfChanged("clickBtnPosX", self.UIConfig.axisXConfigs[self.selectedTab] or self.UIConfig.axisXConfigs[1])
            elseif name == "btnEventName" then
                self:publishIfChanged("btnEventName", self.UIData[self.selectedTab] and "Enter " .. (self.UIData[self.selectedTab].name or "") or "")
            elseif name == "tabsPosX" then
                local visibleCount = math.min(self.tabsNum, 3)
                local targetIndex = self.selectedTab
                local half = math.floor(visibleCount / 2)
                local swipeIndex = math.max(1, targetIndex - half)
                swipeIndex = math.min(swipeIndex, self.tabsNum - visibleCount + 1)

                local tabsPosX = (visibleCount == 1 and 400) or (visibleCount == 2 and 260) or (visibleCount == 3 and 60) or 0

                if swipeIndex > 1 then
                    tabsPosX = -self.UIConfig.swipeDistance * (swipeIndex - 1)
                end

                self.swipeIndex = swipeIndex
                self.swipeX = -tabsPosX
                self:publishIfChanged("tabsPosX", tabsPosX)
            elseif name == "highlightbtn" then
                self:publishIfChanged("highlightbtn", self.UIConfig.axisXConfigs[self.selectedTab] or self.UIConfig.axisXConfigs[1])
            elseif name == "btnheight" then
                for i = 1, self.tabsNum do
                    self:publishIfChanged("btnheight" .. i, i == self.selectedTab and 410 or 400)
                end
            elseif name == "statsVisible" or name == "budgetVisible" or name == "teamstatsVisible" or name == "playerstatsVisible" then
                -- FIX: Trigger content publication dynamically when resuming the script
                self:publishTabSpecialContent()
            else
                self:publishDisplay(name, idx, bnd.type, bnd.default)
            end
        end)
    end
end

function UI:setupActions()
    for i = 1, #self.UIConfig.tabNames do
        self.im.RegisterAction("act_toTab" .. i, function()
            self.backgroundProcessor:setAnimating(true, true)
            self:handleNav(i)
        end)
    end
    self.im.RegisterAction("act_btnEvent", function()
        self:tabClickHandler()
    end)
    self.im.RegisterAction("act_swipeLeft", function()
        self:swipeActionHandler(-1)
    end)
    self.im.RegisterAction("act_swipeRight", function()
        self:swipeActionHandler(1)
    end)
    self.im.RegisterDataAction("bnd_swipe", "act_swipetest", function(bindingName, actionName, panEvent)
        local panX = panEvent.panX * -1
        local X = panX > 0 and 30 or -30
        self.swipeX = panX + self.swipeX + X
        self:swipeAction(self.swipeX)
    end)
    for i = 1, self.UIConfig.maxTabs do
        self.im.RegisterAction("act_btn" .. i, function()
            self:btnClickAction(i)
        end)
    end
end

function UI:getMaxSwipe()
    return (self.tabsNum - 3) * self.UIConfig.swipeDistance
end

function UI:swipeAction(X)
    local swipeX = X
    if self.tabsNum < 4 then return end

    local maxSwipe = self:getMaxSwipe()
    local minSwipe = 0

    if swipeX > maxSwipe then
        self:publishIfChanged("tabsPosX", maxSwipe * -1)
        self.swipeX = maxSwipe
    elseif swipeX < minSwipe then
        self:publishIfChanged("tabsPosX", minSwipe)
        self.swipeX = minSwipe
    else
        self:publishIfChanged("tabsPosX", swipeX * -1)
    end
end

function UI:swipeActionHandler(direction)
    local maxSwipeIdx = math.max(1, self.tabsNum - 2)
    local newSwipeIndex = self.swipeIndex + direction

    if newSwipeIndex >= 1 and newSwipeIndex <= maxSwipeIdx then
        self.swipeIndex = newSwipeIndex
        local startX = self.tabX
        local targetX = -self.UIConfig.swipeDistance * (self.swipeIndex - 1)
        self.tabX = targetX

        print("UI:swipeActionHandler: startX=" .. startX .. ", targetX=" .. targetX)

        if self.swipeTabs then
            self.swipeTabs(startX, targetX, function()
                print("UI: Swipe animation completed → tabsPosX=" .. targetX)
                self:publishIfChanged("tabsPosX", targetX)
            end)
        else
            print("UI: Warning: no swipeTabs → instant jump")
            self:publishIfChanged("tabsPosX", targetX)
        end
    else
        print("UI: Swipe ignored — new index " .. newSwipeIndex .. " out of [1.." .. maxSwipeIdx .. "]")
    end
end

function UI:formatString(sentence)
    if not sentence or sentence == "" then return "" end
    if self.formattedDescs[sentence] then return self.formattedDescs[sentence] end

    local words = {}
    local lineLength = 0
    for word in sentence:gmatch("%S+") do
        if lineLength == 0 then
            table.insert(words, word)
            lineLength = #word
        elseif lineLength + 1 + #word <= self.UIConfig.maxDescLength then
            table.insert(words, " " .. word)
            lineLength = lineLength + 1 + #word
        else
            table.insert(words, "\n" .. word)
            lineLength = #word
        end
    end
    local result = table.concat(words)
    self.formattedDescs[sentence] = result
    return result
end

function UI:btnClickAction(btnIdx)
    if btnIdx < 1 or btnIdx > self.UIConfig.maxTabs then return end
    self.previousSelectedTab = self.selectedTab or 0
    self.selectedTab = btnIdx
    self:handleTabUI({ type = "tabClick", data = self.UIConfig.axisXConfigs[btnIdx] })
end

function UI:_displayTabElements()
    self:publishIfChanged("isTab1", self.currentTab == 1)
    self:publishIfChanged("isNotTab1", self.currentTab ~= 1)
    self:publishIfChanged("tabName", self.UIConfig.tabNames[self.currentTab] or "Unknown")
    self:publishIfChanged("tabNamePosX", self.UIConfig.tabXConfig[self.currentTab] or 0)
    self:handleTabUI()
end

function UI:tabClickHandler()
    local tabData = self.UIData[self.selectedTab]
    lastSelectedTabButton = self.selectedTab
    if tabData and tabData.event and tabData.event ~= "" then
        if type(tabData.event) == "function" then
            tabData.event(self)
        elseif type(tabData.event) == "string" then
            self.nav.Event(nil, tabData.event)
        end
    end
end

function UI:handleNav(tab)
    if tab < 1 or tab > #self.UIConfig.tabNames then return end
    if tab == self.currentTab then return end

    local direction = tab > self.currentTab and 1 or -1
    local oldTabsNum = self.tabsNum
    local oldUIData = self.UIData

    print("UI:handleNav → tab " .. tab .. " (dir=" .. direction .. ", oldTabs=" .. oldTabsNum .. ")")

    self.currentTab = tab
    lastAccessedTab = tab
    self.tabX = 0
    self.previousSelectedTab = 0
    self.selectedTab = lastSelectedTabButton or 1
    lastSelectedTabButton = self.selectedTab

    self:_displayTabElements()

    self:handleTabUI({
        type = "tabSwitch",
        direction = direction,
        oldTabsNum = oldTabsNum,
        oldUIData = oldUIData
    })
end

function UI:handleTabUI(data)
    if self.currentTab == 1 then return end

    if data and eventHandlers[data.type] then
        eventHandlers[data.type](self, data)
        return
    end

    self.UIData = self.activeData["Tab" .. self.currentTab] or {}
    self.tabsNum = math.min(#self.UIData, self.UIConfig.maxTabs)

    local direction = data and data.direction or 1
    local fadeInStartX = direction == 1 and 3000 or -3000
    local fadeOutX     = direction == 1 and -3000 or 3000

    local oldTabsNum = data and data.oldTabsNum or self.tabsNum
    local oldUIData  = data and data.oldUIData  or self.UIData

    self.selectedTab = direction == 1 and 1 or self.tabsNum

    local visibleCount = math.min(self.tabsNum, 3)
    local tabsPosX = 0

    if visibleCount == 1 then
        tabsPosX = 400
    elseif visibleCount == 2 then
        tabsPosX = 260
    elseif visibleCount == 3 then
        tabsPosX = 60
    end

    if direction == -1 then
        local maxOffset = self:getMaxSwipe()
        if maxOffset > 0 then
            tabsPosX = -maxOffset
            if visibleCount >= 2 then
                tabsPosX = tabsPosX + 80
            end
        end
        self.swipeIndex = math.max(1, self.tabsNum - visibleCount + 1)
    else
        self.swipeIndex = 1
    end

    self:publishIfChanged("tabsPosX", tabsPosX)
    self.swipeX = -tabsPosX

    self:publishIfChanged("highlightbtn", 3000)

    for i = 1, oldTabsNum do
        local tabData = oldUIData[i] or {}
        local bndName = "btnX" .. i
        self.lastPublished["bnd_" .. bndName] = nil
        self.im.Publish("bnd_" .. bndName, self.UIConfig.btnTabsXConfig[i])
        self:publishIfChanged("btnvisible" .. i, true)
        self:publishIfChanged("btnName" .. i, tabData.name or "")
        self:publishIfChanged("btnSubName" .. i, tabData.subInfo or "")
        self:publishIfChanged("btnIcon" .. i, tabData.imgSrc or "")
        self:publishIfChanged("btnDesc" .. i, self:formatString(tabData.desc or ""))
    end

    for i = oldTabsNum + 1, self.UIConfig.maxTabs do
        self:publishIfChanged("btnvisible" .. i, false)
    end

    if self.animateTabButtons then
        print("Starting fade-out: oldTabsNum=" .. oldTabsNum .. ", fadeOutX=" .. fadeOutX)
        self.animateTabButtons(oldTabsNum, self.UIConfig.btnTabsXConfig, direction, "fadeOut", fadeOutX, function()
            print("Fade-out done → updating new tab properties and starting fade-in")

            for i = 1, self.tabsNum do
                local tabData = self.UIData[i] or {}
                local bndName = "btnX" .. i
                self.lastPublished["bnd_" .. bndName] = nil
                self.im.Publish("bnd_" .. bndName, fadeInStartX)
                self:publishIfChanged("btnvisible" .. i, true)
                self:publishIfChanged("btnheight" .. i, i == self.selectedTab and 410 or 400)
                self:publishIfChanged("btnName" .. i, tabData.name or "")
                self:publishIfChanged("btnSubName" .. i, tabData.subInfo or "")
                self:publishIfChanged("btnIcon" .. i, tabData.imgSrc or "")
                self:publishIfChanged("btnDesc" .. i, self:formatString(tabData.desc or ""))
            end

            for i = self.tabsNum + 1, self.UIConfig.maxTabs do
                self:publishIfChanged("btnvisible" .. i, false)
            end

            self:publishIfChanged("clickBtnPosX", self.UIConfig.axisXConfigs[self.selectedTab] or self.UIConfig.axisXConfigs[1])
            self:publishIfChanged("btnEventName", self.UIData[self.selectedTab] and "Enter " .. (self.UIData[self.selectedTab].name or "") or "")

            self:publishTabSpecialContent()

            self.animateTabButtons(self.tabsNum, self.UIConfig.btnTabsXConfig, direction, "fadeIn", fadeInStartX, function()
                print("Fade-in completed")
                for i = 1, self.tabsNum do
                    self:publishIfChanged("btnX" .. i, self.UIConfig.btnTabsXConfig[i])
                end
                self:publishIfChanged("highlightbtn", self.UIConfig.axisXConfigs[self.selectedTab] or self.UIConfig.axisXConfigs[1])
            end)
        end)
    else
        print("No animateTabButtons → instant update")
        for i = 1, self.tabsNum do
            self:publishIfChanged("btnX" .. i, self.UIConfig.btnTabsXConfig[i])
            local td = self.UIData[i] or {}
            self:publishIfChanged("btnvisible" .. i, true)
            self:publishIfChanged("btnheight" .. i, i == self.selectedTab and 410 or 400)
            self:publishIfChanged("btnName" .. i, td.name or "")
            self:publishIfChanged("btnSubName" .. i, td.subInfo or "")
            self:publishIfChanged("btnIcon" .. i, td.imgSrc or "")
            self:publishIfChanged("btnDesc" .. i, self:formatString(td.desc or ""))
        end
        for i = self.tabsNum + 1, self.UIConfig.maxTabs do
            self:publishIfChanged("btnvisible" .. i, false)
        end

        self:publishIfChanged("clickBtnPosX", self.UIConfig.axisXConfigs[self.selectedTab] or self.UIConfig.axisXConfigs[1])
        self:publishIfChanged("btnEventName", self.UIData[self.selectedTab] and "Enter " .. (self.UIData[self.selectedTab].name or "") or "")

        self:publishTabSpecialContent()
    end
end

function UI:publishDisplay(name, idx, bndType, default)
    local bndName = name .. (self.bndTable[name].count > 1 and idx or "")
    self:publishIfChanged(bndName, default)
end

function UI:reset(fullReset)
    fullReset = true
    self.lastPublished = {}
    self.formattedDescs = {}

    if fullReset then
        self.UIData = {}
        self.tabsNum = 0
        self.currentTab = 1
        self.selectedTab = 1
        self.previousSelectedTab = 0
        self.swipeIndex = 1
        self.swipeX = 0
        self.tabX = 0

        lastAccessedTab = nil
        lastSelectedTabButton = nil

        self:publishIfChanged("isTab1", true)
        self:publishIfChanged("isNotTab1", false)
        self:publishIfChanged("tabName", self.UIConfig.tabNames[1] or "Central")
        self:publishIfChanged("tabNamePosX", self.UIConfig.tabXConfig[1] or 0)
        self:publishIfChanged("tabsPosX", 0)
        self:publishIfChanged("highlightbtn", 3000)
        self:publishIfChanged("clickBtnPosX", 3000)

        for i = 1, self.UIConfig.maxTabs do
            self:publishIfChanged("btnvisible" .. i, false)
            self:publishIfChanged("btnheight" .. i, 400)
        end

        self:publishIfChanged("statsVisible", false)
        self:publishIfChanged("playerstatsVisible", false)
        self:publishIfChanged("teamstatsVisible", false)
        self:publishIfChanged("budgetVisible", false)
    end

    if not fullReset then
        self:loadBnd("btnX")
    end

    print("UI reset complete" .. (fullReset and " (full)" or ""))
end

return UI
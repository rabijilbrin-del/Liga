local sessionVars, Timer, CareerModeLeagues, Brain, PlayerAge, playerData = ...
local TeamSelector = {}

-- Utility function to break a string into lines of max 20 characters
local function breakString(str)
  if not str or str == "" then return "-" end
  local maxLength = 20
  local lines = {}
  local currentLine = ""
  local words = {}
  
  -- Split string into words
  for word in str:gmatch("%S+") do
    table.insert(words, word)
  end
  
  for i, word in ipairs(words) do
    if #currentLine + #word + 1 <= maxLength then
      currentLine = currentLine == "" and word or currentLine .. " " .. word
    else
      if currentLine ~= "" then
        table.insert(lines, currentLine)
        currentLine = word
      else
        -- Handle long words by splitting at maxLength
        while #word > maxLength do
          table.insert(lines, word:sub(1, maxLength))
          word = word:sub(maxLength + 1)
        end
        currentLine = word
      end
    end
  end
  
  if currentLine ~= "" then
    table.insert(lines, currentLine)
  end
  
  return table.concat(lines, "\n")
end

local function formatFunds(funds)
    if funds >= 1e9 then
        local b = funds / 1e9
        return b < 10 and ("£%.2fB"):format(b) or ("£%.1fB"):format(b):gsub("%.0B", "B")
    elseif funds >= 1e6 then
        local m = funds / 1e6
        return m < 10 and ("£%.2fM"):format(m) or ("£%.1fM"):format(m):gsub("%.0M", "M")
    elseif funds >= 1e3 then
        return ("£%dK"):format(funds / 1e3)
    else
        return "£" .. funds
    end
end

local teamStadiums = {
-- Premier league --
    [1] = "Emirates Stadium",                 -- Arsenal
    [2] = "Villa Park",                       -- Aston Villa
    [3] = "Ewood Park",                       -- Blackburn Rovers
    [4] = "Reebok Stadium",                   -- Bolton Wanderers
    [5] = "Stamford Bridge",                  -- Chelsea
    [7] = "Goodison Park",                    -- Everton
    [9] = "Anfield",                          -- Liverpool
    [10] = "Etihad Stadium",                  -- Manchester City
    [11] = "Old Trafford",                    -- Manchester United
    [12] = "Riverside Stadium",              -- Middlesbrough
    [13] = "St. James' Park",                 -- Newcastle United
    [14] = "City Ground",                     -- Nottingham Forest
    [15] = "Loftus Road",                     -- Queens Park Rangers
    [17] = "St. Mary's Stadium",              -- Southampton
    [18] = "White Hart Lane",                 -- Tottenham Hotspur
    [19] = "Boleyn Ground (Upton Park)",      -- West Ham United
    [88] = "St. Andrew's",                    -- Birmingham City
    [94] = "Portman Road",                    -- Ipswich Town
    [95] = "King Power Stadium",              -- Leicester City
    [106] = "Stadium of Light",               -- Sunderland
    [109] = "The Hawthorns",                  -- West Bromwich Albion
    [110] = "Molineux Stadium",               -- Wolverhampton Wanderers
[5] = "Stamford Bridge",           -- Chelsea
[9] = "Anfield",                   -- Liverpool
[10] = "Etihad Stadium",           -- Manchester City
[11] = "Old Trafford",             -- Manchester United
[18] = "Tottenham Hotspur Stadium", -- Tottenham Hotspur
[19] = "London Stadium",           -- West Ham United
[95] = "King Power Stadium",       -- Leicester City
[110] = "Molineux Stadium",        -- Wolverhampton Wanderers
[1795] = "Vicarage Road",          -- Watford
[1796] = "Turf Moor",              -- Burnley
[1799] = "Selhurst Park",          -- Crystal Palace
[1808] = "American Express Stadium", -- Brighton & Hove Albion
[1943] = "Vitality Stadium",       -- AFC Bournemouth
[1960] = "Swansea.com Stadium",    -- Swansea City
[1961] = "Cardiff City Stadium",   -- Cardiff City
[335] = "King Power Stadium",      -- Leicester City (alternative ID)
[340] = "American Express Stadium",-- Brighton (alternative ID)
[355] = "London Stadium",          -- West Ham (alternative ID)
[409] = "Tottenham Hotspur Stadium",-- Spurs (alternative ID)
[432] = "Elland Road",             -- Leeds United
[433] = "Bramall Lane",            -- Sheffield United
[450] = "Gtech Community Stadium", -- Brentford
[460] = "Kenilworth Road",         -- Luton Town
[494] = "RAMS Park",               -- AFC Bournemouth (alternative)
[326] = "Stadium of Light",        -- Sunderland
[327] = "The Hawthorns",           -- West Bromwich Albion
[328] = "Craven Cottage",          -- Fulham
[329] = "Carrow Road",             -- Norwich City
[330] = "Selhurst Park",           -- Crystal Palace (alternative)
[336] = "Turf Moor",               -- Burnley (alternative)
[337] = "MATRADE Loftus Road",     -- QPR
[347] = "Vicarage Road",           -- Watford (alternative)
[348] = "Vitality Stadium",        -- Bournemouth (alternative)
[349] = "Riverside Stadium",       -- Middlesbrough
[350] = "Portman Road",            -- Ipswich Town
[364] = "Cívitas Metropolitano",   -- (Note: This is actually Atletico Madrid's stadium - likely incorrect mapping)
-- Premier League Teams (2023/24)
[13] = "St. James' Park",           -- Newcastle United
[14] = "The City Ground",           -- Nottingham Forest
[17] = "St. Mary's Stadium",        -- Southampton
[94] = "Portman Road",              -- Ipswich Town
[144] = "Craven Cottage",           -- Fulham
[7] = "Goodison Park",              -- Everton
-- La Liga 2023/24 Teams with Stadiums
[240] = "Cívitas Metropolitano",       -- Atlético de Madrid
[241] = "Spotify Camp Nou",            -- FC Barcelona
[243] = "Estadio Santiago Bernabéu",   -- Real Madrid
[448] = "San Mamés",                   -- Athletic Club
[449] = "Estadio Benito Villamarín",   -- Real Betis
[450] = "Abanca-Balaídos",             -- Celta Vigo
[452] = "RCDE Stadium",                -- Espanyol
[453] = "Visit Mallorca Estadi",       -- Mallorca
[456] = "El Molinón",                  -- Sporting Gijón (Segunda División)
[457] = "Reale Arena",                 -- Real Sociedad
[459] = "Estadio Municipal de Butarque", -- Leganés (Segunda)
[461] = "Estadio Mestalla",            -- Valencia CF
[462] = "Estadio José Zorrilla",       -- Real Valladolid (Segunda)
[463] = "Mendizorrotza",               -- Alavés
[467] = "Ipurua",                      -- Eibar (Segunda)
[468] = "Martínez Valero",             -- Elche (Segunda)
[472] = "Estadio Gran Canaria",        -- Las Palmas
[479] = "El Sadar",                    -- Osasuna
[480] = "Estadio de Vallecas",         -- Rayo Vallecano
[481] = "Ramón Sánchez-Pizjuán",       -- Sevilla FC
[483] = "Estadio de la Cerámica",      -- Villarreal CF
[1853] = "Estadio Ciudad de Valencia", -- Levante (Segunda)
[1860] = "Coliseum Alfonso Pérez",     -- Getafe
[1861] = "Power Horse Stadium",        -- Almería
[386] = "Estadio de la Cerámica",      -- Villarreal (alternative ID)
[388] = "San Mamés",                   -- Athletic Bilbao (alternative ID)
[389] = "Ramón Sánchez-Pizjuán",       -- Sevilla (alternative ID)
[390] = "Coliseum Alfonso Pérez",      -- Getafe (alternative ID)
[392] = "Estadio Benito Villamarín",   -- Betis (alternative ID)
[394] = "Abanca-Balaídos",             -- Celta Vigo (alternative ID)
[396] = "Estadio Ciutat de València",  -- Levante (alternative)
[397] = "Reale Arena",                 -- Real Sociedad (alternative)
[400] = "Estadio Montilivi",           -- Girona
[427] = "Estadio José Zorrilla",       -- Valladolid (alternative)
[428] = "Estadio El Alcoraz",          -- Huesca (Segunda)
[429] = "Estadio de Vallecas",         -- Rayo Vallecano (alternative)
[437] = "El Sadar",                    -- Osasuna (alternative)
[440] = "Visit Mallorca Estadi",       -- Mallorca (alternative)
[455] = "Nuevo Mirandilla",            -- Cádiz CF
[110062] = "Estadio Montilivi",        -- Girona (alternative ID)
[110832] = "Nuevo Los Cármenes",       -- Granada CF
[110839] = "El Alcoraz",               -- SD Huesca (Segunda)
[1968] = "Nuevo Mirandilla",           -- Cádiz (alternative ID)
-- Bundesliga 2023/24 Teams with Stadiums
[21] = "Allianz Arena",               -- FC Bayern München
[22] = "Signal Iduna Park",           -- Borussia Dortmund
[23] = "Borussia-Park",               -- Borussia Mönchengladbach
[25] = "Europa-Park Stadion",         -- SC Freiburg
[32] = "BayArena",                    -- Bayer 04 Leverkusen
[34] = "VELTINS-Arena",               -- FC Schalke 04 (currently in 2. Bundesliga)
[36] = "MHPArena",                    -- VfB Stuttgart
[38] = "Weserstadion",                -- SV Werder Bremen
[160] = "Vonovia Ruhrstadion",        -- VfL Bochum
[165] = "Sportpark Ronhof",           -- Greuther Fürth (2. Bundesliga)
[166] = "Olympiastadion Berlin",      -- Hertha BSC (2. Bundesliga)
[169] = "MEWA Arena",                 -- 1. FSV Mainz 05
[171] = "Max-Morlock-Stadion",        -- 1. FC Nürnberg (2. Bundesliga)
[175] = "Volkswagen Arena",           -- VfL Wolfsburg
[10029] = "PreZero Arena",            -- TSG Hoffenheim
[10030] = "Home Deluxe Arena",        -- SC Paderborn 07 (2. Bundesliga)
[110500] = "Eintracht-Stadion",       -- Eintracht Braunschweig (2. Bundesliga)
[110502] = "Merck-Stadion am Böllenfalltor", -- SV Darmstadt 98
[110588] = "MDCC-Arena",              -- 1. FC Magdeburg (2. Bundesliga)
[110636] = "Merkur Spiel-Arena",      -- Fortuna Düsseldorf (2. Bundesliga)
[110645] = "Sportpark Höhenberg",     -- Viktoria Köln (3. Liga)
[110676] = "Stadion Rote Erde",       -- Borussia Dortmund II (3. Liga)
[111235] = "Voith-Arena",             -- 1. FC Heidenheim
[112172] = "Red Bull Arena",          -- RB Leipzig
[343] = "Borussia-Park",              -- Borussia M'gladbach (alternative ID)
[406] = "Volkswagen Arena",           -- Wolfsburg (alternative ID)
[407] = "PreZero Arena",              -- Hoffenheim (alternative ID)
[412] = "WWK Arena",                  -- FC Augsburg
[413] = "Weserstadion",               -- Werder Bremen (alternative ID)
[414] = "MEWA Arena",                 -- Mainz 05 (alternative ID)
[416] = "Deutsche Bank Park",         -- Eintracht Frankfurt
[417] = "Heinz von Heiden-Arena",     -- Hannover 96 (2. Bundesliga)
[418] = "MHPArena",                   -- Stuttgart (alternative ID)
[420] = "Red Bull Arena",             -- RB Leipzig (alternative ID)
[422] = "Max-Morlock-Stadion",        -- Nürnberg (alternative ID)
[423] = "RheinEnergieStadion",        -- 1. FC Köln
[454] = "SchücoArena",                -- Arminia Bielefeld (2. Bundesliga)
[473] = "Vonovia Ruhrstadion",        -- Bochum (alternative ID)
[474] = "Sportpark Ronhof",           -- Fürth (alternative ID)
[485] = "HDI-Arena",                  -- Hannover 96
[100409] = "WWK Arena",               -- Augsburg (alternative ID)
-- Serie A 2023/2024 Teams with Stadiums
[45] = "Allianz Stadium",            -- Juventus
[48] = "Diego Armando Maradona",     -- Napoli
[50] = "Stadio Ennio Tardini",       -- Parma (Serie B)
[52] = "Stadio Olimpico",            -- Roma
[54] = "Stadio Olimpico Grande Torino", -- Torino
[55] = "Dacia Arena",                -- Udinese
[1842] = "Unipol Domus",             -- Cagliari
[1843] = "Stadio Renzo Barbera",     -- Palermo (Serie B)
[1848] = "Stadio San Nicola",        -- Bari (Serie B)
[110373] = "Stadio Arechi",          -- Salernitana
[110374] = "Stadio Artemio Franchi", -- Fiorentina
[110556] = "Luigi Ferraris",         -- Genoa
[111657] = "Stadio Benito Stirpe",   -- Frosinone
[111811] = "U-Power Stadium",        -- Monza
[111974] = "Mapei Stadium",          -- Sassuolo
[113973] = "Stadio Mario Rigamonti", -- Brescia (Serie B)
[113974] = "Stadio Alberto Picco",   -- Spezia (Serie B)
[116280] = "Allianz Stadium",        -- Juventus (alternative ID)
[116282] = "Stadio Olimpico",        -- Roma (alternative ID)
[110738] = "Arena Garibaldi",        -- Pisa (Serie B)
[110740] = "Stadio Città del Tricolore", -- Reggiana (Serie B)
[131720] = "Stadio Via del Mare",    -- Lecce
[131724] = "Stade de la Meinau",     -- Strasbourg (Ligue 1, contoh cross-league)
[131733] = "Stadio Carlo Castellani", -- Empoli
[131447] = "Parc des Princes",       -- Paris SG (contoh cross-league)
[111434] = "Stadio Giovanni Zini",   -- Cremonese (Serie B)
[111993] = "Stadio Piercesare Tombolato", -- Cittadella (Serie B)
[112168] = "Stadio San Vito",        -- Cosenza (Serie B)
[112494] = "Stadio Druso",           -- Südtirol (Serie B)
[113616] = "Stadio Franz Fekete",    -- Grazer AK (Austria, contoh cross-league)
[190] = "San Siro (Giuseppe Meazza)",  -- Inter Milan
[194] = "San Siro (Giuseppe Meazza)",  -- AC Milan
-- Ligue 1 2023/24 Teams with Stadiums
[57] = "Stade de l'Abbé-Deschamps",       -- AJ Auxerre
[65] = "Decathlon Arena (Stade Pierre-Mauroy)",  -- LOSC Lille
[66] = "Groupama Stadium",                 -- Olympique Lyonnais
[69] = "Stade Louis II",                   -- AS Monaco
[70] = "Stade de la Mosson",               -- Montpellier HSC
[71] = "Stade de la Beaujoire",            -- FC Nantes
[72] = "Allianz Riviera",                  -- OGC Nice
[73] = "Parc des Princes",                 -- Paris Saint-Germain
[74] = "Roazhon Park",                     -- Stade Rennais
[76] = "Stade de la Meinau",               -- Strasbourg
[217] = "Stade du Moustoir",               -- FC Lorient
[219] = "Orange Vélodrome",                -- Olympique de Marseille
[294] = "Stade de l'Aube",                 -- ESTAC Troyes
[378] = "Stade Francis-Le Blé",            -- Stade Brestois
[379] = "Stade Auguste-Delaune",           -- Stade de Reims
[116034] = "Parc des Princes",             -- Paris SG (alternative ID)
[116035] = "Stade Charléty",               -- Paris FC (Ligue 2)
[116037] = "Stade de la Mosson",           -- Montpellier (alternative ID)
[116039] = "Stade Gaston-Gérard",          -- Dijon FCO (Ligue 2)
[116040] = "Stade Auguste-Delaune",        -- Reims (alternative ID)
[116044] = "Stade Geoffroy-Guichard",      -- AS Saint-Étienne (Ligue 2)
[1530] = "Stade Raymond-Kopa",             -- Angers SCO (Ligue 2)
[1738] = "Stade Océane",                   -- Le Havre AC
[1809] = "Stadium de Toulouse",            -- Toulouse FC
[1815] = "Stade Gabriel-Montpied",         -- Clermont Foot
[1816] = "Stade de la Licorne",            -- Amiens SC (Ligue 2)
[1819] = "Stade Geoffroy-Guichard",        -- AS Saint-Étienne
[111817] = "Stade Charléty",               -- Paris FC (alternative ID)
[111276] = "Stade Marcel-Tribut",          -- USL Dunkerque (Ligue 2)
[131447] = "Parc des Princes",             -- Paris SG (cross-reference)
-- Brasileirão Série A 2024 Teams with Stadiums
[383] = "Allianz Parque",                  -- Palmeiras
[517] = "Estádio Nilton Santos",           -- Botafogo
[567] = "Maracanã",                        -- Fluminense
[568] = "Mineirão",                        -- Cruzeiro
[598] = "Morumbi",                         -- São Paulo
[1013] = "Estádio Pedro Bidegain",         -- San Lorenzo (Argentina, but in your list)
[1035] = "Arena MRV",                      -- Atlético Mineiro
[1039] = "Arena da Baixada",               -- Athletico Paranaense
[1041] = "Neo Química Arena",              -- Corinthians
[1043] = "Maracanã",                       -- Flamengo
[1048] = "Beira-Rio",                      -- Internacional
[1629] = "Arena do Grêmio",                -- Grêmio
[112472] = "Estádio Nabi Abi Chedid",      -- RB Bragantino
[115530] = "Arena Pantanal",               -- Cuiabá
[111052] = "Castelão (CE)",                -- Fortaleza
[101100] = "Atanasio Girardot",            -- Atlético Nacional (Colombia, in your list)
[101101] = "Metropolitano Roberto Meléndez", -- Junior (Colombia, in your list)
[101105] = "El Campín",                    -- Millonarios (Colombia, in your list)
[110968] = "Estádio Hernando Siles",       -- Bolívar (Bolivia, in your list)
[110975] = "Estádio San Carlos de Apoquindo", -- Universidad Católica (Chile, in your list)
[110980] = "Estádio Monumental",           -- Colo-Colo (Chile, in your list)
[110986] = "Estádio Rodrigo Paz Delgado",  -- LDU Quito (Ecuador, in your list)
[112540] = "Estádio do Pacaembu",          -- (Note: Currently not used as main stadium)
[112996] = "Allianz Parque",               -- (Alternative for Palmeiras)
-- AFC Teams (Top Asian Leagues) with Stadiums
[605] = "King Fahd International Stadium",  -- Al Hilal (Saudi Arabia)
[607] = "King Abdullah Sports City",       -- Al Ittihad (Saudi Arabia)
[980] = "Daejeon World Cup Stadium",       -- Daejeon Hana Citizen (South Korea)
[982] = "Seoul World Cup Stadium",         -- FC Seoul (South Korea)
[111674] = "Prince Faisal bin Fahd Stadium", -- Al Shabab (Saudi Arabia)
[112139] = "Mrsool Park",                  -- Al Nassr (Saudi Arabia)
[112387] = "King Abdullah Sports City",    -- Al Ahli (Saudi Arabia)
[112390] = "Prince Abdul Aziz bin Musa'ed", -- Al Fateh (Saudi Arabia)
[112392] = "King Abdullah Sport City",     -- Al Raed (Saudi Arabia)
[112393] = "King Abdullah Sport City",     -- Al Taawoun (Saudi Arabia)
[112408] = "King Abdulaziz Stadium",       -- Al Wehda (Saudi Arabia)
[113037] = "Prince Turki bin Abdul Aziz",  -- Al Riyadh (Saudi Arabia)
[113217] = "Prince Sultan bin Abdul Aziz", -- Damac FC (Saudi Arabia)
[1473] = "Ulsan Munsu Football Stadium",   -- Ulsan Hyundai (South Korea)
[1474] = "Pohang Steel Yard",              -- Pohang Steelers (South Korea)
[1477] = "Jeonju World Cup Stadium",       -- Jeonbuk Hyundai (South Korea)
[1478] = "Jeju World Cup Stadium",         -- Jeju United (South Korea)
[2055] = "Gimcheon Stadium",               -- Gimcheon Sangmu (South Korea)
[2056] = "DGB Daegu Bank Park",            -- Daegu FC (South Korea)
[112258] = "Gwangju Football Stadium",     -- Gwangju FC (South Korea)
[112558] = "Suwon Sports Complex",         -- Suwon FC (South Korea)
[111701] = "Hazza bin Zayed Stadium",      -- Al Ain FC (UAE)
[111724] = "Jinan Olympic Stadium",        -- Shandong Taishan (China)
[111768] = "Workers' Stadium",             -- Beijing Guoan (China)
[111769] = "Changchun Stadium",            -- Changchun Yatai (China)
[111774] = "Tianjin Olympic Center",       -- Tianjin Jinmen Tiger (China)
[111779] = "Zhengzhou Hanghai Stadium",    -- Henan FC (China)
[112540] = "Shanghai Stadium",             -- Shanghai Port (China)
[112979] = "Rugao Olympic Sports Center",  -- Nantong Zhiyun (China)
[112985] = "Cangzhou Stadium",             -- Cangzhou Mighty Lions (China)
[113298] = "Fatorda Stadium",              -- FC Goa (India)
[113299] = "Jawaharlal Nehru Stadium",     -- Kerala Blasters (India)
[113300] = "Mumbai Football Arena",        -- Mumbai City FC (India)
[113301] = "GMC Balayogi Stadium",         -- Hyderabad FC (India)
[113302] = "Sree Kanteerava Stadium",      -- Bengaluru FC (India)
[113146] = "Salt Lake Stadium",            -- Mohun Bagan SG (India)
[115202] = "Tau Devi Lal Stadium",         -- Punjab FC (India)
[111629] = "Salt Lake Stadium",            -- East Bengal (India)
[111633] = "Salt Lake Stadium",            -- Mohammedan SC (India)
[918] = "Aspmyra Stadion",                 -- Bodø/Glimt (Norway, but in AFC CL)
[919] = "Brann Stadion",                   -- SK Brann (Norway, but in AFC CL)
[922] = "Marienlyst Stadion",              -- Strømsgodset (Norway, but in AFC CL)
-- Liga 1 Indonesia 2023/2024
[20001] = "Gelora Bung Karno",          -- Persija Jakarta
[155600] = "Gelora Bung Karno",                 -- Arema FC
[155602] = "Gelora Bandung Lautan Api",  -- Persib Bandung
[20004] = "Kapten I Wayan Dipta",       -- Bali United
[20005] = "Gelora Bung Tomo",           -- Persebaya Surabaya
[20006] = "Maguwoharjo",                -- PSS Sleman
[20007] = "Patriot Candrabhaga",        -- Borneo FC
[20008] = "Segiri",                     -- Persis Solo
[20009] = "Gelora Sriwijaya",           -- Sriwijaya FC
[20010] = "Batakan",                    -- Barito Putera
[20011] = "Gelora Delta",               -- Persikabo 1973
[20012] = "Wibawa Mukti",               -- Persik Kediri
[20013] = "Sultan Agung",               -- PSIS Semarang
[20014] = "Manahan",                    -- Persis Solo (alternate)
[20015] = "Pakansari",                  -- Persita Tangerang
[20016] = "Gelora Joko Samudro",        -- Gresik United
[20017] = "Si Jalak Harupat",           -- Persib (alternate)
[20018] = "Gelora Bumi Kartini",        -- Persijap Jepara
[20019] = "Aji Imbut",                  -- Persis Putra Samarinda
[20020] = "Gelora Supriyadi",           -- Persela Lamongan
[20021] = "Merdeka",                    -- PSMS Medan
[20022] = "Gelora 10 November",         -- Persela (alternate)
[20023] = "Gelora Bung Karno Madya",    -- Shared venue
[20024] = "Haji Agus Salim",            -- PSPS Pekanbaru
[20025] = "Gelora Bumi Kartini",        -- Multi-use

[245] = "Johan Cruijff ArenA",          -- Ajax
[246] = "De Kuip",                      -- Feyenoord
[247] = "Philips Stadion",              -- PSV Eindhoven
[1903] = "Stadion Galgenwaard",         -- FC Utrecht
[1904] = "Rat Verlegh Stadion",         -- NAC Breda
[1905] = "Mandemakers Stadion",         -- RKC Waalwijk
[1906] = "AFAS Stadion",                -- AZ Alkmaar
[1907] = "Koning Willem II Stadion",    -- Willem II
[1908] = "De Grolsch Veste",            -- FC Twente
[1910] = "Goffertstadion",              -- NEC Nijmegen
[1913] = "Abe Lenstra Stadion",         -- sc Heerenveen
[1914] = "MAC³PARK Stadion",            -- PEC Zwolle
[1915] = "Euroborg",                    -- FC Groningen
[100632] = "De Adelaarshorst",          -- Go Ahead Eagles
[100634] = "Erve Asito",                -- Heracles Almelo
[100646] = "Het Kasteel",               -- Sparta Rotterdam
[111380] = "Yanmar Stadion",            -- Almere City FC

[234] = "Estádio da Luz",               -- Benfica
[236] = "Estádio do Dragão",            -- FC Porto
[237] = "Estádio José Alvalade",        -- Sporting CP
[10020] = "Estádio António Coimbra da Mota", -- Estoril Praia
[1887] = "Estádio D. Afonso Henriques", -- Vitória SC
[1888] = "Estádio Cidade de Barcelos",  -- Gil Vicente
[1891] = "Estádio da Madeira",          -- Nacional
[1896] = "Estádio Municipal de Braga",  -- SC Braga
[1898] = "Estádio do Bessa",            -- Boavista
[1900] = "Parque de Jogos Comendador Joaquim de Almeida Freitas", -- Moreirense
[112513] = "Estádio Municipal de Arouca", -- Arouca
[114510] = "Estádio Pina Manique",      -- Casa Pia
[112809] = "Estádio Municipal 22 de Junho", -- Famalicão
[131358] = "Estádio da Luz",            -- Benfica (alternative ID)
[131463] = "Estádio do Vizela",        -- Vizela
        -- Belgian Pro League --
        [229] = "Constant Vanden Stock",       -- Anderlecht
        [230] = "Bosuilstadion",               -- Antwerp
        [231] = "Jan Breydel Stadion",         -- Club Brugge
        [232] = "Stade Maurice Dufrasne",      -- Standard Liège
        [100081] = "Guldensporenstadion",      -- Kortrijk
        [100087] = "King Power at Den Dreef",  -- OH Leuven
        [670] = "Stade du Pays de Charleroi",  -- Charleroi
        [673] = "Cegeka Arena",                -- Genk
        [674] = "Ghelamco Arena",              -- Gent
        [675] = "Olympisch Stadion",           -- Beerschot
        [680] = "Stayen",                      -- STVV
        [681] = "Het Kuipje",                  -- Westerlo
        [110724] = "AFAS Stadion",             -- Mechelen

        -- MLS (USA/Canada) --
        [687] = "Lower.com Field",             -- Columbus Crew
        [688] = "Audi Field",                  -- DC United
        [689] = "Red Bull Arena",              -- NY Red Bulls
        [691] = "Gillette Stadium",            -- New England Revolution
        [693] = "Soldier Field",               -- Chicago Fire
        [694] = "Dick's Sporting Goods Park",  -- Colorado Rapids
        [695] = "Toyota Stadium",              -- FC Dallas
        [696] = "Children's Mercy Park",       -- Sporting KC
        [697] = "Dignity Health Sports Park",  -- LA Galaxy
        [698] = "Shell Energy Stadium",        -- Houston Dynamo
        [111112] = "BC Place",                 -- Vancouver Whitecaps
        [111138] = "Allianz Field",            -- Minnesota United
        [111139] = "Saputo Stadium",           -- CF Montréal
        [111140] = "Providence Park",          -- Portland Timbers
        [111144] = "Lumen Field",              -- Seattle Sounders
        [111651] = "BMO Field",                -- Toronto FC
        [112828] = "Yankee Stadium",           -- NYCFC
        [112885] = "Mercedes-Benz Stadium",    -- Atlanta United
        [112893] = "DRV PNK Stadium",          -- Inter Miami
        [112996] = "Banc of California",       -- LAFC
        [113018] = "CityPark",                 -- St. Louis CITY
        [114161] = "Q2 Stadium",               -- Austin FC
        [114162] = "Geodis Park",              -- Nashville SC

        -- Turkish Süper Lig --
        [325] = "Nef Stadyumu",                -- Galatasaray
        [326] = "Ülker Stadyumu",              -- Fenerbahçe
        [327] = "Vodafone Park",               -- Beşiktaş
        [436] = "Medical Park Stadyumu",       -- Trabzonspor
        [741] = "Antalya Stadyumu",            -- Antalyaspor
        [748] = "19 Mayıs Stadyumu",           -- Samsunspor
        [495] = "Başakşehir Fatih Terim",     -- İstanbul Başakşehir
        [101014] = "Başakşehir Fatih Terim",  -- Başakşehir (alt)
        [101016] = "Yeni Adana Stadyumu",      -- Adana Demirspor
        [101020] = "Kadir Has Stadyumu",       -- Kayserispor
        [101028] = "Yeni Hatay Stadyumu",      -- Hatayspor
        [101033] = "Konya Büyükşehir",        -- Konyaspor
        [101041] = "Yeni 4 Eylül Stadyumu",    -- Sivasspor
        [111339] = "Recep Tayyip Erdoğan",    -- Kasımpaşa
        [131174] = "Eyüp Stadyumu",            -- Eyüpspor

        -- Liga MX (Mexico) --
        [1386] = "Estadio Azteca",             -- América
        [517] = "Estadio Olímpico Universitario", -- UNAM
        [101099] = "Estadio Azteca",           -- América (alt)
        [112908] = "Estadio Akron",            -- Guadalajara
        [113010] = "Estadio BBVA",             -- Monterrey
        [113029] = "Estadio Olímpico UCV",     -- UCV
        [1386] = "Estadio Jalisco",            -- Atlas
        [1386] = "Estadio Corona",             -- Santos Laguna
        [1386] = "Estadio Cuauhtémoc",         -- Puebla
        [1386] = "Estadio Victoria",           -- Necaxa
        [1386] = "Estadio Hidalgo",            -- Pachuca
        [1386] = "Estadio Caliente",           -- Tijuana
        [1386] = "Estadio Universitario",      -- Tigres
        [1386] = "Estadio Morelos",            -- Morelia
        [1386] = "Estadio León",               -- León
        [1386] = "Estadio Azul",             -- Cruz Azul

       ---Afc u23--
        [111510] = "Gelora Bung Karno"             -- Indonesia
    }
local CountryNamesByLeague = {
    [13] = "ENGLAND",
    [14] = "ENGLAND",
    [60] = "ENGLAND",    
    [16] = "FRANCE",
    [17] = "FRANCE",   
    [19] = "GERMANY",
    [20] = "GERMANY",    
    [31] = "ITALY",
    [32] = "ITALY",    
    [53] = "SPAIN",
    [54] = "SPAIN",    
    [10] = "NETHERLANDS",
    [308] = "PORTUGAL",
    [68] = "TURKEY",
    [4] = "BELGIUM",
    [39] = "USA",
    [2221] = "USA",
    [350] = "SAUDI ARABIA",
    [2235] = "INDONESIA",
    [2254] = "INDONESIA"
}
local CountryLeagueGroups = {}

for leagueID, countryName in pairs(CountryNamesByLeague) do
    CountryLeagueGroups[countryName] =
        CountryLeagueGroups[countryName] or {}

    table.insert(
        CountryLeagueGroups[countryName],
        leagueID
    )
end
for _, leagues in pairs(CountryLeagueGroups) do
    table.sort(leagues)
end
-- handle club worth
local function getTransferValue(selectedPlayer, squad)
    local pInfo = getPlayerInfo(selectedPlayer.CARD_ID, selectedPlayer.teamID, squad)
    local playerRating = pInfo and pInfo.rating or 50
    local playerPosition = pInfo and pInfo.position or "CM"
    local playerIndex = pInfo and pInfo.index or 0
    local repCount = playerReplacementCount(selectedPlayer.teamID, playerPosition, squad) or 0
    local days = 30

    local transferValue, minTValue = computeTransferValue(
        GetPlayerAge(selectedPlayer.CARD_ID) or 25,
        playerRating,
        playerPosition,
        playerIndex,
        repCount,
        days
    )

    return transferValue
end
function TeamSelector:updateLeagueBackground()
    if self.currentLeagueID then
        self.im.Publish(
            "bnd_backgroundcareer",
            {
                name = "$CareerTable",
                id = self.currentLeagueID
            }
        )
    end
end
local eligibleLeagues = {}
local funds = {}
local clubWorth = {}

function TeamSelector:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.dirs = {"left", "right"}
  o.keys = {"team", "country", "league"}
  o.nav = o.data.nav
  o.careerType = o.data.careertype
  o.currentFocus = "team"
  local CountryService = o.api("CountryService")
  local TeamService = o.api("TeamService")
  local MatchSetup = o.api("MatchSetupService")
  local gameStateService = o.api("GameStateService")
  local settingsService = o.api("SettingsService")
  local BrowserService = o.api("BrowserService")
  local MiscService = o.api("MiscService")
  local CardService = o.api("CardService")
  o.SquadManagementService = o.api("SquadMgtService")
  o.FUTUserInfoService = o.api("FUTUserInfoService")

  -- List of countries to search for
  local targetCountries = {}
  eligibleLeagues = {}
  for i = 1, #CareerModeLeagues do
    eligibleLeagues[CareerModeLeagues[i]] = true
  end

  -- Dynamically retrieve country IDs with valid leagues
  o.countries = {}
  o.countryNames = {}
  local countryData = CountryService.GetIDs()
  for _, v in pairs(countryData) do
    if type(v) == "table" and v.name then
      local upperName = string.upper(v.name)
      for _, targetName in ipairs(targetCountries) do
        if upperName == targetName then
          -- Only include countries with at least one league
          local leagues = CountryService.GetLeaguesIDsByCountry(v.id)
          if leagues and #leagues > 0 then
            table.insert(o.countries, v.id)
            o.countryNames[v.id] = upperName
          end
          break
        end
      end
    end
  end
  

  o.kitTypes = {
    {type = 0, name = "HOME KIT"},
    {type = 1, name = "AWAY KIT"},
    {type = 3, name = "THIRD KIT"}
  }
o.currentCountryIndex = 1
o.currentCountryID = o.countries[o.currentCountryIndex] or 14

o.leagues = {}
o.currentLeagueIndex = 1
o.currentLeagueID = nil

o.countryList = {}
o.currentCountryIndex = 1

for countryName, _ in pairs(CountryLeagueGroups) do
    table.insert(o.countryList, countryName)
end

table.sort(o.countryList)

o.teamsData = {}
o.currentTeamIndex = 1
o.currentKitIndex = 1

  o.im.RegisterAction("act_back", function()
    o.nav.Event(nil, "evt_hide_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/TeamSelector/TeamSelector.vvm"})
  end)

  for i = 1, 3 do
    o.im.RegisterAction("act_focus" .. o.keys[i], function()
      o:focus(o.keys[i])
    end)
  end

  for i = 1, 3 do
    local bnd = "bnd_on" .. o.keys[i]
    o.im.Subscribe(bnd, function()
      o.im.Publish(bnd, o.keys[i] == o.currentFocus)
    end)
  end

o.im.Subscribe("bnd_countryname", function()
    o.im.Publish(
        "bnd_countryname",
        CountryNamesByLeague[o.currentLeagueID] or "WORLD"
    )
end)

    o.im.Subscribe("bnd_leaguename", function()
    if o.currentLeagueID then
      o.im.Publish("bnd_leaguename", string.upper(o.loc.LocalizeString("LeagueName_Abbr15_" .. o.currentLeagueID)))
    else
      o.im.Publish("bnd_leaguename", "NO LEAGUE SELECTED")
    end
  end)

  for i = 1, 3 do
    o.im.Subscribe("bnd_csize" .. i, function()
      o.im.Publish("bnd_csize" .. i, i == o.currentKitIndex and 12 or 7)
    end)
    o.im.Subscribe("bnd_calpha" .. i, function()
      o.im.Publish("bnd_calpha" .. i, i == o.currentKitIndex and 1 or 0.5)
    end)
  end
    
  o.im.Subscribe("bnd_teamname", function()
    if o.teamsData[o.currentTeamIndex] then
      o.im.Publish("bnd_teamname", o.teamsData[o.currentTeamIndex].name)
    else
      o.im.Publish("bnd_teamname", "NO TEAM SELECTED")
    end
  end)

  o.im.Subscribe("bnd_stadiumname", function()
    if o.teamsData[o.currentTeamIndex] then
      local teamID = o.teamsData[o.currentTeamIndex].id
      local stadium = teamStadiums[teamID] or "-"
      o.im.Publish("bnd_stadiumname", breakString(stadium))
    else
      o.im.Publish("bnd_stadiumname", "-")
    end
  end)

  o.im.Subscribe("bnd_teamcrest", function()
    if o.teamsData[o.currentTeamIndex] then
      o.im.Publish("bnd_teamcrest", {name = "$Crest", id = o.teamsData[o.currentTeamIndex].id})
    else
      o.im.Publish("bnd_teamcrest", {})
    end
  end)
o.im.Subscribe("bnd_backgroundcareer", function()
    if o.currentLeagueID then
        o.im.Publish("bnd_backgroundcareer", {
            name = "$CareerTable",
            id = o.currentLeagueID
        })
    else
        o.im.Publish("bnd_leaguecrest", {})
    end
end)
  o.im.Subscribe("bnd_teamstar", function()
    if o.teamsData[o.currentTeamIndex] then
      o.im.Publish("bnd_teamstar", o.teamsData[o.currentTeamIndex].starRating)
    else
      o.im.Publish("bnd_teamstar", 0)
    end
  end)

  o.im.Subscribe("bnd_teamkit", function()
    if o.teamsData[o.currentTeamIndex] then
      local kitData = o.teamsData[o.currentTeamIndex].kits[o.currentKitIndex]
      local kitId = string.format("%s_%s_%s", kitData.KITTYPE, o.teamsData[o.currentTeamIndex].id, kitData.YEAR)
      o.im.Publish("bnd_teamkit", {name = "$Kits", id = kitId})
    else
      o.im.Publish("bnd_teamkit", {})
    end
  end)

  o.im.Subscribe("bnd_teamkitname", function()
    if o.teamsData[o.currentTeamIndex] then
      o.im.Publish("bnd_teamkitname", o.kitTypes[o.currentKitIndex].name)
    else
      o.im.Publish("bnd_teamkitname", "NO KIT SELECTED")
    end
  end)
  
  if o.teamsData[o.currentTeamIndex] and not funds[o.teamsData[o.currentTeamIndex].id] then
    local players = o.SquadManagementService.GetCurrentPlayerLineup(0, o.teamsData[o.currentTeamIndex].id, 0)
    local cw = 0
    for i = 1, #players do
      local cp = players[i]
      local playervalue = getTransferValue(cp, players)
      cw = cw + playervalue
    end
    clubWorth[o.teamsData[o.currentTeamIndex].id] = cw
    funds[o.teamsData[o.currentTeamIndex].id] = 1000
  end
  o.im.Subscribe("bnd_clubbudget", function()
    if o.teamsData[o.currentTeamIndex] then
      o.im.Publish("bnd_clubbudget", formatFunds(funds[o.teamsData[o.currentTeamIndex].id]))
    else
      o.im.Publish("bnd_clubbudget", "")
    end
  end)
  o.im.Subscribe("bnd_clubworth", function()
    if o.teamsData[o.currentTeamIndex] then
      o.im.Publish("bnd_clubworth", formatFunds(clubWorth[o.teamsData[o.currentTeamIndex].id]))
    else
      o.im.Publish("bnd_clubworth", "")
    end
  end)

  o.im.RegisterDataAction("bnd_swipeKit", "act_swipeKit", function(bindingName, actionName, panEvent)
    local panX = panEvent.panX * -1
    if panX > -40 then
      o:toggleKit(1)
    elseif panX < 40 then
      o:toggleKit(2)
    end
    return
  end)

  for i = 1, 2 do
    o.im.RegisterAction("act_toggleT" .. o.dirs[i], function()
      o:toggleTeam(i)
    end)
    o.im.RegisterAction("act_toggleC" .. o.dirs[i], function()
      o:toggleCountry(i)
    end)
    o.im.RegisterAction("act_toggleL" .. o.dirs[i], function()
      o:toggleLeague(i)
    end)
  end
  o.im.RegisterAction("act_advance", function()
    o:advance()
  end)

  o:loadLeagues()
  o:loadTeams()

  return o
end

function TeamSelector:advance()
  currentSelectedTeamID = self.teamsData[self.currentTeamIndex].id
  self.FUTUserInfoService.SetUserFavoriteTeam(currentSelectedTeamID)
  sessionVars.set("currentUserLeagueID", self.currentLeagueID)  
  self.nav.Event(nil, "evt_enter_cm")
  self.nav.Event(nil, "evt_hide_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/TeamSelector/TeamSelector.vvm"})
end

function TeamSelector:focus(k)
  self.currentFocus = k or self.currentFocus
  for i = 1, 3 do
    local bnd = "bnd_on" .. self.keys[i]
    self.im.Publish(bnd, self.keys[i] == self.currentFocus)
  end
end

function TeamSelector:toggleCountry(dir)

    if #self.countryList == 0 then
        return
    end

    if dir == 1 then
        self.currentCountryIndex = self.currentCountryIndex - 1
        if self.currentCountryIndex < 1 then
            self.currentCountryIndex = #self.countryList
        end
    else
        self.currentCountryIndex = self.currentCountryIndex + 1
        if self.currentCountryIndex > #self.countryList then
            self.currentCountryIndex = 1
        end
    end

    local countryName =
        self.countryList[self.currentCountryIndex]

    self.leagues =
        CountryLeagueGroups[countryName] or {}

    self.currentLeagueIndex = 1
    self.currentLeagueID = self.leagues[1]

    self:updateLeagueBackground()

    self.im.Publish(
        "bnd_countryname",
        countryName
    )

    self.im.Publish(
        "bnd_leaguename",
        self.currentLeagueID and
        string.upper(
            self.loc.LocalizeString(
                "LeagueName_Abbr15_" ..
                self.currentLeagueID
            )
        )
        or "NO LEAGUE SELECTED"
    )

    self.currentTeamIndex = 1
    self.currentKitIndex = 1

    self:loadTeams()
end

function TeamSelector:loadLeagues()

    local countryName =
        self.countryList[self.currentCountryIndex]

    self.leagues =
        CountryLeagueGroups[countryName] or {}

    self.currentLeagueIndex = 1
    self.currentLeagueID = self.leagues[1]

    self:updateLeagueBackground()

    self.im.Publish(
        "bnd_countryname",
        countryName
    )

    self.im.Publish(
        "bnd_leaguename",
        self.currentLeagueID and
        string.upper(
            self.loc.LocalizeString(
                "LeagueName_Abbr15_" ..
                self.currentLeagueID
            )
        )
        or "NO LEAGUE SELECTED"
    )
end

function TeamSelector:toggleLeague(dir)

    local country = CountryNamesByLeague[self.currentLeagueID]
    local leagues = {}

    for _, leagueID in ipairs(CareerModeLeagues) do
        if CountryNamesByLeague[leagueID] == country then
            table.insert(leagues, leagueID)
        end
    end

    if #leagues == 0 then
        return
    end

    local currentPos = 1

    for i, leagueID in ipairs(leagues) do
        if leagueID == self.currentLeagueID then
            currentPos = i
            break
        end
    end

    if dir == 1 then
        currentPos = currentPos - 1
        if currentPos < 1 then
            currentPos = #leagues
        end
    else
        currentPos = currentPos + 1
        if currentPos > #leagues then
            currentPos = 1
        end
    end

    self.currentLeagueID = leagues[currentPos]

    self:updateLeagueBackground()

    self.im.Publish(
        "bnd_countryname",
        CountryNamesByLeague[self.currentLeagueID] or "WORLD"
    )

    self.im.Publish(
        "bnd_leaguename",
        string.upper(
            self.loc.LocalizeString(
                "LeagueName_Abbr15_" .. self.currentLeagueID
            )
        )
    )

    self.currentTeamIndex = 1
    self.currentKitIndex = 1
    self.teamsData = {}

    self:loadTeams()

    if self.teamsData[1] then
        self.im.Publish(
            "bnd_teamname",
            self.teamsData[1].name
        )

        self.im.Publish(
            "bnd_teamcrest",
            {
                name = "$Crest",
                id = self.teamsData[1].id
            }
        )

        self.im.Publish(
            "bnd_teamstar",
            self.teamsData[1].starRating
        )
    end
end

function TeamSelector:loadTeams()
  local TeamService = self.api("TeamService")
  self.teamsData = {}
  if self.currentLeagueID then
    local teamIDs = TeamService.GetTeams(self.currentLeagueID, 0, 0, false) or {}
    for _, teamData in ipairs(teamIDs) do
      local teamInfo = {
        id = teamData.id,
        name = string.upper(self.loc.LocalizeString("TeamName_Abbr15_" .. teamData.id)),
        starRating = teamData.starRating or 0,
        kits = {
          {KITTYPE = 0, YEAR = 0},
          {KITTYPE = 1, YEAR = 0},
          {KITTYPE = 3, YEAR = 0}
        }
      }
      table.insert(self.teamsData, teamInfo)
    end
  end
  if self.teamsData[self.currentTeamIndex] then
    self.im.Publish("bnd_teamname", self.teamsData[self.currentTeamIndex].name)
    self.im.Publish("bnd_teamcrest", {name = "$Crest", id = self.teamsData[self.currentTeamIndex].id})
    self.im.Publish("bnd_teamstar", self.teamsData[self.currentTeamIndex].starRating)
    self.im.Publish("bnd_stadiumname", breakString(teamStadiums[self.teamsData[self.currentTeamIndex].id] or "-"))
    local kitData = self.teamsData[self.currentTeamIndex].kits[self.currentKitIndex]
    local kitId = string.format("%s_%s_%s", kitData.KITTYPE, self.teamsData[self.currentTeamIndex].id, kitData.YEAR)
    self.im.Publish("bnd_teamkit", {name = "$Kits", id = kitId})
    self.im.Publish("bnd_teamkitname", self.kitTypes[self.currentKitIndex].name)
  else
    self.im.Publish("bnd_teamname", "NO TEAM SELECTED")
    self.im.Publish("bnd_teamcrest", {})
    self.im.Publish("bnd_teamstar", 0)
    self.im.Publish("bnd_teamkit", {})
    self.im.Publish("bnd_stadiumname", "-")
    self.im.Publish("bnd_teamkitname", "NO KIT SELECTED")
  end
  if not funds[self.teamsData[self.currentTeamIndex].id] then
    local players = self.SquadManagementService.GetCurrentPlayerLineup(0, self.teamsData[self.currentTeamIndex].id, 0)
    local cw = 0
    local ctx = Brain:buildInitialFinanceContext()
    for i = 1, #players do
      local cp = players[i]
      local playervalue = getTransferValue(cp, players)
      cw = cw + playervalue
    end
    clubWorth[self.teamsData[self.currentTeamIndex].id] = cw
    funds[self.teamsData[self.currentTeamIndex].id] = Brain:calculateTeamFunds(players, self.teamsData[self.currentTeamIndex].id, false, ctx)
  end
  
  self.im.Publish("bnd_clubbudget", formatFunds(funds[self.teamsData[self.currentTeamIndex].id]))
  self.im.Publish("bnd_clubworth", formatFunds(clubWorth[self.teamsData[self.currentTeamIndex].id]))
end

function TeamSelector:toggleTeam(dir)
  if #self.teamsData == 0 then
    return
  end
  if dir == 1 then
    self.currentTeamIndex = self.currentTeamIndex - 1
    if self.currentTeamIndex < 1 then
      self.currentTeamIndex = #self.teamsData
    end
  else
    self.currentTeamIndex = self.currentTeamIndex + 1
    if self.currentTeamIndex > #self.teamsData then
      self.currentTeamIndex = 1
    end
  end
  self.currentKitIndex = 1
  self.im.Publish("bnd_teamname", self.teamsData[self.currentTeamIndex].name)
  self.im.Publish("bnd_teamcrest", {name = "$Crest", id = self.teamsData[self.currentTeamIndex].id})
  self.im.Publish("bnd_teamstar", self.teamsData[self.currentTeamIndex].starRating)
  self.im.Publish("bnd_stadiumname", breakString(teamStadiums[self.teamsData[self.currentTeamIndex].id] or "-"))
  local kitData = self.teamsData[self.currentTeamIndex].kits[self.currentKitIndex]
  local kitId = string.format("%s_%s_%s", kitData.KITTYPE, self.teamsData[self.currentTeamIndex].id, kitData.YEAR)
  self.im.Publish("bnd_teamkit", {name = "$Kits", id = kitId})
  self.im.Publish("bnd_teamkitname", self.kitTypes[self.currentKitIndex].name)
  if not funds[self.teamsData[self.currentTeamIndex].id] then
    local players = self.SquadManagementService.GetCurrentPlayerLineup(0, self.teamsData[self.currentTeamIndex].id, 0)
    local cw = 0
    for i = 1, #players do
      local cp = players[i]
      local playervalue = getTransferValue(cp, players)
      cw = cw + playervalue
    end
    clubWorth[self.teamsData[self.currentTeamIndex].id] = cw
    funds[self.teamsData[self.currentTeamIndex].id] = Brain:calculateTeamFunds(players, self.teamsData[self.currentTeamIndex].id)
  end
  self.im.Publish("bnd_clubbudget", formatFunds(funds[self.teamsData[self.currentTeamIndex].id]))
  self.im.Publish("bnd_clubworth", formatFunds(clubWorth[self.teamsData[self.currentTeamIndex].id]))
self.im.Publish(
    "bnd_countryname",
    CountryNamesByLeague[self.currentLeagueID] or "TeamName_Abbr15_"
)  
end

function TeamSelector:toggleKit(dir)
  if dir == 1 then
    self.currentKitIndex = self.currentKitIndex - 1
    if self.currentKitIndex < 1 then
      self.currentKitIndex = #self.kitTypes
    end
  else
    self.currentKitIndex = self.currentKitIndex + 1
    if self.currentKitIndex > #self.kitTypes then
      self.currentKitIndex = 1
    end
  end
  if self.teamsData[self.currentTeamIndex] then
    local kitData = self.teamsData[self.currentTeamIndex].kits[self.currentKitIndex]
    local kitId = string.format("%s_%s_%s", kitData.KITTYPE, self.teamsData[self.currentTeamIndex].id, kitData.YEAR)
    self.im.Publish("bnd_teamkit", {name = "$Kits", id = kitId})
    self.im.Publish("bnd_teamkitname", self.kitTypes[self.currentKitIndex].name)
    for i = 1, 3 do
      self.im.Publish("bnd_calpha" .. i, i == self.currentKitIndex and 1 or 0.5)
      self.im.Publish("bnd_csize" .. i, i == self.currentKitIndex and 12 or 7)
    end
  else
    self.im.Publish("bnd_teamkit", {})
    self.im.Publish("bnd_teamkitname", "NO KIT SELECTED")
  end
end

return TeamSelector
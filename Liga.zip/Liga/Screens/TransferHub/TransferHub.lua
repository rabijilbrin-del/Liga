-- TransferHub.lua

local Timer, HubRows = ...

local TransferHub = {}

function TransferHub:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  initTheme(o.im)

  -- Initialize HubRows with a specific teamID
  o.teamID = currentSelectedTeamID -- Use provided teamID or default
  o.hubRows = HubRows:new({
    teamID = o.teamID,
    im = o.im, -- Pass interface manager
    api = o.api, -- Pass API access
    nav = o.nav,
    loc = o.loc
  })

  return o
end

function TransferHub:update(elapsedTime)
  -- Delegate update to HubRows for cursor and bounce animations
  self.hubRows:update(elapsedTime)
end

function TransferHub:finalize()
  -- Clean up HubRows
  self.hubRows:finalize()
end

return TransferHub
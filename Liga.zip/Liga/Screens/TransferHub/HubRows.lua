local Timer, FCPopup, sessionVars, Squads, Scouting, Date = ...

local function formatStat(val)
  local col = ""
  if type(val) == "number" then
    local int = val
    if int < 50 then
      col = "0xFF2F00"
    elseif int < 70 then
      col = "0xFFFF00"
    elseif int < 79 then
      col = "0x006400"
    else
      col = "0x00FF00"
    end
  elseif type(val) == "string" then
    if val == "Happy" or val == "Very Happy" then
      col = "0x00FF00"
    elseif val == "Normal" then
      col = "0xFFFF00"
    else
      col = "0xFF2F00"
    end
  end
  return col or "0xFFFFFF"
end

local function formatHeight(cm)
  local totalInches = cm / 2.54
  local feet = math.floor(totalInches / 12)
  local inches = math.floor(totalInches % 12 + 0.5)
  return string.format("%d'%d\"", feet, inches)
end

local function indexOf(tbl, value)
  for i, v in ipairs(tbl) do
    if v == value then
      return i
    end
  end
  return nil
end

local HubRows = {}
local rowField = {"position", "head", "name", "ovr", "role"}
local colorField = {"pos", "name", "ovr", "role"}
local panelAttributes = {"position", "opened"}
local panelPositions = {30, 82, 134, 186, 238, 290, 342, 342, 342}
local playerRolesTable = {"Crucial", "Important", "Rotation", "Sporadic", "Prospect"}
local PlayerListData = {}
local ROW_COUNT = 9
local FIELD_COUNT = 5
local COLOR_FIELD_COUNT = 4
local ACTIONS_BTN_COUNT = 2
local transferListed = {}
local notListed = {}
local loanListed = {}
local displayType = nil
-- player receivedOffers
local userLeagueID = sessionVars.get("currentUserLeagueID") or {}
local playerGoals = sessionVars.get("PlayerGoals") or {}
local leagueGoals = playerGoals[userLeagueID] or {}
local teamPlayers = nil

-- Define position order for sorting
local positionOrder = {
    "GK", "RB", "RWB", "CB", "LB", "LWB", "CDM", "RM", "CM", "LM", "CAM", "ST", "CF", "LF", "RF"
}
local positionIndex = {}
for i, pos in ipairs(positionOrder) do
    positionIndex[pos] = i
end

-- Sort field mapping (adjusted for actual sortable fields: 1=pos, 3=name, 4=ovr, 5=role)
local sortMap = {
    [1] = "position",
    [3] = "name",
    [4] = "ovr",
    [5] = "role"
}

local playerBindings = {
  "bnd_player_rating", "ratinginfocol",
  "bnd_player_position", "bnd_player_name", "bnd_player_country",
  "ageinfo", "WHinfo", "preffootinfo", "statusinfo", "roleinfo",
  "forminfo", "availableinfo", "transfervalue", "transferstatus", "transferclause", "transferteam",
  "transferteamimg"
}

function HubRows:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.services = { SquadManagementService = o.api("SquadMgtService") }
  o.teamID = o.teamID or currentSelectedTeamID -- Use provided teamID or default
  o.selectedRow = 1      -- Selected row index (1 to totalPlayers)
  o.selectedPlayer = nil
  o.startIndex = 1       -- First player index in visible window
  o.totalPlayers = 0     -- Total players in roster
  o.rowData = {}         -- Preallocated row data (9 rows x 8 fields: 1-5 fields, 6=form, 7=team crest, 8=morale)
  o.cursorData = {}      -- Preallocated cursor states (9 booleans)
  o.cursorHeight = 70    -- Fixed cursor height (always 70)
  o.panelposition = 0
  o.selectedPanelBtn = 1
  o.currentTab = currentHubTab or "shortList"
  o.panelvisible = false
  o.panelData = {o.panelposition, o.panelvisible}
  o.FCPopup = FCPopup:new({nav = o.nav})
  o.cursorMarginTop = 0  -- Dynamic cursor marginTop
  o.targetMarginTop = 0  -- Target cursor marginTop for animation
  o.cursorTimer = nil    -- Timer for cursor animation
  o.rowPublishTimer = nil -- Timer for staggered row publishing
  o.bounceTimer = nil
  o.renderPauseTimer = nil
  o.actionsViewActive = false -- Tracks if actions view (with cleared rows) is active
  o.swipeY = 0
  o.sortField = 1
  o.sortDirection = "asc"
  o.lastSortField = nil
  o.initTimer = nil
  o.initialized = false
  o.isInitialLoad = true
  o.clearRow1 = nil
  o.clearRow2 = nil
  o.clearRow3 = nil
  teamPlayers = Squads.getCachedTeamPlayers(o.teamID)

  -- Preallocate rowData and cursorData
  for i = 1, ROW_COUNT do
    o.rowData[i] = { "", {name="$Head",id=0}, "", "", "", {}, {}, 4 }
    o.cursorData[i] = false
  end

  -- Smart binding registration
  local bindings = {}
  local bindingCount = 0
  for i = 1, ROW_COUNT do
    for j = 1, FIELD_COUNT do
      bindingCount = bindingCount + 1
      bindings[bindingCount] = "bnd_row"..rowField[j]..i
    end
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "bnd_rowselected"..i
    for j = 1, COLOR_FIELD_COUNT do
      bindingCount = bindingCount + 1
      bindings[bindingCount] = "bnd_"..colorField[j].."color"..i
    end
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "bnd_rowvisible"..i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "bnd_rowteam"..i
  end
  bindingCount = bindingCount + 1
  bindings[bindingCount] = "bnd_rowcursor_height"
  bindingCount = bindingCount + 1
  bindings[bindingCount] = "bnd_rowcursor_marginTop"
  bindingCount = bindingCount + 1
  bindings[bindingCount] = "bnd_rowcursorvisible"
  for i = 1, 2 do
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "bnd_panel"..panelAttributes[i]
  end
  for i = 1, ROW_COUNT do
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "formOne".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "formTwo".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "formTwoType".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "formThree".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "formThreeType".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "moraleOne".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "moraleTwo".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "moraleThree".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "moraleFour".. i
  end
  bindingCount = bindingCount + 1
  bindings[bindingCount] = "isRowEmpty"

  for i = 1, bindingCount do
    o.im.Subscribe(bindings[i], function() o:publishPending() end)
  end

  -- Player info subscriptions
  for _, binding in ipairs(playerBindings) do
    o.im.Subscribe(binding, function() o:publishPlayerInfo() end)
  end

  -- Precompute all publish keys to avoid runtime string concat
  o.publishKeys = {
    rowFields = {},
    selected = {},
    colors = {},
    visible = {},
    team = {},
    formOne = {},
    formTwo = {},
    formTwoType = {},
    formThree = {},
    formThreeType = {},
    moraleOne = {},
    moraleTwo = {},
    moraleThree = {},
    moraleFour = {},
  }
  for i = 1, ROW_COUNT do
    o.publishKeys.rowFields[i] = {}
    for j = 1, FIELD_COUNT do
      o.publishKeys.rowFields[i][j] = "bnd_row"..rowField[j]..i
    end
    o.publishKeys.selected[i] = "bnd_rowselected"..i
    o.publishKeys.colors[i] = {}
    for j = 1, COLOR_FIELD_COUNT do
      o.publishKeys.colors[i][j] = "bnd_"..colorField[j].."color"..i
    end
    o.publishKeys.visible[i] = "bnd_rowvisible"..i
    o.publishKeys.team[i] = "bnd_rowteam"..i
    o.publishKeys.formOne[i] = "formOne"..i
    o.publishKeys.formTwo[i] = "formTwo"..i
    o.publishKeys.formTwoType[i] = "formTwoType"..i
    o.publishKeys.formThree[i] = "formThree"..i
    o.publishKeys.formThreeType[i] = "formThreeType"
    o.publishKeys.moraleOne[i] = "moraleOne"..i
    o.publishKeys.moraleTwo[i] = "moraleTwo"..i
    o.publishKeys.moraleThree[i] = "moraleThree"..i
    o.publishKeys.moraleFour[i] = "moraleFour"..i
  end
  o.publishKeys.cursorHeight = "bnd_rowcursor_height"
  o.publishKeys.cursorMarginTop = "bnd_rowcursor_marginTop"
  o.publishKeys.cursorVisible = "bnd_rowcursorvisible"
  o.publishKeys.panelPosition = "bnd_panelposition"
  o.publishKeys.panelOpened = "bnd_panelopened"
  o.im.Subscribe("inShortlist", function() o.im.Publish("inShortlist", o.currentTab == "shortList") end)
  o.im.Subscribe("inReceivedOffers", function() o.im.Publish("inReceivedOffers", o.currentTab == "receivedOffers") end)
  o.im.Subscribe("inScoutedPlayers", function() o.im.Publish("inScoutedPlayers", o.currentTab == "scoutedPlayers") end)
  o.im.Subscribe("tab1name", function() o.im.Publish("tab1name", transferScreen == "transfersearch" and "ATT" or "Shortlist") end)
  o.im.Subscribe("tab2name", function() o.im.Publish("tab2name", transferScreen == "transfersearch" and "MID" or "Received Offers") end)
  o.im.Subscribe("tab3name", function() o.im.Publish("tab3name", transferScreen == "transfersearch" and "DEF" or "Scouted Players") end)

  o.im.RegisterAction("act_scrollbtn1", function() o:rowAction(1) end)
  -- Register sort actions only for sortable fields (1=pos, 3=name, 4=ovr, 5=role)
  o.im.RegisterAction("act_sort1", function() o:sortRowsBy(1) end)
  o.im.RegisterAction("act_sort2", function() o:sortRowsBy(3) end)
  o.im.RegisterAction("act_sort3", function() o:sortRowsBy(4) end)
  o.im.RegisterAction("act_sort4", function() o:sortRowsBy(5) end)
  o.im.RegisterAction("toreceivedOffers", function() o:toggleTab("receivedOffers") end)
  o.im.RegisterAction("toshortList", function() o:toggleTab("shortList") end)
  o.im.RegisterAction("toscoutedPlayers", function() o:toggleTab("scoutedPlayers") end)
  o.im.RegisterAction("act_scrollbtn2", function() o:rowAction(2) end)
  o.im.RegisterAction("act_actions", function() o:showActionsEvent() end)
  o.im.RegisterDataAction("bnd_swipeRow", "act_swipeRow", function(bindingName, actionName, panEvent)
    local swipeY = panEvent.panY  
    o:swipeRow(swipeY * -1) 
  end)
  o.nav.AddActionHandler("finalize", false, nil, function()
    o:finalize()
  end)

  for i = 1, ROW_COUNT do
    o.im.RegisterAction("act_row"..i, function() o:rowClickEvent(i) end)
  end

  for i = 1, ACTIONS_BTN_COUNT do
    o.im.RegisterAction("action"..i, function() o:panelBtnAction(i) end)
  end
  
  o:setupPanel()

  o:publishLoadingState()

  o.initTimer = Timer:new({
    id = "initTimer",
    interval = 0.2,
    reps = 1,
    onTimerComplete = function()
      o.initialized = true
      o:Init()
      local renderPauseTimer = Timer:new({
        id = "renderPauseTimer",
        interval = 0.1,
        reps = 1,
        onTimerComplete = function()
          o:publishPlayerInfo()          
          o:publishPending()
          o.isInitialLoad = false
          o.renderPauseTimer = nil
        end
      })
      o.renderPauseTimer = renderPauseTimer
      renderPauseTimer:start()
      o.initTimer = nil
    end
  })
  o.initTimer:start()
  return o
end

function HubRows:publishPlayerInfo()
  if self.totalPlayers == 0 or not self.selectedPlayer then
    return
  end
  local cp = self.selectedPlayer
  local energy = 100
  local sharpness = 100
  local morale_str = "Normal"
  
  local function formatWithCommas(value)
    local formatted = tostring(math.floor(value))
    -- Add commas for thousands
    local k
    while true do
        formatted, k = formatted:gsub("^(-?%d+)(%d%d%d)", "%1,%2")
        if k == 0 then break end
    end
    return "£" .. formatted
end

local function getTransferValue(selectedPlayer)
    local pInfo = getPlayerInfo(selectedPlayer.CARD_ID, selectedPlayer.team)
    local playerRating = pInfo and pInfo.rating or 50
    local playerPosition = pInfo and pInfo.position or "CM"
    local playerIndex = pInfo and pInfo.index or 0
    local repCount = playerReplacementCount(selectedPlayer.teamID, playerPosition) or 0
    local days = daysLeftInTransferWindow(GLOBAL_DATE_PLACEHOLDER or "2025-03-22") or 30

    local transferValue, minTValue = computeTransferValue(
        GetPlayerAge(selectedPlayer.CARD_ID) or 25,
        playerRating,
        playerPosition,
        playerIndex,
        repCount,
        days
    )

    local formattedValue = formatWithCommas(transferValue)

    return formattedValue
end
  
  if cp.morale == 1 then
    morale_str = "Very Happy"
  elseif cp.morale == 2 then
    morale_str = "Happy"
  elseif cp.morale == 3 then
    morale_str = "Normal"
  else
    morale_str = "Unhappy"
  end
  
  cp.team = self.currentTab == "receivedOffers" and cp.offeringTeam or cp.team
  local transfervalue = self.currentTab == "receivedOffers" and formatWithCommas(cp.offeringFee) or getTransferValue(cp)
  
  self.im.Publish("bnd_player_rating", cp.rating or "") 
  self.im.Publish("ratinginfocol", formatStat(cp.rating) or "0xFFFFFF") 
  self.im.Publish("bnd_player_position", cp.position or "") 
  self.im.Publish("bnd_player_name", tostring(cp.playerName or ""))
  self.im.Publish("bnd_player_country", { name = "$Flag128x128", id = cp.nationalityID or 0 }) 
  self.im.Publish("ageinfo", GetPlayerAge(cp.CARD_ID) or 18) 
  local height = GetPlayerData("height", cp.CARD_ID) or 180
  local weight = GetPlayerData("weight", cp.CARD_ID) or 80
  self.im.Publish("WHinfo", formatHeight(height) .. "/" .. weight .. " lbs") 
  self.im.Publish("preffootinfo", (GetPlayerData("prefFoot", cp.CARD_ID) or 0) == 1 and "Right" or "Left") 
  self.im.Publish("statusinfo", (transferredPlayers or {})[cp.CARD_ID] and "Joined this season" or "Has been here for quite awhile") 
  self.im.Publish("roleinfo", cp.role or "") 
  self.im.Publish("forminfo", "Normal") 
  self.im.Publish("availableinfo", "Match Fit") 
  self.im.Publish("transfervalue", (cp.isLoan and (cp.loanDuration == 1 and "Short Loan" or "Season Loan") or transfervalue)) 
  self.im.Publish("transferstatus", "None") 
  self.im.Publish("transferclause", "None") 
  self.im.Publish("transferteam", self.loc.LocalizeString("TeamName_Abbr3_" .. cp.team)) 
  self.im.Publish("transferteamimg", { name = "$Crest", id = cp.team or 0 }) 
end

function HubRows:canTransferProceed(playerTeam, playerForTransfer)
  local players = Squads.getCachedTeamPlayers(playerTeam)
  local position = nil
  local index = nil
  local replacements = 0
  
  if #players < 11 or not players then
    return false
  end
  
  for i = 1, #players do
    local player = players[i]
    if player.CARD_ID == playerForTransfer then
      position = player.position
      index = i
    end
  end
  
  if index > 11 then
    return true
  end
  
  if #players >= 20 then
    return true
  end
  
  return false
end

function HubRows:toggleTab(tab)
  if tab == self.currentTab then
    return
  end
  self.currentTab = tab    
  self.im.Publish("inReceivedOffers", self.currentTab == "receivedOffers")
  self.im.Publish("inShortlist", self.currentTab == "shortList")
  self.im.Publish("inScoutedPlayers", self.currentTab == "scoutedPlayers")
  self.im.Publish("bnd_rowcursor_marginTop", 0)
  self.actionsViewActive = false
  self.panelData = {0, false}
  self.selectedPanelBtn = 1
  self.selectedRow = 1      -- Selected row index (1 to totalPlayers)
  self.startIndex = 1       -- First player index in visible window
  self.swipeY = 0
  self.clearRow1 = nil
  self.clearRow2 = nil
  self.clearRow3 = nil
  self:Init()
  self:updatePlayerState()
  self:publishPlayerInfo()
  self:publishPending()
end
  
function HubRows:publishLoadingState()
  local Publish = self.im.Publish
  local keys = self.publishKeys

  -- Publish blank state for all rows immediately
  for i = 1, ROW_COUNT do
    for j = 1, FIELD_COUNT do
      Publish(keys.rowFields[i][j], "")
    end
    Publish(keys.selected[i], false)
    for j = 1, COLOR_FIELD_COUNT do
      Publish(keys.colors[i][j], "0xFFFFFF")
    end
    Publish(keys.visible[i], false)
    Publish(keys.team[i], {})
    Publish(keys.formOne[i], false)
    Publish(keys.formTwo[i], false)
    Publish(keys.formTwoType[i], 0)
    Publish(keys.formThree[i], false)
    Publish(keys.formThreeType[i], 0)
    Publish(keys.moraleOne[i], false)
    Publish(keys.moraleTwo[i], false)
    Publish(keys.moraleThree[i], false)
    Publish(keys.moraleFour[i], false)
  end

  -- Hide cursor and panel during loading
  Publish(keys.cursorVisible, false)
  Publish(keys.panelOpened, false)
end

function HubRows:Init()
    local lineup = {}
    local fillIdx = 0
    local transferOffers = sessionVars.get("transferOffers") or {}
    local scoutedPlayers = self.currentTab == "scoutedPlayers" and Scouting:getScoutedPlayers(sessionVars) or {}
    local shortlistedPlayers = sessionVars.get("shortlistedPlayers") or {}
    local playerTable = self.currentTab == "receivedOffers" and transferOffers or (self.currentTab == "scoutedPlayers" and scoutedPlayers or shortlistedPlayers)
    
      for k, v in pairs(playerTable) do
        local team = self.currentTab == "receivedOffers" and self.teamID or v
        local playerTeam = Squads.getCachedTeamPlayers(team) or {}
        local currentPlayer = nil
        for i = 1, #playerTeam do
          if playerTeam[i].CARD_ID == k then
            currentPlayer = playerTeam[i]
            fillIdx = fillIdx + 1
            lineup[fillIdx] = currentPlayer
            if self.currentTab == "receivedOffers" then
              lineup[fillIdx].offeringTeam = v.offeringClub
              lineup[fillIdx].offeringFee = v.priceTag
              lineup[fillIdx].isLoan = v.isLoan
              lineup[fillIdx].loanDuration = v.loanDuration
            end
            break
          end
        end
      end
    
    
    local n = #lineup
    PlayerListData = {}
    local math_random = math.random
    for i = 1, n do
        local _form = math_random(15)
        local form = _form < 6 and 1 or _form > 10 and 2 or 3
        local _formtype = math_random(15)
        local formtype = _formtype < 6 and 1 or _formtype > 10 and 2 or 3
        local _morale = math_random(20)
        local morale = 1
        if _morale > 15 then
            morale = 4
        elseif _morale < 6 then
            morale = 1
        elseif _morale < 16 and _morale > 9 then
            morale = 3
        else
            morale = 2
        end
        PlayerListData[i] = {
            position = lineup[i].position or "EM",
            CARD_ID = lineup[i].CARD_ID,
            playerName = lineup[i].playerName or "No name",
            rating = lineup[i].rating or 100,
            nationalityID = lineup[i].nationalityID,
            role = playerRolesTable[math_random(#playerRolesTable)] or "Normal", -- Assign role from playerRolesTable
            form = {form = form, type = formtype},
            team = lineup[i].teamID,
            offeringTeam = lineup[i].offeringTeam,
            offeringFee = lineup[i].offeringFee,
            isLoan = lineup[i].isLoan,
            loanDuration= lineup[i].loanDuration,
            morale = morale
        }
    end
    self.totalPlayers = n

    -- Sort by position on initialization
    table.sort(PlayerListData, function(a, b)
        local posA = positionIndex[a.position] or 999
        local posB = positionIndex[b.position] or 999
        return posA < posB
    end)

    self:cacheRowData()
    self:cacheCursorData()
    self:calculateCursorMarginTop()
    self:updatePlayerState()
    self:publishPlayerInfo()
end

function HubRows:swipeRow(Y)
  if self.totalPlayers < 10 then
    return
  end
  if not self.actionsViewActive then
    local math_floor = math.floor
    local jump = Y > 0 and 30 or -30
    local maxStart = (self.totalPlayers - ROW_COUNT) * 60
    self.swipeY = self.swipeY + Y + jump
    self.swipeY = self.swipeY < 1 and 0 or (self.swipeY > maxStart and maxStart or self.swipeY)
    local swipeIdx = (math_floor((self.swipeY/60)) + 1) or 1
    self.startIndex = swipeIdx
    self:cacheRowData()
    self:cacheCursorData()
    self:calculateCursorMarginTop()
    self:animateCursor()
    self:updatePlayerState()
    self:publishPlayerInfo()
  end
end

function HubRows:setupPanel()
  for i = 1, ACTIONS_BTN_COUNT do
    self.im.Subscribe("btntextcolor" ..i, function() self.im.Publish("btntextcolor" ..i, i ~= self.selectedPanelBtn and "0xFFFFFF" or "0x000000") end)
    self.im.Subscribe("btntext" ..i, function() self:setupPanelBtns(i) end)
  end
  
  local X, Y = self.selectedBtnConfig(self.selectedPanelBtn)
  self.im.Subscribe("selectedbtnX", function() self.im.Publish("selectedbtnX", X) end)
  self.im.Subscribe("selectedbtnY", function() self.im.Publish("selectedbtnY", Y) end)
end

function HubRows:setupPanelBtns(id)
  local shortlistedPlayers = sessionVars.get("shortlistedPlayers") or {}
  local btnTxt = ""
  if id == 1 then
    if self.currentTab == "shortList" then
      btnTxt = "Negotiate"
    elseif self.currentTab == "receivedOffers" then
      btnTxt = "Accept Offer"
    elseif self.currentTab == "scoutedPlayers" then
      btnTxt = shortlistedPlayers[self.selectedPlayer.CARD_ID] and "Unlist" or "Shortlist"
    end
    self.im.Publish("btntext" ..id, btnTxt)
  elseif id == 2 then
    if self.currentTab == "shortList" then
      btnTxt = "Unlist"
    elseif self.currentTab == "receivedOffers" then
      btnTxt = "Reject Offer"
    elseif self.currentTab == "scoutedPlayers" then
      btnTxt = "Remove player"
    end
    self.im.Publish("btntext" ..id, btnTxt)
  end
end

function HubRows:displayConfirmationMsg(message, evt, callbck, error)
  local buttonData = error and {"Back"} or {"Yes", "No"}
  self.FCPopup:getResponse(message, buttonData, function(clickResponse)
    if clickResponse == 1 then
      if callbck then
        callbck()
        return
      end
      if error then
      else
        self.nav.Event(nil, evt)
      end
    end
  end)
end

function HubRows.selectedBtnConfig(btnId)
  local X = {40, 210, 385}
  local Y = {15, 50, 85}
  if btnId <= 3 then
    return X[1], Y[btnId]
  elseif btnId > 3 and btnId <= 5 then
    return X[2], Y[btnId - 3]
  elseif btnId > 5 and btnId <= 7 then
    return X[3], Y[btnId - 5]
  end
  
  return X[1], Y[1]
end

function HubRows:refreshRow()
  self.actionsViewActive = false
  self.clearRow1 = nil
  self.clearRow2 = nil
  self.clearRow3 = nil
  self.panelData[2] = false
  table.remove(PlayerListData, self.selectedRow)
  self.totalPlayers = #PlayerListData
  if self.selectedRow > self.totalPlayers then
    self.selectedRow = math.max(1, self.totalPlayers)
  end
  local maxStart = math.max(1, self.totalPlayers - ROW_COUNT + 1)
  if self.startIndex > maxStart then
    self.startIndex = maxStart
  end
  self:cacheRowData()
  self:cacheCursorData()
  self:calculateCursorMarginTop()
  self:animateCursor()
  self:updatePlayerState()
  self:publishPlayerInfo()
  self:publishPending()
end

function HubRows:goBackVvm(data)
  self.nav.Event(nil, "evt_hide_overlay")
  self:refreshRow()
  if data then
    data.close = function() self.nav.Event(nil, "evt_hide_overlay") end
  end
    self.nav.Event(nil, "evt_show_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/TransferPopup/TransferPopup.vvm", data = data})
end

function HubRows:panelBtnAction(btnId)
  local loanedPlayers = sessionVars.get("loanedPlayers") or {}
  if self.totalPlayers == 0 then
    return
  end
  if btnId == self.selectedPanelBtn then
    if btnId == 1 then
      if self.currentTab == "shortList" then
        if Date:IsTransferWindowOpen() then
         if self:canTransferProceed(self.selectedPlayer.team, self.selectedPlayer.CARD_ID) then
          sessionVars.set("playerForTransfer", self.selectedPlayer.CARD_ID)
          sessionVars.set("playerTeam", self.selectedPlayer.team)      
	      self.nav.Event(nil, "evt_show_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/Negotiate/Negotiate.vvm", data = {team = self.selectedPlayer.team, player = self.selectedPlayer.CARD_ID, nav = self.nav, back = function(data) self:goBackVvm(data) end}})
  	  elseif transferredPlayers[self.selectedPlayer.CARD_ID] then
	      local message = "Player recently joined and isn't willing to move to a new team."	      
	      self:displayConfirmationMsg(message, nil, nil, true)
  	  else
          local message = "Player is too important to be sold."	      
	      self:displayConfirmationMsg(message, nil, nil, true)
  	  end
        else
          local message = "Transfer window is currently closed"
	      self:displayConfirmationMsg(message, nil, nil, true)
        end
      elseif self.currentTab == "receivedOffers" then
        local msg = ""
        if #teamPlayers <= 25 then
          msg = "Board cannot permit this transfer due to current squad size."
          self:displayConfirmationMsg(msg, nil, nil, true)
        elseif loanedPlayers[self.selectedPlayer.CARD_ID] then 
          msg = "Action cannot be completed due to player being on loan."
          self:displayConfirmationMsg(msg, nil, nil, true)
        else
          transferPlayer(self.selectedPlayer.CARD_ID, self.teamID, self.selectedPlayer.offeringTeam, self.selectedPlayer.isLoan, self.selectedPlayer.loanDuration)
          if not self.selectedPlayer.isLoan then
            GLOBAL_FUNDS[self.selectedPlayer.offeringTeam] = GLOBAL_FUNDS[self.selectedPlayer.offeringTeam] - self.selectedPlayer.offeringFee
            GLOBAL_FUNDS[self.teamID] = GLOBAL_FUNDS[self.teamID] + self.selectedPlayer.offeringFee
          end
          self:refreshRow()
        end
      elseif self.currentTab == "scoutedPlayers" then
        local shortlistedPlayers = sessionVars.get("shortlistedPlayers")
        if shortlistedPlayers[self.selectedPlayer.CARD_ID] then
          shortlistedPlayers[self.selectedPlayer.CARD_ID] = nil
        else
          shortlistedPlayers[self.selectedPlayer.CARD_ID] = self.selectedPlayer.team
        end
        sessionVars.set("shortlistedPlayers", shortlistedPlayers)
      end
    elseif btnId == 2 then
      if self.currentTab == "shortList" then
        local shortlistedPlayers = sessionVars.get("shortlistedPlayers")
        shortlistedPlayers[self.selectedPlayer.CARD_ID] = nil
        sessionVars.set("shortlistedPlayers", shortlistedPlayers)
      elseif self.currentTab == "receivedOffers" then
        local transferOffers = sessionVars.get("transferOffers") or {}
        transferOffers[self.selectedPlayer.CARD_ID] = nil
        sessionVars.set("transferOffers", transferOffers)
      elseif self.currentTab == "scoutedPlayers" then
        local scoutedPlayers = sessionVars.get("scoutedPlayers")
        scoutedPlayers[self.selectedPlayer.CARD_ID] = nil
        sessionVars.set("scoutedPlayers", scoutedPlayers)
      end
      self:refreshRow()
    end
    self:setupPanelBtns(btnId)
  return
  end
    
  self.selectedPanelBtn = btnId
  local X, Y = self.selectedBtnConfig(self.selectedPanelBtn)
  for i = 1, ACTIONS_BTN_COUNT do
    self.im.Publish("btntextcolor" ..i, i ~= btnId and "0xFFFFFF" or "0x000000")
  end
  self.im.Publish("selectedbtnX", X)
  self.im.Publish("selectedbtnY", Y)
end

function HubRows:updatePlayerState()
  if self.totalPlayers > 0 then
    self.selectedPlayer = PlayerListData[self.selectedRow]
  else
    self.selectedPlayer = nil
  end
end

function HubRows:sortRowsBy(idx)
  if self.actionsViewActive then
    return
  end
  self.sortField = idx
  self:sortRows()
end

function HubRows:sortRows()
    if self.totalPlayers == 0 then
      return
    end
    if self.actionsViewActive then
      return
    end
    local field = sortMap[self.sortField] or "position"
    local isDescending = self.sortDirection == "desc"

    -- Toggle sort direction if same field
    if self.lastSortField == field then
        self.sortDirection = isDescending and "asc" or "desc"
    else
        self.sortDirection = "desc" -- Default to descending on first click
        self.lastSortField = field
    end

    table.sort(PlayerListData, function(a, b)
        local valA, valB

        if field == "position" then
            valA = positionIndex[a.position] or 999
            valB = positionIndex[b.position] or 999
        elseif field == "name" then
            valA = a.playerName:lower()
            valB = b.playerName:lower()
        elseif field == "ovr" then
            valA = tonumber(a.rating) or 0
            valB = tonumber(b.rating) or 0
        elseif field == "role" then -- can be goal of the currentTab is receivedOffers
            valA = (indexOf(playerRolesTable, a.role) or 999)
            valB = (indexOf(playerRolesTable, b.role) or 999)
        end

        if self.sortDirection == "asc" then
            return valA < valB
        else
            return valA > valB
        end
    end)

    self:cacheRowData()
    self:cacheCursorData()
    self:calculateCursorMarginTop()
    self:animateCursor()
    self:updatePlayerState()
    self:publishPlayerInfo()
    self:publishPending()
end

function HubRows:cacheRowData() 
  if self.actionsViewActive then
    local clear1 = self.clearRow1
    local clear2 = self.clearRow2
    local clear3 = self.clearRow3
    local clearSet = {}
    if clear1 and clear1 <= ROW_COUNT then
      clearSet[clear1] = true
    end
    if clear2 and clear2 <= ROW_COUNT then
      clearSet[clear2] = true
    end
    if clear3 and clear3 <= ROW_COUNT then
      clearSet[clear3] = true
    end
    local offset = 0
    for i = 1, ROW_COUNT do
      local row = self.rowData[i]
      local is_clear = clearSet[i]
      if is_clear then
        row[1] = ""
        row[2].id = nil
        row[3] = ""
        row[4] = ""
        row[5] = ""
        row[6] = {}
        row[7] = {}
        row[8] = 4
        offset = offset + 1
      else
        local idx = self.startIndex + i - 1 - offset
        if idx >= 1 and idx <= self.totalPlayers then
          local p = PlayerListData[idx]
          row[1] = p.position
          row[2].id = p.CARD_ID
          row[3] = p.playerName
          row[4] = p.rating
          row[5] = p.role
          row[6] = p.form
          row[7] = self.currentTab == "receivedOffers" and {name = "$Crest", id = p.offeringTeam} or {name = "$Crest", id = p.team}
          row[8] = p.morale
        else
          row[1] = ""
          row[2].id = nil
          row[3] = ""
          row[4] = ""
          row[5] = ""
          row[6] = {}
          row[7] = {}
          row[8] = 4
        end
      end
    end
  else
    for i = 1, ROW_COUNT do
      local idx = self.startIndex + i - 1
      local row = self.rowData[i]
      if idx <= self.totalPlayers and idx >= 1 then
        local p = PlayerListData[idx]
        row[1] = p.position
        row[2].id = p.CARD_ID
        row[3] = p.playerName
        row[4] = p.rating
        row[5] = p.role
        row[6] = p.form
        row[7] = self.currentTab == "receivedOffers" and {name = "$Crest", id = p.offeringTeam} or {name = "$Crest", id = p.team}
        row[8] = p.morale
      else
        row[1] = ""
        row[2].id = nil
        row[3] = ""
        row[4] = ""
        row[5] = ""
        row[6] = {}
        row[7] = {}
        row[8] = 4
      end
    end
  end
end

function HubRows:cacheCursorData()
  for i = 1, ROW_COUNT do
    self.cursorData[i] = i == self.selectedRow - self.startIndex + 1
  end
end

function HubRows:calculateCursorMarginTop()
  if self.totalPlayers <= 1 then
    self.targetMarginTop = 0
    return
  end
  local math_max = math.max
  local math_min = math.min
  local maxMarginTop = 370
  local maxStart = math_max(1, self.totalPlayers - ROW_COUNT + 1)
  local clamped_start = math_min(self.startIndex, maxStart)
  if maxStart == 1 then
    self.targetMarginTop = 0
    return
  end
  self.targetMarginTop = maxMarginTop * (clamped_start - 1) / (maxStart - 1)
end

function HubRows:rowClickEvent(rowIdx)
  if self.totalPlayers == 0 then
    return
  end
  if rowIdx < 1 or rowIdx > ROW_COUNT then
    return
  end

  local newSelectedRow = self.startIndex + rowIdx - 1
  if newSelectedRow > self.totalPlayers or newSelectedRow < 1 then
    return
  end

  if self.actionsViewActive then
    if newSelectedRow == self.selectedRow then
      self:showActionsEvent()
    end
    return
  end

  if newSelectedRow == self.selectedRow then
    self:showActionsEvent()
    for i = 1, ACTIONS_BTN_COUNT do -- refreshes btn displays for each new clicked player
      self:setupPanelBtns(i)
    end
    return
  end

  local oldStart = self.startIndex
  self.selectedRow = newSelectedRow

  local viewLastRow = self.startIndex + ROW_COUNT - 1
  if self.selectedRow < self.startIndex then
    self.startIndex = self.selectedRow
  elseif self.selectedRow > viewLastRow then
    self.startIndex = self.selectedRow - ROW_COUNT + 1
  end

  local maxStart = self.totalPlayers - ROW_COUNT + 1
  maxStart = maxStart < 1 and 1 or maxStart
  if self.startIndex < 1 then
    self.startIndex = 1
  elseif self.startIndex > maxStart then
    self.startIndex = maxStart
  end

  if oldStart ~= self.startIndex then
    self:cacheRowData()
  end
  self:cacheCursorData()
  self:calculateCursorMarginTop()
  self:animateCursor()
  self:updatePlayerState()
  self:publishPlayerInfo()
end

function HubRows:showActionsEvent()
  if self.totalPlayers == 0 then
    return
  end
  self.actionsViewActive = not self.actionsViewActive
  local relativeRowIdx = self.selectedRow - self.startIndex + 1

  if self.actionsViewActive then
    if relativeRowIdx > 6 then
      self.startIndex = math.max(1, self.selectedRow - 5)
      relativeRowIdx = self.selectedRow - self.startIndex + 1
    end
    self.clearRow1 = relativeRowIdx + 1
    self.clearRow2 = relativeRowIdx + 2
    self.clearRow3 = relativeRowIdx + 3
    self.panelData[1] = panelPositions[relativeRowIdx]
    self.panelData[2] = true
  else
    local viewLastRow = self.startIndex + ROW_COUNT - 1
    if self.selectedRow < self.startIndex then
      self.startIndex = self.selectedRow
    elseif self.selectedRow > viewLastRow then
      self.startIndex = self.selectedRow - ROW_COUNT + 1
    end
    local maxStart = self.totalPlayers - ROW_COUNT + 1
    maxStart = maxStart < 1 and 1 or maxStart
    if self.startIndex < 1 then
      self.startIndex = 1
    elseif self.startIndex > maxStart then
      self.startIndex = maxStart
    end
    self.clearRow1 = nil
    self.clearRow2 = nil
    self.clearRow3 = nil
    self.panelData[2] = false
  end

  self:cacheRowData()
  self:cacheCursorData()
  self:calculateCursorMarginTop()
  self:animateCursor()
  self:updatePlayerState()
  self:publishPlayerInfo()
end

function HubRows:rowAction(btn)
  if self.totalPlayers < 10 then
    return
  end
  local oldStart = self.startIndex
  local maxStart = self.totalPlayers - ROW_COUNT + 1
  maxStart = maxStart < 1 and 1 or maxStart

  if btn == 2 then -- Scroll down
    if self.selectedRow < self.totalPlayers then
      self.selectedRow = self.selectedRow + 1
      local viewLastRow = self.startIndex + ROW_COUNT - 1
      local math_max = math.max
      if self.actionsViewActive then
        if self.selectedRow >= self.totalPlayers - 2 then
          self.startIndex = math_max(1, self.selectedRow - 5)
        elseif self.selectedRow - self.startIndex + 1 > ROW_COUNT - 3 then
          self.startIndex = self.selectedRow - (ROW_COUNT - 4)
        end
      elseif self.selectedRow == viewLastRow and self.selectedRow < self.totalPlayers then
        self:cacheCursorData()
        self:calculateCursorMarginTop()
        self:animateCursor()
        if self.bounceTimer then
          self.bounceTimer:finalize()
          self.bounceTimer = nil
        end
        self.bounceTimer = Timer:new({
          id = "bounceTimer",
          interval = 0.08,
          reps = 1,
          onTimerComplete = function()
            self.startIndex = self.startIndex + 1
            self.selectedRow = self.startIndex + ROW_COUNT - 2
            self:cacheRowData()
            self:cacheCursorData()
            self:calculateCursorMarginTop()
            self:animateCursor()
            self:updatePlayerState()
            self:publishPlayerInfo()
            self.bounceTimer = nil
          end
        })
        self.bounceTimer:start()
        return
      elseif self.selectedRow > viewLastRow and self.startIndex < maxStart then
        self.startIndex = self.startIndex + 1
      end
    end
  else -- Scroll up
    if self.selectedRow > 1 then
      self.selectedRow = self.selectedRow - 1
      local math_max = math.max
      if self.actionsViewActive and self.selectedRow >= self.totalPlayers - 2 then
        self.startIndex = math_max(1, self.selectedRow - 5)
      elseif self.selectedRow < self.startIndex and self.startIndex > 1 then
        self.startIndex = self.startIndex - 1
      end
    end
  end

  local needsUpdate = oldStart ~= self.startIndex
  if needsUpdate then
    self:cacheRowData()
  end
  self:cacheCursorData()
  self:calculateCursorMarginTop()
  self:animateCursor()
  self:updatePlayerState()
  self:publishPlayerInfo()
end

function HubRows:formatForm(tbl, target)
  if target == "form" then
    if tbl.form == 1 then 
      return true
    else
      return false
    end
  elseif target == "formtype" then
    if tbl.type == 1 then
      return 0
    elseif tbl.type == 2 then
      return 100
    else
      return 0
    end
  end
  return 0
end

function HubRows:publishPending()
  if not self.initialized then
    return
  end
  local Publish = self.im.Publish
  local keys = self.publishKeys
  
  Publish("isRowEmpty", self.totalPlayers == 0)

  -- Publish non-row elements first for immediate display
  Publish(keys.cursorHeight, self.cursorHeight)
  Publish(keys.cursorMarginTop, self.cursorMarginTop)
  Publish(keys.cursorVisible, not self.actionsViewActive and self.totalPlayers >= ROW_COUNT)
  Publish(keys.panelPosition, self.panelData[1])
  Publish(keys.panelOpened, self.panelData[2])

  if self.totalPlayers == 0 then
    for i = 1, ROW_COUNT do
      Publish(keys.visible[i], false)
    end
    return
  end

  -- Stop any existing row publish timer
  if self.rowPublishTimer then
    self.rowPublishTimer:finalize()
    self.rowPublishTimer = nil
  end

  -- Function to publish a single row's data (now includes visibility check)
  local function publishSingleRow(i)
    local row = self.rowData[i]
    for j = 1, FIELD_COUNT do
      local value = row[j]
      Publish(keys.rowFields[i][j], value)
    end
    Publish(keys.team[i], row[7])
    if row[6] and row[6].form then
      local formType = self:formatForm(row[6], "formtype")
      Publish(keys.formOne[i], row[6].form == 1)
      Publish(keys.formTwo[i], row[6].form == 2)
      Publish(keys.formTwoType[i], formType)
      Publish(keys.formThree[i], row[6].form == 3)
      Publish(keys.formThreeType[i], formType)   
    end
    local morale = row[8] or 4
    Publish(keys.moraleOne[i], morale == 1)
    Publish(keys.moraleTwo[i], morale == 2)
    Publish(keys.moraleThree[i], morale == 3)
    Publish(keys.moraleFour[i], morale == 4)
    Publish(keys.selected[i], self.cursorData[i])
    for j = 1, COLOR_FIELD_COUNT do
      local color = (colorField[j] == "ovr" and row[4] ~= "") and formatStat(tonumber(row[4])) or "0xFFFFFF"
      Publish(keys.colors[i][j], color)
    end
    local isVisible = row[2].id ~= nil
    Publish(keys.visible[i], isVisible)
  end

  local interval = 0.02  -- Small delay between rows (adjust as needed)

  if self.isInitialLoad and self.totalPlayers >= 10 then
    -- Staggered publishing starting from row 1
    local currentRow = 1
    local function publishRowStep()
      if currentRow > ROW_COUNT then
        self.rowPublishTimer = nil
        return
      end
      publishSingleRow(currentRow)
      currentRow = currentRow + 1
      if currentRow <= ROW_COUNT then
        self.rowPublishTimer = Timer:new({
          id = "rowPublish_" .. currentRow,
          interval = interval,
          reps = 1,
          onTimerComplete = function()
            self.rowPublishTimer = nil
            publishRowStep()
          end
        })
        self.rowPublishTimer:start()
      end
    end
    publishRowStep()
  else
    -- Immediate publishing for all rows
    for i = 1, ROW_COUNT do
      publishSingleRow(i)
    end
  end
end

function HubRows:animateCursor()
  if self.cursorTimer then
    self.cursorTimer:finalize()
    self.cursorTimer = nil
  end

  local math_abs = math.abs
  local math_floor = math.floor
  local startMarginTop = self.cursorMarginTop
  local endMarginTop = self.targetMarginTop
  local duration = 0.1
  local stepInterval = 0.025
  local steps = math_floor(duration / stepInterval)
  local stepSize = (endMarginTop - startMarginTop) / steps

  local function animateStep(step)
    if step > steps then
      self.cursorMarginTop = endMarginTop
      self:publishPending()
      self.cursorTimer = nil
      return
    end

    self.cursorMarginTop = startMarginTop + stepSize * step
    self:publishPending()

    self.cursorTimer = Timer:new({
      id = "cursorTimer_"..step,
      interval = stepInterval,
      reps = 1,
      onTimerComplete = function()
        self.cursorTimer = nil
        animateStep(step + 1)
      end
    })
    self.cursorTimer:start()
  end

  if math_abs(endMarginTop - startMarginTop) > 0.01 then
    animateStep(1)
  else
    self.cursorMarginTop = endMarginTop
    self:publishPending()
  end
end

function HubRows:update(elapsedTime)
  if self.initTimer then
    self.initTimer:update(elapsedTime)
  end
  if self.cursorTimer then
    self.cursorTimer:update(elapsedTime)
  end
  if self.rowPublishTimer then
    self.rowPublishTimer:update(elapsedTime)
  end
  if self.bounceTimer then
    self.bounceTimer:update(elapsedTime)
  end
  if self.renderPauseTimer then
    self.renderPauseTimer:update(elapsedTime)
  end
end

function HubRows:finalize()
  if self.initTimer then
    self.initTimer:finalize()
    self.initTimer = nil
  end
  if self.cursorTimer then
    self.cursorTimer:finalize()
    self.cursorTimer = nil
  end
  if self.rowPublishTimer then
    self.rowPublishTimer:finalize()
    self.rowPublishTimer = nil
  end
  if self.bounceTimer then
    self.bounceTimer:finalize()
    self.bounceTimer = nil
  end
  if self.renderPauseTimer then
    self.renderPauseTimer:finalize()
    self.renderPauseTimer = nil
  end
  local Unsubscribe = self.im.Unsubscribe
  for i = 1, ROW_COUNT do
    for j = 1, FIELD_COUNT do
      Unsubscribe("bnd_row"..rowField[j]..i)
    end
    Unsubscribe("bnd_rowselected"..i)
    for j = 1, COLOR_FIELD_COUNT do
      Unsubscribe("bnd_"..colorField[j].."color"..i)
    end
    Unsubscribe("bnd_rowvisible"..i)
    Unsubscribe("bnd_rowteam"..i)
    Unsubscribe("formOne"..i)
    Unsubscribe("formTwo"..i)
    Unsubscribe("formTwoType"..i)
    Unsubscribe("formThree"..i)
    Unsubscribe("formThreeType"..i)
    Unsubscribe("moraleOne"..i)
    Unsubscribe("moraleTwo"..i)
    Unsubscribe("moraleThree"..i)
    Unsubscribe("moraleFour"..i)
  end
  Unsubscribe("bnd_rowcursor_height")
  Unsubscribe("bnd_rowcursor_marginTop")
  Unsubscribe("bnd_rowcursorvisible")
  for i = 1, 2 do
    Unsubscribe("bnd_panel"..panelAttributes[i])
  end
  Unsubscribe("isRowEmpty")
  for _, binding in ipairs(playerBindings) do
    Unsubscribe(binding)
  end
  self.im.UnregisterAction("act_scrollbtn1")
  self.im.UnregisterAction("act_sort1")
  self.im.UnregisterAction("act_sort2")
  self.im.UnregisterAction("act_sort3")
  self.im.UnregisterAction("act_sort4")
  self.im.UnregisterAction("toreceivedOffers")
  self.im.UnregisterAction("toshortList")
  self.im.UnregisterAction("toscoutedPlayers")
  self.im.UnregisterAction("act_scrollbtn2")
  self.im.UnregisterAction("act_actions")
  for i = 1, ROW_COUNT do
    self.im.UnregisterAction("act_row"..i)
  end
  for i = 1, ACTIONS_BTN_COUNT do
    self.im.UnregisterAction("action"..i)
  end
  currentHubTab = nil
end

return HubRows
local AuctionHouseModel, TableUtil, FormationModel = ...
local Searching = {}
CURRENTCLUBID = nil
CURRENTLEAGUEID = nil
CURRENTNATIONALITYID = nil
-- Add more as needed for other filters
LEAGUEINE = nil
LASTACCESSEDFILTER = nil
local DEFAULT_SEARCH_TYPE = AuctionHouseModel.SEARCH_TYPE_PLAYER
local ID_MIN_BID = 1
local ID_MAX_BID = 2
local ID_MIN_BUY = 3
local ID_MAX_BUY = 4
local BND_MIN_BID = "bnd_min_bid"
local BND_MAX_BID = "bnd_max_bid"
local bndBackgroundCareer = "bnd_background_career"
local bndLeagueColor = "bnd_league_color"
local BND_MIN_BUY = "bnd_min_buy"
local BND_MAX_BUY = "bnd_max_buy"
local BND_SEARCH_BY_NAME_VISIBLE = "bnd_search_by_name_visible"
local BND_AUTO_COMPLETE_LIST_VISIBLE = "bnd_auto_complete_list_visible"
local BND_AUTO_COMPLETE_LIST = "bnd_auto_complete_list"
local BND_AUTO_COMPLETE_TEXT = "bnd_auto_complete_text"
local BND_CLUB_FILTER_ENABLED = "bnd_club_filter_enabled"
local BND_SEARCH_TYPE_ENABLED = "bnd_search_type_enabled"
local filterCategoryDescBindings = {
  "bnd_filter_category_desc_1",
  "bnd_filter_category_desc_2",
  "bnd_filter_category_desc_3",
  "bnd_filter_category_desc_4",
  "bnd_filter_category_desc_5",
  "bnd_filter_category_desc_6"
}

local leagueColors = {
    [0] = 0xFF1E1D27,   -- Premier League (default)
    [13] = 0xFF17001D,  -- League 13
    [16] = 0xFF060E1A,  -- League 16  
    [19] = 0xFF121212,  -- League 19
    [53] = 0xFF09090B,   -- League 53
    [2236] = 0x00073F   -- League 2236                
}
local bndSearchTypeList = "bnd_search_type_list"
local bndSearchTypeIndex = "bnd_search_type_index"
local BND_FILTER_INDEX = "bnd_filter_index"
local ACT_CHANGE_FILTER_INDEX = "act_change_filter_index"
local BND_MAX_VALUE = "bnd_max_value"
local BND_MIN_VALUE = "bnd_min_value"
local BND_FILTER_CATEGORY_DATA = "bnd_filter_category_data"
local BND_FILTER_OVERLAY_VISIBILITY = "bnd_filter_overlay_visibility"
local BND_FILTER_OVERLAY_TITLE = "bnd_filter_overlay_title"
local BND_DEFAULT_CELL_DATA = ""
local BND_FILTER_TABLE_ROWS = "bnd_filter_table_rows"
local BND_FILTER_TABLE_COLUMNS = "bnd_filter_table_columns"
local BND_FILTER_TABLE_WIDTH = "bnd_filter_table_width"
local BND_FILTER_TABLE_HEIGHT = "bnd_filter_table_height"
local BND_FILTER_TABLE_CELL_STYLE = "bnd_filter_table_cell_style"
local BND_FILTER_TABLE_HAS_BULLETS = "bnd_filter_table_has_bullets"
local BND_FILTER_GRID_Y_POS = "bnd_filter_grid_y_pos"
local BND_COUNTRY_INITIALS_VISIBLE = "bnd_country_initials_visible"
local BND_FILTER_TABLE_CONTAINER_HEIGHT = "bnd_filter_table_container_height"
local ACT_AMOUNT_DECREASE = "act_amount_decrease"
local ACT_AMOUNT_INCREASE = "act_amount_increase"
local actSearchTypeChange = "act_change"
local actReset = "act_reset"
local actSearch = "act_search"
local actMinBidChange = "act_min_bid_change"
local actMaxBidChange = "act_max_bid_change"
local actMinBuyChange = "act_min_buy_change"
local actMaxBuyChange = "act_max_buy_change"
local ACT_MIN_BID_FOCUSOUT = "act_min_bid_focusOut"
local ACT_MAX_BID_FOCUSOUT = "act_max_bid_focusOut"
local ACT_MIN_BUY_FOCUSOUT = "act_min_buy_focusOut"
local ACT_MAX_BUY_FOCUSOUT = "act_max_buy_focusOut"
local ACT_TEXT_CHANGE = "act_text_change"
local ACT_CHANGE_OPTION = "act_change_option"
local ACT_FOCUS_OUT = "act_focus_out"
local ACT_FILTER_CATEGORY = {
  "act_ab",
  "act_cf",
  "act_gl",
  "act_mp",
  "act_qs",
  "act_tz"
}
local BND_FILTER_COLOR = {
  "bnd_filter1_color",
  "bnd_filter2_color",
  "bnd_filter3_color",
  "bnd_filter4_color",
  "bnd_filter5_color",
  "bnd_filter6_color"
}
local showFilterOverlayActions = {
  "act_show_filter1_overlay",
  "act_show_filter2_overlay",
  "act_show_filter3_overlay",
  "act_show_filter4_overlay",
  "act_show_filter5_overlay",
  "act_show_filter6_overlay"
}
local ACT_FILTER_OVERLAY_CANCEL = "act_filter_overlay_cancel"
local ACT_FILTER_OVERLAY_ANY = "act_filter_overlay_any"
local FILTERS_COUNT = 6
local LEVEL_OVERLAY_TABLE_WIDTH = 600
local LEVEL_OVERLAY_TABLE_HEIGHT = 316
local LEVEL_OVERLAY_TABLE_CELL_STYLE = "FilterCellLevel"
local DEFAULT_OVERLAY_TABLE_WIDTH = 800
local DEFAULT_OVERLAY_TABLE_HEIGHT = 390
local DEFAULT_OVERLAY_TABLE_CELL_STYLE = "FilterCellGeneric"
local OVERLAY_COUNTRIES_INITIALS_HEIGHT = 56
local COLOR_NORMAL = "0xffffff"
local COLOR_SELECTED = "0xffffff"
local MAX_VALUE = 15000000
local MIN_VALUE = 150
local NIL_VALUE = 0
local INVALID_GRID_INDEX = -1
local FILTER_ID_ANY = -1
local DEFAULT_FORMATION_ID = 0
local DEFAULT_COUNTRY_ID = 75
local DEFAULT_LEAGUE_ID = 76
local DEFAULT_CLUB_ID = 130000
local BND_TAB1_VISIBLE = "bnd_tab1_visible"
local BND_TAB2_VISIBLE = "bnd_tab2_visible"
local BND_TAB3_VISIBLE = "bnd_tab3_visible"
local BND_TAB4_VISIBLE = "bnd_tab4_visible"
local BND_TAB5_VISIBLE = "bnd_tab5_visible"
local BND_TAB6_VISIBLE = "bnd_tab6_visible"
local ACT_MVNPROD = "act_mvnprod"
local TAB1 = 1
local TAB2 = 2
local TAB3 = 3
local TAB4 = 4
local TAB5 = 5
local TAB5 = 6
transferScreen = nil

function setPlayerFilter()
  playerFilter = "Type Name"
  -- Override with text if it exists
    if text then  -- Assuming text is defined somewhere, e.g., as a global or parameter
      playerFilter = text:upper()
    end
    if text == "" then
      playerFilter = "Type Name"
    end
end
function Searching:new(init)
  print("Searching:new()")
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.services = {
    squadmgt = o.api("FUTSquadManagementService"),
    TeamService = o.api("TeamService"),
    myClub = o.api("MyClubService"),
    country = o.api("CountryService"),
    items = o.api("ItemsService"),
    card = o.api("CardService")
  }
  o.playerNameSearchDisabled = o.services.card.IsPlayerNameSearchKillSwitchOn()
  o.teamID = o.services.squadmgt.GetFUTTeamId()
  o.groupIndex = 1
  o.models = {
    AuctionHouseModel = AuctionHouseModel:new({
      api = o.api,
      loc = o.loc,
      nav = o.nav
    }),
    FormationModel = FormationModel:new({
      im = o.im,
      api = o.api,
      loc = o.loc,
      teamID = o.teamID,
      gamemode = "fut"
    })
  }
  o:restorePreviousFilterData()
  o:getAllSearchOptions()
  o:initFilters()
  o:updateGridFilters()
  o:checkMinBidPrice()
  o:checkMinBuyPrice()
  o:addDataBindings()
  o:addChangeBidValueActions()
  o:addSearchActions()
  o:addSearchTypeActionsAndBindings()
  o:addFilterOverlayBindings()
  setPlayerFilter()
  local leagueFilterSelection = Searching:getSelectedOrAnyID(o.filterLeague)
  o:enableClubFilter(leagueFilterSelection ~= FILTER_ID_ANY)
  if automation then
    automation.Add("AuctionHouseStartSearch", {
      AuctionHouseStartSearch = function()
        o:search()
      end
    })
  end
  o.buttonsID = { TAB1, TAB2, TAB3, TAB4, TAB5, TAB6 }
  o.im.Subscribe(BND_TAB1_VISIBLE, function()
  end)
  o.im.Subscribe(bndBackgroundCareer, function()  
    local currentLeague = o:getCurrentLeague()
    o.im.Publish(bndBackgroundCareer, {name = "$CareerTable", id = currentLeague})   
end)
o.im.Subscribe(bndLeagueColor, function()
  local leagueColor = o:getLeagueColor()
  o.im.Publish(bndLeagueColor, leagueColor)
end)
  o.im.Subscribe(BND_TAB2_VISIBLE, function()
  end)
  o.im.Subscribe(BND_TAB3_VISIBLE, function()
  end)
  o.im.Subscribe(BND_TAB4_VISIBLE, function()
  end)
  o.im.Subscribe(BND_TAB5_VISIBLE, function()
  end)
  o.im.Subscribe(BND_TAB6_VISIBLE, function()
  end)
  o:HideSelections()
  o.im.Publish(BND_TAB1_VISIBLE, true)
  o.im.RegisterAction(ACT_MVNPROD, function(actionName, data)
    o:HideSelections()
    if o.buttonsID[data.buttonID + 1] == TAB1 then
      o.im.Publish(BND_TAB1_VISIBLE, true)
    elseif o.buttonsID[data.buttonID + 1] == TAB2 then
      o.im.Publish(BND_TAB2_VISIBLE, true)
    elseif o.buttonsID[data.buttonID + 1] == TAB3 then
      o.im.Publish(BND_TAB3_VISIBLE, true)
    elseif o.buttonsID[data.buttonID + 1] == TAB4 then
      o.im.Publish(BND_TAB4_VISIBLE, true)
    elseif o.buttonsID[data.buttonID + 1] == TAB5 then
      o.im.Publish(BND_TAB5_VISIBLE, true)
    elseif o.buttonsID[data.buttonID + 1] == TAB6 then
      o.im.Publish(BND_TAB6_VISIBLE, true)
    end
  end)
  return o
end

function Searching:getLeagueColor()
    local currentLeague = self:getCurrentLeague()
    return leagueColors[currentLeague] or leagueColors[0] -- Default to Premier League
end

------------------------------------------------------------------------------------------
function Searching:getCurrentLeague()
    if not currentSelectedTeamID then
        return 0 -- Premier League por defecto
    end
    
    -- Intentar obtener la liga del equipo actual
    local teamService = self.api("TeamService")
    if teamService and teamService.GetTeamLeague then
        local leagueID = teamService.GetTeamLeague(currentSelectedTeamID)
        if leagueID and leagueID > 0 then
            return leagueID
        end
    end
    
    local leagueMap = {
        -- 1
[269]=1, [270]=1, [271]=1, [819]=1, [820]=1, [822]=1, [1443]=1, [1447]=1,
[1516]=1, [1786]=1, [1788]=1, [15001]=1,

-- 4
[681]=4, [1750]=4, [670]=4, [100081]=4, [229]=4, [100087]=4, [110724]=4,
[230]=4, [673]=4, [680]=4, [231]=4, [674]=4, [232]=4, [2014]=4, [537]=4,
[675]=4,

-- 7
[1629]=7, [598]=7, [1035]=7, [111052]=7, [517]=7, [1048]=7, [383]=7,
[567]=7, [1598]=7, [1041]=7, [111041]=7, [1719]=7, [569]=7, [568]=7,
[1043]=7, [112472]=7, [1053]=7, [111059]=7, [111057]=7, [130361]=7,

-- 10
[634]=10, [1913]=10, [245]=10, [1903]=10, [247]=10, [1910]=10, [100632]=10,
[1908]=10, [246]=10, [100646]=10, [1906]=10, [1915]=10, [1914]=10,
[100634]=10, [1904]=10, [645]=10, [1971]=10,

-- 13
[13]=13, [1925]=13, [14]=13, [110]=13, [18]=13, [19]=13, [5]=13, [2]=13,
[10]=13, [144]=13, [1]=13, [11]=13, [1799]=13, [1943]=13, [1808]=13,
[7]=13, [9]=13, [8]=13, [1796]=13, [106]=13, [1794]=13,

-- 14
[15]=14, [97]=14, [1800]=14, [1919]=14, [109]=14, [1960]=14, [1952]=14,
[1807]=14, [1806]=14, [12]=14, [3]=14, [1795]=14, [1792]=14,
[1951]=14, [1790]=14, [91]=14, [1801]=14, [88]=14, [1947]=14, [17]=14,
[94]=14, [95]=14, [89]=14,

-- 16
[65]=16, [69]=16, [76]=16, [219]=16, [73]=16, [66]=16, [64]=16, [74]=16,
[1738]=16, [72]=16, [71]=16, [1530]=16, [57]=16, [378]=16, [379]=16,
[1809]=16, [217]=16, [111817]=16,

-- 17
[210]=17, [62]=17, [294]=17, [1816]=17, [111659]=17, [1815]=17,
[115494]=17, [58]=17, [110321]=17, [1814]=17, [1805]=17, [614]=17,
[68]=17, [67]=17, [111273]=17, [111276]=17, [70]=17, [1819]=17,

-- 19
[175]=19, [38]=19, [112172]=19, [23]=19, [36]=19, [32]=19, [1831]=19,
[21]=19, [100409]=19, [1824]=19, [25]=19, [111235]=19, [22]=19,
[110329]=19, [10029]=19, [169]=19, [31]=19, [28]=19,

-- 20
[580]=20, [165]=20, [110500]=20, [10030]=20, [1832]=20, [34]=20, [485]=20,
[166]=20, [171]=20, [110636]=20, [29]=20, [531]=20, [110588]=20,
[110502]=20, [160]=20, [576]=20, [159]=20, [503]=20, [523]=20,

-- 31
[52]=31, [46]=31, [347]=31, [55]=31, [1842]=31, [110556]=31, [206]=31,
[110374]=31, [39]=31, [48]=31, [44]=31, [54]=31, [45]=31, [189]=31,
[50]=31, [1745]=31, [47]=31, [110738]=31, [111974]=31, [111434]=31,

-- 32
[1746]=32, [205]=32, [111811]=32, [1744]=32, [1837]=32, [1843]=32,
[1848]=32, [110373]=32, [110740]=32, [110908]=32, [110915]=32,
[111433]=32, [111657]=32, [111993]=32, [112124]=32, [112168]=32,
[112493]=32, [112494]=32, [190]=32, [110741]=32,

-- 39
[111140]=39, [114161]=39, [697]=39, [114640]=39, [111928]=39, [693]=39,
[688]=39, [112828]=39, [694]=39, [691]=39, [113149]=39, [112893]=39,
[114162]=39, [112885]=39, [687]=39, [112134]=39, [101112]=39,
[112996]=39, [112606]=39, [111651]=39, [698]=39, [111065]=39, [696]=39,
[689]=39, [111139]=39, [111138]=39, [695]=39, [111144]=39, [113018]=39,
[115243]=39,

-- 50
[81]=50, [181]=50, [83]=50, [77]=50, [80]=50, [100805]=50, [78]=50,
[86]=50, [82]=50, [180]=50, [79]=50, [621]=50,

-- 53
[1860]=53, [449]=53, [457]=53, [243]=53, [461]=53, [240]=53, [241]=53,
[453]=53, [448]=53, [450]=53, [483]=53, [110062]=53, [481]=53, [479]=53,
[463]=53, [480]=53, [452]=53, [110827]=53, [1853]=53, [468]=53,

-- 54
[472]=54, [100888]=54, [462]=54, [467]=54, [456]=54, [1861]=54,
[110839]=54, [1854]=54, [459]=54, [260]=54, [110069]=54, [573]=54,
[100851]=54, [10846]=54, [244]=54, [110832]=54, [1968]=54, [242]=54,
[1867]=54, [100852]=54, [110242]=54, [121110]=54,

-- 56
[319]=56, [320]=56, [321]=56, [433]=56, [700]=56, [702]=56, [708]=56,
[710]=56, [711]=56, [1439]=56, [111594]=56, [111705]=56, [112072]=56,
[112126]=56, [112180]=56, [113458]=56,

-- 60
[1797]=60, [1793]=60, [1933]=60, [4]=60, [1930]=60, [1926]=60, [1917]=60,
[1958]=60, [361]=60, [149]=60, [1939]=60, [1932]=60, [1938]=60,
[15015]=60, [1940]=60, [1931]=60, [143]=60, [142]=60, [1928]=60,
[1804]=60, [1923]=60, [1929]=60, [1961]=60, [112259]=60,

-- 65
[305]=65, [306]=65, [423]=65, [445]=65, [563]=65, [753]=65, [834]=65,
[837]=65, [1571]=65, [1572]=65,

-- 66
[301]=66, [420]=66, [873]=66, [1871]=66, [110206]=66, [110745]=66,
[110746]=66, [110747]=66, [110749]=66, [111083]=66, [111086]=66,
[111088]=66, [111091]=66, [111092]=66, [111097]=66, [114004]=66,
[114326]=66, [114393]=66,

-- 67
[312]=67, [315]=67, [100764]=67, [100765]=67, [100767]=67, [100769]=67,
[110102]=67, [110109]=67, [110227]=67, [110231]=67, [110232]=67,
[110239]=67, [112217]=67, [112218]=67, [112261]=67, [130988]=67,
[110222]=67,

-- 68
[326]=68, [325]=68, [110776]=68, [436]=68, [327]=68, [101041]=68,
[101033]=68, [113142]=68, [111339]=68, [101028]=68, [101014]=68,
[101020]=68, [101016]=68, [741]=68, [748]=68, [101026]=68, [101037]=68,
[121174]=68, [121388]=68,

-- 76
[133333]=76, [263]=76, [110870]=76, [393]=76, [1884]=76, [278]=76,
[111596]=76, [110943]=76, [111353]=76, [110981]=76, [115650]=76,
[115651]=76, [115652]=76, [115700]=76, [110969]=76, [110968]=76,
[110986]=76, [112908]=76, [112716]=76, [111008]=76, [111010]=76,
[111014]=76, [110989]=76, [110990]=76, [130109]=76, [257]=76, [130633]=76,
[100135]=76, [100325]=76, [130678]=76, [130733]=76, [101315]=76,
[100820]=76, [101070]=76, [130615]=76, [111969]=76, [264]=76, [100818]=76,
[111282]=76, [417]=76, [110472]=76, [130053]=76, [1202]=76, [112028]=76,
[129105]=76, [129107]=76, [130250]=76, [129108]=76, [129109]=76,
[111160]=76, [129229]=76, [129112]=76, [129113]=76, [129114]=76,
[129148]=76, [129117]=76, [130258]=76, [130927]=76, [129115]=76,
[129116]=76, [130246]=76, [129128]=76, [129129]=76, [129130]=76,
[130244]=76, [129118]=76, [129119]=76, [129155]=76, [129120]=76,
[129121]=76, [130249]=76, [129122]=76, [129123]=76, [129125]=76,
[129126]=76, [129127]=76, [130259]=76, [129205]=76, [130245]=76,
[130929]=76, [129131]=76, [129156]=76, [129157]=76, [129158]=76,
[129197]=76, [129201]=76, [129202]=76, [129203]=76, [130257]=76,
[129159]=76, [129133]=76, [129196]=76, [110941]=76, [130247]=76,
[130930]=76, [130251]=76, [129050]=76, [129134]=76, [129135]=76,
[129136]=76, [129137]=76, [130248]=76, [111172]=76, [129147]=76,
[129195]=76, [129138]=76, [129194]=76, [129145]=76, [129149]=76,
[129209]=76, [130255]=76, [130256]=76, [129143]=76, [129151]=76,
[129217]=76, [129222]=76, [129225]=76, [130243]=76, [130932]=76,
[129140]=76, [129141]=76, [129032]=76, [129033]=76, [129142]=76,
[129200]=76, [130238]=76, [130933]=76, [129152]=76, [110940]=76,
[129198]=76, [130936]=76, [130180]=76, [112090]=76, [101142]=76,
[111727]=76, [112812]=76, [116493]=76, [130184]=76, [130028]=76,
[130025]=76, [130185]=76, [111731]=76, [130187]=76, [130163]=76,
[130026]=76, [130188]=76, [112208]=76, [130227]=76, [115701]=76,
[114423]=76, [114427]=76, [114424]=76, [114426]=76, [114430]=76,
[114428]=76, [114429]=76, [114425]=76, [112190]=76
    }
    
    return leagueMap[currentSelectedTeamID] or 0 -- Premier League por defecto
end
------------------------------------------------------------------------------------------

function Searching:restorePreviousFilterData()
  print("Searching:restorePreviousFilterData()")
  self.selectedFilters = self.services.items.GetPreviousAuctionHouseFilters()
  if self.selectedFilters.SEARCH_TYPE ~= nil then
    self.currSearchType = self.selectedFilters.SEARCH_TYPE
    self.amountMinBid = self.selectedFilters.MIN_PRICE
    self.amountMaxBid = self.selectedFilters.MAX_PRICE
    self.amountMinBuy = self.selectedFilters.MIN_BUY_NOW
    self.amountMaxBuy = self.selectedFilters.MAX_BUY_NOW
    if self.selectedFilters.CARD_NAME ~= nil then
      self.selectedName = self.selectedFilters.CARD_NAME
    else
      self.selectedName = ""
    end
    self.selectedCardID = self.selectedFilters.CARD_ID
  else
    self.currSearchType = DEFAULT_SEARCH_TYPE
    self.amountMinBid = 0
    self.amountMaxBid = 0
    self.amountMinBuy = 0
    self.amountMaxBuy = 0
    self.selectedName = ""
    self.selectedCardID = FILTER_ID_ANY
  end
  self.minBidData = {
    value = self.amountMinBid,
    locValue = self.loc.LocalizeInteger(self.amountMinBid)
  }
  self.maxBidData = {
    value = self.amountMaxBid,
    locValue = self.loc.LocalizeInteger(self.amountMaxBid)
  }
  self.minBuyData = {
    value = self.amountMinBuy,
    locValue = self.loc.LocalizeInteger(self.amountMinBuy)
  }
  self.maxBuyData = {
    value = self.amountMaxBuy,
    locValue = self.loc.LocalizeInteger(self.amountMaxBuy)
  }
end

function Searching:getAllSearchOptions()
  self.searchOptions = self.services.items.GetAllSearchOptions()
end

function Searching:HideSelections()
  self.im.Publish(BND_TAB1_VISIBLE, false)
  self.im.Publish(BND_TAB2_VISIBLE, false)
  self.im.Publish(BND_TAB3_VISIBLE, false)
  self.im.Publish(BND_TAB4_VISIBLE, false)
  self.im.Publish(BND_TAB5_VISIBLE, false)
  self.im.Publish(BND_TAB6_VISIBLE, false)
end

function Searching:initFilters()
  self.gridFilters = {}
  self.defaultFilterName = self.loc.LocalizeString("LTXT_CMN_ANY")
  self.filterLevel = {}
  self:setFilterDescription(self.filterLevel, "Player Name")
  self:setFilterMetaData(self.filterLevel, {
    imageType = "$Head",
    default = self.searchOptions.level.default,
    overlayTitle = self.loc.LocalizeString("LTXT_AH_SELECT_LEVEL"),
    rowsCount = 1,
    columnsCount = 3,
    overlayWidth = LEVEL_OVERLAY_TABLE_WIDTH,
    overlayHeight = LEVEL_OVERLAY_TABLE_HEIGHT,
    hasBullets = false,
    filterCellStyle = LEVEL_OVERLAY_TABLE_CELL_STYLE,
    name = playerFilter
  })
  self:setLevelFilterData()
  self.filterStaffRoles = {}
  self:setFilterDescription(self.filterStaffRoles, self.loc.LocalizeString("\n"))
  self:setFilterMetaData(self.filterStaffRoles, {
    imageType = "$AHIconStaffType",
    default = self.searchOptions.searchStaffRoles.default,
    overlayTitle = "\n",
    rowsCount = 2,
    columnsCount = 3
  })
  self:setStafFilterData()
  self.filterFormation = {}
  self:setFilterDescription(self.filterFormation, self.loc.LocalizeString("\n"))
  self:setFilterMetaData(self.filterFormation, {
    imageType = "$AHIconFormation",
    defaultID = DEFAULT_FORMATION_ID,
    overlayTitle = "\n",
    rowsCount = 2,
    columnsCount = 3
  })
  self:setFormationFilterData()
  self.filterPosition = {}
  self:setFilterDescription(self.filterPosition, self.loc.LocalizeString("\n"))
  self:setFilterMetaData(self.filterPosition, {
    imageType = "$AHIconPosition",
    default = self.searchOptions.position.default,
    overlayTitle = "\n",
    rowsCount = 2,
    columnsCount = 4
  })
  self:setPositionFilterData()
  self.filterNationality = {}
  self:setFilterDescription(self.filterNationality, self.loc.LocalizeString("\n"))
  self:setFilterMetaData(self.filterNationality, {
    imageType = "$Flag128x128",
    defaultID = 0,
    overlayTitle = "\n",
    rowsCount = 2,
    columnsCount = 4,
    overlayContainerHeight = DEFAULT_OVERLAY_TABLE_HEIGHT + OVERLAY_COUNTRIES_INITIALS_HEIGHT
  })
  self:setCountryFilterData()
  self.filterLeague = {}
  self:setFilterDescription(self.filterLeague, self.loc.LocalizeString("\n"))
  self:setFilterMetaData(self.filterLeague, {
    imageType = "$LeagueCrest",
    defaultID = DEFAULT_LEAGUE_ID,
    overlayTitle = "\n",
    rowsCount = 2,
    columnsCount = 3
  })
  self:setLeagueFilterData()
  self.filterClub = {}
  self:setFilterDescription(self.filterClub, self.loc.LocalizeString("\n"))
  self:setFilterMetaData(self.filterClub, {
    imageType = "$Crest",
    defaultID = 333333,
    overlayTitle = "",
    rowsCount = 2,
    columnsCount = 4
  })
  self:setClubFilterData()
  self.filterKitBadgesType = {}
  self:setFilterDescription(self.filterKitBadgesType, self.loc.LocalizeString(""))
  self:setFilterMetaData(self.filterKitBadgesType, {
    imageType = "$AHIconKitBadgesType",
    overlayTitle = self.loc.LocalizeString(""),
    rowsCount = 2,
    columnsCount = 3
  })
  self:setKitBadgesTypeFilterData()
  self.filterEmpty = {gridIndex = INVALID_GRID_INDEX}
  self:setFilterDescription(self.filterEmpty, "", "", true)
  self.filterEmpty.data = {}
  self:setFilterMetaData(self.filterEmpty, {})
  self:setSearchTypeFilterData()
end

function Searching:setFilterDescription(filter, categoryName, isDisabled)
  categoryName = categoryName or ""
  isDisabled = isDisabled or false
  filter.desc = {}
  filter.desc.category = categoryName
  filter.desc.isDisabled = isDisabled
end

function Searching:updateFilterDescription(filterIndex, description)
  print("Searching:updateFilterDescription() filterIndex " .. tostring(filterIndex))
  self.gridFilters[filterIndex].desc.image = description.image
  self.gridFilters[filterIndex].desc.selectionName = description.label
  self.im.Refresh(filterCategoryDescBindings[filterIndex])
end

function Searching:getSelectedFilterDescription(filterIndex, dataID)
  local filter = self.gridFilters[filterIndex]
  local filterData
  if filter == self.filterNationality then
    filterData = filter.data.data
  else
    filterData = filter.data
  end
  for i = 1, #filterData do
    if filterData[i].id == dataID then
      return {
        image = filterData[i].image,
        label = filterData[i].label
      }
    end
  end
end

function Searching:setFilterMetaData(filter, metaData)
  metaData.name = metaData.name or self.defaultFilterName  -- Keep global default as fallback
  metaData.hasOverridingDefault = metaData.defaultID ~= nil
  metaData.defaultID = metaData.defaultID or FILTER_ID_ANY
  if metaData.hasBullets == nil then
    metaData.hasBullets = true
  end
  filter.overlayWidth = metaData.overlayWidth or DEFAULT_OVERLAY_TABLE_WIDTH
  filter.overlayHeight = metaData.overlayHeight or DEFAULT_OVERLAY_TABLE_HEIGHT
  filter.overlayContainerHeight = metaData.overlayContainerHeight or filter.overlayHeight
  filter.overlayTitle = metaData.overlayTitle or ""
  filter.filterCellStyle = metaData.filterCellStyle or DEFAULT_OVERLAY_TABLE_CELL_STYLE
  filter.imageType = metaData.imageType or ""
  filter.rowsCount = metaData.rowsCount
  filter.columnsCount = metaData.columnsCount
  filter.hasBullets = metaData.hasBullets
  filter.default = metaData.default or {
    name = metaData.name,  -- Use the custom name here
    value = metaData.defaultID
  }
  filter.hasOverridingDefault = metaData.hasOverridingDefault
  filter.defaultName = metaData.name  -- Explicitly store the custom name on the filter
end

function Searching:setFilterData(params)
  params.filter.data = {}
  local idKey = params.idKey
  local alternateBG = false
  for i = 1, #params.data do
    local dataID = params.data[i][idKey]
    table.insert(params.filter.data, {
      label = params.data[i].name,
      id = dataID,
      image = {
        name = params.image,
        id = dataID
      },
      alternateBackground = selected,
      imageWidth = 100,
      imageHeight = 100
    })
    if params.filter.columnsCount % 2 == 1 then
      alternateBackground = selected
    elseif i % params.filter.columnsCount ~= 0 then
      alternateBackground = selected
    end
  end
  
  -- Update LEAGUEINE if there's a selected ID
  if params.selectedID then
    LEAGUEINE = params.selectedID
    LASTACCESSEDFILTER = params.filter -- This might be redundant if always called from onFilterOptionSelected, but safe to include
  end
  
  self:restorePreviousSelectedFilterID({
    filter = params.filter,
    id = params.selectedID
  })
end

function Searching:restorePreviousSelectedFilterID(params)
  local filter = params.filter
  if params.id == nil or params.id == FILTER_ID_ANY then
    filter.selectedID = filter.default.value
  else
    filter.selectedID = params.id
  end
end

function Searching:updateGridFilters()
  print("Searching:updateGridFilters() self.currSearchType " .. tostring(self.currSearchType))
  if self.currSearchType == AuctionHouseModel.SEARCH_TYPE_PLAYER then
    self:setFilters({
      self.filterLevel,
      self.filterLeague,
      self.filterClub,
      self.filterNationality,
      self.filterFormation,
      self.filterPosition
    })
  elseif self.currSearchType == AuctionHouseModel.SEARCH_TYPE_STAFF then
    self:setFilters({
      self.filterLevel,
      self.filterStaffRoles
    })
  elseif self.currSearchType == AuctionHouseModel.SEARCH_TYPE_KITS_AND_BADGES then
    self:setFilters({
      self.filterLevel,
      self.filterLeague,
      self.filterClub,
      self.filterKitBadgesType
    })
  elseif self.currSearchType == AuctionHouseModel.SEARCH_TYPE_STADIUM then
    self:setFilters({
      self.filterLevel
    })
  elseif self.currSearchType == AuctionHouseModel.SEARCH_TYPE_BALL then
    self:setFilters({})
  end
  self:updateSelectedFilterIDs()
end

function Searching:setFilters(newFilters)
  for i = 1, FILTERS_COUNT do
    if self.gridFilters[i] then
      self.gridFilters[i].gridIndex = INVALID_GRID_INDEX
    end
  end
  local newFiltersCount = #newFilters
  for i = 1, newFiltersCount do
    self.gridFilters[i] = newFilters[i]
    self.gridFilters[i].gridIndex = i
  end
  local nextFilterIndex = newFiltersCount + 1
  for i = nextFilterIndex, FILTERS_COUNT do
    self.gridFilters[i] = self.filterEmpty
    self.gridFilters[i].gridIndex = INVALID_GRID_INDEX
  end
end

function Searching:updateSelectedFilterIDs()
  for i = 1, FILTERS_COUNT do
    local filter = self.gridFilters[i]
    if not filter.desc.isDisabled then
      local selectedID = filter.selectedID
      local defaultID = filter.default.value
      if selectedID and selectedID ~= defaultID then
        self:setSelectedFilterID(i, selectedID)
      else
        self:setSelectedFilterAny(i)
      end
    end
  end
end

function Searching:setSelectedFilterID(filterIndex, selectedID)
  local filter = self.gridFilters[filterIndex]
  filter.selectedID = selectedID
  local description = self:getSelectedFilterDescription(filterIndex, selectedID)
  if description ~= nil then
    self:updateFilterDescription(filterIndex, description)
  end
  self:updateCellsSelectedStatus(filter)
end

function Searching:setSelectedFilterAny(filterIndex)
  local filter = self.gridFilters[filterIndex]
  filter.selectedID = filter.default.value
  local defaultImage = {
    name = filter.imageType,
    id = filter.default.value
  }
  self:updateFilterDescription(filterIndex, {
    image = defaultImage,
    label = filter.defaultName or self.defaultFilterName  -- Use filter-specific name, fallback to global
  })
  self:updateCellsSelectedStatus(filter)
end

function Searching:updateCellsSelectedStatus(filter)
  local filterData
  if filter == self.filterNationality then
    filterData = filter.data.data
  else
    filterData = filter.data
  end
  for i = 1, #filterData do
    filterData[i].selected = filter.selectedID == filterData[i].id
  end
end

function Searching:addDataBindings()
  print("Searching:addDataBindings()")
  self.im.Subscribe(BND_MAX_VALUE, function()
    self:setMaxValue()
  end)
  self.im.Subscribe(BND_MIN_VALUE, function()
    self:setMinValue()
  end)
  self.im.Subscribe(BND_MIN_BID, function()
    self.im.Publish(BND_MIN_BID, self.minBidData)
  end)
  self.im.Subscribe(BND_MAX_BID, function()
    self.im.Publish(BND_MAX_BID, self.maxBidData)
  end)
  self.im.Subscribe(BND_MIN_BUY, function()
    self.im.Publish(BND_MIN_BUY, self.minBuyData)
  end)
  self.im.Subscribe(BND_MAX_BUY, function()
    self.im.Publish(BND_MAX_BUY, self.maxBuyData)
  end)
  self.im.Subscribe(BND_SEARCH_BY_NAME_VISIBLE, function()
    self.im.Publish(BND_SEARCH_BY_NAME_VISIBLE, self.playerNameSearchDisabled == false)
  end)
  self.im.Subscribe(BND_AUTO_COMPLETE_LIST_VISIBLE, function()
    self.im.Publish(BND_AUTO_COMPLETE_LIST_VISIBLE, false)
  end)
  self.im.Subscribe(BND_AUTO_COMPLETE_LIST, function()
    self:publishAutoCompleteList()
  end)
  self.im.Subscribe(BND_AUTO_COMPLETE_TEXT, function()
    self:publishAutoCompleteText()
  end)
  self.im.Subscribe(bndSearchTypeIndex, function()
    self:publishSearchTypeIndex()
  end)
  self.im.Subscribe(bndSearchTypeList, function()
    self:publishSearchType()
  end)
  for i = 1, #filterCategoryDescBindings do
    self.im.Subscribe(filterCategoryDescBindings[i], function()
      self.im.Publish(filterCategoryDescBindings[i], self.gridFilters[i].desc)
    end)
  end
  self.filterOverlayData = {}
  self.filterOverlayData.selected = false
  self.im.Subscribe(BND_FILTER_CATEGORY_DATA, function()
    self.im.Publish(BND_FILTER_CATEGORY_DATA, self.filterOverlayData)
  end)
end

function Searching:addChangeBidValueActions()
  self.im.RegisterAction(ACT_AMOUNT_DECREASE, function(actionName, id)
    print("[Searching]: " .. actionName .. "(" .. id .. ")")
    local binding = ""
    if id == ID_MIN_BID then
      self.amountMinBid = self.models.AuctionHouseModel:decreaseBid(self.amountMinBid)
      binding = BND_MIN_BID
    elseif id == ID_MAX_BID then
      self.amountMaxBid = self.models.AuctionHouseModel:decreaseBid(self.amountMaxBid)
      self:checkMinBidPrice()
      self:checkMaxBidPrice()
      binding = BND_MAX_BID
    elseif id == ID_MIN_BUY then
      self.amountMinBuy = self.models.AuctionHouseModel:decreaseBid(self.amountMinBuy)
      binding = BND_MIN_BUY
    elseif id == ID_MAX_BUY then
      self.amountMaxBuy = self.models.AuctionHouseModel:decreaseBid(self.amountMaxBuy)
      self:checkMinBuyPrice()
      self:checkMaxBuyPrice()
      binding = BND_MAX_BUY
    end
    self:publishAmountSelector(binding)
  end)
  self.im.RegisterAction(ACT_AMOUNT_INCREASE, function(actionName, id)
    print("[Searching]: " .. actionName .. "(" .. id .. ")")
    local binding = ""
    if id == ID_MIN_BID then
      self.amountMinBid = self.models.AuctionHouseModel:increaseBid(self.amountMinBid)
      self:checkMaxBidPrice()
      binding = BND_MIN_BID
    elseif id == ID_MAX_BID then
      self.amountMaxBid = self.models.AuctionHouseModel:increaseBid(self.amountMaxBid)
      self:checkMaxBidPrice()
      binding = BND_MAX_BID
    elseif id == ID_MIN_BUY then
      self.amountMinBuy = self.models.AuctionHouseModel:increaseBid(self.amountMinBuy)
      self:checkMaxBuyPrice()
      binding = BND_MIN_BUY
    elseif id == ID_MAX_BUY then
      self.amountMaxBuy = self.models.AuctionHouseModel:increaseBid(self.amountMaxBuy)
      self:checkMaxBuyPrice()
      binding = BND_MAX_BUY
    end
    self:publishAmountSelector(binding)
  end)
  self.im.RegisterAction(actMinBidChange, function(actionName, data)
    data.text = tonumber(data.text)
    if not data.text then
      data.text = 0
    end
    self.amountMinBid = data.text
    local data = {
      value = self.amountMinBid,
      locValue = self.loc.LocalizeInteger(data.text)
    }
    self.im.Publish(BND_MIN_BID, data)
  end)
  self.im.RegisterAction(actMaxBidChange, function(actionName, data)
    data.text = tonumber(data.text)
    if not data.text then
      data.text = 0
    end
    self.amountMaxBid = data.text
    local data = {
      value = self.amountMaxBid,
      locValue = self.loc.LocalizeInteger(data.text)
    }
    self.im.Publish(BND_MAX_BID, data)
  end)
  self.im.RegisterAction(actMinBuyChange, function(actionName, data)
    data.text = tonumber(data.text)
    if not data.text then
      data.text = 0
    end
    self.amountMinBuy = data.text
    local data = {
      value = self.amountMinBuy,
      locValue = self.loc.LocalizeInteger(data.text)
    }
    self.im.Publish(BND_MIN_BUY, data)
  end)
  self.im.RegisterAction(actMaxBuyChange, function(actionName, data)
    data.text = tonumber(data.text)
    if not data.text then
      data.text = 0
    end
    self.amountMaxBuy = data.text
    local data = {
      value = self.amountMaxBuy,
      locValue = self.loc.LocalizeInteger(data.text)
    }
    self.im.Publish(BND_MAX_BUY, data)
  end)
  self.im.RegisterAction(ACT_MIN_BID_FOCUSOUT, function(actionName)
    self.amountMinBid = self.models.AuctionHouseModel:checkValue(self.amountMinBid)
    if self.amountMinBid < MIN_VALUE and self.amountMinBid ~= 0 then
      self.amountMinBid = MIN_VALUE
    end
    self:checkMaxBidPrice()
    self:publishAmountSelector(BND_MIN_BID)
  end)
  self.im.RegisterAction(ACT_MAX_BID_FOCUSOUT, function(actionName)
    self.amountMaxBid = self.models.AuctionHouseModel:checkValue(self.amountMaxBid)
    if self.amountMaxBid < MIN_VALUE and self.amountMaxBid ~= 0 then
      self.amountMaxBid = MIN_VALUE
    end
    if self.amountMaxBid ~= 0 then
      self:checkMinBidPrice()
    end
    self:checkMaxBidPrice()
    self:publishAmountSelector(BND_MAX_BID)
  end)
  self.im.RegisterAction(ACT_MIN_BUY_FOCUSOUT, function(actionName)
    self.amountMinBuy = self.models.AuctionHouseModel:checkValue(self.amountMinBuy)
    if self.amountMinBuy < MIN_VALUE and self.amountMinBuy ~= 0 then
      self.amountMinBuy = MIN_VALUE
    end
    self:checkMaxBuyPrice()
    self:publishAmountSelector(BND_MIN_BUY)
  end)
  self.im.RegisterAction(ACT_MAX_BUY_FOCUSOUT, function(actionName)
    self.amountMaxBuy = self.models.AuctionHouseModel:checkValue(self.amountMaxBuy)
    if self.amountMaxBuy < MIN_VALUE and self.amountMaxBuy ~= 0 then
      self.amountMaxBuy = MIN_VALUE
    end
    if self.amountMaxBuy ~= 0 then
      self:checkMinBuyPrice()
    end
    self:checkMaxBuyPrice()
    self:publishAmountSelector(BND_MAX_BUY)
  end)
end

function Searching:addSearchActions()
  self.im.RegisterAction(ACT_TEXT_CHANGE, function(actionName, data)
    if data.text == "" then
      self.autoCompleteList = nil
      self.selectedName = ""
      self.selectedCardID = FILTER_ID_ANY
      GLOBAL_NAME = ""  -- Clear GLOBAL_NAME when text is empty
    else
      self.autoCompleteList = self.services.card.FindAllCardsWithName(data.text)
      local len = table.getn(self.autoCompleteList)
      for i = 1, len do
        self.autoCompleteList[i].data.clickAction = ACT_CHANGE_OPTION
      end
      self.selectedName = data.text
      GLOBAL_NAME = data.text
    end
    self:publishAutoCompleteList()
  end)
  self.im.RegisterAction(ACT_CHANGE_OPTION, function(actionName, data)
    local index = data.id + 1
    self.selectedName = self.autoCompleteList[index].data.NAME
    self.selectedCardID = self.autoCompleteList[index].data.CARD_ID
    GLOBAL_NAME = self.selectedName
    self:publishAutoCompleteText()
    self.im.Publish(BND_AUTO_COMPLETE_LIST_VISIBLE, false)
  end)
  self.im.RegisterAction(ACT_FOCUS_OUT, function(actionName, data)
    self.selectedName = ""
    self.selectedCardID = FILTER_ID_ANY
    GLOBAL_NAME = ""
    self:publishAutoCompleteText()
    self.im.Publish(BND_AUTO_COMPLETE_LIST_VISIBLE, false)
  end)
  self.im.RegisterAction(actSearch, function(bindingName, actionName, index)
    self:search()
  end)
  self.im.RegisterAction(actReset, function(bindingName, actionName, index)
    self:resetAllFilters()
  end)
  for i = 1, #ACT_FILTER_CATEGORY do
    self.im.RegisterAction(ACT_FILTER_CATEGORY[i], function()
      self.groupIndex = i
      self:updateFilterStyles()
      self:getCountriesData()
      self.im.Publish(BND_FILTER_CATEGORY_DATA, self.filterOverlayData)
    end)
  end
end

function Searching:search()
  print("Searching:search()")
  self.params = {}
  if self.currSearchType == AuctionHouseModel.SEARCH_TYPE_PLAYER then
    if self.selectedCardID ~= FILTER_ID_ANY then
      self.params.CARD_ID = self.selectedCardID
      self.params.CARD_NAME = self.selectedName
      SelectedName = self.selectedName
    end
    self.params.CARD_LEVEL = self:getSelectedOrAnyID(self.gridFilters[1])
    self.params.LEAGUE = self:getSelectedOrAnyID(self.gridFilters[2])
    self.params.CLUB = self:getSelectedOrAnyID(self.gridFilters[3])
    self.params.NATIONALITY = self:getSelectedOrAnyID(self.gridFilters[4])
    self.params.FORMATION = self:getSelectedOrAnyID(self.gridFilters[5])
    self.params.POSITION = self:getSelectedOrAnyID(self.gridFilters[6])
  elseif self.currSearchType == AuctionHouseModel.SEARCH_TYPE_STAFF then
    self.params.CARD_LEVEL = self:getSelectedOrAnyID(self.gridFilters[1])
    self.params.ROLE = self:getSelectedOrAnyID(self.gridFilters[2])
  elseif self.currSearchType == AuctionHouseModel.SEARCH_TYPE_KITS_AND_BADGES then
    self.params.CARD_LEVEL = self:getSelectedOrAnyID(self.gridFilters[1])
    self.params.LEAGUE = self:getSelectedOrAnyID(self.gridFilters[2])
    self.params.CLUB = self:getSelectedOrAnyID(self.gridFilters[3])
    self.params.KITBADGE_TYPE = self:getSelectedOrAnyID(self.gridFilters[4])
  elseif self.currSearchType == AuctionHouseModel.SEARCH_TYPE_STADIUM then
    self.params.CARD_LEVEL = self:getSelectedOrAnyID(self.gridFilters[1])
  elseif self.currSearchType == AuctionHouseModel.SEARCH_TYPE_BALL then
  end
  self.params.START = 0
  self.params.NUMBER_RESULTS = 10
  self.params.SEARCH_TYPE = self.currSearchType
  self.params.SEARCH_TYPE_INDEX = self.currSearchType
  self.params.MIN_PRICE = self.amountMinBid
  self.params.MAX_PRICE = self.amountMaxBid
  self.params.MIN_BUY_NOW = self.amountMinBuy
  self.params.MAX_BUY_NOW = self.amountMaxBuy
  self.nav.Event(nil, "evt_to_auction_search_results", {
    param = self.params
  })
end

function Searching:getSelectedOrAnyID(filter)
  if filter.hasOverridingDefault and filter.selectedID == filter.default.value then
    return FILTER_ID_ANY
  end
  return filter.selectedID
end

function Searching:resetAllFilters()
  self:resetFilterSelectedIDs()
  self.selectedName = ""
  self.selectedCardID = FILTER_ID_ANY
  self.autoCompleteList = nil
  self.amountMinBid = 0
  self.amountMaxBid = 0
  self.amountMinBuy = 0
  self.amountMaxBuy = 0
  self:setClubFilterData()
  self:updateGridFilters()
  self:publishAutoCompleteText()
  self:publishSearchTypeIndex()
  self:publishSearchType()
  self:publishAllFilterDescriptions()
  self:publishAmountSelector()
end

function Searching:resetFilterSelectedIDs()
  self.filterStaffRoles.selectedID = self.filterStaffRoles.default.value
  self.filterLevel.selectedID = self.filterLevel.default.value
  self.filterFormation.selectedID = self.filterFormation.default.value
  self.filterPosition.selectedID = self.filterPosition.default.value
  self.filterNationality.selectedID = self.filterNationality.default.value
  self.filterLeague.selectedID = self.filterLeague.default.value
  self.filterClub.selectedID = self.filterClub.default.value
  self.filterKitBadgesType.selectedID = self.filterKitBadgesType.default.value
end

function Searching:addSearchTypeActionsAndBindings()
  self.im.RegisterDataAction(bndSearchTypeIndex, actSearchTypeChange, function(bindingName, actionName, index)
    self:setFilterOverlayVisibility(false)
    self.currSearchType = self.searchType[index + 1].id
    self:resetFilterSelectedIDs()
    self:updateGridFilters()
    self:cascadeLeagueFilterSelection()
    self:publishSearchTypeIndex()
    self:publishAllFilterDescriptions()
  end)
  self.searchTypeToggleEnabled = true
  self.im.Subscribe(BND_SEARCH_TYPE_ENABLED, function()
    self.im.Publish(BND_SEARCH_TYPE_ENABLED, self.searchTypeToggleEnabled)
  end)
end

function Searching:addFilterOverlayBindings()
  self.isFilterOverlayVisible = false
  self.im.Subscribe(BND_FILTER_OVERLAY_VISIBILITY, function()
    self.im.Publish(BND_FILTER_OVERLAY_VISIBILITY, self.isFilterOverlayVisible)
  end)
  self.filterOverlayTitle = ""
  self.im.Subscribe(BND_FILTER_OVERLAY_TITLE, function()
    self.im.Publish(BND_FILTER_OVERLAY_TITLE, self.filterOverlayTitle)
  end)
  self.filterOverlayTableRowsCount = 0
  self.im.Subscribe(BND_FILTER_TABLE_ROWS, function()
    self.im.Publish(BND_FILTER_TABLE_ROWS, self.filterOverlayTableRowsCount)
  end)
  self.filterOverlayTableColumnsCount = 0
  self.im.Subscribe(BND_FILTER_TABLE_COLUMNS, function()
    self.im.Publish(BND_FILTER_TABLE_COLUMNS, self.filterOverlayTableColumnsCount)
  end)
  self.filterOverlayTableWidth = 0
  self.im.Subscribe(BND_FILTER_TABLE_WIDTH, function()
    self.im.Publish(BND_FILTER_TABLE_WIDTH, self.filterOverlayTableWidth)
  end)
  self.filterOverlayTableHeight = 0
  self.im.Subscribe(BND_FILTER_TABLE_HEIGHT, function()
    self.im.Publish(BND_FILTER_TABLE_HEIGHT, self.filterOverlayTableHeight)
  end)
  self.filterOverlayTableCellStyleName = ""
  self.im.Subscribe(BND_FILTER_TABLE_CELL_STYLE, function()
    self.im.Publish(BND_FILTER_TABLE_CELL_STYLE, self.filterOverlayTableCellStyleName)
  end)
  self.filterOverlayTableHasBullets = true
  self.im.Subscribe(BND_FILTER_TABLE_HAS_BULLETS, function()
    self.im.Publish(BND_FILTER_TABLE_HAS_BULLETS, self.filterOverlayTableHasBullets)
  end)
  self.filterGridYPos = 0
  self.im.Subscribe(BND_FILTER_GRID_Y_POS, function()
    self.im.Publish(BND_FILTER_GRID_Y_POS, self.filterGridYPos)
  end)
  self.filterOverlayContainerHeight = 0
  self.im.Subscribe(BND_FILTER_TABLE_CONTAINER_HEIGHT, function()
    self.im.Publish(BND_FILTER_TABLE_CONTAINER_HEIGHT, self.filterOverlayContainerHeight)
  end)
  self.countryInitialsVisible = false
  self.im.Subscribe(BND_COUNTRY_INITIALS_VISIBLE, function()
    self.im.Publish(BND_COUNTRY_INITIALS_VISIBLE, self.countryInitialsVisible)
  end)
  self.defaultCellData = {
    label = "",
    image = {},
    id = FILTER_ID_ANY,
    imageWidth = 0,
    imageHeight = 0
  }
  self.im.Subscribe(BND_DEFAULT_CELL_DATA, function()
    self.im.Publish(BND_DEFAULT_CELL_DATA, self.defaultCellData)
  end)
  for i = 1, #showFilterOverlayActions do
    self.im.RegisterAction(showFilterOverlayActions[i], function(actionName)
      self:disableFilterTileActions()
      self:showFilterOverlay(i)
    end)
  end
  for i = 1, #BND_FILTER_COLOR do
    self.im.Subscribe(BND_FILTER_COLOR[i], function()
      self:updateFilterStyles()
    end)
  end
  self.im.RegisterDataAction(BND_FILTER_INDEX, ACT_CHANGE_FILTER_INDEX, function(bindingName, actionName, selectedID)
    self:onFilterOptionSelected(selectedID)
  end)
  self.clubFilterIsEnabled = false
  self.im.Subscribe(BND_CLUB_FILTER_ENABLED, function()
    self.im.Publish(BND_CLUB_FILTER_ENABLED, self.clubFilterIsEnabled)
  end)
  self.im.RegisterAction(ACT_FILTER_OVERLAY_CANCEL, function(actionName)
    self:onFilterOptionCancelSelected()
  end)
  self.im.RegisterAction(ACT_FILTER_OVERLAY_ANY, function(actionName)
    self:onFilterOptionAnySelected()
  end)
end

function Searching:disableFilterTileActions()
  for i = 1, #showFilterOverlayActions do
    self.im.ChangeActionState(showFilterOverlayActions[i], self.im.GetActionState("INVALID"))
  end
end

function Searching:enableFilterTileActions()
  for i = 1, #showFilterOverlayActions do
    self.im.ChangeActionState(showFilterOverlayActions[i], self.im.GetActionState("VALID"))
  end
end

function Searching:updateFilterStyles()
  for i = 1, #BND_FILTER_COLOR do
    self.im.Publish(BND_FILTER_COLOR[i], COLOR_NORMAL)
  end
  self.im.Publish(BND_FILTER_COLOR[self.groupIndex], COLOR_SELECTED)
end

function Searching:onFilterOptionSelected(selectedID)
  print("Searching:onFilterOptionSelected() selectedID " .. tostring(selectedID))
  self:setSelectedFilterID(self.overlayFilterIndex, selectedID)
  
  -- Update LASTACCESSEDFILTER to track which filter was last accessed
  if self.overlayFilterIndex == self.filterClub.gridIndex then
    LASTACCESSEDFILTER = self.filterClub
  elseif self.overlayFilterIndex == self.filterLeague.gridIndex then
    LASTACCESSEDFILTER = self.filterLeague
  elseif self.overlayFilterIndex == self.filterNationality.gridIndex then
    LASTACCESSEDFILTER = self.filterNationality
  elseif self.overlayFilterIndex == self.filterPosition.gridIndex then
    LASTACCESSEDFILTER = self.filterPosition
    -- Add more conditions for other filters if needed
  end
  
  -- Update LEAGUEINE with the selected ID
  LEAGUEINE = selectedID
  
  -- Update the corresponding placeholder variable
  self:updatePlaceholderVariable()
  
  self:checkAndCascadeLeagueFilterSelection()
  self:setFilterOverlayVisibility(false)
end

function Searching:updatePlaceholderVariable()
  if LASTACCESSEDFILTER == self.filterClub then
    CURRENTCLUBID = LEAGUEINE
  elseif LASTACCESSEDFILTER == self.filterLeague then
    CURRENTLEAGUEID = self.leagueIDs[LEAGUEINE]
  elseif LASTACCESSEDFILTER == self.filterNationality then
    CURRENTNATIONALITYID = LEAGUEINE
  elseif LASTACCESSEDFILTER == self.filterPosition then
    CURRENTPOSITIONID = LEAGUEINE
    -- Add more conditions for other filters if needed
  end
end

function Searching:onFilterOptionAnySelected()
  print("Searching:onFilterOptionAnySelected()")
  self:setSelectedFilterAny(self.overlayFilterIndex)
  self:checkAndCascadeLeagueFilterSelection()
  self:setFilterOverlayVisibility(false)
end

function Searching:checkAndCascadeLeagueFilterSelection()
  print("Searching:checkAndCascadeLeagueFilterSelection()")
  if self.overlayFilterIndex == self.filterLeague.gridIndex and self.filterClub.gridIndex ~= INVALID_GRID_INDEX and self.filterClub.gridIndex ~= nil then
    self:setSelectedFilterAny(self.filterClub.gridIndex)
    self:setClubFilterData()
    self:publishClubList()
    local leagueFilterSelection = Searching:getSelectedOrAnyID(self.filterLeague)
    self:enableClubFilter(leagueFilterSelection ~= FILTER_ID_ANY)
  end
end

function Searching:cascadeLeagueFilterSelection()
  print("Searching:cascadeLeagueFilterSelection()")
  if self.filterClub.gridIndex ~= INVALID_GRID_INDEX and self.filterClub.gridIndex ~= nil then
    self:setSelectedFilterAny(self.filterClub.gridIndex)
    self:setClubFilterData()
    self:publishClubList()
    local leagueFilterSelection = Searching:getSelectedOrAnyID(self.filterLeague)
    self:enableClubFilter(leagueFilterSelection ~= FILTER_ID_ANY)
  end
end

function Searching:onFilterOptionCancelSelected()
  self:setFilterOverlayVisibility(false)
end

function Searching:showFilterOverlay(filterIndex)
  if self.isFilterOverlayVisible then
    return
  end
  print("Searching:showFilterOverlay() filterIndex " .. tostring(filterIndex))
  print("Searching:showFilterOverlay() categoryName " .. tostring(self.gridFilters[filterIndex].category))
  local selectedFilter = self.gridFilters[filterIndex]
  if selectedFilter ~= self.filterEmpty then
    self.overlayFilterIndex = filterIndex
    if selectedFilter == self.filterNationality then
      self.filterGridYPos = OVERLAY_COUNTRIES_INITIALS_HEIGHT
      self.im.Refresh(BND_FILTER_GRID_Y_POS)
      self.countryInitialsVisible = true
      self.im.Refresh(BND_COUNTRY_INITIALS_VISIBLE)
    else
      self.filterGridYPos = 0
      self.im.Refresh(BND_FILTER_GRID_Y_POS)
      self.countryInitialsVisible = false
      self.im.Refresh(BND_COUNTRY_INITIALS_VISIBLE)
    end
    self:setFilterOverlayTableWidth(selectedFilter.overlayWidth)
    self:setFilterOverlayTableHeight(selectedFilter.overlayHeight)
    self:setFilterOverlayTableRows(selectedFilter.rowsCount)
    self:setFilterOverlayTableColumns(selectedFilter.columnsCount)
    self:setFilterOverlayTableCellStyle(selectedFilter.filterCellStyle)
    self:setFilterOverlayTableHasBullets(selectedFilter.hasBullets)
    self:setFilterOvelayContainerHeight(selectedFilter.overlayContainerHeight)
    self:updateFilterOverlayTitle(selectedFilter.overlayTitle)
    self:setFilterOverlayData(selectedFilter.data)
    self:setFilterOverlayVisibility(true)
  end
end

function Searching:setFilterOverlayTableWidth(overlayWidth)
  self.filterOverlayTableWidth = overlayWidth
  self.im.Refresh(BND_FILTER_TABLE_WIDTH)
end

function Searching:setFilterOverlayTableHeight(overlayHeight)
  self.filterOverlayTableHeight = overlayHeight
  self.im.Refresh(BND_FILTER_TABLE_HEIGHT)
end

function Searching:setFilterOverlayTableRows(rowsCount)
  self.filterOverlayTableRowsCount = rowsCount
  self.im.Refresh(BND_FILTER_TABLE_ROWS)
end

function Searching:setFilterOverlayTableColumns(columnsCount)
  self.filterOverlayTableColumnsCount = columnsCount
  self.im.Refresh(BND_FILTER_TABLE_COLUMNS)
end

function Searching:setFilterOverlayTableCellStyle(styleName)
  self.filterOverlayTableCellStyleName = styleName
  self.im.Refresh(BND_FILTER_TABLE_CELL_STYLE)
end

function Searching:setFilterOverlayTableHasBullets(hasBullets)
  self.filterOverlayTableHasBullets = hasBullets
  self.im.Refresh(BND_FILTER_TABLE_HAS_BULLETS)
end

function Searching:updateFilterOverlayTitle(title)
  self.filterOverlayTitle = title
  self.im.Refresh(BND_FILTER_OVERLAY_TITLE)
end

function Searching:setFilterOverlayData(data)
  self.filterOverlayData = data
  self.im.Refresh(BND_FILTER_CATEGORY_DATA)
end

function Searching:setFilterOverlayVisibility(visible)
  print("Searching:setFilterOverlayVisibility() visible " .. tostring(visible))
  if self.isFilterOverlayVisible ~= visible then
    if visible == false then
      self:enableFilterTileActions()
    end
    self.isFilterOverlayVisible = visible
    self.im.Refresh(BND_FILTER_OVERLAY_VISIBILITY)
    self.searchTypeToggleEnabled = not self.isFilterOverlayVisible
    self.im.Refresh(BND_SEARCH_TYPE_ENABLED)
  end
end

function Searching:setFilterOvelayContainerHeight(overlayHeight)
  self.filterOverlayContainerHeight = overlayHeight
  self.im.Refresh(BND_FILTER_TABLE_CONTAINER_HEIGHT)
end

function Searching:enableClubFilter(value)
  print("Searching:enableClubFilter() enable: " .. tostring(value))
  if self.clubFilterIsEnabled ~= value then
    self.clubFilterIsEnabled = value
    self.im.Refresh(BND_CLUB_FILTER_ENABLED)
  end
end

function Searching:checkMinBidPrice()
  if self.amountMaxBid ~= 0 then
    if self.amountMinBid >= self.amountMaxBid then
      self.amountMinBid = self.models.AuctionHouseModel:decreaseBid(self.amountMaxBid)
    end
    self:publishAmountSelector(BND_MIN_BID)
  end
end

function Searching:checkMaxBidPrice()
  if self.amountMaxBid ~= 0 then
    if self.amountMinBid >= self.amountMaxBid then
      self.amountMaxBid = self.models.AuctionHouseModel:increaseBid(self.amountMinBid)
    end
    self:publishAmountSelector(BND_MAX_BID)
  end
end

function Searching:checkMinBuyPrice()
  if self.amountMaxBuy ~= 0 then
    if self.amountMinBuy >= self.amountMaxBuy then
      self.amountMinBuy = self.models.AuctionHouseModel:decreaseBid(self.amountMaxBuy)
    end
    self:publishAmountSelector(BND_MIN_BUY)
  end
end

function Searching:checkMaxBuyPrice()
  if self.amountMaxBuy ~= 0 then
    if self.amountMinBuy >= self.amountMaxBuy then
      self.amountMaxBuy = self.models.AuctionHouseModel:increaseBid(self.amountMinBuy)
    end
    self:publishAmountSelector(BND_MAX_BUY)
  end
end

function Searching:setMaxValue()
  local data = {
    value = MAX_VALUE,
    locValue = self.loc.LocalizeInteger(MAX_VALUE)
  }
  self.im.Publish(BND_MAX_VALUE, data)
end

function Searching:setMinValue()
  local data = {
    value = NIL_VALUE,
    locValue = self.loc.LocalizeInteger(NIL_VALUE)
  }
  self.im.Publish(BND_MIN_VALUE, data)
end

function Searching:setSearchTypeFilterData()
  print("Searching:setSearchTypeFilterData()")
  local searchTypeData = self.searchOptions.searchType.data.data
  self.searchType = {}
  for i = 1, #searchTypeData do
    table.insert(self.searchType, {
      text = searchTypeData[i].name,
      GLOBAL_NAME = text,
      id = searchTypeData[i].value
    })
  end
end

function Searching:setStafFilterData()
  print("Searching:setStafFilterData()")
  local staffData = self.searchOptions.searchStaffRoles.data.data
  self:setFilterData({
    filter = self.filterStaffRoles,
    data = staffData,
    idKey = "value",
    image = self.filterStaffRoles.imageType,
    selectedID = self.selectedFilters.ROLE
  })
end

function Searching:setLevelFilterData()
  print("Searching:setLevelFilterData()")
  local levelData = self.searchOptions.level.data.data
  self:setFilterData({
    filter = self.filterLevel,
    data = levelData,
    idKey = "value",
    image = self.filterLevel.imageType,
    selectedID = self.selectedFilters.CARD_LEVEL
  })
end

function Searching:setPositionFilterData()
  print("Searching:setPositionFilterData()")
  local positionData = self.searchOptions.position.data.data
  self:setFilterData({
    filter = self.filterPosition,
    data = positionData,
    idKey = "value",
    image = self.filterPosition.imageType,
    selectedID = self.selectedFilters.POSITION
  })
end

function Searching:setConsumableTypeFilterData()
  print("Searching:setConsumableTypeFilterData()")
  local consumableTypeData = self.searchOptions.consumableType.data.data
  self:setFilterData({
    filter = self.filterConsumablesType,
    data = consumableTypeData,
    idKey = "value",
    image = self.filterConsumablesType.imageType,
    selectedID = self.selectedFilters.DEVELOPMENT_TYPE
  })
end

function Searching:setKitBadgesTypeFilterData()
  print("Searching:setKitBadgesTypeFilterData()")
  local kitBadgesData = self.searchOptions.kitBadgesType.data.data
  self:setFilterData({
    filter = self.filterKitBadgesType,
    data = kitBadgesData,
    idKey = "value",
    image = self.filterKitBadgesType.imageType,
    selectedID = self.selectedFilters.KITBADGE_TYPE
  })
end

function Searching:setTrainingTypeFilterData()
  print("Searching:setTrainingTypeFilterData()")
  local trainingTypeData = self.searchOptions.trainingTypes.data.data
  self:setFilterData({
    filter = self.filterTrainingType,
    data = trainingTypeData,
    idKey = "value",
    image = self.filterTrainingType.imageType,
    selectedID = self.selectedFilters.TRAINING_TYPE
  })
end

function Searching:setFormationFilterData()
  print("Searching:setFormationFilterData()")
  local formations = self.models.FormationModel:getFormationList()
  self:setFilterData({
    filter = self.filterFormation,
    data = formations,
    idKey = "id",
    image = self.filterFormation.imageType,
    selectedID = self.selectedFilters.FORMATION
  })
end

function Searching:setCountryFilterData()
  print("Searching:setCountryFilterData()")
  local prevID = self.selectedFilters.NATIONALITY
  if prevID == nil or prevID == FILTER_ID_ANY then
    self:getCountriesData()
  else
    local found = false
    for i = 1, #ACT_FILTER_CATEGORY do
      self.groupIndex = i
      self:getCountriesData()
      local filterData = self.filterNationality.data.data
      for i = 1, #filterData do
        if filterData[i].id == prevID then
          found = true
          break
        end
      end
      if found == true then
        break
      end
    end
  end
  self:restorePreviousSelectedFilterID({
    filter = self.filterNationality,
    id = self.selectedFilters.NATIONALITY
  })
end

function Searching:getCountriesData()
  print("Searching:getCountriesData")
  local countryNames = {}
  local sortAscending = true
  self.countriesData = nil
  self.countriesData = self.services.country.GetGroupIDs(sortAscending, self.groupIndex)
  local alternateBG = false
  for i = 1, #self.countriesData do
    local countryData = self.countriesData[i]
    table.insert(countryNames, {
      label = countryData.name,
      image = {
        name = "$Flag128x128",
        id = countryData.id
      },
      id = countryData.id,
      alternateBackground = selected,
      imageWidth = 128,
      imageHeight = 128
    })
    if i % 4 ~= 0 then
      alternateBackground = selected
    end
  end
  self.filterNationality.data = {
    index = self.groupIndex,
    data = countryNames
  }
  self.filterOverlayData = self.filterNationality.data
end

-- Define a global placeholder for the selected league and club
GlobalSelections = {
  leagueID = nil,
  clubID = nil
}

function Searching:setLeagueFilterData()
  print("Searching:setLeagueFilterData()")
  
  -- Define the allowed leagues with their respective crests
  self.leagueIDs = { 13, 14, 60, 16, 17, 19, 20, 31, 32, 10, 308, 350, 50, 53, 54, 68, 39, 4, 2235, 2254, 2255 }

  
  -- Clear existing data and set new data for the league filter
  self.filterLeague.data = {}
  local alternateBG = false
  for i = 1, #self.leagueIDs do
    table.insert(self.filterLeague.data, {
      label = self.loc.LocalizeString("LeagueName_Abbr15_" .. self.leagueIDs[i]), -- Use label based on the ID
      image = {
        name = "$LeagueCrest",
        id = self.leagueIDs[i]
      },
      id = i,
      alternateBackground = selected,
      imageWidth = 210,
      imageHeight = 70
    })
    alternateBG = not alternateBG
  end
  
  -- Store the selected league in the global placeholder
  GlobalSelections.leagueID = self.filterLeague.selectedID
  
  -- Restore previous selected league filter if applicable
  self:restorePreviousSelectedFilterID({
    filter = self.filterLeague,
    id = self.selectedFilters.LEAGUE
  })
end

function Searching:setClubFilterData()
  print("Searching:setClubFilterData() self.filterLeague.selectedID " .. tostring(self.filterLeague.selectedID))
  
  -- Declare teamIDs here, it will be set based on leagueIndex
  
  -- Assign teamIDs based on leagueIndex
  local teams = self.services.TeamService.GetTeams(self.leagueIDs[self.filterLeague.selectedID], 0, 0, false) -- Fetch real team I
  teamIDs = {}
  for i = 1, #teams do
    table.insert(teamIDs, teams[i].id)
  end
  
  currentLeagueIndex = self.filterLeague.selectedID

  -- Function to get the team name and crest for a given team ID
  local function getTeamInfo(teamID)
    return {
      id = teamID,
      name = self.loc.LocalizeString("TeamName_Abbr15_"..teamID),
      crest = "crest_" .. teamID  -- Crest based on teamID
    }
  end
  
  -- Prepare the team data based on the selected league
  local teamData = {}
  for _, teamID in ipairs(teamIDs) do
    if teamID ~= currentSelectedTeamID then
      table.insert(teamData, getTeamInfo(teamID))
    end
  end

  -- Store the selected club in the global placeholder as the teamID on the grid
  GlobalSelections.clubID = self.filterClub.selectedID  -- This is now the actual teamID
  
  -- Set the filter data with the prepared team data
  self:setFilterData({
    filter = self.filterClub,
    data = teamData,
    idKey = "id",
    image = self.filterClub.imageType,
    selectedID = self.selectedFilters.CLUB,
    imageWidth = 0,
    imageHeight = 0
  })
end

function Searching:publishClubList()
  self.filterClub.selectedID = self.filterClub.default.value
  self.im.Refresh(filterCategoryDescBindings[3])
end

function Searching:publishSearchTypeIndex()
  self.im.Publish(bndSearchTypeIndex, self:getIndexFromSearchType(self.currSearchType))
  local isSearchByNameVisible = self.currSearchType == AuctionHouseModel.SEARCH_TYPE_PLAYER and self.playerNameSearchDisabled == false
  self.im.Publish(BND_SEARCH_BY_NAME_VISIBLE, isSearchByNameVisible)
end

function Searching:publishSearchType()
  self.im.Publish(bndSearchTypeList, {
    data = self.searchType,
    index = self:getIndexFromSearchType(self.currSearchType)
  })
end

function Searching:publishAmountSelector(bindingName)
  if bindingName == nil then
    self:publishAmountSelector(BND_MIN_BID)
    self:publishAmountSelector(BND_MAX_BID)
    self:publishAmountSelector(BND_MIN_BUY)
    self:publishAmountSelector(BND_MAX_BUY)
  else
    if bindingName == BND_MIN_BID then
      self.minBidData.value = self.amountMinBid
      self.minBidData.locValue = self.loc.LocalizeInteger(self.amountMinBid)
    elseif bindingName == BND_MAX_BID then
      self.maxBidData.value = self.amountMaxBid
      self.maxBidData.locValue = self.loc.LocalizeInteger(self.amountMaxBid)
    elseif bindingName == BND_MIN_BUY then
      self.minBuyData.value = self.amountMinBuy
      self.minBuyData.locValue = self.loc.LocalizeInteger(self.amountMinBuy)
    elseif bindingName == BND_MAX_BUY then
      self.maxBuyData.value = self.amountMaxBuy
      self.maxBuyData.locValue = self.loc.LocalizeInteger(self.amountMaxBuy)
    end
    self.im.Refresh(bindingName)
  end
end

function Searching:publishAllFilterDescriptions()
  for i = 1, #filterCategoryDescBindings do
    self.im.Refresh(filterCategoryDescBindings[i])
  end
end

function Searching:publishAutoCompleteList()
  if self.autoCompleteList == nil then
    self.im.Publish(BND_AUTO_COMPLETE_LIST_VISIBLE, false)
  else
    self.im.Publish(BND_AUTO_COMPLETE_LIST, self.autoCompleteList)
    self.im.Publish(BND_AUTO_COMPLETE_LIST_VISIBLE, true)
  end
end

function Searching:publishAutoCompleteText()
  self.im.Publish(BND_AUTO_COMPLETE_TEXT, {
    data = self.selectedName
  })
end

function Searching:getIndexFromSearchType(searchType)
  local toggleIndex = 0
  for i = 1, #self.searchType do
    if self.searchType[i].id == searchType then
      toggleIndex = i - 1
    end
  end
  return toggleIndex
end

function Searching:finalize()
  self.models.FormationModel:finalize()
  self.models.AuctionHouseModel:finalize()
  self.im.Unsubscribe(BND_MIN_BID)
  self.im.Unsubscribe(BND_MAX_BID)
  self.im.Unsubscribe(BND_MIN_BUY)
  self.im.Unsubscribe(BND_MAX_BUY)
  self.im.Unsubscribe(BND_SEARCH_BY_NAME_VISIBLE)
  self.im.Unsubscribe(BND_AUTO_COMPLETE_LIST_VISIBLE)
  self.im.Unsubscribe(BND_AUTO_COMPLETE_LIST)
  self.im.Unsubscribe(BND_AUTO_COMPLETE_TEXT)
  self.im.Unsubscribe(BND_MIN_VALUE)
  self.im.Unsubscribe(BND_MAX_VALUE)
  for i = 1, #filterCategoryDescBindings do
    self.im.Unsubscribe(filterCategoryDescBindings[i])
  end
  self.im.Unsubscribe(bndSearchTypeList)
  self.im.Unsubscribe(bndSearchTypeIndex)
  self.im.Unsubscribe(BND_FILTER_CATEGORY_DATA)
  self.im.Unsubscribe(BND_FILTER_OVERLAY_VISIBILITY)
  self.im.Unsubscribe(BND_FILTER_OVERLAY_TITLE)
  self.im.Unsubscribe(BND_FILTER_TABLE_ROWS)
  self.im.Unsubscribe(BND_FILTER_TABLE_COLUMNS)
  self.im.Unsubscribe(BND_FILTER_TABLE_WIDTH)
  self.im.Unsubscribe(BND_FILTER_TABLE_HEIGHT)
  self.im.Unsubscribe(BND_FILTER_TABLE_CELL_STYLE)
  self.im.Unsubscribe(BND_FILTER_TABLE_HAS_BULLETS)
  self.im.Unsubscribe(BND_FILTER_GRID_Y_POS)
  self.im.Unsubscribe(BND_TAB1_VISIBLE)
  self.im.Unsubscribe(BND_TAB2_VISIBLE)
  self.im.Unsubscribe(BND_TAB3_VISIBLE)
  self.im.Unsubscribe(BND_TAB4_VISIBLE)
  self.im.Unsubscribe(BND_TAB5_VISIBLE)
  self.im.Unsubscribe(bndLeagueColor)
  self.im.Unsubscribe(BND_TAB6_VISIBLE)
  self.im.Unsubscribe(BND_COUNTRY_INITIALS_VISIBLE)
  self.im.Unsubscribe(BND_FILTER_TABLE_CONTAINER_HEIGHT)
  self.im.Unsubscribe(BND_DEFAULT_CELL_DATA)
  for i = 1, #BND_FILTER_COLOR do
    self.im.Unsubscribe(BND_FILTER_COLOR[i])
  end
  self.im.UnregisterAction(ACT_AMOUNT_DECREASE)
  self.im.UnregisterAction(ACT_AMOUNT_INCREASE)
  self.im.UnregisterAction(actSearch)
  self.im.UnregisterAction(actReset)
  self.im.UnregisterAction(actMinBidChange)
  self.im.UnregisterAction(actMaxBidChange)
  self.im.UnregisterAction(actMinBuyChange)
  self.im.UnregisterAction(actMaxBuyChange)
  self.im.UnregisterDataAction(bndSearchTypeIndex, actSearchTypeChange)
  self.im.UnregisterDataAction(BND_FILTER_INDEX, ACT_CHANGE_FILTER_INDEX)
  self.im.UnregisterAction(ACT_MIN_BID_FOCUSOUT)
  self.im.UnregisterAction(ACT_MAX_BID_FOCUSOUT)
  self.im.UnregisterAction(ACT_MIN_BUY_FOCUSOUT)
  self.im.UnregisterAction(ACT_MAX_BUY_FOCUSOUT)
  self.im.UnregisterAction(ACT_TEXT_CHANGE)
  self.im.UnregisterAction(ACT_CHANGE_OPTION)
  self.im.UnregisterAction(ACT_MVNPROD)
  self.im.UnregisterAction(ACT_FOCUS_OUT)
  for i = 1, #ACT_FILTER_CATEGORY do
    self.im.UnregisterAction(ACT_FILTER_CATEGORY[i])
  end
  for i = 1, #showFilterOverlayActions do
    self.im.UnregisterAction(showFilterOverlayActions[i])
  end
  self.im.Unsubscribe(BND_CLUB_FILTER_ENABLED)
  self.im.Unsubscribe(BND_SEARCH_TYPE_ENABLED)
  self.im.UnregisterAction(ACT_FILTER_OVERLAY_ANY)
  self.im.UnregisterAction(ACT_FILTER_OVERLAY_CANCEL)
  self.nav.Event(nil, "evt_hide_blocking_load")
end

return Searching

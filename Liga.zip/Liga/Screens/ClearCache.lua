local Cache = {}

function Cache:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.cont = o.data.cont
  o.cont()
  return o
end

return Cache
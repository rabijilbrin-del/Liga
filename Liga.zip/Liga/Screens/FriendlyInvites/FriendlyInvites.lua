local Invitation = {}
local _nav = _nav or nil
local TournamentName = {"Champions Trophy", "American Challenge Cup", "Invitational Cup"}
local FCPopup, Modes, sessionVars = ...
local bindings = { "message", "TName1", "TName2", "TName3", "T1team1",  "T1team2", "T1team3", "T1team4",  "T1team5", "T1team6", "T1team7", "T2team1",  "T2team2", "T2team3", "T2team4",  "T2team5", "T2team6", "T2team7", "T3team1",  "T3team2", "T3team3", "T3team4",  "T3team5", "T3team6", "T3team7", "TPrice1", "TPrice2", "TPrice3"}
local TOURNEYS = 3
local FRIENDLYID = 175
function Invitation:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  for i = 1, #bindings do
    o.im.Subscribe("bnd_" .. bindings[i], function()
    o:_displayData()
    end)
  end
  o.teams = {[1] = {}, [2] = {}, [3] = {}}
  o:setTourneyTeams()
  for btns = 1, 3 do
    o.im.RegisterAction("act_btn" .. btns, function(actionName, data)
      o:_clickEvent(btns)
    end)
  end
  o.im.RegisterAction("act_skip", function(actionName, data)
      o:_skipInvites()
    end)
  return o
end

function Invitation:setTourneyTeams()
  local leagueTeams = sessionVars.get("LeagueTeams")
  local userLg = sessionVars.get("currentUserLeagueID")
  local leagueID = {13, 16, 19, 31, 53}  
  for i = 1, TOURNEYS do
    local teams = leagueTeams[leagueID[i]]
    local add = 0
    for j = 1, 7 do
      if teams[j] == currentSelectedTeamID then
        add = 1
      end
      self.teams[i][j] = teams[j + add]
    end
  end 
end

function Invitation:_displayData()
  self.im.Publish("bnd_message", "You have been invited to participate in a pre-season friendly tournament. This is a great opportunity to get to know all the players in your squad, experiment with different tactics,\nand get the team ready for the upcoming season. There is also prize money for doing well in the tournament.")
    for i = 1, 3 do
      self.im.Publish("bnd_TName" ..i, TournamentName[i])
      self.im.Publish("bnd_TPrice" ..i, "£6,200,000")
      for j = 1, 7 do
        self.im.Publish("bnd_T" ..i .. "team" ..j, { name = "$Crest", id = self.teams[i][j] or 0 })      
      end
    end
end


function Invitation:_clickEvent(btnId)
  self:displayConfirmationMsg(btnId)
end

function Invitation:_skipInvites()
  self:displayConfirmationMsg(nil)
end

function Invitation:displayConfirmationMsg(response)
  _nav = Modes:getNav()
  local message = ""
  local buttonData = {}
  if response == nil then
    message = "Do you want to advance skipping all Friendlies Invitations?"
    buttonData = {"Yes", "No"}
  else
    message = "Advance with " .. TournamentName[response] .. "?"
    buttonData = {"Yes", "No"}
  end
  Modes:validateInput(message, buttonData, response, function() self.teams[response][8] = currentSelectedTeamID local teams = sessionVars.get("LeagueTeams") teams[FRIENDLYID] = self.teams[response] sessionVars.set("LeagueTeams", teams) return self.teams[response] end, {"Advance",  "Back"})
end

return Invitation
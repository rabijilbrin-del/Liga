local sessionVars, Timer, CareerModeLeagues, Brain, PlayerAge, playerData, Config = ...
local TourneyTeamSelector = {}
local PLAYER_COUNT = 11
local TeamList = {
241,243,481,461,483,240,1,5,9,10,11,18,69,65,66,219,73,32,22,21,34,112172,1831,175,38,39,110374,44,45,46,47,48,52,245,1906,246
			}

local function subscribeBindings(im, bindings, context)
  for _, binding in ipairs(bindings) do
    for i = 1, binding.count do
      im.Subscribe(binding.prefix .. i .. (binding.suffix or ""), function() binding.callback(context) end)
    end
  end
end

function TourneyTeamSelector:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.dirs = {"left", "right"}
  o.keys = {"team", "country", "league"}
  o.nav = o.data.nav
  o.careerType = o.data.careertype
  o.CountryService = o.api("CountryService")
  o.TeamService = o.api("TeamService")
  local MatchSetup = o.api("MatchSetupService")
  local gameStateService = o.api("GameStateService")
  local settingsService = o.api("SettingsService")
  local BrowserService = o.api("BrowserService")
  local MiscService = o.api("MiscService")
  local CardService = o.api("CardService")
  o.SquadManagementService = o.api("SquadMgtService")
  o.FUTUserInfoService = o.api("FUTUserInfoService")
  o.TacticsService = o.api("TacticsService")
  o.im.Subscribe("theme", function()
    o.im.Publish("theme", {name = "$CareerTable", id = 2236})
  end)
  o.im.Subscribe("bnd_compcrest", function()
    o.im.Publish("bnd_compcrest", {name = "$LeagueLogo",id = 2236})
  end)
     o.focus          = "tourney"        -- "tourney" | "team"
    o.tourneyList    = {2236}           -- list of league/tournament IDs available to pick
    o.teamsData      = {}               -- built below from TeamList
    o.currentIndex   = 1
    o.currentLeagueID = o.tourneyList[1] -- pre-select the first (and usually only) tournament 
  o.teamsData = {}
  
  local teamIDs = TeamList
  for i = 1, #teamIDs do
    local id = teamIDs[i]
    local teamInfo = {
      id = id,
      name = string.upper(o.loc.LocalizeString("TeamName_Abbr15_" .. id)),
      starRating = o.SquadManagementService.GetTeamInfo(id).starRating,
      squad = o.SquadManagementService.GetCurrentPlayerLineup(0, id, 0)
    }
    table.insert(o.teamsData, teamInfo)
  end
  
  
  o.currentTeamIndex = 1
   local bindings = {    
    {prefix = "bnd_posTop", count = PLAYER_COUNT, callback = function(self) self:publishPlayers() end},
    {prefix = "bnd_posLeft", count = PLAYER_COUNT, callback = function(self) self:publishPlayers() end},
    {prefix = "bnd_kit", count = 3, callback = function(self) self:publishTeamInfo() end}
  }
  subscribeBindings(o.im, bindings, o)

  o.im.RegisterAction("act_back", function()
    o.nav.Event(nil, "evt_hide_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/TourneyTeamSelector/TeamSelector.vvm"})
  end)

  o.im.Subscribe("bnd_teamname", function()
    if o.teamsData[o.currentTeamIndex] then
      o.im.Publish("bnd_teamname", o.teamsData[o.currentTeamIndex].name)
    else
      o.im.Publish("bnd_teamname", "NO TEAM SELECTED")
    end
  end)

  o.im.Subscribe("bnd_teamcrest", function()
    if o.teamsData[o.currentTeamIndex] then
      o.im.Publish("bnd_teamcrest", {name = "$Crest", id = o.teamsData[o.currentTeamIndex].id})
    else
      o.im.Publish("bnd_teamcrest", {})
    end
  end)
  o.im.Subscribe("bnd_teamcountry", function()
    if o.teamsData[o.currentTeamIndex] then
      o:publishTeamInfo()
    else
      o.im.Publish("bnd_teamcountry", {})
    end
  end)
  o.im.Subscribe("bnd_teamleague", function()
    if o.teamsData[o.currentTeamIndex] then
      o:publishTeamInfo()
    else
      o.im.Publish("bnd_teamleague", {})
    end
  end)
  o.im.Subscribe("bnd_starplayer", function()
    if o.teamsData[o.currentTeamIndex] then
      o:publishTeamInfo()
    else
      o.im.Publish("bnd_starplayer", {})
    end
  end)

  o.im.Subscribe("bnd_teamstar", function()
    if o.teamsData[o.currentTeamIndex] then
      o:loadTeams()
    else
      o.im.Publish("bnd_teamstar", 0)
    end
  end)


  for i = 1, 2 do
    o.im.RegisterAction("act_toggleT" .. o.dirs[i], function()
      o:toggleTeam(i)
    end)
  end
  o.im.RegisterAction("act_advance", function()
    o:advance()
  end)
  o:loadTeams()

  return o
end

function TourneyTeamSelector:publishPlayersBool()
  for i = 1, PLAYER_COUNT do
    self.im.Publish("bnd_selected" .. i, false)
  end
end

function TourneyTeamSelector:publishPlayers()
  local teamID = self.teamsData[self.currentTeamIndex] and self.teamsData[self.currentTeamIndex].id
  
  if not teamID then
    self.im.Publish("bnd_posTop" .. i, 0)
    self.im.Publish("bnd_posLeft" .. i, 0)
    return
  end
  local homeKitId = string.format("%s_%s_%s", 0, teamID, 0)
  local formationKey = "formation" .. (self.TacticsService.GetFormation(0, teamID))
  local players = self.SquadManagementService.GetCurrentPlayerLineup(0, teamID, 0) or {}
  local formation = Config.FORMATION_POSITIONS[formationKey] or {}
  for i = 1, PLAYER_COUNT do
    local player = players[i] or {}    
    self.im.Publish("bnd_posTop" .. i, (formation[i] or {}).top or 0)
    self.im.Publish("bnd_posLeft" .. i, (formation[i] or {}).left or 0)
  end
end

function TourneyTeamSelector:publishTeamInfo()
  local team = self.teamsData[self.currentTeamIndex] and self.teamsData[self.currentTeamIndex].id
  local squad = self.teamsData[self.currentTeamIndex] and self.teamsData[self.currentTeamIndex].squad
  Lid = self.CountryService.GetLeagueInfoByTeamId(team).id
  local Cid = self.CountryService.GetCountryInfoByLeagueId(Lid).id
  local highestOvr = 0
  local starPlayer = nil
  local Kits = {0,1,3}
  for i = 1, 3 do
    local KitId = string.format("%s_%s_%s", Kits[i], team, 0)
    self.im.Publish("bnd_kit" .. i, {name = "$Kits", id = KitId})
  end
  
  for i = 1, #squad do
    if squad[i].rating > highestOvr then
      highestOvr = squad[i].rating
      starPlayer = squad[i].CARD_ID
    end
  end
  
  self.im.Publish("bnd_starplayer", {name = "$Head", id = starPlayer})
  self.im.Publish("bnd_teamleague", {name = "$LeagueLogo", id = Lid})
  self.im.Publish("bnd_teamcountry", {name = "$Flag128x128", id = Cid})  
end

function TourneyTeamSelector:advance()
  currentSelectedTeamID = self.teamsData[self.currentTeamIndex].id
  sessionVars.set("currentUserLeagueID", self.currentLeagueID)  
  self.nav.Event(nil, "evt_enter_cm")
  self.nav.Event(nil, "evt_hide_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/TeamSelector/TeamSelector.vvm"})
end

function TourneyTeamSelector:loadTeams()
  local TeamService = self.api("TeamService")
  
  if self.teamsData[self.currentTeamIndex] then
    self:publishPlayers()
    self:publishTeamInfo()
    self.im.Publish("bnd_teamname", self.teamsData[self.currentTeamIndex].name)
    self.im.Publish("bnd_teamcrest", {name = "$Crest", id = self.teamsData[self.currentTeamIndex].id})
    self.im.Publish("bnd_teamstar", (self.teamsData[self.currentTeamIndex].starRating or self.SquadManagementService.GetTeamInfo(id).starRating))
    
    --self.im.Publish("bnd_stadiumname", breakString(teamStadiums[self.teamsData[self.currentTeamIndex].id] or "-"))
  else
    self.im.Publish("bnd_teamname", "NO TEAM SELECTED")
    self.im.Publish("bnd_teamcrest", {})
    self.im.Publish("bnd_teamstar", 0)
    self.im.Publish("bnd_stadiumname", "-")
    self.im.Publish("bnd_teamleague", {name = "$LeagueLogo", id = 0})
    self.im.Publish("bnd_teamcountry", {name = "$Flag128x128", id = 0})
    self.im.Publish("bnd_teamstar", 0)
  end
end

function TourneyTeamSelector:toggleTeam(dir)
  if #self.teamsData == 0 then
    return
  end
  if dir == 1 then
    self.currentTeamIndex = self.currentTeamIndex - 1
    if self.currentTeamIndex < 1 then
      self.currentTeamIndex = #self.teamsData
    end
  else
    self.currentTeamIndex = self.currentTeamIndex + 1
    if self.currentTeamIndex > #self.teamsData then
      self.currentTeamIndex = 1
    end
  end
  self:publishPlayers()
  self:publishTeamInfo()
  self.im.Publish("bnd_teamname", self.teamsData[self.currentTeamIndex].name)
  self.im.Publish("bnd_teamcrest", {name = "$Crest", id = self.teamsData[self.currentTeamIndex].id})
  self.im.Publish("bnd_teamstar", self.teamsData[self.currentTeamIndex].starRating)   
  
end

return TourneyTeamSelector
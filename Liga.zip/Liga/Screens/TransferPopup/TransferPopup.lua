-- TransferPopup.lua
local TransferPopup = {}

function TransferPopup:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.tp = o.data
  
  o.im.Subscribe("obj1", function()
    o.im.Publish("obj1", {name = "$Head", id = o.tp.hid})
  end)
  
  o.im.Subscribe("obj2", function()
    o.im.Publish("obj2", {name = "$Crest", id = o.tp.cid1})
  end)
  o.im.Subscribe("obj3", function()
    o.im.Publish("obj3", {name = "$Crest", id = o.tp.cid2})
  end)
o.im.Subscribe("text1", function()
    o.im.Publish("text1", o.tp.t1)
  end)
  o.im.Subscribe("text2", function()
    o.im.Publish("text2", o.tp.t2)
  end)
  o.im.Subscribe("text3", function()
    o.im.Publish("text3", o.tp.t3)
  end)
 o.im.RegisterAction("close", o.tp.close)

  return o
end

function TransferPopup:finalize()
end

return TransferPopup
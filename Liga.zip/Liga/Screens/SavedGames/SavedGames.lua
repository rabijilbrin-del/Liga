local sessionVars, Timer, CareerModeLeagues, Brain, PlayerAge, playerData, Config = ...
local SavedGames = {}

local function subscribeBindings(im, bindings, context)
  for _, binding in ipairs(bindings) do
    for i = 1, binding.count do
      im.Subscribe(binding.prefix .. i .. (binding.suffix or ""), function() binding.callback(context) end)
    end
  end
end

function SavedGames:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.dirs = {"left", "right"}
  local save = "/flows/mainflow/gamemodes/Liga/Screens/SavedGames/ValidateSave" .. tostring(1) .. ".vvm"
  o.nav.Event = (function(...) o.data.nav.Event(...) o.data.nav.Event(nil, "evt_open_overlay", {vvm = save}) o.data.nav.Event(nil, "evt_hide_overlay") o.data.nav.Event(nil, "evt_open_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/SavedGames/SavedGames.vvm"}) end)
  o.careerType = o.data.careertype
  o.CountryService = o.api("CountryService")
  o.TeamService = o.api("TeamService")
  local MatchSetup = o.api("MatchSetupService")
  local gameStateService = o.api("GameStateService")
  local settingsService = o.api("SettingsService")
  local BrowserService = o.api("BrowserService")
  local MiscService = o.api("MiscService")
  local CardService = o.api("CardService")
  o.SquadManagementService = o.api("SquadMgtService")
  o.FUTUserInfoService = o.api("FUTUserInfoService")
  o.TacticsService = o.api("TacticsService")
  o.im.Subscribe("bnd_compcrest", function()
    o.im.Publish("bnd_compcrest", {name = "$LeagueLogo",id = 2236})
  end)
  
  o.currIdx = 1

  o.im.RegisterAction("act_back", function()
    o.nav.Event(nil, "evt_hide_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/SavedGames/TeamSelector.vvm"})
  end)

  o.im.Subscribe("bnd_teamname", function()
    if o.teamsData[o.currentTeamIndex] then
      o.im.Publish("bnd_teamname", o.teamsData[o.currentTeamIndex].name)
    else
      o.im.Publish("bnd_teamname", "NO TEAM SELECTED")
    end
  end)

  o.im.Subscribe("bnd_teamcrest", function()
    if o.teamsData[o.currentTeamIndex] then
      o.im.Publish("bnd_teamcrest", {name = "$Crest", id = o.teamsData[o.currentTeamIndex].id})
    else
      o.im.Publish("bnd_teamcrest", {})
    end
  end)
  
  currIdx = currIdx or 1

  for i = 1, 2 do
    o.im.RegisterAction("act_toggleT" .. o.dirs[i], function()
      o:toggleTeam(i)
    end)
  end
  o.im.RegisterAction("act_advance", function()
    o:advance()
  end)
  o:loadList(currIdx)

  return o
end

function SavedGames:loadList(idx)
  --local save = "/flows/mainflow/gamemodes/Liga/Screens/SavedGames/ValidateSave" .. tostring(idx) .. ".vvm"
  --self.nav.Event(nil, "evt_hide_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/SavedGames/SavedGames.vvm"})
  --self.nav.Event(nil, "evt_open_overlay", {vvm = save})
  --self.nav.Event(nil, "evt_hide_overlay")
  --self.nav.Event(nil, "evt_open_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/SavedGames/SavedGames.vvm"})
  if save then
    self:publishTeamInfo(save.currentSelectedTeamID)
  else
    self.nav.Event(nil, "evt_hide_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/TeamSelector/TeamSelector.vvm"})
  end
end

function SavedGames:publishTeamInfo(id)
  self.im.Publish("bnd_teamname", self.loc.LocalizeString("TeamName_Abbr15_" .. id))
  self.im.Publish("bnd_teamcrest", {name = "$Crest", id = id})
end

function SavedGames:advance()
  currentSelectedTeamID = self.teamsData[self.currentTeamIndex].id
  sessionVars.set("currentUserLeagueID", self.currentLeagueID)  
  self.nav.Event(nil, "evt_enter_cm")
  self.nav.Event(nil, "evt_hide_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/TeamSelector/TeamSelector.vvm"})
end

function SavedGames:toggleTeam(dir)
  currIdx = (dir == 1) and (currIdx - 1) or (currIdx + 1)
  currIdx = (currIdx < 1) and 1 or currIdx
  self:loadList(currIdx)
end

return SavedGames
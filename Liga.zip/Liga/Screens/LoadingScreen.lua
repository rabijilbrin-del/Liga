local LoadingScreen = {}
local sessionVars, CareerModeLeagues, glInstancePasser = ...
local bndBackgroundCareer = "bnd_background_career"
local bndBanner = "bnd_banner"
local colorBanner = {
    [0] = 0xFF1E1D27,   -- Premier League (default)
    [13] = 0x9400AD,  -- League 13
    [16] = 0x0100C8,  -- League 16  
    [19] = 0xFF121212,  -- League 19
    [31] = 0x001177,   -- League 31        
    [53] = 0xFF5F2C37,   -- League 53
    [350] = 0x003803,   -- League 350    
    [2236] = 0x001CFF,   -- League 2236              
    [2235] = 0x072A7E   -- League 2235                           
}
function LoadingScreen:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.setInstance = o.data.getInstance
  o.im.Subscribe("bnd_progress", function()
  end)
  o.test = "Loading Screen Loaded"
  
  if o.data and o.data.getInstance then
    o.setInstance(o)
  end
  o.im.Subscribe(bndBackgroundCareer, function()  
  local currentLeague = o:getCurrentLeague()
    o.im.Publish(bndBackgroundCareer, {name = "$CareerTable", id = currentLeague})
  end)
o.im.Subscribe("bnd_league_logo", function()
    local leagueLogo = o:getLeagueLogo()
    o.im.Publish("bnd_league_logo", leagueLogo)
end)  
o.im.Subscribe(bndBanner, function()
  local colorBanner = o:getcolorBanner()
  o.im.Publish(bndBanner, colorBanner)
end)
  return o
end

function LoadingScreen:getLeagueLogo()
    local currentLeague = self:getCurrentLeague()
    return {
        name = "$LeagueCrest",  
        id = currentLeague
    }
end

function LoadingScreen:getcolorBanner()
    local currentLeague = self:getCurrentLeague()
    return colorBanner[currentLeague] or colorBanner[0] 
end

function LoadingScreen:getCurrentLeague()    
    local league = selectedLeague

    if not league and CareerModeLeagues then
        if CareerModeLeagues.getCurrentLeague then
            league = CareerModeLeagues:getCurrentLeague()
        end
    end

    return league or sessionVars.get("currentUserLeagueID") or 0
end


return LoadingScreen
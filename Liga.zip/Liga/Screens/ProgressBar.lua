local ProgressBar = {}


function ProgressBar:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.setInstance = o.data.getInstance
  o.im.Subscribe("bnd_progress", function()
  end)
  o.step = function(prog, clbk) if type(prog) ~= "number" then return false o.im.Publish("bnd_progress", prog) clbk() return true end
  o.stream = o.data.start
  
  
  
  if o.data and o.data.getInstance then
    o.setInstance(o.step)
  end
  
  o.stream()

  return o
end


return ProgressBar
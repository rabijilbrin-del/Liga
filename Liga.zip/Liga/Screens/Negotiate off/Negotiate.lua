-- @!League Management Module by DAVUNPES
-- A professional, extendable football league simulation framework
local FCPopup, sessionVars, Squads = ...
local League = {}

-- Configuration Constants
League.Config = {
    MinValue = 0,
    MaxValue = 500000000,
    BaseTransferValue = 15000000,
    BidAdjustments = {
        MinBid = { Id = 1, Step = 50000, Binding = "bnd_min_bid" },
        MaxBid = { Id = 2, Step = 1000000, Binding = "bnd_max_bid" },
        MinBuy = { Id = 3, Step = 100000, Binding = "bnd_min_buy" },
        MaxBuy = { Id = 4, Step = 500000, Binding = "bnd_max_buy" }
    },
    Actions = {
        DecreaseBid = "act_amount_decrease",
        IncreaseBid = "act_amount_increase",
        Search = "act_search",
        Reset = "act_reset",
        AdvanceMatch = "act_advance",
        Back = "act_back"
    },
    Bindings = {
        MatchList = "bnd_match_list",
        TeamName = "bnd_teamname_label",
        TeamStats = "bnd_teamstats_label",
        Status = "bnd_status_label",
        TransferValue = "bnd_transfervalue_label",
        TeamLogo = "bnd_team_logo",
        PlayerHead = "bnd_player_head",
        TeamMatchProgress = "bnd_teammp_label",
        FinishLabel = "bnd_finish_label"
    }
}

-- Helper Functions
local function adjustBidValue(currentValue, increment, step)
    local newValue = math.floor(currentValue / step) * step + increment
    return math.max(League.Config.MinValue, math.min(newValue, League.Config.MaxValue))
end

-- Mock External Functions (Remove if already defined in your environment)

-- Constructor
function League:new(options)
    local instance = options or {}
    setmetatable(instance, self)
    self.__index = self
    instance.playerTeam = instance.data.team
    instance.playerForTransfer = instance.data.player
    instance.nav = instance.data.nav
    instance.back = instance.data.back
    instance.services = {
        settings = instance.api("SettingsService"),
        squadManagement = instance.api("SquadMgtService")
    }
    instance.FCPopup = FCPopup:new({nav = instance.nav})
    instance.currentOptions = instance.services.settings.GetCurrentOptions()

    -- Player and Team Visuals
    instance.teamVisuals = {
        crest = { name = "$Crest", id = instance.playerTeam or 1 },
        playerHead = { name = "$Head", id = instance.playerForTransfer or 1001 }
    }
    
    -- State Initialization
    instance.bidValues = {
        minBid = League.Config.MinValue,
        maxBid = League.Config.MinValue,
        minBuy = League.Config.MinValue,
        maxBuy = League.Config.MinValue
    }
    instance.rejectionCount = 0
    instance.playerStats = { rating = 50, position = "CM", age = 25 }
    
    -- Initialize and Setup
    instance:setupBindings()
    instance:setupBidActions()
    instance:setupSearchActions()
    instance:publishPlayerCount()
    instance:updateBidPlaceholders()
    instance:subscribeToEvents()
    instance:fetchPlayerStats()
    instance:publishMatchLabel() -- Ensure UI updates on initialization
    
    return instance
end

function League:displayConfirmationMsg(message, evt, callbck, error)
  local buttonData = error and {"Back"} or {"Yes", "No"}
  self.FCPopup:getResponse(message, buttonData, function(clickResponse)
    if clickResponse == 1 then
      if callbck then
        callbck()
        return
      end
      if error then
        self.nav.Event(nil, "evt_hide_overlay")
      else
        self.nav.Event(nil, evt)
      end
    end
  end)
end

-- Player Stats
function League:fetchPlayerStats()
    print("Fetching player stats...")
    local players = self.services.squadManagement.GetCurrentPlayerLineup(0, self.playerTeam or 1, 0) or {}
    for _, player in ipairs(players) do
        if player.CARD_ID == (self.playerForTransfer or 1001) then
            self.playerStats.rating = player.rating or 50
            self.playerStats.position = player.position or "CM"
            self.playerStats.age = GetPlayerAge(self.playerForTransfer or 1001) or 25
            break
        end
    end
end

-- Event Handling
function League:subscribeToEvents()
    print("Subscribing to events...")
    local eventBindings = {
        League.Config.Bindings.TeamName, League.Config.Bindings.TeamStats, 
        League.Config.Bindings.Status, League.Config.Bindings.TransferValue,
        League.Config.Bindings.TeamLogo, League.Config.Bindings.PlayerHead,
        League.Config.Bindings.TeamMatchProgress, League.Config.Bindings.FinishLabel,
        League.Config.Bindings.MatchList
    }
    for _, binding in ipairs(eventBindings) do
        self.im.Subscribe(binding, function() self:publishMatchLabel() end)
    end
    self.im.RegisterAction(League.Config.Actions.AdvanceMatch, function() self.nav.Event(nil, "evt_hide_overlay") end)
    self.im.RegisterAction(League.Config.Actions.Back, function() self.nav.Event(nil, "evt_hide_overlay") end)
end

-- Data Bindings
function League:setupBindings()
    print("Setting up bindings...")
    local function publishBid(binding, value)
        self.im.Publish(binding, { value = 1, locValue = self.loc.LocalizeInteger(value) })
        self:updateBidPlaceholders()
    end
    self.im.Subscribe(League.Config.BidAdjustments.MinBid.Binding, function() publishBid(League.Config.BidAdjustments.MinBid.Binding, self.bidValues.minBid) end)
    self.im.Subscribe(League.Config.BidAdjustments.MaxBid.Binding, function() publishBid(League.Config.BidAdjustments.MaxBid.Binding, TVALUE or 0) end)
    self.im.Subscribe(League.Config.BidAdjustments.MinBuy.Binding, function() publishBid(League.Config.BidAdjustments.MinBuy.Binding, self.bidValues.minBuy) end)
    self.im.Subscribe(League.Config.BidAdjustments.MaxBuy.Binding, function() publishBid(League.Config.BidAdjustments.MaxBuy.Binding, self.bidValues.maxBuy) end)
end

-- Bid Adjustments
function League:setupBidActions()
    local function adjustBid(isIncrease, _, id)
        local config = League.Config.BidAdjustments
        local adjustment
        if id == config.MinBid.Id then
            adjustment = config.MinBid
            self.bidValues.minBid = adjustBidValue(self.bidValues.minBid, isIncrease and adjustment.Step or -adjustment.Step, adjustment.Step)
        elseif id == config.MaxBid.Id then
            adjustment = config.MaxBid
            self.bidValues.maxBid = adjustBidValue(self.bidValues.maxBid, isIncrease and adjustment.Step or -adjustment.Step, adjustment.Step)
        elseif id == config.MinBuy.Id then
            adjustment = config.MinBuy
            self.bidValues.minBuy = adjustBidValue(self.bidValues.minBuy, isIncrease and adjustment.Step or -adjustment.Step, adjustment.Step)
        elseif id == config.MaxBuy.Id then
            adjustment = config.MaxBuy
            self.bidValues.maxBuy = adjustBidValue(self.bidValues.maxBuy, isIncrease and adjustment.Step or -adjustment.Step, adjustment.Step)
            WAGEMAX = self.bidValues.maxBuy
        end
        self:publishAmountSelector(adjustment.Binding)
        self:publishPlayerCount()
        self:findPlayerInfo(self.playerForTransfer or 1001, self.playerTeam or 1)
        self:publishMatchLabel()
    end
    
    self.im.RegisterAction(League.Config.Actions.DecreaseBid, function(actionName, id) adjustBid(false, actionName, id) end)
    self.im.RegisterAction(League.Config.Actions.IncreaseBid, function(actionName, id) adjustBid(true, actionName, id) end)
end

-- Search and Reset Actions
function League:setupSearchActions()
    print("Setting up search actions...")
    self.im.RegisterAction(League.Config.Actions.Search, function() self:search() end)
    self.im.RegisterAction(League.Config.Actions.Reset, function() self:resetFilters() end)
end

-- Price Placeholders
function League:updateBidPlaceholders()
    print("Updating bid placeholders...")
    PRICEMIN, PRICEMAX = self.bidValues.minBid, self.bidValues.maxBid
    WAGEMIN, WAGEMAX = self.bidValues.minBuy, self.bidValues.maxBuy
end

-- Cleanup
function League:finalize()
    print("Finalizing league...")
    local actions = {
        League.Config.Actions.AdvanceMatch, League.Config.Actions.DecreaseBid,
        League.Config.Actions.IncreaseBid, League.Config.Actions.Search, League.Config.Actions.Reset
    }
    local bindings = {
        League.Config.Bindings.MatchList, League.Config.BidAdjustments.MinBid.Binding,
        League.Config.BidAdjustments.MaxBid.Binding, League.Config.BidAdjustments.MinBuy.Binding,
        League.Config.BidAdjustments.MaxBuy.Binding, League.Config.Bindings.TeamName,
        League.Config.Bindings.TeamStats, League.Config.Bindings.Status,
        League.Config.Bindings.TransferValue, League.Config.Bindings.TeamLogo,
        League.Config.Bindings.PlayerHead, League.Config.Bindings.TeamMatchProgress,
        League.Config.Bindings.FinishLabel
    }
    for _, action in ipairs(actions) do self.im.UnregisterAction(action) end
    for _, binding in ipairs(bindings) do self.im.Unsubscribe(binding) end
    self.rivalMatches = {}
end

-- Player and Match Management
function League:publishMatchLabel()
    print("publishMatchLabel called")
    local playerInfo = self:findPlayerInfo(self.playerForTransfer or 1001, self.playerTeam or 1)
    print("PlayerInfo:", playerInfo)
    local fund = GLOBAL_FUNDS[currentSelectedTeamID]
    local playerTeam = self.playerTeam or 1
    local cardID = self.playerForTransfer or 1001
    local pInfo = getPlayerInfo(cardID, self.playerTeam)
    
    local playerRating = pInfo and pInfo.rating or 50
    local playerPosition = pInfo and pInfo.position or "CM"
    local playerIndex = pInfo and pInfo.index or 0
    local repCount = playerReplacementCount(self.playerTeam, playerPosition) or 0
    local days = daysLeftInTransferWindow(GLOBAL_DATE_PLACEHOLDER or "2025-03-22") or 30
    
    TVALUE, minTValue = computeTransferValue(GetPlayerAge(cardID) or 25, playerRating, playerPosition, playerIndex, repCount, days)
    if not TVALUE then TVALUE = 1000000 end -- Fallback
    if not minTValue then minTValue = 500000 end -- Fallback
    print("TVALUE:", TVALUE, "minTValue:", minTValue)
    
    self.im.Publish(League.Config.Bindings.TeamName, "")
    self.im.Publish(League.Config.Bindings.TeamLogo, self.teamVisuals.crest)
    self.im.Publish(League.Config.Bindings.PlayerHead, self.teamVisuals.playerHead)
    self.im.Publish(League.Config.Bindings.TeamMatchProgress, "£" .. self.loc.LocalizeInteger(fund))
    self.im.Publish(League.Config.Bindings.Status, "")
    self.im.Publish(League.Config.Bindings.TransferValue, "£" .. self.loc.LocalizeInteger(TVALUE))
end

function League:publishPlayerCount()
    local players = self.services.squadManagement.GetCurrentPlayerLineup(0, self.playerTeam, 0) or {}
    local replacementCount = 0
    local playerInfo = self:findPlayerInfo(self.playerForTransfer, self.playerTeam)
    if playerInfo then
        local position = playerInfo.position
        for i = 12, #players do
            if players[i].position == position then replacementCount = replacementCount + 1 end
        end
    end
    COUNT = replacementCount
end

function League:findPlayerInfo(playerId, teamId)
    local players = self.services.squadManagement.GetCurrentPlayerLineup(0, teamId, 0) or {}
    for i, player in ipairs(players) do
        if player.CARD_ID == playerId then 
            return { index = i, position = player.position } 
        end
    end
    return nil
end

function League:swapPlayersInTeam(teamId, cardIdToSwap)
    local players = self.services.squadManagement.GetCurrentPlayerLineup(0, teamId, 0) or {}
    if #players == 0 then return end
    
    local swapIdx, swapPos
    for i, player in ipairs(players) do
        if player.CARD_ID == cardIdToSwap then swapIdx, swapPos = i, player.position break end
    end
    if not swapIdx then return end
    
    for i = 12, #players do
        if players[i].position == swapPos then
            players[swapIdx], players[i] = players[i], players[swapIdx]
            local updatedPlayerIds = {}
            for _, player in ipairs(players) do table.insert(updatedPlayerIds, player.CARD_ID) end
            self.services.squadManagement.SetCurrentPlayerLineup(0, teamId, 0, 0, updatedPlayerIds)          
            return
        end
    end   
end

-- Search and Reset
function League:search()
    self:publishPlayerCount()

    local fund              = GLOBAL_FUNDS[currentSelectedTeamID]
    local playerTeam        = self.playerTeam or 1
    local cardID            = self.playerForTransfer or 1001
    local playerInfo        = self:findPlayerInfo(cardID, playerTeam)
    local playerIdx         = playerInfo and playerInfo.index or 0
    local pInfo             = getPlayerInfo(cardID, playerTeam)

    local playerRating      = pInfo and pInfo.rating or 50
    local playerPosition    = pInfo and pInfo.position or "CM"
    local repCount          = playerReplacementCount(playerTeam, playerPosition) or 0
    local days              = daysLeftInTransferWindow(GLOBAL_DATE_PLACEHOLDER or "2025-03-22") or 30
    local sellerPlayers     = self.services.squadManagement.GetCurrentPlayerLineup(0, playerTeam, 0) or {}

    -- Compute transfer values
    TVALUE, minTValue = computeTransferValue(
        GetPlayerAge(cardID) or 25,
        playerRating,
        playerPosition,
        playerIdx,
        repCount,
        days
    )
    TVALUE    = TVALUE or 1000000
    minTValue = minTValue or 500000

    WAGEMAX = WAGEMAX or 0

    if WAGEMAX < minTValue then
        self.rejectionCount = self.rejectionCount + 1

        local message = self.loc.LocalizeString("TeamName_Abbr15_" .. playerTeam) ..
                        " are not impressed by your offer of £" ..
                        self.loc.LocalizeInteger(WAGEMAX) ..
                        " (Target: £" .. self.loc.LocalizeInteger(TVALUE) ..
                        ", Min: £" .. self.loc.LocalizeInteger(minTValue) .. ")"

        self.im.Publish(League.Config.Bindings.Status, message)

        if self.rejectionCount >= 3 then
            self:failTransfer("Club has rejected your offer too many times")
            return
        elseif WAGEMAX < 0.5 * TVALUE then
            self:failTransfer("Offer is too low compared to market value")
            return
        elseif fund < WAGEMAX then
            self:failTransfer("You don't have enough funds to complete this transfer")
            return
        end
        return
    end

    if WAGEMAX > fund then
        self:failTransfer("Insufficient funds")
        return
    end

    if #sellerPlayers < 24 then
        self:failTransfer("Team are not looking to sell players right now")
        return
    end

    TVALUE = (WAGEMAX >= TVALUE) and TVALUE or WAGEMAX

    self:completeTransfer()
    self.rejectionCount = 0
end

function League:resetFilters()
    print("Resetting filters...")
    self.bidValues.minBid, self.bidValues.maxBid = League.Config.MinValue, League.Config.MinValue
    self.bidValues.minBuy, self.bidValues.maxBuy = League.Config.MinValue, League.Config.MinValue
    self.rejectionCount = 0
    self:publishAmountSelector()
    self:updateBidPlaceholders()
end

function League:publishAmountSelector(bindingName)
    print("Publishing amount selector for:", bindingName)
    if not bindingName then
        for _, adjustment in pairs(League.Config.BidAdjustments) do
            self:publishAmountSelector(adjustment.Binding)
        end
    else
        self.im.Refresh(bindingName)
    end
end

-- Transfer Outcomes
function League:failTransfer(reason)    
  self.nav.Event(nil, "evt_hide_overlay")
  message = reason or "Player is too important to " .. self.loc.LocalizeString("TeamName_Abbr15_" .. (self.playerTeam or 1))
  self:displayConfirmationMsg(message, nil, nil, true)
end

function League:completeTransfer()
    transferPlayer(self.playerForTransfer, self.playerTeam , currentSelectedTeamID)    
    local transferOffers = sessionVars.get("transferOffers") or {}
    local scoutedPlayers = sessionVars.get("scoutedPlayers") or {}
    local shortlistedPlayers = sessionVars.get("shortlistedPlayers") or {}
    scoutedPlayers[self.playerForTransfer] = nil
    transferOffers[self.playerForTransfer] = nil 
    shortlistedPlayers[self.playerForTransfer] = nil
    sessionVars.set("transferOffers", transferOffers)
    sessionVars.set("scoutedPlayers", scoutedPlayers)
    sessionVars.set("shortlistedPlayers", shortlistedPlayers)
    GLOBAL_FUNDS[currentSelectedTeamID] = GLOBAL_FUNDS[currentSelectedTeamID] - WAGEMAX
    self.back()
    return League
end

return League
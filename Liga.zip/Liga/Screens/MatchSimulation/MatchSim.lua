local MatchSimulator, sessionVars, Date = ...
local MatchSim = {}

function MatchSim:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
displayMatchdayFixtures = true
  initTheme(o.im)
  o.services = {
        SquadManagementService = o.api("SquadMgtService")
    }        
  o.MatchSimulator = MatchSimulator:new({sessionVars = sessionVars, services = o.services})
  o.im.RegisterAction("act_advance", o.data.advance)
  o.MatchData, o.sMatchData = o.MatchSimulator:simulateMatch(currentMatch.HomeTeamID, currentMatch.AwayTeamID)
  if (not o.MatchData) or (not o.sMatchData) then
    o.data.advance()
  end
  o.im.Subscribe("bnd_HomeCrest", function() o:publishMatchData() end)
  o.im.Subscribe("bnd_AwayCrest", function() o:publishMatchData() end)
  o.im.Subscribe("bnd_HomeTeam", function() o:publishMatchData() end)
  o.im.Subscribe("bnd_AwayTeam", function() o:publishMatchData() end)
  o.im.Subscribe("homeposs", function() o:publishMatchData() end)
  o.im.Subscribe("awayposs", function() o:publishMatchData() end)
  o.im.Subscribe("homeshots", function() o:publishMatchData() end)
  o.im.Subscribe("awayshots", function() o:publishMatchData() end)
  o.im.Subscribe("homechances", function() o:publishMatchData() end)
  o.im.Subscribe("awaychances", function() o:publishMatchData() end)
  o.im.Subscribe("matchscores", function() o:publishMatchData() end)
  o.im.Subscribe("simulationdata", function() o:simulationRow() end)
  return o
end

function MatchSim:publishMatchData()
  local homeID = currentMatch.HomeTeamID or 9
  local awayID = currentMatch.AwayTeamID or 1
  local homeScore = self.MatchData.pen and (self.MatchData.homeScore + self.MatchData.homePenScore) or self.MatchData.homeScore or 0
  local awayScore = self.MatchData.pen and (self.MatchData.awayScore + self.MatchData.awayPenScore) or self.MatchData.awayScore or 0
  local homePos = self.sMatchData.possessionHome
  local awayPos = self.sMatchData.possessionAway
  local homeShots = self.sMatchData.shotsHome
  local awayShots = self.sMatchData.shotsAway
  local homeChances = self.sMatchData.chancesHome
  local awayChances = self.sMatchData.chancesAway
  self.im.Publish("bnd_HomeCrest", {name = "$Crest", id = homeID})
  self.im.Publish("bnd_AwayCrest", {name = "$Crest", id = awayID})
  self.im.Publish("bnd_HomeTeam", self.loc.LocalizeString("TeamName_Abbr15_" .. homeID))
  self.im.Publish("bnd_AwayTeam", self.loc.LocalizeString("TeamName_Abbr15_" .. awayID))
  self.im.Publish("homeposs", homePos)
  self.im.Publish("awayposs", awayPos)
  self.im.Publish("homeshots", homeShots)
  self.im.Publish("awayshots", awayShots)
  self.im.Publish("homechances", homeChances)
  self.im.Publish("awaychances", awayChances)
  self.im.Publish("matchscores", homeScore .. " : " .. awayScore)
end

function MatchSim:simulationRow()
  -- 1 pen goal, 2 pen missed, 3 goal disallowed, 4 substitution, 5 yc, 6 dyc rc, 7 rc, 8 injury, 9 goal
  local v = {}
  local homeScorers = self.sMatchData.homeScorers or {}
  local awayScorers = self.sMatchData.awayScorers or {}
  local totalGoals = #homeScorers + #awayScorers

  if totalGoals == 0 then
    self.im.Publish("simulationdata", v)
    return
  end

  -- Generate unique random minutes (1-90) for each goal to avoid overlaps
  local minutes = {}
  for i = 1, totalGoals do
    local minute
    repeat
      minute = math.random(1, 90)
    until not minutes[minute]
    minutes[minute] = true
  end

  -- Collect all goals as a list: {isHome = true/false, playerID = id}
  local allGoals = {}
  for _, player in ipairs(homeScorers) do
    table.insert(allGoals, {isHome = true, player = player})
  end
  for _, player in ipairs(awayScorers) do
    table.insert(allGoals, {isHome = false, player = player})
  end

  -- Shuffle the allGoals list for random assignment order
  for i = #allGoals, 2, -1 do
    local j = math.random(i)
    allGoals[i], allGoals[j] = allGoals[j], allGoals[i]
  end

  -- Get sorted minute list
  local _minuteList = {}
  for m, _ in pairs(minutes) do
    table.insert(_minuteList, m)
  end
  table.sort(_minuteList)  -- Chronological order
  
  local minuteList = {}
  local minLen = #_minuteList
  for i = 1, minLen do
    minuteList[i] = _minuteList[(minLen + 1) - i]
  end

  -- Assign shuffled goals to sorted minutes
  local goalEvents = {}
  for i, minute in ipairs(minuteList) do
    local goal = allGoals[i]
    table.insert(goalEvents, {minute = minute, isHome = goal.isHome, player = goal.player})
  end

  -- Create exactly totalGoals rows
  for i = 1, totalGoals do
    v[i] = {}
    v[i].data = {}
    local event = goalEvents[i]
    local playerName = event.player
    local minuteStr = tostring(event.minute)

    if event.isHome then
      -- Home goal: Set home keys, clear away
      v[i].data.PlayerHead = { name = "$Head", id = playerID }
      v[i].data.PlayerName = playerName
      v[i].data.PlayerName1 = ""
      v[i].data.PlayerName2 = ""
      v[i].data.Event = { name = "$Events", id = 9 }
      v[i].data.Event1 = ""  -- Empty for goal
      v[i].data.Event2 = ""
      --v[i].data.Event1 = "$SubstitutionInArrow" home sub
      --v[i].data.Event2 = "$SubstitutionOutArrow" home sub
      -- Clear away keys
      v[i].data.PlayerHeadA = {}
      v[i].data.PlayerNameA = ""
      v[i].data.PlayerName1A = ""
      v[i].data.PlayerName2A = ""
      v[i].data.EventA = {}
      v[i].data.Event1A = ""
      v[i].data.Event2A = ""
    else
      -- Away goal: Set away keys, clear home
      v[i].data.PlayerHeadA = { name = "$Head", id = playerID }
      v[i].data.PlayerNameA = playerName
      v[i].data.PlayerName1A = ""
      v[i].data.PlayerName2A = ""
      v[i].data.EventA = { name = "$Events", id = 9 }
      v[i].data.Event1A = ""
      v[i].data.Event2A = ""
      --v[i].data.Event1A = "$SubstitutionInArrow" away sub
    --v[i].data.Event2A = "$SubstitutionOutArrow" away sub
      -- Clear home keys
      v[i].data.PlayerHead = {}
      v[i].data.PlayerName = ""
      v[i].data.PlayerName1 = ""
      v[i].data.PlayerName2 = ""
      v[i].data.Event = {}
      v[i].data.Event1 = ""
      v[i].data.Event2 = ""
    end
    v[i].data.Minute = minuteStr .. "'"
  end
  self.im.Publish("simulationdata", v)
end

return MatchSim
local sessionVars, CareerModeLeagues, Timer, TeamStats = ...
local Liga = {}
local bndMatchList = "bnd_match_list"
local bndMatchList1 = "bnd_match_list1"
local bndLogo = "bnd_logo"
local bndTeamLogo = "bnd_team_logo"
local bndTeamName = "bnd_team_name"
local ACT_ADVANCE = "act_advance"
local ACT_NEXT = "act_next"
local ACT_DECREASE = "act_decrease"
local BND_SCALE_X = "bnd_scale_x"
local BND_SCALE_Y = "bnd_scale_y"
local BND_POS_X   = "bnd_pos_x"
local BND_POS_Y   = "bnd_pos_y"
local BND_ALPHA = "bnd_alpha"

local leagueNames = {
    [4] = "Pro League",
    [7] = "Serie A",
    [10] = "Eredivisie",
    [13] = "Premier League",
    [14] = "Championship",
    [16] = "Ligue 1",
    [17] = "Ligue 2",
    [19] = "Bundesliga 1",
    [20] = "Bundesliga 2",
    [31] = "Serie A",
    [32] = "Serie B",
    [39] = "MLS",
    [50] = "Premiership",
    [53] = "La Liga",
    [54] = "Segunda",
    [60] = "League One",
    [66] = "Ekstraklasa",
    [68] = "Süper Lig",
    [76] = "Rest of World",
    [77] = "Rest of World 2",
    [78] = "International",
    [83] = "K League 1",
    [308] = "Primeira Liga",
    [341] = "Liga MX",
    [347] = "Premier Division",
    [349] = "J1 League",
    [350] = "Pro League",
    [351] = "A-League",
    [353] = "Primera División",
    [365] = "AFC",
    [1114] = "Premier League",
    [1245] = "Classic Team",
    [1246] = "Classic International",
    [2012] = "Super League",
    [2034] = "Ligue 1",
    [2136] = "International Women",
    [2149] = "Super League",
    [2215] = "Frauen-Bundesliga",
    [2216] = "FA WSL",
    [2218] = "Division 1 Féminine",
    [2221] = "NWSL",
    [2222] = "Liga F",
    [2231] = "Premier League",
    [2235] = "Liga 1",
    [2236] = "Champions League",
    [2237] = "Super League",
    [2238] = "Europe League",
    [2240] = "Champions League Women",
    [2250] = "Botola Pro",
    [2252] = "League 1",
    [2254] = "Liga 2",
    [2260] = "V.League 1",
    [0] = "League" -- Default
}

ligaId = 1
if not round then
  round = 1
else 
  round = round
end

if not selectedteam then
  selectedteam = 0
else 
  selectedteam = selectedteam
end

local rivalListData = {}
local matchesPlayed = 0 

function Liga:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.services = {
    settingsService = o.api("SettingsService"),
    SquadManagementService = o.api("SquadMgtService")
  }
  o.nav = o.data.nav
  o.callBack = o.data.clbk
  o.teamStats = TeamStats:new({loc = init.loc})
  o.switchPanelOpened = false
  o.currentOptions = o.services.settingsService.GetCurrentOptions()
  o.backgroundTimer = nil
  o.hideOverlayTimer = nil  -- New timer for hiding overlay
  o.animScaleX = 0
o.animScaleY = 1
o.animPosX = 0
o.animPosY = 70
o.animAlpha = 1

o.animTarget = 1
o.animating = true
o.isHiding = false
o.animMode = "FADE"
  o.Init()
 o.cachedRows = nil 
  o.im.Subscribe(bndMatchList1, function()
     o:publishMatchRows2()
  end)
  
  o.im.Subscribe("LeagueList", function()
     o:displayLeagues()
  end)
 
o.im.Subscribe(BND_SCALE_X, function()
    o.im.Publish(BND_SCALE_X, o.animScaleX)
end)

o.im.Subscribe(BND_SCALE_Y, function()
    o.im.Publish(BND_SCALE_Y, o.animScaleY)
end)

o.im.Subscribe(BND_POS_X, function()
    o.im.Publish(BND_POS_X, o.animPosX)
end)

o.im.Subscribe(BND_POS_Y, function()
    o.im.Publish(BND_POS_Y, o.animPosY)
end)

o.im.Subscribe(BND_ALPHA, function()
    o.im.Publish(BND_ALPHA, o.animAlpha)
end) 
  
o.im.Subscribe("bnd_league_logo", function()
    local leagueLogo = o:getLeagueLogo()
    o.im.Publish("bnd_league_logo", leagueLogo)
end)

o.im.Subscribe("bnd_league_name", function()
    local leagueName = o:getLeagueName()
    o.im.Publish("bnd_league_name", leagueName)
end)

  o.im.Subscribe(bndLogo, function()  
  local currentLeague = o:getCurrentLeague()
    o.im.Publish(bndLogo, {name = "$LeagueLogo", id = currentLeague})
  end)

  o.im.Subscribe("bgskin", function()  
    local currentLeague = o:getCurrentLeague()
    o.im.Publish("bgskin", {name = "$CareerTable", id = currentLeague})   
  end)
  
  o.im.Subscribe(bndTeamName, function()  
        o.im.Publish(bndTeamName, o.loc.LocalizeString("TeamName_Abbr15_"..currentSelectedTeamID))       
    end)
    
  o.im.RegisterAction("act_advance", function(actionName, data)
    o.nav.Event(nil, "evt_hide_overlay")
    o.callBack()
  end)
  
  o.nav.AddActionHandler("kill", false, nil, function()
      o:finalize()
    end)
    
  -- Start the 10-second timer to hide the overlay
if Timer then
    o.hideOverlayTimer = Timer:new({
        id = "hideOverlayTimer",
        interval = 4,
        reps = 1,
        onTimerComplete = function()

            -- MULAI HIDE
            o.isHiding = true
            o.animTarget = 0
            o.animating = true

            o.hideOverlayTimer = nil

        end
    })

    o.hideOverlayTimer:start()
end

  return o
end

function Liga:getLeagueLogo()
    local currentLeague = self:getCurrentLeague()
    return {
        name = "$LeagueLogo",  
        id = currentLeague
    }
end

function Liga:getLeagueName()
    local currentLeague = self:getCurrentLeague()
    return leagueNames[currentLeague] or leagueNames[0]
end

function Liga:getCurrentLeague()    
    return selectedLeague or sessionVars.get("currentUserLeagueID")
end

function Liga:Init()
    local userLeagueID = selectedLeague or sessionVars.get("currentUserLeagueID") or 13
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    local matchData = leagueMatchData[userLeagueID] or {}
    
    rivalListData = {}
    local matchCount = #matchData
    for i = 1, matchCount do
        local obj = {
            homeID = matchData[i].homeID,
            awayID = matchData[i].awayID,
            homeScore = matchData[i].homeScore or 0,
            awayScore = matchData[i].awayScore or 0,
            data = {}
        }
        rivalListData[i] = obj
    end
end

function Liga:displayLeagues()
  local v = {}
  local currentLg = 0
  for i = 1, #CareerModeLeagues do
    currentLg = CareerModeLeagues[i]
    v[i] = {}
    v[i].data = {}
    v[i].data.flagCrest = {
      name = "$LeagueLogo",
      id = currentLg
    }
    v[i].data.TeamName = leagueNames[currentLg] or self.loc.LocalizeString("LeagueName_Abbr15_" .. currentLg)
    v[i].data.clickAction = "selectleague"
    v[i].data.TeamNameFontColor = "0xffffff"
  end
  self.im.Publish("LeagueList", v)
end

function Liga:getNextOpponent(teamID)
    local userLeagueID = selectedLeague or sessionVars.get("currentUserLeagueID") or 13
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    local matchData = leagueMatchData[userLeagueID] or {}
    
    for i = 1, #matchData do
        local match = matchData[i]
        local played = match.played or false
        
        if not played then
            if match.homeID == teamID then
                return match.awayID 
            elseif match.awayID == teamID then
                return match.homeID 
            end
        end
    end
    return nil
end

function Liga:publishMatchRows2()
    local userLeagueID = selectedLeague
        or sessionVars.get("currentUserLeagueID")
        or 13

    local standings = self.teamStats:getGroupStandings(userLeagueID)

    if not standings or #standings == 0 then
        self.im.Publish(bndMatchList1, {})
        return
    end

    local rows = {}
    local maxRows = math.min(7, #standings)

    local SelectedTeamID = currentSelectedTeamID or selectedteam

    -- Definisi warna
    local normalColor = "0x808080"
    local highlightColor = "0xFFFFFF"

    for i = 1, maxRows do
        local t = standings[i]
        
        -- Logika penentuan warna
        local isSelected = (SelectedTeamID and tonumber(t.teamID) == tonumber(SelectedTeamID))
        local colorToUse = isSelected and highlightColor or normalColor

        -- Inisialisasi table teamData
        local teamData = {
            Teampos = tostring(i),
            TeamCrest = {
                name = "$Crest64x64",
                id = t.teamID or 0
            },
            TeamName = t.teamName or "",
            Teammp = tostring(t.matchesPlayed or 0),
            TeamWin = tostring(t.wins or 0),
            TeamDraw = tostring(t.draws or 0),
            TeamLoss = tostring(t.losses or 0),
            TeamGA = tostring(t.goalsScored or 0),
            TeamGC = tostring(t.goalsConceded or 0),
            TeamGD = tostring(t.goalDifference or 0),
            TeamPoint = tostring(t.points or 0)
        }

        -- Menerapkan warna di luar kurung kurawal (setelah table terbuat)
        teamData.TeamNameColor = colorToUse
        teamData.TeamposColor  = colorToUse
        teamData.TeammpColor   = colorToUse
        teamData.TeamWinColor  = colorToUse
        teamData.TeamDrawColor = colorToUse
        teamData.TeamLossColor = colorToUse
        teamData.TeamGAColor   = colorToUse
        teamData.TeamGCColor   = colorToUse
        teamData.TeamGDColor   = colorToUse

        local nameLength = string.len(teamData.TeamName)
        teamData.IconMarginLeft = 400 + (nameLength * 9.5)

        if isSelected then
            teamData.Icon = {
                name = "$IconCheckMark",
                id = t.teamID
            }
        end

        rows[i] = {
            data = teamData
        }
    end

    self.cachedRows = rows
    self.im.Publish(bndMatchList1, self.cachedRows)
end



function Liga:update(elapsedTime)

    if self.backgroundTimer then
        self.backgroundTimer:update(elapsedTime)
    end

    if self.hideOverlayTimer then
        self.hideOverlayTimer:update(elapsedTime)
    end

    -- ANIMASI
    if self.animating then

        local diff = self.animTarget - self.animScaleX

        local speed = self.isHiding and 0.22 or 0.18
        local step = diff * speed

        local maxStep = 0.08
        if step > maxStep then step = maxStep end
        if step < -maxStep then step = -maxStep end

        self.animScaleX = self.animScaleX + step

if math.abs(diff) < 0.002 then

    self.animScaleX = self.animTarget
    self.animating = false

    if self.isHiding then

        self.isHiding = false

        self.im.Publish("bnd_active", false)

        if self.nav then
            self.nav.Event(nil, "evt_hide_overlay")
            self.callBack()
        end

    end

end

        local sx = 1
        local sy = 1
        local alpha = 1

        local v = self.animScaleX

        if self.animMode == "SCALE_X" then

            sx = v
            sy = 1

        elseif self.animMode == "SCALE_Y" then

            sx = 1
            sy = v

        elseif self.animMode == "RIGHT_FADE" then

            sx = v
            alpha = v

        elseif self.animMode == "LEFT_FADE" then

            sx = v
            alpha = v

        elseif self.animMode == "TOP_FADE" then

            sy = v
            alpha = v

        elseif self.animMode == "BOTTOM_FADE" then

            sy = v
            alpha = v

        elseif self.animMode == "FADE" then

            alpha = v

        end

        self.animScaleY = sy
        self.animAlpha = alpha
        self.animPosX = 0

        local startOffsetY = 70
        self.animPosY = startOffsetY * (1 - v)

self.im.Publish(BND_SCALE_X, sx)
self.im.Publish(BND_SCALE_Y, self.animScaleY)
self.im.Publish(BND_POS_X, self.animPosX)
self.im.Publish(BND_POS_Y, self.animPosY)
self.im.Publish(BND_ALPHA, self.animAlpha)

if self.cachedRows and self.animScaleX > 0.6 then
    self.im.Publish(bndMatchList1, self.cachedRows)
    self.cachedRows = nil
end
end
end

function Liga:finalize()
  if self.backgroundTimer then
    self.backgroundTimer:finalize()
    self.backgroundTimer = nil
  end
  if self.hideOverlayTimer then
    self.hideOverlayTimer:finalize()
    self.hideOverlayTimer = nil
  end
  self.im.UnregisterAction("switchLeague")
  self.im.UnregisterAction("selectleague")
  self.im.UnregisterAction(ACT_NEXT)
  self.im.UnregisterAction(ACT_DECREASE)
  self.im.Unsubscribe("bnd_match_list")
  self.im.Unsubscribe("bnd_match_list1")
  self.im.Unsubscribe("bnd_matchday_label")
  self.im.Unsubscribe("bnd_point_label")
  self.im.Unsubscribe("bnd_team_label")
  self.im.Unsubscribe("bnd_matchup_label")
  self.im.Unsubscribe("bnd_matchdate_label")
  self.im.Unsubscribe("bnd_league_label")
  self.im.Unsubscribe("bnd_advance_label")
  self.im.Unsubscribe("bnd_month_label")
  self.im.Unsubscribe("bnd_finish_label")
  selectedLeague = nil
end

return Liga
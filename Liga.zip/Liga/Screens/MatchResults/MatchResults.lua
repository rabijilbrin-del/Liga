local sessionVars, Timer, Date, DateUtils, MatchSimulator, MatchHandler, CareerFriendlies, TeamStats, Modes, Squads = ...
local MatchResults = {}
local matchList= {}

local function publishDate(im)
  local months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}
  local day, month, year = GLOBAL_DATE_PLACEHOLDER:match("(%d%d)/(%d%d)/(%d%d)")
  day, month, year = tonumber(day), tonumber(month), tonumber(year)
  local currentYear = 2000 + year
  local dateStr = tostring(day) .. " " .. months[month] .. " " .. tostring(currentYear)
  im.Publish("bnd_date", dateStr)
end

function MatchResults:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  initTheme(o.im)
  o.nav = o.data.nav
  o.matchType = nil
  o.teams = {}
  o.userLeagueID = sessionVars.get("currentUserLeagueID")
  o.services = {
    SquadManagementService = o.api("SquadMgtService"),    
    TacticsService = o.api("TacticsService")
  }
  o.matchSimulator = MatchSimulator:new({
        DateUtils = DateUtils,
        sessionVars = sessionVars,
        currentSelectedTeamID = currentSelectedTeamID,
        services = o.services
    })  
  o.matchSimulator:simulateDayMatches(GLOBAL_DATE_PLACEHOLDER)
  o:Init()
  o.im.Subscribe("bnd_date", function()
    publishDate(o.im)
  end)
  o.im.Subscribe("bnd_leaguelogo", function()
     o.im.Publish("bnd_leaguelogo", {name = "$LeagueCrest", id = o.userLeagueID})
  end)
  o.im.Subscribe("bnd_match_list", function()
    o:publishMatches()
  end)
  o.im.RegisterAction("act_advance", function()
    o:advance()
  end)
  return o
end

function MatchResults:advance()
 local FRIENDLYID = 175
 local currentLeagueID = sessionVars.get("currentUserLeagueID")
  Date:advanceDate()
  self.matchSimulator:simulateDayMatches(GLOBAL_DATE_PLACEHOLDER) -- simulate advanced date matches
  self:updateSuspension()
  self:teamSheet()
  if currentLeagueID == FRIENDLYID then 
    if CareerFriendlies:haveAllFriendliesBeenPlayed() and (TeamStats:getTeamPosition(FRIENDLYID, currentSelectedTeamID) == 1) then
      GLOBAL_FUNDS[currentSelectedTeamID] = GLOBAL_FUNDS[currentSelectedTeamID] + 6200000
    end
  end
  displayMatchdayFixtures = false
  currentMatch.isKnockout = nil
  self.nav.Event(nil, "evt_reload")
  self.nav.Event(nil, "evt_hide_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/MatchResults/MatchResults.vvm"})
end

function MatchResults:teamSheet()
  local teamID = currentSelectedTeamID  
  if sessionVars.get("teamMgtData") then
    local teamData = sessionVars.get("teamMgtData")
    local players = teamData.players
    local formationID = teamData.formation
    self.services.TacticsService.SetFormation(0, teamID, formationID)
    if getCachedTeamPlayers(teamID) then
      local TeamCachedData = sessionVars.get("TeamCachedData")
      TeamCachedData[teamID].players = players  
      sessionVars.set("TeamCachedData", TeamCachedData)
    end
  end
  
  if self.teams then
    for i = 1, 2 do
      local teamID = self.teams[i]
      local obj = Squads.getBaseCachedTeamPlayers(teamID)
      local playerIDs = {}
      for k = 1, #obj do
        playerIDs[k] = obj[k].CARD_ID
      end
     self.services.SquadManagementService.SetCurrentPlayerLineup(0, teamID, 0, 0, playerIDs)
    end
  end
  
  sessionVars.set("isPreMatch", false)
  sessionVars.set("teamMgtData", nil)  
end

function MatchResults:updateSuspension()
  local suspension = sessionVars.get("redMatchCount")
  for k, v in pairs(suspension) do
    suspension[k] = v ~= 1 and (v - 1) or nil
    if not suspension[k] then
      isSuspended[k] = nil
    end
  end
  sessionVars.set("redMatchCount", suspension)
end 

function MatchResults:Init() 
    local matchData = MatchHandler:getMatchesForDateWithoutIndex(GLOBAL_DATE_PLACEHOLDER)
    matchList = {}
    local matchCount = #matchData
    for i = 1, matchCount do
        local obj = {
            homeID = matchData[i].homeID,
            awayID = matchData[i].awayID,
            leagueID = matchData[i].leagueID,
            played = matchData[i].played,
            matchday = matchData[i].matchday,
            matchType = matchData[i].matchType,
            homeScore = matchData[i].homeScore or 0,
            pen = matchData[i].pen or false,
            homePenScore = matchData[i].homePenScore or 0,
            awayScore = matchData[i].awayScore or 0,
            awayPenScore = matchData[i].awayPenScore or 0,
            data = {}
        }
        if (obj.homeID == currentSelectedTeamID or obj.awayID == currentSelectedTeamID) then
          self.matchType = obj.matchType
          self.teams = {obj.homeID, obj.awayID}
        end
        matchList[i] = obj -- Direct index assignment
    end
end

function MatchResults:publishMatches()
    local userLeagueID = sessionVars.get("currentUserLeagueID")
    local filteredMatchList = {}
    local filteredIndex = 1

    local SelectedTeamID = currentSelectedTeamID

    -- Loop through all matches in matchList
    for i = 1, #matchList do
        local v = matchList[i]
        local shouldIncludeMatch = true
        shouldIncludeMatch = (v.leagueID == userLeagueID)

        if shouldIncludeMatch then

            -- Populate match data
            v.data.TeamHomeCrest = {
                name = "$Crest64x64",
                id = v.homeID
            }

            v.data.TeamAwayCrest = {
                name = "$Crest64x64",
                id = v.awayID
            }

            v.data.TeamHomeName =
                self.loc.LocalizeString("TeamName_Abbr15_" .. v.homeID)

            v.data.TeamAwayName =
                self.loc.LocalizeString("TeamName_Abbr15_" .. v.awayID)

            -- Checkmark tim yang dipilih
            v.data.HomeIcon =
                (SelectedTeamID and tonumber(v.homeID) == tonumber(SelectedTeamID))
                and {
                    name = "$IconCheckMark",
                    id = v.homeID
                }
                or nil

            v.data.AwayIcon =
                (SelectedTeamID and tonumber(v.awayID) == tonumber(SelectedTeamID))
                and {
                    name = "$IconCheckMark",
                    id = v.awayID
                }
                or nil

            v.data.MatchScore = v.pen
                and (v.homeScore .. "(" .. v.homePenScore .. ")" ..
                    "    -    " ..
                    "(" .. v.awayPenScore .. ")" .. v.awayScore)
                or (v.homeScore .. "    -    " .. v.awayScore)

            v.data.TeamScoreFontColor = "0xffffff"
            v.data.TeamNameFontColor = "0x4A2C6D"
            v.data.MatchStatus = "FT"

            filteredMatchList[filteredIndex] = v
            filteredIndex = filteredIndex + 1
        end
    end

    self.im.Publish("bnd_match_list", filteredMatchList)
end


return MatchResults
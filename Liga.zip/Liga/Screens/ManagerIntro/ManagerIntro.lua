local ManagerIntro = {}
local text = ""
local ACT_ADVANCE = "act_advance"
local ACT_Q = "act_q"
local ACT_W = "act_w"
local ACT_E = "act_e"
local ACT_R = "act_r"
local ACT_T = "act_t"
local ACT_Y = "act_y"
local ACT_U = "act_u"
local ACT_I = "act_i"
local ACT_O = "act_o"
local ACT_P = "act_p"
local ACT_A = "act_a"
local ACT_S = "act_s"
local ACT_D = "act_d"
local ACT_F = "act_f"
local ACT_G = "act_g"
local ACT_H = "act_h"
local ACT_J = "act_j"
local ACT_K = "act_k"
local ACT_L = "act_l"
local ACT_Z = "act_z"
local ACT_X = "act_x"
local ACT_C = "act_c"
local ACT_V = "act_v"
local ACT_B = "act_b"
local ACT_N = "act_n"
local ACT_M = "act_m"
local ACT_DOT = "act_dot"
local ACT_BACKSPACE = "act_backspace"
local ACT_DELETE = "act_delete"
local ACT_SUBMIT = "act_submit"

if not text then
  text = ""
end

function ManagerIntro:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  
  o.im.Subscribe("bnd_textarea", function()
    o:publishLabel()
  end)
  
  o.im.RegisterAction(ACT_ADVANCE, function(actionName, data)
    o:nextt()
  end)
  o.im.RegisterAction(ACT_Q, function(actionName, data)
    o:q()
  end)
  o.im.RegisterAction(ACT_W, function(actionName, data)
    o:w()
  end)
  o.im.RegisterAction(ACT_E, function(actionName, data)
    o:e()
  end)
  o.im.RegisterAction(ACT_R, function(actionName, data)
    o:r()
  end)
  o.im.RegisterAction(ACT_T, function(actionName, data)
    o:t()
  end)
  o.im.RegisterAction(ACT_Y, function(actionName, data)
    o:y()
  end)
  o.im.RegisterAction(ACT_U, function(actionName, data)
    o:u()
  end)
  o.im.RegisterAction(ACT_I, function(actionName, data)
    o:i()
  end)
  o.im.RegisterAction(ACT_O, function(actionName, data)
    o:o()
  end)
  o.im.RegisterAction(ACT_P, function(actionName, data)
    o:p()
  end)
  o.im.RegisterAction(ACT_A, function(actionName, data)
    o:a()
  end)
  o.im.RegisterAction(ACT_S, function(actionName, data)
    o:s()
  end)
  o.im.RegisterAction(ACT_D, function(actionName, data)
    o:d()
  end)
  o.im.RegisterAction(ACT_F, function(actionName, data)
    o:f()
  end)
  o.im.RegisterAction(ACT_G, function(actionName, data)
    o:g()
  end)
  o.im.RegisterAction(ACT_H, function(actionName, data)
    o:h()
  end)
  o.im.RegisterAction(ACT_J, function(actionName, data)
    o:j()
  end)
  o.im.RegisterAction(ACT_K, function(actionName, data)
    o:k()
  end)
  o.im.RegisterAction(ACT_L, function(actionName, data)
    o:l()
  end)
  o.im.RegisterAction(ACT_Z, function(actionName, data)
    o:z()
  end)
  o.im.RegisterAction(ACT_X, function(actionName, data)
    o:x()
  end)
  o.im.RegisterAction(ACT_C, function(actionName, data)
    o:c()
  end)
  o.im.RegisterAction(ACT_V, function(actionName, data)
    o:v()
  end)
  o.im.RegisterAction(ACT_B, function(actionName, data)
    o:b()
  end)
  o.im.RegisterAction(ACT_N, function(actionName, data)
    o:n()
  end)
  o.im.RegisterAction(ACT_M, function(actionName, data)
    o:m()
  end)
  o.im.RegisterAction(ACT_DOT, function(actionName, data)
    o:dot()
  end)
  o.im.RegisterAction(ACT_BACKSPACE, function(actionName, data)
    o:backspace()
  end)
  o.im.RegisterAction(ACT_DELETE, function(actionName, data)
    o:deleteall()
  end)
  o.im.RegisterAction(ACT_SUBMIT, function(actionName, data)
    o:submit()
  end)

  return o
end

-----------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------
function ManagerIntro:publishLabel()
  self.im.Publish("bnd_textarea", text)
end

function ManagerIntro:q()
  text = text .. "q"
  self:publishLabel()
end
function ManagerIntro:w()
  text = text .. "w"
  self:publishLabel()
end
function ManagerIntro:e()
  text = text .. "e"
  self:publishLabel()
end
function ManagerIntro:r()
  text = text .. "r"
  self:publishLabel()
end
function ManagerIntro:t()
  text = text .. "t"
  self:publishLabel()
end
function ManagerIntro:y()
  text = text .. "y"
  self:publishLabel()
end
function ManagerIntro:u()
  text = text .. "u"
  self:publishLabel()
end
function ManagerIntro:i()
  text = text .. "i"
  self:publishLabel()
end
function ManagerIntro:o()
  text = text .. "o"
  self:publishLabel()
end
function ManagerIntro:p()
  text = text .. "p"
  self:publishLabel()
end
function ManagerIntro:a()
  text = text .. "a"
  self:publishLabel()
end
function ManagerIntro:s()
  text = text .. "s"
  self:publishLabel()
end
function ManagerIntro:d()
  text = text .. "d"
  self:publishLabel()
end
function ManagerIntro:f()
  text = text .. "f"
  self:publishLabel()
end
function ManagerIntro:g()
  text = text .. "g"
  self:publishLabel()
end
function ManagerIntro:h()
  text = text .. "h"
  self:publishLabel()
end
function ManagerIntro:j()
  text = text .. "j"
  self:publishLabel()
end
function ManagerIntro:k()
  text = text .. "k"
  self:publishLabel()
end
function ManagerIntro:l()
  text = text .. "l"
  self:publishLabel()
end
function ManagerIntro:z()
  text = text .. "z"
  self:publishLabel()
end
function ManagerIntro:x()
  text = text .. "x"
  self:publishLabel()
end
function ManagerIntro:c()
  text = text .. "c"
  self:publishLabel()
end
function ManagerIntro:v()
  text = text .. "v"
  self:publishLabel()
end
function ManagerIntro:b()
  text = text .. "b"
  self:publishLabel()
end
function ManagerIntro:n()
  text = text .. "n"
  self:publishLabel()
end
function ManagerIntro:m()
  text = text .. "m"
  self:publishLabel()
end
function ManagerIntro:dot()
  text = text .. " "
  self:publishLabel()
end
function ManagerIntro:backspace()
    if #text > 0 then
        text = text:sub(1, -2)  -- Removes the last character
    end
    self:publishLabel()
end
function ManagerIntro:deleteall()
    if #text > 0 then
        text = text:sub(1, 0)  -- Removes all characters
    end
    self:publishLabel()
end
function ManagerIntro:submit()
  self:publishLabel()
  self.nav.Event(nil, "evt_back")
end


function ManagerIntro:finalize()
end

return ManagerIntro
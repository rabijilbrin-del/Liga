local Popup = {}
local FCPopup, Utils = ...
local bindings = { "message", "button1", "button2", "button3", "btnvisible1",  "btnvisible2", "btnvisible3"}
function Popup:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.data = FCPopup:getPopupData()
  for i = 1, #bindings do
    o.im.Subscribe("bnd_" .. bindings[i], function()
      o:_displayPopupData()
    end)
  end
  for btns = 1, 3 do
    o.im.RegisterAction("act_btn" .. btns, function(actionName, data)
      o:_clickEvent(btns)
    end)
  end
  return o
end

function Popup:_displayPopupData()
  local btnCount = #self.data.buttonData
  self.im.Publish("bnd_message", Utils.formatString(self.data.message, 45) or "")
    for i = 1, 3 do
      self.im.Publish("bnd_btnvisible" ..i, i <= btnCount)
      self.im.Publish("bnd_button" ..i, i <= btnCount and self.data.buttonData[i] or "empty")
    end
end

function Popup:_clickEvent(btnId)
  local inputId = btnId
  FCPopup:setResponse(inputId)
end

return Popup
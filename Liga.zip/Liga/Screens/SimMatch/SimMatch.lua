-- ================================================================
-- RONDO SIM v4.0  –  True Self-Play PPO Edition
-- ================================================================
-- Pure end-to-end RL · Proximal Policy Optimization + GAE
-- Zero hand-crafted shaping · Shared team networks · Lua 5.1
-- ----------------------------------------------------------------
-- Architecture decisions:
--   • PPO (ε=0.2, K=4 epochs) with GAE (γ=0.99, λ=0.95)
--   • Factorised discrete policy: 9-dir move × 7 ball actions
--   • TWO shared networks: atk_net (×6 attackers), def_net (×2 defs)
--     – more data per update; agents learn from all teammates' xp
--   • On-policy rollout (T=24/player) → GAE → pool → PPO update
--   • Adam with step-counter bias-correction + gradient norm clip
--   • Advantage normalisation per update batch
--   • Entropy bonus β=0.01 sustained for exploration
-- ----------------------------------------------------------------
-- Rewards (the ONLY signals):
--   • +1.0 / -1.0 on interception (def/atk_holder)
--   •  0.004/step while ball is possessed (survival, same scale as γ)
--   • -0.15 on 10-s no-touch timeout (stagnation)
--   Everything else — spacing, passing, pressing, shadowing — must
--   be discovered entirely through self-play.
-- ================================================================
local SimMatch = {}
local Timer    = ...

-- ================================================================
-- §1  MATH UTILITIES
-- ================================================================

local TWO_PI = 2*math.pi

local function dist(x1,y1,x2,y2)
    local dx,dy=x2-x1,y2-y1; return math.sqrt(dx*dx+dy*dy) end

local function norm(dx,dy)
    local d=math.sqrt(dx*dx+dy*dy)
    if d<1e-4 then return 0,0,0 end
    return dx/d,dy/d,d end

local function clamp(v,lo,hi) return math.max(lo,math.min(hi,v)) end
local function lerp(a,b,t)    return a+(b-a)*t end
local function rng(a,b)       return a+math.random()*(b-a) end

local function clampCircle(x,y,cx,cy,r)
    local dx,dy=x-cx,y-cy; local d=math.sqrt(dx*dx+dy*dy)
    if d>r then return cx+dx*(r/d),cy+dy*(r/d) end
    return x,y end

local function angleDiff(a,b)
    local d=(b-a)%TWO_PI
    if d>math.pi then d=d-TWO_PI end; return d end

local function lerpAngle(a,b,t) return a+angleDiff(a,b)*t end

-- ================================================================
-- §2  NEURAL NETWORK  (fixed Adam · He init · gradient clipping)
-- ================================================================
-- Architecture: shared trunk → policy heads (move + ball) + value head
-- move logits [1..9], ball logits [10..16], value [17]
-- ================================================================

local NN = {}

-- Hyper-params
local ADAM_B1    = 0.9
local ADAM_B2    = 0.999
local ADAM_EPS   = 1e-8
local ADAM_LR    = 2e-4
local MAX_GNORM  = 0.5    -- gradient clipping (L2 norm)

-- Network shape
local INPUT_SZ   = 48
local HIDDEN_SZ  = {128, 64}
local MOVE_DIM   = 9      -- 8 compass directions + stay
local BALL_DIM   = 7      -- pass1-5, dribble/press, hold/shadow
local OUTPUT_SZ  = MOVE_DIM + BALL_DIM + 1   -- 17 (last = value)

-- Movement direction table (unit vectors for 8 dirs + {0,0} for stay)
local MOVE_DIRS = {
    {1,0},{1,1},{0,1},{-1,1},{-1,0},{-1,-1},{0,-1},{1,-1},{0,0}
}
do  -- normalise diagonal directions
    for i=1,8 do
        local d=MOVE_DIRS[i]
        local len=math.sqrt(d[1]*d[1]+d[2]*d[2])
        if len>0 then MOVE_DIRS[i]={d[1]/len,d[2]/len} end
    end
end
local MOVE_SCALE = 55   -- pixels per decision-frame

-- ── Layer construction ─────────────────────────────────────────

function NN.newLayer(inSz,outSz)
    local sc=math.sqrt(2.0/inSz)   -- He initialisation
    local nw=inSz*outSz
    local w,m1w,m2w={},{},{}
    for k=1,nw do w[k]=(math.random()*2-1)*sc; m1w[k]=0; m2w[k]=0 end
    local b,m1b,m2b={},{},{}
    for k=1,outSz do b[k]=0; m1b[k]=0; m2b[k]=0 end
    return {w=w,b=b,m1w=m1w,m2w=m2w,m1b=m1b,m2b=m2b,
            inSz=inSz,outSz=outSz}
end

function NN.newNet(inSz,hiddens,outSz)
    local layers,prev={},inSz
    for _,h in ipairs(hiddens) do
        layers[#layers+1]=NN.newLayer(prev,h); prev=h end
    layers[#layers+1]=NN.newLayer(prev,outSz)
    return {layers=layers, t=0}   -- t = global Adam step counter
end

-- ── Forward pass (returns output vec + cache for backprop) ─────

function NN.fwd(net,x)
    local L=#net.layers
    local acts,zs={x},{}
    for li=1,L do
        local ly=net.layers[li]
        local iSz,oSz=ly.inSz,ly.outSz
        local z={}
        for i=1,oSz do
            local s=ly.b[i]; local off=(i-1)*iSz
            for j=1,iSz do s=s+ly.w[off+j]*x[j] end
            z[i]=s
        end
        local a={}
        if li<L then   -- hidden layers: tanh
            for i=1,oSz do a[i]=math.tanh(z[i]) end
        else           -- output layer: linear (policy logits + value)
            for i=1,oSz do a[i]=z[i] end
        end
        zs[li]=z; acts[li+1]=a; x=a
    end
    return acts[L+1],{acts=acts,zs=zs}
end

-- ── Backward pass ──────────────────────────────────────────────

function NN.bwd(net,cache,dout)
    local L=#net.layers
    local acts,zs=cache.acts,cache.zs
    local grads={}
    local delta=dout
    for li=L,1,-1 do
        local ly=net.layers[li]
        local iSz,oSz=ly.inSz,ly.outSz
        local aprev=acts[li]
        if li<L then   -- apply tanh derivative for hidden layers
            local nd={}
            local z=zs[li]
            for i=1,oSz do
                local th=math.tanh(z[i]); nd[i]=delta[i]*(1-th*th) end
            delta=nd
        end
        local dw,db={},{}
        for i=1,oSz do
            db[i]=delta[i]; local off=(i-1)*iSz
            for j=1,iSz do dw[off+j]=delta[i]*aprev[j] end
        end
        local dap={}
        for j=1,iSz do
            local s=0
            for i=1,oSz do s=s+ly.w[(i-1)*iSz+j]*delta[i] end
            dap[j]=s
        end
        grads[li]={dw=dw,db=db}; delta=dap
    end
    return grads
end

-- ── Adam step with gradient norm clipping ──────────────────────
-- net.t is the global step counter; bias correction = 1-β^t

function NN.adamStep(net,grads,lr)
    lr=lr or ADAM_LR
    net.t = net.t+1
    local t=net.t
    local ibc1=1/(1-ADAM_B1^t)
    local ibc2=1/(1-ADAM_B2^t)

    -- Compute global gradient L2 norm
    local gnorm_sq=0
    for li=1,#net.layers do
        local g=grads[li]
        if g then
            for k=1,#g.dw do gnorm_sq=gnorm_sq+g.dw[k]*g.dw[k] end
            for k=1,#g.db do gnorm_sq=gnorm_sq+g.db[k]*g.db[k] end
        end
    end
    local clip=1.0
    local gnorm=math.sqrt(gnorm_sq)
    if gnorm>MAX_GNORM then clip=MAX_GNORM/gnorm end

    for li=1,#net.layers do
        local ly=net.layers[li]; local g=grads[li]
        if g then
            for k=1,#ly.w do
                local gk=g.dw[k]*clip
                ly.m1w[k]=ADAM_B1*ly.m1w[k]+(1-ADAM_B1)*gk
                ly.m2w[k]=ADAM_B2*ly.m2w[k]+(1-ADAM_B2)*gk*gk
                local mhat=ly.m1w[k]*ibc1
                local vhat=ly.m2w[k]*ibc2
                ly.w[k]=ly.w[k]-lr*mhat/(math.sqrt(vhat)+ADAM_EPS)
            end
            for k=1,#ly.b do
                local gk=g.db[k]*clip
                ly.m1b[k]=ADAM_B1*ly.m1b[k]+(1-ADAM_B1)*gk
                ly.m2b[k]=ADAM_B2*ly.m2b[k]+(1-ADAM_B2)*gk*gk
                local mhat=ly.m1b[k]*ibc1
                local vhat=ly.m2b[k]*ibc2
                ly.b[k]=ly.b[k]-lr*mhat/(math.sqrt(vhat)+ADAM_EPS)
            end
        end
    end
end

-- ── Masked softmax + categorical sample ────────────────────────

function NN.softmax(logits,valid)
    local maxv=-math.huge
    for _,i in ipairs(valid) do
        if logits[i]>maxv then maxv=logits[i] end end
    local sum,ex=0,{}
    for _,i in ipairs(valid) do
        local e=math.exp(clamp(logits[i]-maxv,-20,20))
        ex[i]=e; sum=sum+e end
    local p={}
    for k=1,#logits do p[k]=0 end
    for _,i in ipairs(valid) do p[i]=ex[i]/(sum+1e-10) end
    return p
end

function NN.sample(probs,valid)
    local r,cum=math.random(),0
    for _,i in ipairs(valid) do
        cum=cum+(probs[i] or 0)
        if r<=cum then return i end
    end
    return valid[#valid]
end

function NN.logProb(probs,a_idx)
    return math.log((probs[a_idx] or 0)+1e-10)
end

function NN.entropy(probs,valid)
    local h=0
    for _,i in ipairs(valid) do
        local p=probs[i] or 0
        if p>1e-10 then h=h-p*math.log(p) end
    end
    return h
end

-- ================================================================
-- §3  TEAM AGENT  (PPO + GAE · shared by all same-role players)
-- ================================================================
-- Each team (atk/def) shares ONE network.  All same-role players
-- contribute transitions to a shared pool.  When the pool is large
-- enough the agent runs K PPO epochs over it, then clears.
-- ================================================================

local PPO_GAMMA   = 0.99
local PPO_LAMBDA  = 0.95   -- GAE λ
local PPO_EPS     = 0.2    -- clip epsilon
local PPO_K       = 4      -- update epochs per rollout batch
local PPO_MBSZ    = 32     -- mini-batch size for each epoch pass
local PPO_TRIGGER = 96     -- pool size to trigger an update
local VCOEF       = 0.5    -- value loss coefficient
local ECOEF       = 0.01   -- entropy bonus coefficient

local TeamAgent = {}
TeamAgent.__index = TeamAgent

function TeamAgent.new(isDefender)
    local ta = setmetatable({}, TeamAgent)
    ta.net        = NN.newNet(INPUT_SZ, HIDDEN_SZ, OUTPUT_SZ)
    ta.isDefender = isDefender
    ta.pool       = {}   -- GAE-processed transitions ready for PPO
    ta.updates    = 0    -- total PPO update calls
    return ta
end

-- ── GAE computation over a single player's rollout ─────────────
-- rollout : array of {s,a_m,a_b,r,done,lp_old,v_old,vm,vb}
-- boot_v  : V(s_{T+1}), bootstrapped from current net

function TeamAgent:computeGAE(rollout, boot_v)
    local T=#rollout
    local gae=0
    local v_next=boot_v
    for t=T,1,-1 do
        local exp=rollout[t]
        local nt=1-exp.done
        local delta=exp.r + PPO_GAMMA*v_next*nt - exp.v_old
        gae=delta + PPO_GAMMA*PPO_LAMBDA*nt*gae
        exp.adv=gae
        exp.ret=gae+exp.v_old
        v_next=exp.v_old
    end
    return rollout
end

-- ── Add a processed rollout to the team pool and maybe update ──

function TeamAgent:addRollout(processed)
    for _,exp in ipairs(processed) do
        self.pool[#self.pool+1]=exp end
    if #self.pool >= PPO_TRIGGER then
        self:ppoUpdate()
        self.pool={}
    end
end

-- ── PPO update: normalise advantages, K epochs, mini-batches ───

function TeamAgent:ppoUpdate()
    local pool=self.pool
    local N=#pool
    if N<2 then return end

    -- Advantage normalisation
    local mu=0
    for _,e in ipairs(pool) do mu=mu+e.adv end; mu=mu/N
    local sig2=0
    for _,e in ipairs(pool) do
        local d=e.adv-mu; sig2=sig2+d*d end
    local sigma=math.sqrt(sig2/N+1e-8)
    for _,e in ipairs(pool) do e.adv_n=(e.adv-mu)/sigma end

    -- K epochs over shuffled mini-batches
    for _=1,PPO_K do
        -- Fisher-Yates shuffle
        local idx={}
        for i=1,N do idx[i]=i end
        for i=N,2,-1 do
            local j=math.random(i); idx[i],idx[j]=idx[j],idx[i] end

        local mb_s=1
        while mb_s<=N do
            local mb_e=math.min(mb_s+PPO_MBSZ-1,N)
            local inv=1.0/(mb_e-mb_s+1)
            local gacc=nil

            for k=mb_s,mb_e do
                local exp=pool[idx[k]]

                -- Forward pass with current weights
                local out,cache=NN.fwd(self.net,exp.s)

                -- Extract logits for both heads
                local mlog,blog={},{}
                for i=1,MOVE_DIM do mlog[i]=out[i] end
                for i=1,BALL_DIM do blog[i]=out[MOVE_DIM+i] end
                local v_new=out[OUTPUT_SZ]

                -- Probabilities under new policy
                local mp=NN.softmax(mlog,exp.vm)
                local bp=NN.softmax(blog,exp.vb)

                -- New log-prob for stored actions
                local lp_new = NN.logProb(mp,exp.a_m) + NN.logProb(bp,exp.a_b)

                -- PPO importance ratio (combined)
                local ratio=math.exp(clamp(lp_new-exp.lp_old,-10,10))
                local A=exp.adv_n

                -- Determine if gradient should be applied (clip gate):
                -- Block gradient when ratio is already beyond clip in the
                -- direction that would improve A (i.e. already "too good").
                local apply_pg = true
                if A>=0 and ratio>=(1+PPO_EPS) then apply_pg=false end
                if A<0  and ratio<=(1-PPO_EPS) then apply_pg=false end

                -- ── Build output gradient vector ────────────────
                local dout={}
                for i=1,OUTPUT_SZ do dout[i]=0 end

                -- Policy gradient for move head [1..MOVE_DIM]
                if apply_pg then
                    for i=1,MOVE_DIM do
                        local p=mp[i] or 0
                        local is_a=(i==exp.a_m) and 1 or 0
                        -- Gradient of -min(r*A, clip*A) ≈ -A*(1_{i=a}-p)
                        dout[i]=(-A*(is_a-p))*inv
                    end
                end
                -- Policy gradient for ball head [MOVE_DIM+1..MOVE_DIM+BALL_DIM]
                if apply_pg then
                    for i=1,BALL_DIM do
                        local p=bp[i] or 0
                        local is_a=(i==exp.a_b) and 1 or 0
                        dout[MOVE_DIM+i]=(-A*(is_a-p))*inv
                    end
                end

                -- Value loss: VCOEF*(V-G)²  →  d/dV = 2*VCOEF*(V-G)
                local v_err=v_new-exp.ret
                dout[OUTPUT_SZ]=(2*VCOEF*v_err)*inv

                -- Entropy regularisation: maximise H → add -ECOEF*H to loss
                -- d(-H)/d(logit_i) = p_i*(log p_i + 1)
                for i=1,MOVE_DIM do
                    local p=mp[i] or 0
                    if p>1e-10 then
                        dout[i]=dout[i]+(-ECOEF*p*(math.log(p)+1))*inv
                    end
                end
                for i=1,BALL_DIM do
                    local p=bp[i] or 0
                    if p>1e-10 then
                        dout[MOVE_DIM+i]=dout[MOVE_DIM+i]+(-ECOEF*p*(math.log(p)+1))*inv
                    end
                end

                -- Backprop
                local grads=NN.bwd(self.net,cache,dout)

                -- Lazy-init and accumulate gradients
                if not gacc then
                    gacc={}
                    for li=1,#self.net.layers do
                        local ly=self.net.layers[li]
                        local dw,db={},{}
                        for kk=1,#ly.w do dw[kk]=0 end
                        for kk=1,#ly.b do db[kk]=0 end
                        gacc[li]={dw=dw,db=db}
                    end
                end
                for li=1,#self.net.layers do
                    local g=grads[li]
                    if g then
                        local ga=gacc[li]
                        for kk=1,#g.dw do ga.dw[kk]=ga.dw[kk]+g.dw[kk] end
                        for kk=1,#g.db do ga.db[kk]=ga.db[kk]+g.db[kk] end
                    end
                end
            end  -- mini-batch

            if gacc then NN.adamStep(self.net,gacc) end
            mb_s=mb_e+1
        end  -- while
    end  -- K epochs

    self.updates=self.updates+1
end

-- ================================================================
-- §4  PLAYER BUFFER  (per-player on-policy rollout collection)
-- ================================================================
-- Collects ROLLOUT_T transitions independently per player.
-- When full: computes GAE with V(s_{T+1}) bootstrap → flushes to
-- the team's shared pool.
-- ================================================================

local ROLLOUT_T = 24   -- decisions per player before contributing

local PlayerBuffer = {}
PlayerBuffer.__index = PlayerBuffer

function PlayerBuffer.new(teamAgent)
    local pb=setmetatable({},PlayerBuffer)
    pb.team    = teamAgent
    pb.rollout = {}
    -- Previous decision bookkeeping
    pb.lastS   = nil
    pb.lastAm  = nil   -- move action index
    pb.lastAb  = nil   -- ball action index
    pb.lastLp  = 0     -- log π_old(a_m, a_b | s)
    pb.lastV   = 0     -- V(s) at decision time
    pb.lastVm  = nil   -- valid move mask
    pb.lastVb  = nil   -- valid ball mask
    pb.accR    = 0     -- reward accumulator since last decision
    pb.done    = false -- episode-done flag
    return pb
end

function PlayerBuffer:addReward(r) self.accR=self.accR+r end
function PlayerBuffer:setDone()   self.done=true end

-- Call BEFORE executing the new action (records previous transition).
-- newS   : current observation vector
-- a_m,a_b: chosen move / ball action indices
-- lp     : log π_new(a_m,a_b | newS)
-- v      : V(newS) from critic
-- vm,vb  : valid masks at newS
function PlayerBuffer:step(newS,a_m,a_b,lp,v,vm,vb)
    -- Push previous transition if it exists
    if self.lastS then
        self.rollout[#self.rollout+1]={
            s     = self.lastS,
            a_m   = self.lastAm,
            a_b   = self.lastAb,
            lp_old= self.lastLp,
            v_old = self.lastV,
            vm    = self.lastVm,
            vb    = self.lastVb,
            r     = clamp(self.accR,-2,2),
            done  = self.done and 1 or 0,
        }
        self.accR=0; self.done=false
    end

    -- If rollout is full: compute GAE and send to team pool
    if #self.rollout >= ROLLOUT_T then
        local boot_out=NN.fwd(self.team.net, newS)
        local boot_v=boot_out[OUTPUT_SZ]
        local processed=self.team:computeGAE(self.rollout, boot_v)
        self.team:addRollout(processed)
        self.rollout={}
    end

    -- Store current decision for next step
    self.lastS=newS; self.lastAm=a_m; self.lastAb=a_b
    self.lastLp=lp;  self.lastV=v
    self.lastVm=vm;  self.lastVb=vb
end

-- ================================================================
-- §5  CONFIG
-- ================================================================

local Cfg = {
    arenaR = 160,
    ball = {
        friction    = 0.962,
        stopSpeed   = 0.22,
        receiveR    = 9,
        softR       = 17,
        speed = {
            driven  = {near=6.2, far=11.5},
            normal  = {near=4.0, far= 7.8},
            soft    = {near=2.5, far= 4.8},
        },
        maxPassDist = 220,
    },
    pl = {
        mode = {
            idle      = {accel=0.09, top=0.80},
            walk      = {accel=0.18, top=1.75},
            recv      = {accel=0.38, top=4.30},
            fetch     = {accel=0.30, top=3.20},
            press     = {accel=0.26, top=2.50},
            intercept = {accel=0.42, top=4.60},
            drib      = {accel=0.22, top=2.80},
        },
        turnRate    = 0.19,
        friction    = 0.80,
        stopDist    = 1.5,
        idleAreaR   = 36,
        pressureR   = 30,
        colR        = 8,
        cooldown    = 18,      -- frames between decisions per player
        holderCD    = 8,       -- faster decision rate for holder
    },
    pass = {
        looseBase       = 0.07,
        loosePressBonus = 0.10,
    },
    layout = {
        {id="p1",angle=  0,r=160,def=false},
        {id="p2",angle= 60,r=160,def=false},
        {id="p3",angle=120,r=160,def=false},
        {id="p4",angle=180,r=160,def=false},
        {id="p5",angle=240,r=160,def=false},
        {id="p6",angle=300,r=160,def=false},
        {id="p7",angle= 30,r= 70,def=true },
        {id="p8",angle=210,r= 70,def=true },
    },
    fps=60, dt=1/60,
}

-- ── Reward constants (sparse; NO shaping beyond these) ──────────
local RW_INTERCEPT   =  1.0    -- defender who catches ball
local RW_LOSE_BALL   = -1.0    -- attacker whose pass was intercepted
local RW_SURVIVAL    =  0.004  -- per frame, all atk, while ball possessed
local RW_TIMEOUT     = -0.15   -- all players on 10-s no-touch timeout
local NO_TOUCH_LIMIT = 600

-- ================================================================
-- §6  SIMATCH CONSTRUCTOR
-- ================================================================

function SimMatch:new(init)
    local o=init or {}
    setmetatable(o,self); self.__index=self

    o.im             = init.im
    o.timer          = nil
    o.frame          = 0
    o.lastTouchFrame = 0

    -- Two shared team networks
    o.atkAgent = TeamAgent.new(false)
    o.defAgent = TeamAgent.new(true)

    -- Ball state
    o.ball={x=0,y=0,vx=0,vy=0,
            holder=nil,inFlight=false,
            target=nil,targetX=0,targetY=0,lastHolder=nil}

    -- Build players
    o.players={}; o.playerList={}

    for i,pcfg in ipairs(Cfg.layout) do
        local rad  = math.rad(pcfg.angle)
        local bx   = pcfg.r*math.cos(rad)
        local by   = pcfg.r*math.sin(rad)
        local isDef= pcfg.def

        local ckCX = isDef and 0  or bx
        local ckCY = isDef and 0  or by
        local ckR  = isDef and Cfg.arenaR or Cfg.pl.idleAreaR

        local teamAgent = isDef and o.defAgent or o.atkAgent

        local p={
            id           = pcfg.id,
            btSlot       = i-1,
            isDefender   = isDef,

            baseX=bx, baseY=by,
            x=bx, y=by, vx=0, vy=0,
            facing=rad,

            ckCX=ckCX, ckCY=ckCY, ckR=ckR,

            moveTarget   = {x=bx,y=by},
            moveMode     = "idle",

            buf          = PlayerBuffer.new(teamAgent),
            lastDecision = -Cfg.pl.cooldown,

            framesSinceTouch = 0,
            framesSinceRecv  = 9999,
        }
        o.players[pcfg.id]=p
        table.insert(o.playerList,p)
    end

    -- Give ball to p1
    local starter=o.players["p1"]
    o.ball.x=starter.x; o.ball.y=starter.y
    o.ball.holder="p1"; o.ball.lastHolder="p1"
    starter.framesSinceRecv=0

    o:subscribeBindings()
    o:startLoop()
    return o
end

-- ================================================================
-- §7  CHANNEL / PUBLISH HELPERS
-- ================================================================

function SimMatch:chanX(id)
    local n=tonumber(id:match("p(%d+)"))
    if not n then return id.."X" end
    if n<=6 then return "1X"..n
    elseif n==7 then return "2X1"
    else return "2X2" end
end

function SimMatch:chanY(id)
    local n=tonumber(id:match("p(%d+)"))
    if not n then return id.."Y" end
    if n<=6 then return "1Y"..n
    elseif n==7 then return "2Y1"
    else return "2Y2" end
end

function SimMatch:pub(id,x,y)
    if id=="ball" then
        self.im.Publish("ballX",x); self.im.Publish("ballY",y)
    else
        self.im.Publish(self:chanX(id),x)
        self.im.Publish(self:chanY(id),y)
    end
end

function SimMatch:subscribeBindings()
    for id,p in pairs(self.players) do
        local xc,yc=self:chanX(id),self:chanY(id)
        self.im.Subscribe(xc,function() self.im.Publish(xc,p.x) end)
        self.im.Subscribe(yc,function() self.im.Publish(yc,p.y) end)
    end
    self.im.Subscribe("ballX",function() self.im.Publish("ballX",self.ball.x) end)
    self.im.Subscribe("ballY",function() self.im.Publish("ballY",self.ball.y) end)
end

-- ================================================================
-- §8  QUERY / SORT HELPERS
-- ================================================================

function SimMatch:getSortedTeammates(p)
    local list={}
    for id,q in pairs(self.players) do
        if id~=p.id and q.isDefender==p.isDefender then
            list[#list+1]={id=id,d=dist(p.x,p.y,q.x,q.y)}
        end
    end
    table.sort(list,function(a,b) return a.d<b.d end)
    local ids={}; for _,v in ipairs(list) do ids[#ids+1]=v.id end
    return ids
end

function SimMatch:getSortedAttackers(x,y)
    local list={}
    for id,p in pairs(self.players) do
        if not p.isDefender then
            list[#list+1]={id=id,d=dist(x,y,p.x,p.y)}
        end
    end
    table.sort(list,function(a,b) return a.d<b.d end)
    local ids={}; for _,v in ipairs(list) do ids[#ids+1]=v.id end
    return ids
end

function SimMatch:getSortedOthers(p)
    local list={}
    for id,q in pairs(self.players) do
        if id~=p.id then
            list[#list+1]={id=id, d=dist(p.x,p.y,q.x,q.y),
                           sameTeam=(q.isDefender==p.isDefender),
                           q=q}
        end
    end
    table.sort(list,function(a,b) return a.d<b.d end)
    return list
end

function SimMatch:nearestDef(x,y,excl)
    local bestId,bestD=nil,math.huge
    for id,p in pairs(self.players) do
        if p.isDefender and id~=(excl or "") then
            local d=dist(x,y,p.x,p.y)
            if d<bestD then bestD=d; bestId=id end
        end
    end
    return bestId,bestD
end

function SimMatch:nearestAtk(x,y,excl)
    local bestId,bestD=nil,math.huge
    for id,p in pairs(self.players) do
        if not p.isDefender and id~=(excl or "") then
            local d=dist(x,y,p.x,p.y)
            if d<bestD then bestD=d; bestId=id end
        end
    end
    return bestId,bestD
end

-- ================================================================
-- §9  MOVEMENT PHYSICS  (unchanged)
-- ================================================================

function SimMatch:walkTo(p,tx,ty,mode)
    p.moveTarget={x=tx,y=ty}
    p.moveMode  = mode or "walk"
end

function SimMatch:applyMovement(p)
    local mt=Cfg.pl.mode[p.moveMode] or Cfg.pl.mode.idle
    local tx,ty=p.moveTarget.x,p.moveTarget.y
    local dx,dy,d=norm(tx-p.x,ty-p.y)

    if d>Cfg.pl.stopDist then
        p.vx=p.vx+dx*mt.accel; p.vy=p.vy+dy*mt.accel
        local spd=math.sqrt(p.vx*p.vx+p.vy*p.vy)
        if spd>mt.top then
            local s=mt.top/spd; p.vx=p.vx*s; p.vy=p.vy*s end
        local sd=spd*spd/(2*mt.accel+0.001)
        if d<sd*1.1 then
            p.vx=p.vx*Cfg.pl.friction; p.vy=p.vy*Cfg.pl.friction end
    else
        p.vx=p.vx*Cfg.pl.friction; p.vy=p.vy*Cfg.pl.friction
        if math.abs(p.vx)<0.04 and math.abs(p.vy)<0.04 then
            p.vx,p.vy=0,0 end
        if p.moveMode~="idle" then p.moveMode="idle" end
    end

    p.x=p.x+p.vx; p.y=p.y+p.vy

    local spd=math.sqrt(p.vx*p.vx+p.vy*p.vy)
    if spd>0.15 then
        p.facing=lerpAngle(p.facing,math.atan2(p.vy,p.vx),Cfg.pl.turnRate) end

    p.x,p.y=clampCircle(p.x,p.y,p.ckCX,p.ckCY,p.ckR)
end

function SimMatch:resolveCollisions()
    local list=self.playerList; local r=Cfg.pl.colR
    for i=1,#list do
        for j=i+1,#list do
            local a,b=list[i],list[j]
            local dx,dy=b.x-a.x,b.y-a.y
            local d=math.sqrt(dx*dx+dy*dy)
            if d<r and d>0.001 then
                local push=(r-d)*0.55; local nx,ny=dx/d,dy/d
                a.x=a.x-nx*push; a.y=a.y-ny*push
                b.x=b.x+nx*push; b.y=b.y+ny*push
                a.vx=a.vx-nx*push*0.5; a.vy=a.vy-ny*push*0.5
                b.vx=b.vx+nx*push*0.5; b.vy=b.vy+ny*push*0.5
            end
        end
    end
end

-- ================================================================
-- §10  BALL PHYSICS
-- ================================================================

function SimMatch:kickPass(fromId,toId,ptype)
    local ball=self.ball
    local passer=self.players[fromId]
    local recvr=self.players[toId]
    if not passer or not recvr then return end

    local dx,dy,d=norm(recvr.x-passer.x,recvr.y-passer.y)
    if d<1 then return end

    local speeds=Cfg.ball.speed[ptype] or Cfg.ball.speed.normal
    local t=clamp(d/Cfg.ball.maxPassDist,0,1)
    local spd=lerp(speeds.near,speeds.far,t)

    local _,defDist=self:nearestDef(passer.x,passer.y,fromId)
    local underPress=(defDist<Cfg.pl.pressureR)
    local loosePct=Cfg.pass.looseBase
    if underPress then loosePct=loosePct+Cfg.pass.loosePressBonus end

    local finalX,finalY=recvr.x,recvr.y
    if math.random()<loosePct then
        finalX=finalX+rng(-1,1)*22; finalY=finalY+rng(-1,1)*22 end

    ball.x=passer.x; ball.y=passer.y
    ball.vx=dx*spd;  ball.vy=dy*spd
    ball.inFlight=true; ball.holder=nil
    ball.lastHolder=fromId; ball.target=toId
    ball.targetX=finalX; ball.targetY=finalY

    self.lastTouchFrame=self.frame
    passer.framesSinceTouch=0

    -- Signal receiver to run for ball
    if recvr then self:walkTo(recvr,finalX,finalY,"recv") end

    -- Cancel other players' recv modes
    for id,p in pairs(self.players) do
        if id~=toId and (p.moveMode=="recv" or p.moveMode=="fetch") then
            p.moveMode="idle" end
    end
end

function SimMatch:updateBall()
    local ball=self.ball
    if not ball.inFlight then
        if ball.holder then
            local h=self.players[ball.holder]
            if h then ball.x,ball.y=h.x,h.y end
        end
        return
    end

    ball.x=ball.x+ball.vx; ball.y=ball.y+ball.vy
    ball.vx=ball.vx*Cfg.ball.friction; ball.vy=ball.vy*Cfg.ball.friction
    local spd=math.sqrt(ball.vx*ball.vx+ball.vy*ball.vy)

    for _,p in ipairs(self.playerList) do
        local d=dist(ball.x,ball.y,p.x,p.y)
        local thr=(spd<2.5) and Cfg.ball.softR or Cfg.ball.receiveR
        if p.id==ball.target then thr=thr*1.25 end
        if d<thr then self:onBallArrived(p.id); return end
    end

    if spd<Cfg.ball.stopSpeed or dist(ball.x,ball.y,0,0)>Cfg.arenaR+25 then
        ball.vx,ball.vy=0,0; ball.inFlight=false
        local nearId,_=self:nearestAtk(ball.x,ball.y)
        if nearId then self:walkTo(self.players[nearId],ball.x,ball.y,"fetch") end
    end
end

function SimMatch:onBallArrived(receiverId)
    local ball=self.ball
    local p=self.players[receiverId]
    local prevHolder=ball.lastHolder

    ball.x,ball.y=p.x,p.y
    ball.vx,ball.vy=0,0
    ball.inFlight=false; ball.target=nil
    self.lastTouchFrame=self.frame

    if p.isDefender then
        -- ── Interception ──────────────────────────────────────
        -- Sparse terminal reward: defender wins, passer loses.
        p.buf:addReward(RW_INTERCEPT)
        p.buf:setDone()
        if prevHolder and self.players[prevHolder] then
            local prev=self.players[prevHolder]
            prev.buf:addReward(RW_LOSE_BALL)
            prev.buf:setDone()
        end
        self:doRoleSwap(receiverId,prevHolder)
    else
        -- ── Safe receipt ───────────────────────────────────────
        ball.holder=receiverId; ball.lastHolder=receiverId
        p.framesSinceRecv=0; p.framesSinceTouch=0
        self.lastTouchFrame=self.frame
    end

    for _,pl in ipairs(self.playerList) do
        if pl.moveMode=="recv" or pl.moveMode=="fetch" then
            pl.moveMode="idle" end
    end
    p.lastDecision=self.frame-Cfg.pl.cooldown
end

-- ================================================================
-- §11  ROLE SWAP  (game mechanic, not a learning artifact)
-- ================================================================

function SimMatch:doRoleSwap(defId,atkLoserId)
    local defP=self.players[defId]
    local atkP=atkLoserId and self.players[atkLoserId]
    if not defP then return end

    -- Swap team membership
    if atkP then
        defP.baseX,atkP.baseX=atkP.baseX,defP.baseX
        defP.baseY,atkP.baseY=atkP.baseY,defP.baseY
        defP.isDefender,atkP.isDefender=false,true
        defP.ckCX,atkP.ckCX=atkP.ckCX,defP.ckCX
        defP.ckCY,atkP.ckCY=atkP.ckCY,defP.ckCY
        defP.ckR, atkP.ckR =atkP.ckR, defP.ckR
        -- Swap player buffer team references
        defP.buf.team=self.atkAgent
        atkP.buf.team=self.defAgent
        atkP.lastDecision=self.frame-Cfg.pl.cooldown
    else
        defP.isDefender=false
        defP.buf.team=self.atkAgent
    end

    defP.lastDecision=self.frame-Cfg.pl.cooldown

    -- Transfer ball to new holder (was defender, now attacker)
    local ball=self.ball
    ball.x=defP.x; ball.y=defP.y
    ball.holder=defId; ball.lastHolder=defId
    defP.framesSinceRecv=0; defP.framesSinceTouch=0
end

-- ================================================================
-- §12  STATE BUILDER  (48-dim egocentric observation)
-- ================================================================
-- Layout:
--   [1-9]    Self: x/R, y/R, vx/4, vy/4, cos/sin(facing),
--                  dist_ctr/R, has_ball, is_def
--   [10-16]  Ball: bx_rel/R, by_rel/R, bvx/8, bvy/8,
--                  in_flight, ball_dist/R, touch_timer
--   [17-36]  5 nearest teammates × 4: rel_x/R, rel_y/R,
--                  dist/R, has_ball
--   [37-46]  2 nearest opponents × 5: rel_x/R, rel_y/R,
--                  dist/R, vx/4, vy/4
--   [47]     Is ball heading toward me (dot product, clamped)
--   [48]     Nearest opp dist / R (quick-access for value fn)
-- ================================================================

function SimMatch:buildState(p)
    local R=Cfg.arenaR
    local ball=self.ball
    local s={}
    local VN=4.5  -- approx max player speed for normalisation

    -- §12a  Self (9)
    s[1]=p.x/R; s[2]=p.y/R
    s[3]=clamp(p.vx/VN,-1,1); s[4]=clamp(p.vy/VN,-1,1)
    s[5]=math.cos(p.facing);   s[6]=math.sin(p.facing)
    s[7]=clamp(dist(p.x,p.y,0,0)/R,0,1)
    s[8]=(ball.holder==p.id) and 1 or 0
    s[9]=p.isDefender and 1 or 0

    -- §12b  Ball (7)
    local brx=(ball.x-p.x)/R; local bry=(ball.y-p.y)/R
    s[10]=clamp(brx,-2,2); s[11]=clamp(bry,-2,2)
    s[12]=clamp(ball.vx/8,-1,1); s[13]=clamp(ball.vy/8,-1,1)
    s[14]=ball.inFlight and 1 or 0
    s[15]=clamp(dist(p.x,p.y,ball.x,ball.y)/R,0,2)
    s[16]=clamp((p.framesSinceTouch or 0)/NO_TOUCH_LIMIT,0,1)

    -- §12c  5 nearest teammates (4 each = 20, indices 17-36)
    local others=self:getSortedOthers(p)
    local tIdx=17; local tmCnt=0
    for _,o in ipairs(others) do
        if o.sameTeam and tmCnt<5 then
            local q=o.q
            s[tIdx]=clamp((q.x-p.x)/R,-2,2)
            s[tIdx+1]=clamp((q.y-p.y)/R,-2,2)
            s[tIdx+2]=clamp(o.d/R,0,2)
            s[tIdx+3]=(ball.holder==q.id) and 1 or 0
            tIdx=tIdx+4; tmCnt=tmCnt+1
        end
    end
    while tmCnt<5 do  -- pad if fewer teammates
        s[tIdx]=0; s[tIdx+1]=0; s[tIdx+2]=2; s[tIdx+3]=0
        tIdx=tIdx+4; tmCnt=tmCnt+1
    end   -- tIdx ends at 37

    -- §12d  2 nearest opponents (5 each = 10, indices 37-46)
    local opCnt=0
    for _,o in ipairs(others) do
        if not o.sameTeam and opCnt<2 then
            local q=o.q
            s[37+opCnt*5]=clamp((q.x-p.x)/R,-2,2)
            s[38+opCnt*5]=clamp((q.y-p.y)/R,-2,2)
            s[39+opCnt*5]=clamp(o.d/R,0,2)
            s[40+opCnt*5]=clamp(q.vx/VN,-1,1)
            s[41+opCnt*5]=clamp(q.vy/VN,-1,1)
            opCnt=opCnt+1
        end
    end
    while opCnt<2 do
        for k=0,4 do s[37+opCnt*5+k]=0 end; opCnt=opCnt+1
    end  -- fills 37-46

    -- §12e  Global signals (47-48)
    -- How much is ball velocity pointing toward this player?
    local bspd=math.sqrt(ball.vx*ball.vx+ball.vy*ball.vy)
    if bspd>0.1 then
        local bvnx,bvny=ball.vx/bspd,ball.vy/bspd
        local tobx,toby=p.x-ball.x,p.y-ball.y
        local todist=math.sqrt(tobx*tobx+toby*toby)
        if todist>0.1 then
            s[47]=clamp(bvnx*(tobx/todist)+bvny*(toby/todist),-1,1)
        else s[47]=0 end
    else s[47]=0 end

    -- Nearest opponent distance
    local nearOppDist=math.huge
    for _,o in ipairs(others) do
        if not o.sameTeam then nearOppDist=math.min(nearOppDist,o.d) end
    end
    s[48]=clamp(nearOppDist/R,0,1)

    return s
end

-- ================================================================
-- §13  VALID ACTION MASKS
-- ================================================================
-- move_mask: all 9 movement directions always valid
-- ball_mask: depends on role and possession
--   Attacker + holder  : pass1-5 (by teammate rank), dribble(6), hold(7)
--   Attacker, no ball  : run-to-space(6), wait-for-ball(7)
--   Defender           : mark-k-th-atk(1-5), press-holder(6), shadow(7)
-- ================================================================

local ALL_MOVES = {1,2,3,4,5,6,7,8,9}

function SimMatch:getValidBall(p)
    local valid={}
    if p.isDefender then
        local atks=self:getSortedAttackers(p.x,p.y)
        for i=1,math.min(5,#atks) do valid[#valid+1]=i end
        valid[#valid+1]=6; valid[#valid+1]=7
    elseif self.ball.holder==p.id then
        local mates=self:getSortedTeammates(p)
        for i=1,math.min(5,#mates) do valid[#valid+1]=i end
        valid[#valid+1]=6; valid[#valid+1]=7
    else
        valid[1]=6; valid[2]=7  -- move to space or wait
    end
    if #valid==0 then valid[1]=7 end
    return valid
end

-- ================================================================
-- §14  DECISION LOOP  (on-policy collection + team net inference)
-- ================================================================

function SimMatch:decideAction(p)
    local teamNet=(p.isDefender and self.defAgent or self.atkAgent).net

    -- Build current observation
    local s_new=self:buildState(p)

    -- Valid masks
    local vm=ALL_MOVES
    local vb=self:getValidBall(p)

    -- Forward pass
    local out,_=NN.fwd(teamNet,s_new)

    -- Extract logits for both heads
    local mlog,blog={},{}
    for i=1,MOVE_DIM do mlog[i]=out[i] end
    for i=1,BALL_DIM do blog[i]=out[MOVE_DIM+i] end
    local v_est=out[OUTPUT_SZ]

    -- Sample actions
    local mp=NN.softmax(mlog,vm)
    local bp=NN.softmax(blog,vb)
    local a_m=NN.sample(mp,vm)
    local a_b=NN.sample(bp,vb)

    -- Log probability (sum of both action logs = joint log-prob)
    local lp=NN.logProb(mp,a_m)+NN.logProb(bp,a_b)

    -- Record previous transition + maybe flush rollout to team pool
    p.buf:step(s_new,a_m,a_b,lp,v_est,vm,vb)

    -- ── Apply movement ────────────────────────────────────────
    local dir=MOVE_DIRS[a_m]
    local tx=p.x+dir[1]*MOVE_SCALE
    local ty=p.y+dir[2]*MOVE_SCALE
    tx,ty=clampCircle(tx,ty,p.ckCX,p.ckCY,p.ckR)

    local mode
    if p.isDefender then mode="press"
    elseif self.ball.holder==p.id then mode="drib"
    else mode="walk" end
    self:walkTo(p,tx,ty,mode)

    -- ── Execute ball action ───────────────────────────────────
    self:executeBallAction(p,a_b)
end

-- ================================================================
-- §15  BALL ACTION EXECUTOR
-- ================================================================
-- Translates discrete ball-action index into a physical game command.
-- NO scripted agent logic here — the NN chose the action; we only
-- map it to the physics layer.
-- ================================================================

function SimMatch:executeBallAction(p,action)

    -- ── Defenders ─────────────────────────────────────────────
    if p.isDefender then
        if action>=1 and action<=5 then
            -- Mark the k-th nearest attacker
            local atks=self:getSortedAttackers(p.x,p.y)
            local tgtId=atks[action]
            if tgtId then
                local tgt=self.players[tgtId]
                self:walkTo(p,tgt.x,tgt.y,"press")
            end

        elseif action==6 then
            -- Aggressive press: head straight for ball / holder
            local hId=self.ball.holder
            if hId then
                self:walkTo(p,self.players[hId].x,self.players[hId].y,"intercept")
            elseif self.ball.inFlight then
                self:walkTo(p,self.ball.x,self.ball.y,"press")
            end

        elseif action==7 then
            -- Positional shadow: place between ball and nearest free atk
            local atks=self:getSortedAttackers(p.x,p.y)
            local tgtId=atks[1]
            if tgtId and self.ball.holder and self.ball.holder~=tgtId then
                local tgt=self.players[tgtId]
                local bx,by=self.ball.x,self.ball.y
                -- Stand halfway between ball and target
                local sx=(bx+tgt.x)*0.5; local sy=(by+tgt.y)*0.5
                self:walkTo(p,sx,sy,"walk")
            end
        end
        return
    end

    -- ── Attacker with ball ────────────────────────────────────
    if self.ball.holder~=p.id then
        -- No ball: action 6 = run to open space, 7 = wait
        if action==6 then
            -- Run toward a position that is far from defenders
            local bestX,bestY,bestScore=p.x,p.y,-math.huge
            for ang=0,360-45,45 do
                local rad=math.rad(ang)
                local tx=p.x+math.cos(rad)*60
                local ty=p.y+math.sin(rad)*60
                tx,ty=clampCircle(tx,ty,p.ckCX,p.ckCY,p.ckR)
                -- Score = distance from nearest defender
                local _,dd=self:nearestDef(tx,ty,nil)
                if dd>bestScore then
                    bestScore=dd; bestX=tx; bestY=ty end
            end
            self:walkTo(p,bestX,bestY,"walk")
        end
        -- action==7: hold position (movement from §14 already set)
        return
    end

    -- Ball holder actions
    if action>=1 and action<=5 then
        local mates=self:getSortedTeammates(p)
        local tgtId=mates[action]
        if tgtId then
            local tgt=self.players[tgtId]
            local d=dist(p.x,p.y,tgt.x,tgt.y)
            local _,defDist=self:nearestDef(p.x,p.y,p.id)
            local underPress=(defDist<Cfg.pl.pressureR)
            local ptype=d<80 and (underPress and "driven" or "normal") or "driven"
            self:kickPass(p.id,tgtId,ptype)
        end

    elseif action==6 then
        -- Dribble: movement already applied from §14's direction choice
        -- Just ensure the ball stays with holder (handled in main loop)
        p.framesSinceTouch=0

    elseif action==7 then
        -- Hold ball: stand still (movement from §14 may be stay dir)
        p.framesSinceTouch=0
    end
end

-- ================================================================
-- §16  PER-FRAME REWARDS  (sparse — only survival signal)
-- ================================================================

function SimMatch:applyFrameRewards()
    -- Survival reward: small signal for every frame ball stays possessed
    if self.ball.holder then
        local holder=self.players[self.ball.holder]
        if holder and not holder.isDefender then
            -- All attackers benefit from ball retention
            for _,p in ipairs(self.playerList) do
                if not p.isDefender then
                    p.buf:addReward(RW_SURVIVAL) end
            end
        end
    end

    -- Increment touch timers
    for _,p in ipairs(self.playerList) do
        p.framesSinceTouch=(p.framesSinceTouch or 0)+1
        if p.framesSinceRecv~=nil then
            p.framesSinceRecv=p.framesSinceRecv+1 end
    end
end

-- ================================================================
-- §17  NO-TOUCH TIMEOUT  (10 s → penalty + restart)
-- ================================================================

function SimMatch:checkNoTouchTimeout()
    if self.frame-self.lastTouchFrame < NO_TOUCH_LIMIT then return end

    -- Minimal stagnation penalty — no behavioural shaping
    for _,p in ipairs(self.playerList) do
        p.buf:addReward(RW_TIMEOUT)
        p.buf:setDone()
        p.framesSinceTouch=0
    end

    -- Reset ball to a random attacker
    local atks=self:getSortedAttackers(0,0)
    local lucky=atks[math.random(#atks)]
    if lucky then
        local h=self.players[lucky]
        self.ball.x=h.x; self.ball.y=h.y
        self.ball.vx=0; self.ball.vy=0
        self.ball.inFlight=false; self.ball.holder=lucky
        self.ball.lastHolder=lucky; self.ball.target=nil
        h.framesSinceRecv=0; h.framesSinceTouch=0
        h.lastDecision=self.frame-Cfg.pl.cooldown
    end
    self.lastTouchFrame=self.frame
end

-- ================================================================
-- §18  MAIN LOOP
-- ================================================================

function SimMatch:startLoop()
    if self.timer then self.timer:finalize() end
    local sim=self

    local function step()
        sim.frame=sim.frame+1
        local f=sim.frame
        local n=#sim.playerList

        -- 1. Per-frame sparse survival reward
        sim:applyFrameRewards()

        -- 2. Staggered NN decisions (round-robin slot)
        local slot=(f-1)%n
        local btP=sim.playerList[slot+1]
        if btP then
            local isHolder=(sim.ball.holder==btP.id)
            local cd=isHolder and Cfg.pl.holderCD or Cfg.pl.cooldown
            if f-btP.lastDecision >= cd then
                sim:decideAction(btP)
                btP.lastDecision=f
            end
        end

        -- 3. Safety: force holder to act if idle > holderCD frames
        if not sim.ball.inFlight and sim.ball.holder then
            local h=sim.players[sim.ball.holder]
            if h and not h.isDefender
               and (f-h.lastDecision) >= Cfg.pl.holderCD then
                sim:decideAction(h); h.lastDecision=f
            end
        end

        -- 4. Ball physics
        sim:updateBall()

        -- 5. Player movement
        for _,p in ipairs(sim.playerList) do sim:applyMovement(p) end

        -- 6. Loose-ball pickup
        if not sim.ball.inFlight and not sim.ball.holder then
            local nearId,nearDist=sim:nearestAtk(sim.ball.x,sim.ball.y)
            if nearId and nearDist<Cfg.ball.receiveR then
                sim.ball.holder=nearId; sim.ball.lastHolder=nearId
                sim.players[nearId].lastDecision=f-Cfg.pl.cooldown
                sim.players[nearId].framesSinceRecv=0
                sim.players[nearId].framesSinceTouch=0
                sim.lastTouchFrame=f
            end
        end

        -- 7. Sync ball to holder
        if not sim.ball.inFlight and sim.ball.holder then
            local h=sim.players[sim.ball.holder]
            if h then sim.ball.x,sim.ball.y=h.x,h.y end
        end

        -- 8. Collision resolution
        sim:resolveCollisions()

        -- 9. No-touch timeout check
        sim:checkNoTouchTimeout()

        -- 10. Publish positions
        for id,p in pairs(sim.players) do sim:pub(id,p.x,p.y) end
        sim:pub("ball",sim.ball.x,sim.ball.y)

        -- Schedule next frame
        sim.timer=Timer:new({
            id="rondoTimer", interval=Cfg.dt, reps=1,
            onTimerComplete=step,
        })
        sim.timer:start()
    end

    step()
end

-- ================================================================
-- §19  PUBLIC API
-- ================================================================

function SimMatch:update(elapsed)
    if self.timer then self.timer:update(elapsed) end
end

function SimMatch:finalize()
    if self.timer then self.timer:finalize() end
    for id,_ in pairs(self.players) do
        self.im.Unsubscribe(self:chanX(id))
        self.im.Unsubscribe(self:chanY(id))
    end
    self.im.Unsubscribe("ballX")
    self.im.Unsubscribe("ballY")
end

-- Expose training diagnostics for external monitoring
function SimMatch:getTrainingStats()
    return {
        atk = {
            updates = self.atkAgent.updates,
            poolSz  = #self.atkAgent.pool,
            netStep = self.atkAgent.net.t,
        },
        def = {
            updates = self.defAgent.updates,
            poolSz  = #self.defAgent.pool,
            netStep = self.defAgent.net.t,
        },
    }
end

return SimMatch
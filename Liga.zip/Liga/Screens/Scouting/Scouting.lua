local Scouting = {}
local FCPopup, Utils, sessionVars = ...
Scouting.__index = Scouting
local objnum = 4
local subobjnum = {2, 2, 1, 1}
Scouting.params = {
[1] = {
[1] = {"Any", "DEF", "MID", "ATT"},
[2] = {"Any", "GK", "RB", "LB", "CB", "RM", "LM", "CM", "CAM", "CDM", "CF", "LW", "RW", "RF", "LF", "ST"}
},
[2] = {
[1] = 17,
[2] = 50
},
[3] = {
[1] = {"Any", "Starter", "Wonderkid", "Veteran", "Sporadic"}
},
[4] = {
[1] = {"Any", "Dribbler", "Prolific", "Dueler", "Speedster", "Fox in the Box", "Poacher", "Playmaker", "Maestro", "Anchor", "Defensive minded"}
}
}

local function getIdxfromObj(par, sub)
local idx = 0
  if par ~= 1 then
    for i = 1, (par - 1) do
      idx = idx + subobjnum[i]
    end
  end
  idx = idx + sub
  return idx
end

function Scouting:new(init)
  local o = init or {}
  setmetatable(o, self)

  o.onFocus = 1
  o.onFocusSub = 1
  o.currentConfig = {1, 1, 1, 1, 1, 1, 0} -- 6 params derived from sub obj number total {2, 2, 1, 1} and last is days
  o.FCPopup = FCPopup:new({nav = o.nav})

  -- Register all parent and sub focus actions
  for i = 1, objnum do
    o.im.Subscribe("onfocus" .. i, function()
      o.im.Publish("onfocus" .. i, o.onFocus == i)
    end)

    o.im.RegisterAction("act_focus" .. i, function()
      o:focus("parent", i)
    end)

    for j = 1, (subobjnum[i] or 1) do
      local key = "onfocus" .. i .. j
      local textkey= "text" .. i .. j
      o.im.Subscribe(key, function()
        o.im.Publish(key, (o.onFocus == i and o.onFocusSub == j))
      end)
      
      o.im.Subscribe(textkey, function()
        o:displayParams(textkey, i, j)
      end)

      o.im.RegisterAction("act_focus" .. i .. j, function()
        o:focus("sub", i, j)
      end)
    end
  end
  
  o.im.RegisterAction("decrease", function()
    o:modifyParams(-1)
  end)
  o.im.RegisterAction("increase", function()
    o:modifyParams(1)
  end)
  o.im.RegisterAction("exit", function()
    o:onLeave()
  end)
  return o
end

function Scouting:onLeave()
  local message = "Leaving without submitting instructions will cause unsubmitted instructions not to be submitted, Do you want to proceed?"
  local buttonData = {"Yes", "Submit"}
  self.FCPopup:getResponse(message, buttonData, function(clickResponse)
    if clickResponse == 1 then
        self.nav.Event(nil, "evt_back")          
    elseif clickResponse == 2 then      
      sessionVars.set("scoutedPlayers", {})
      sessionVars.set("scoutParam", self.currentConfig)
      self.nav.Event(nil, "evt_back")
    end
  end)
end

function Scouting:decodeConfig()
  local config = sessionVars.get("scoutParam") or {1, 1, 1, 1, 1, 1}
  local result = {}
  local minBase, maxBase = 17, 50
  local idx = 0

  local function resolve(par, sub, idxVal)
    if par == 2 then
      -- Age parameters
      return tostring(minBase + (idxVal - 1))
    else
      local paramSet = Scouting.params[par][sub]
      if type(paramSet) == "table" then
        return paramSet[idxVal] or tostring(idxVal)
      else
        return tostring(paramSet)
      end
    end
  end

  for par = 1, #subobjnum do
    for sub = 1, subobjnum[par] do
      idx = idx + 1
      local label

      if par == 1 and sub == 1 then label = "Role"
      elseif par == 1 and sub == 2 then label = "Position"
      elseif par == 2 and sub == 1 then label = "MinAge"
      elseif par == 2 and sub == 2 then label = "MaxAge"
      elseif par == 3 then label = "Status"
      elseif par == 4 then label = "Trait"
      else label = "Param" .. par .. "_" .. sub
      end

      result[label] = resolve(par, sub, config[idx])
    end
  end

  return result
end

function Scouting:modifyParams(dir)
  local idx = getIdxfromObj(self.onFocus, self.onFocusSub)
  local bnd = "text" .. self.onFocus .. self.onFocusSub

  if self.onFocus == 2 then
    local minBase, maxBase = 17, 50
    local minIdx, maxIdx = getIdxfromObj(2, 1), getIdxfromObj(2, 2)

    if not self.currentConfig[minIdx] or self.currentConfig[minIdx] == 0 then self.currentConfig[minIdx] = 1 end
    if not self.currentConfig[maxIdx] or self.currentConfig[maxIdx] == 0 then self.currentConfig[maxIdx] = (maxBase - minBase + 1) end

    local minValue = minBase + (self.currentConfig[minIdx] - 1)
    local maxValue = minBase + (self.currentConfig[maxIdx] - 1)

    if self.onFocusSub == 1 then
    
      local newMin = math.max(minBase, math.min(maxValue, minValue + dir))
      self.currentConfig[minIdx] = newMin - minBase + 1
      self.im.Publish(bnd, tostring(newMin))

    elseif self.onFocusSub == 2 then
    
      local newMax = math.max(minValue, math.min(maxBase, maxValue + dir))
      self.currentConfig[maxIdx] = newMax - minBase + 1
      self.im.Publish(bnd, tostring(newMax))
    end
    return
  end

  local currentConfig = self.currentConfig[idx]
  local paramSet = Scouting.params[self.onFocus][self.onFocusSub]
  local maxConfig = type(paramSet) == "table" and #paramSet or 1

  currentConfig = currentConfig + dir
  if currentConfig > maxConfig then
    currentConfig = 1
  elseif currentConfig < 1 then
    currentConfig = maxConfig
  end

  self.currentConfig[idx] = currentConfig
  self:displayParams(bnd, self.onFocus, self.onFocusSub)
end

function Scouting:displayParams(bnd, par, sub)
  local idx = getIdxfromObj(par, sub)
  local currentConfig = self.currentConfig[idx]
  local str = type(Scouting.params[par][sub]) == "table" and Scouting.params[par][sub][currentConfig] or Scouting.params[par][sub]
  self.im.Publish(bnd, str)
end

function Scouting:clearAllFocus()
  for i = 1, objnum do
    self.im.Publish("onfocus" .. i, false)
    for j = 1, (subobjnum[i] or 1) do
      self.im.Publish("onfocus" .. i .. j, false)
    end
  end
end

function Scouting:focus(type, i, j)
  self:clearAllFocus()

  if type == "sub" then
    self.onFocus = i
    self.onFocusSub = j
    self.im.Publish("onfocus" .. i, true)
    self.im.Publish("onfocus" .. i .. j, true)
  else
    self.onFocus = i
    self.onFocusSub = 1
    self.im.Publish("onfocus" .. i, true)
    if subobjnum[i] and subobjnum[i] > 0 then
      self.im.Publish("onfocus" .. i .. "1", true)
    end
  end
end

return Scouting
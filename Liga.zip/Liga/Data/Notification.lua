local Notification = {}
Notification.__index = Notification

local sessionVars = ...

local currentNav = nil
local currentIm = nil
local initialized = false

local function getPair()
    return currentNav, currentIm
end

local function publish(state)
    local _, im = getPair()

    if im and im.Publish then
        pcall(function()
            im.Publish("newNotif", state and true or false)
        end)
    end
end

local function updateState()
    local navs = sessionVars.get("notifNavs")

    if type(navs) ~= "table" then
        navs = {}
        sessionVars.set("notifNavs", navs)
    end

    local hasNotif = (#navs > 0)

    sessionVars.set("newNotif", hasNotif and true or false)
    publish(hasNotif)
end

local function initialize(self, nav, im)
    if not nav or not im then
        return
    end

    currentNav = nav
    currentIm = im

    im.Subscribe("newNotif", function()
        local state = sessionVars.get("newNotif") or false

        pcall(function()
            im.Publish("newNotif", state)
        end)
    end)

    im.RegisterAction("act_notif", function()
        pcall(function()
            self:navigate()
        end)
    end)
end

function Notification:new(init)
    local obj = init or {}
    setmetatable(obj, self)

    initialize(obj, obj.nav, obj.im)

    local navs = sessionVars.get("notifNavs")
    if type(navs) ~= "table" then
        sessionVars.set("notifNavs", {})
    end

    return obj
end

function Notification:registerNotification(nav, callback)
    if not nav then
        return
    end

    local navs = sessionVars.get("notifNavs")

    if type(navs) ~= "table" then
        navs = {}
        sessionVars.set("notifNavs", navs)
    end

    for i = 1, #navs do
        local item = navs[i]

        if item and item.nav == nav then
            return
        end
    end

    table.insert(navs, {
        nav = nav,
        callback = callback
    })

    updateState()
end

function Notification:update(nav)
    local navs = sessionVars.get("notifNavs")

    if type(navs) ~= "table" or #navs == 0 then
        return
    end

    for i = #navs, 1, -1 do
        local item = navs[i]

        if item and item.nav == nav then
            table.remove(navs, i)
            break
        end
    end

    updateState()
end

function Notification:navigate()
    local navs = sessionVars.get("notifNavs")

    if type(navs) ~= "table" or #navs == 0 then
        return
    end

    local baseNav = select(1, getPair())

    if not baseNav or not baseNav.Event then
        return
    end

    local item = navs[#navs]

    if not item or not item.nav then
        return
    end

    self:unregisterNotification()

    if type(item.callback) == "function" then
        pcall(function()
            item.callback()
        end)
    end

    pcall(function()
        baseNav.Event(nil, item.nav)
    end)
end

function Notification:unregisterNotification()
    local navs = sessionVars.get("notifNavs")

    if type(navs) == "table" and #navs > 0 then
        table.remove(navs, #navs)
    end

    updateState()
end

return Notification
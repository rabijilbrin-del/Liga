-- AITransfers.lua — Ultra-Optimized Transfer Engine (Lua 5.1)
--
-- MODIFICATIONS:
--   • Responsive target pool – after a signing, the destination’s analysis &
--     target cache are rebuilt immediately to avoid flooding the same position.
--   • Respect for transferListed / loanListed / notListed – blocked players are
--     ignored; listed players become “easy targets” with a rating bonus.
--
-- ORDER-OF-MAGNITUDE IMPROVEMENTS OVER PREVIOUS VERSION
-- ──────────────────────────────────────────────────────
-- 1. PRECOMPUTED DEST POOL — built once before the transfer loop.
-- 2. O(n) PLAYER SELECTION — position-info map replaces O(n²) scan.
-- 3. LINEAR MAX SCAN replaces table.sort on eligible array.
-- 4. transferOffers cached once per batchTransfers call.
-- 5. analyzeTeamSquad uses integer-indexed position maps.
-- 6. cacheTransferTargets merged into batchTransfers precompute phase.
-- 7. # operator replaces table.getn everywhere.
-- 8. Precomputed top-league team split for source selection.

local NewsCenter, sessionVars, Scouting, Notification = ...
local AITransfers = {}
local TeamList = sessionVars.get("CareerModeTeams") or {}
local currentScoutTeamIndex = 0

local RivalTeams = {
    [1]={[5]=true,[19]=true}, [5]={[1]=true,[19]=true}, [19]={[1]=true,[5]=true},
    [10]={[11]=true},
    [11]={[10]=true,[9]=true,[7]=true}, [9]={[11]=true,[7]=true}, [7]={[9]=true,[11]=true},
    [240]={[241]=true}, [241]={[240]=true},
}

local subobjnum = {2,2,1,1}
local ScoutingParams = {
    [1]={[1]={"Any","DEF","MID","ATT"},
         [2]={"Any","GK","RB","LB","CB","RM","LM","CM","CAM","CDM","CF","LW","RW","RF","LF","ST"}},
    [2]={[1]=17,[2]=50},
    [3]={[1]={"Any","Starter","Wonderkid","Veteran","Sporadic"}},
    [4]={[1]={"Any","Dribbler","Prolific","Dueler","Speedster","Fox in the Box",
              "Poacher","Playmaker","Maestro","Anchor","Defensive minded"}},
}

local positionGroups = {
    ATT={ST=true,CF=true,LF=true,RF=true,LW=true,RW=true,LM=true,RM=true},
    MID={CAM=true,CM=true,CDM=true},
    DEF={LB=true,RB=true,CB=true,LWB=true,RWB=true},
}

local attributeConditions = {
    Dribbler        = function(p) return p.stat1>=80 and p.stat4>=82 end,
    Prolific        = function(p) return p.stat1>=80 and p.stat2>=80 and p.stat3>=80 end,
    Dueler          = function(p) return p.stat5>=75 and p.stat6>=84 end,
    Speedster       = function(p) return p.stat1>=85 end,
    ["Fox in the Box"] = function(p) return p.stat2>=83 and p.stat3>=80 and p.stat1>=75 end,
    Poacher         = function(p) return p.stat2>=85 end,
    Playmaker       = function(p) return p.stat3>=85 and p.stat4>=75 end,
    Maestro         = function(p) return p.stat3>=85 end,
    Anchor          = function(p) return p.stat3>=80 and p.stat5>=75 and p.stat6>=75 end,
    ["Defensive minded"] = function(p) return p.stat5>=83 and p.stat6>=80 end,
}

local statusConditions = {
    Starter  = function(p) return (p.rating or 50)>=75 end,
    Wonderkid= function(p) return GetPlayerAge(p.CARD_ID)<23 and (p.rating or 50)>=70 end,
    Veteran  = function(p) return GetPlayerAge(p.CARD_ID)>30 end,
    Sporadic = function(p) return (p.rating or 50)<60 end,
}

-- ── Scout Config Decoder ───────────────────────────────────────────────────

function AITransfers:decodeScoutConfig()
    local config = sessionVars.get("scoutParam") or {1,1,1,1,1,1}
    local result = {}
    local minBase = 17
    local idx = 0
    local labels = {
        [1]={[1]="Role",[2]="Position"},
        [2]={[1]="MinAge",[2]="MaxAge"},
        [3]={[1]="Status"},
        [4]={[1]="Trait"},
    }
    for par=1,4 do
        for sub=1,subobjnum[par] do
            idx=idx+1
            local label = labels[par] and labels[par][sub] or ("Param"..par.."_"..sub)
            if par==2 then
                result[label] = tostring(minBase + (config[idx]-1))
            else
                local ps = ScoutingParams[par][sub]
                result[label] = type(ps)=="table" and (ps[config[idx]] or "Any") or tostring(ps)
            end
        end
    end
    return result
end

-- ── Constructor ────────────────────────────────────────────────────────────

function AITransfers:new(init)
    local o = init or {}
    setmetatable(o, self)
    self.__index = self
    o.services            = init.services or {}
    o.loc                 = init.loc
    o.nav                 = init.nav
    o.transferTargetCache = {}
    o.teamLoansIn         = sessionVars.get("teamLoansIn") or {}
    o.squads              = init.squads
    o.save                = init.save
    sessionVars.set("teamLoansIn", o.teamLoansIn)
    return o
end

-- ── Squad Analysis ─────────────────────────────────────────────────────────

local POS_GROUP = {
    GK=0,
    CB=1,LB=1,RB=1,LWB=1,RWB=1,
    CM=2,DM=2,AM=2,LM=2,RM=2,
    ST=3,CF=3,LW=3,RW=3,
    CAM=2,CDM=2,
}

function AITransfers:analyzeTeamSquad(teamID)
    local players = getCachedTeamPlayers(teamID) or {}
    local n = #players
    local cnt  = {0,0,0,0}
    local rsum = {0,0,0,0}
    local totalCount = 0
    local totalRating = 0

    for i = 1, n do
        local p   = players[i]
        local rat = p.rating or 50
        local g   = POS_GROUP[p.position]
        totalCount  = totalCount + 1
        totalRating = totalRating + rat
        if g then
            local gi = g + 1
            cnt[gi]  = cnt[gi]  + 1
            rsum[gi] = rsum[gi] + rat
        end
    end

    local function avg(c, s) return c>0 and (s/c) or 0 end
    return {
        goalkeepers = { averageRating=avg(cnt[1],rsum[1]), count=cnt[1],
                        positions={GK=true} },
        defenders   = { averageRating=avg(cnt[2],rsum[2]), count=cnt[2],
                        positions={CB=true,LB=true,RB=true,LWB=true,RWB=true} },
        midfielders = { averageRating=avg(cnt[3],rsum[3]), count=cnt[3],
                        positions={CM=true,DM=true,AM=true,LM=true,RM=true,CAM=true,CDM=true} },
        forwards    = { averageRating=avg(cnt[4],rsum[4]), count=cnt[4],
                        positions={ST=true,CF=true,LW=true,RW=true} },
        overall     = { averageRating=avg(totalCount,totalRating), count=totalCount },
    }
end

-- ── Transfer Target Builder ────────────────────────────────────────────────

local function buildTransferTarget(teamID, analysis, teamStrength, globalAvg, budget)
    local groups = {"goalkeepers","defenders","midfielders","forwards"}
    local weakestGroup = nil
    local lowestRating = math.huge
    for gi = 1, 4 do
        local grp  = groups[gi]
        local data = analysis[grp]
        if data.averageRating < lowestRating and data.count < 10 then
            lowestRating  = data.averageRating
            weakestGroup  = grp
        end
    end

    local target = {}
    local groupAvg
    if weakestGroup then
        target.positionGroup = weakestGroup
        target.positions     = analysis[weakestGroup].positions
        groupAvg             = analysis[weakestGroup].averageRating
    else
        target.positionGroup = "any"
        target.positions     = {}
        groupAvg             = analysis.overall.averageRating
    end

    local isBig         = teamStrength > globalAvg
    local upgradeAmount = isBig and 2 or (budget > 4000000 and 1 or 0)
    target.minRating    = math.max(groupAvg + upgradeAmount, 50)
    target.maxRating    = isBig and 95 or (groupAvg + 5)
    return target
end

-- ── Player Selection (O(n), transfer/loan/list aware) ──────────────────────

local function selectBestPlayer(sourceTeamID, destTeamID, sourceSquad,
                                transferTargetCache, transferOffers, squadSize,
                                transferListed, loanListed, notListed)
    local target = transferTargetCache[destTeamID]
    if not target then return nil end

    local minRat   = target.minRating
    local maxRat   = target.maxRating
    local anyPos   = target.positionGroup == "any"
    local tgtPos   = target.positions
    local EASY_BONUS = 10   -- rating boost for transfer/loan listed players

    -- PASS 1: position info map
    local posInfo = {}
    for i = 1, squadSize do
        local p   = sourceSquad[i]
        local pos = p.position
        local rat = p.rating or 50
        local pi  = posInfo[pos]
        if not pi then
            posInfo[pos] = { count=1, best=rat, second=-1 }
        else
            pi.count = pi.count + 1
            if rat > pi.best then
                pi.second = pi.best; pi.best = rat
            elseif rat > pi.second then
                pi.second = rat
            end
        end
    end

    -- PASS 2: best eligible player scan
    local bestPlayer = nil
    local bestRating = -1

    for i = 1, squadSize do
        local p        = sourceSquad[i]
        local playerID = p.CARD_ID
        local pos      = p.position
        local rat      = p.rating or 50

        -- fast reject: transferred, suspended, pending offer, or blocked
        if not transferredPlayers[playerID]
        and not (isSuspended[playerID]==1 or isSuspended[playerID]==2)
        and (sourceTeamID~=currentSelectedTeamID or not transferOffers[playerID])
        and not notListed[playerID] then

            local isListed   = transferListed[playerID] or loanListed[playerID]
            local effectiveRat = rat + (isListed and EASY_BONUS or 0)

            -- rating / position eligibility
            local passesCheck = false
            if isListed then
                -- easy targets: ignore rating bounds, just need position group
                passesCheck = anyPos or tgtPos[pos]
            else
                passesCheck = (rat >= minRat and rat <= maxRat) and (anyPos or tgtPos[pos])
            end

            if passesCheck then
                -- replacement check
                local pi = posInfo[pos]
                local hasReplacement = false
                if isListed then
                    -- explicitly listed for sale/loan → no replacement needed
                    hasReplacement = true
                elseif pi and pi.count >= 2 then
                    if rat == pi.best then
                        hasReplacement = pi.second >= rat - 5
                    else
                        hasReplacement = pi.best >= rat - 5
                    end
                end

                if hasReplacement then
                    if effectiveRat > bestRating then
                        bestRating = effectiveRat
                        bestPlayer = p
                    end
                end
            end
        end
    end

    return bestPlayer
end

-- ── Transfer Type Decision ─────────────────────────────────────────────────

function AITransfers:decideTransferType(destTeamID, playerRating)
    local budget       = GLOBAL_FUNDS[destTeamID] or 0
    local target       = self.transferTargetCache[destTeamID]
    local strength     = target and target.minRating or 50
    local isSmallPoor  = budget < 10000000 or strength < 60
    local currentLoans = self.teamLoansIn[destTeamID] or 0
    if isSmallPoor and currentLoans < 3 and math.random() < 0.6 then
        local loanType = math.random() < 0.5 and 1 or 2
        self.teamLoansIn[destTeamID] = currentLoans + 1
        sessionVars.set("teamLoansIn", self.teamLoansIn)
        return true, loanType
    end
    return false, nil
end

-- ── Batch Transfers ────────────────────────────────────────────────────────
function AITransfers:batchTransfers()
    local transferCount = sessionVars.get("transferCount") or 0
    local _, month, _   = GLOBAL_DATE_PLACEHOLDER:match("(%d%d)/(%d%d)/(%d%d)")
    month = tonumber(month)
    if month ~= 8 and month ~= 1 then return end
    if transferCount >= 400               then return end
    local teamCount = #TeamList
    if teamCount < 2                       then return end

    local topLeagueSet = {[13]=true,[16]=true,[19]=true,[31]=true,[53]=true}

    -- ── PRECOMPUTE PHASE ──────────────────────────────────────────────────
    local teamLeagues   = {}
    local teamStrengths = {}
    local teamAnalyses  = {}
    local teamSquads    = {}
    local squadSizes    = {}
    local sumStrength   = 0

    for i = 1, teamCount do
        local tid          = TeamList[i]
        teamLeagues[tid]   = getTeamLeague(tid)
        local sq           = getCachedTeamPlayers(tid) or {}
        teamSquads[tid]    = sq
        squadSizes[tid]    = #sq
        local analysis     = self:analyzeTeamSquad(tid)
        teamAnalyses[tid]  = analysis
        local str          = analysis.overall.averageRating
        teamStrengths[tid] = str
        sumStrength        = sumStrength + str
    end

    local globalAvg = sumStrength / teamCount

    -- Build transfer target cache (linked to precomputed analysis)
    self.transferTargetCache = {}
    for i = 1, teamCount do
        local tid = TeamList[i]
        self.transferTargetCache[tid] = buildTransferTarget(
            tid, teamAnalyses[tid], teamStrengths[tid], globalAvg,
            GLOBAL_FUNDS[tid] or 0
        )
    end

    -- Destination pool
    local destPool   = {}
    local destCumW   = {}
    local destN      = 0
    local destTotalW = 0
    for i = 1, teamCount do
        local tid = TeamList[i]
        if self.transferTargetCache[tid] and tid ~= currentSelectedTeamID then
            destN = destN + 1
            destPool[destN] = tid
            local w = topLeagueSet[teamLeagues[tid]] and 12 or 1
            destTotalW = destTotalW + w
            destCumW[destN] = destTotalW
        end
    end
    if destN == 0 then return end

    -- Precomputed top/non‑top source lists
    local topSrcAll    = {}
    local nonTopSrcAll = {}
    local topSrcN      = 0
    local nonTopSrcN   = 0
    for i = 1, teamCount do
        local tid = TeamList[i]
        if topLeagueSet[teamLeagues[tid]] then
            topSrcN=topSrcN+1; topSrcAll[topSrcN]=tid
        else
            nonTopSrcN=nonTopSrcN+1; nonTopSrcAll[nonTopSrcN]=tid
        end
    end

    -- Cache session variables once
    local transferOffers = sessionVars.get("transferOffers") or {}
    local transferListed = sessionVars.get("transferListed") or {}
    local loanListed     = sessionVars.get("loanListed") or {}
    local notListed      = sessionVars.get("notListed") or {}

    local daysInWindow = daysLeftInTransferWindow(GLOBAL_DATE_PLACEHOLDER or "2025-03-22") or 30

    -- ── TRANSFER LOOP ─────────────────────────────────────────────────────
    local usedSourceTeams = {}
    local usedPlayers     = {}

    for attempt = 1, 50 do
        repeat   -- repeat/until true = Lua 5.1 "continue"

            -- Select destination (precomputed weighted list)
            local rand = math.random() * destTotalW
            local destTeamID = destPool[destN]
            for k = 1, destN do
                if rand <= destCumW[k] then destTeamID = destPool[k]; break end
            end

            -- Build source pool for this destination
            local isDestBig = teamStrengths[destTeamID] > globalAvg
            local rivals    = RivalTeams[destTeamID]
            local dstLeague = teamLeagues[destTeamID]

            local pickTopProb = isDestBig and 0.2 or 0.7
            local pickTop     = math.random() < pickTopProb
            local srcPoolBase  = pickTop and topSrcAll or nonTopSrcAll
            local srcPoolBaseN = pickTop and topSrcN   or nonTopSrcN

            local srcPool    = {}
            local srcCumW    = {}
            local srcN       = 0
            local srcTotalW  = 0
            local currentInPool = false

            for k = 1, srcPoolBaseN do
                local tid = srcPoolBase[k]
                if tid ~= destTeamID
                and (tid ~= currentSelectedTeamID or not usedSourceTeams[tid]) then
                    local allowRival = math.random() < 0.2
                    if allowRival or not (rivals and rivals[tid]) then
                        if isDestBig or teamLeagues[tid] ~= dstLeague then
                            srcN = srcN + 1
                            srcPool[srcN] = tid
                            local bud = GLOBAL_FUNDS[tid] or 0
                            local w   = bud < 10000000 and 3 or 1
                            srcTotalW = srcTotalW + w
                            srcCumW[srcN] = srcTotalW
                            if tid == currentSelectedTeamID then currentInPool = true end
                        end
                    end
                end
            end

            -- Fallback to full list
            if srcN == 0 then
                for i = 1, teamCount do
                    local tid = TeamList[i]
                    if tid ~= destTeamID
                    and (tid ~= currentSelectedTeamID or not usedSourceTeams[tid]) then
                        local allowRival = math.random() < 0.2
                        if allowRival or not (rivals and rivals[tid]) then
                            if isDestBig or teamLeagues[tid] ~= dstLeague then
                                srcN = srcN + 1
                                srcPool[srcN] = tid
                                local bud = GLOBAL_FUNDS[tid] or 0
                                local w   = bud < 10000000 and 3 or 1
                                srcTotalW = srcTotalW + w
                                srcCumW[srcN] = srcTotalW
                                if tid == currentSelectedTeamID then currentInPool = true end
                            end
                        end
                    end
                end
            end

            if srcN == 0 then break end

            -- Select source team
            local sourceTeamID
            if math.random() < 0.075 and currentInPool then
                sourceTeamID = currentSelectedTeamID
            else
                if srcTotalW > 0 then
                    local r2 = math.random() * srcTotalW
                    sourceTeamID = srcPool[srcN]
                    for k = 1, srcN do
                        if r2 <= srcCumW[k] then sourceTeamID = srcPool[k]; break end
                    end
                else
                    sourceTeamID = srcPool[1]
                end
            end

            -- Squad size guards
            local srcSize = squadSizes[sourceTeamID] or 0
            local dstSize = squadSizes[destTeamID]   or 0
            if srcSize <= 24 and sourceTeamID ~= currentSelectedTeamID then break end
            if dstSize >= 45 then break end

            -- Find best eligible player (now transfer/loan-list aware)
            local sourceSquad = teamSquads[sourceTeamID]
            local player = selectBestPlayer(
                sourceTeamID, destTeamID, sourceSquad,
                self.transferTargetCache, transferOffers, srcSize,
                transferListed, loanListed, notListed
            )
            if not player then break end

            local playerID = player.CARD_ID
            if transferredPlayers[playerID] or usedPlayers[playerID] then break end

            -- Compute transfer value
            local pInfo          = getPlayerInfo(playerID, sourceTeamID)
            local playerRating   = pInfo and pInfo.rating   or 50
            local playerPosition = pInfo and pInfo.position or "CM"
            local playerIndex    = pInfo and pInfo.index    or 0
            local repCount       = playerReplacementCount(sourceTeamID, playerPosition) or 0
            local transferValue  = computeTransferValue(
                GetPlayerAge(playerID) or 25,
                playerRating, playerPosition, playerIndex, repCount, daysInWindow
            )

            local destBudget          = GLOBAL_FUNDS[destTeamID] or 0
            local isLoan, loanDuration= self:decideTransferType(destTeamID, playerRating)
            local fee                 = isLoan and 0 or transferValue

            if not isLoan and destBudget < transferValue then break end

            -- ── Execute transfer / create offer ─────────────────────────
            if sourceTeamID == currentSelectedTeamID then
                -- Block offers for players who are not listed (respect block list)
                if notListed[playerID] then break end

                transferOffers[playerID] = {
                    offeringClub = destTeamID,
                    priceTag     = fee,
                    isLoan       = isLoan,
                    loanDuration = loanDuration,
                }
                sessionVars.set("transferOffers", transferOffers)
                Notification:registerNotification("evt_transferhub", function() currentHubTab = "receivedOffers" end)
            else
                -- AI-to-AI transfer: move player, update funds, news
                GLOBAL_FUNDS[destTeamID] = destBudget - fee
                if not isLoan then
                    GLOBAL_FUNDS[sourceTeamID] = (GLOBAL_FUNDS[sourceTeamID] or 0) + transferValue
                end
                if not transferredPlayers[playerID] then
                    if isLoan then
                        transferPlayer(playerID, sourceTeamID, destTeamID, true, loanDuration)
                    else
                        transferPlayer(playerID, sourceTeamID, destTeamID)
                    end
                end
                NewsCenter:queueTransferNews(
                    player, sourceTeamID, destTeamID,
                    self.loc.LocalizeString("TeamName_Abbr15_"..sourceTeamID),
                    self.loc.LocalizeString("TeamName_Abbr15_"..destTeamID),
                    fee, GLOBAL_DATE_PLACEHOLDER,
                    isLoan and loanDuration or 1
                )
                transferCount = transferCount + 1

                -- ── RESPONSIVE UPDATE: recompute both clubs’ analysis & targets ──
                -- source team (lost player)
                local newSrcSquad = getCachedTeamPlayers(sourceTeamID) or {}
                teamSquads[sourceTeamID] = newSrcSquad
                squadSizes[sourceTeamID] = #newSrcSquad
                local srcAnalysis = self:analyzeTeamSquad(sourceTeamID)
                teamAnalyses[sourceTeamID] = srcAnalysis
                local srcStrength = srcAnalysis.overall.averageRating
                teamStrengths[sourceTeamID] = srcStrength
                self.transferTargetCache[sourceTeamID] = buildTransferTarget(
                    sourceTeamID, srcAnalysis, srcStrength, globalAvg,
                    GLOBAL_FUNDS[sourceTeamID] or 0
                )

                -- destination team (gained player)
                local newDstSquad = getCachedTeamPlayers(destTeamID) or {}
                teamSquads[destTeamID] = newDstSquad
                squadSizes[destTeamID] = #newDstSquad
                local dstAnalysis = self:analyzeTeamSquad(destTeamID)
                teamAnalyses[destTeamID] = dstAnalysis
                local dstStrength = dstAnalysis.overall.averageRating
                teamStrengths[destTeamID] = dstStrength
                self.transferTargetCache[destTeamID] = buildTransferTarget(
                    destTeamID, dstAnalysis, dstStrength, globalAvg,
                    GLOBAL_FUNDS[destTeamID] or 0
                )
            end

            usedPlayers[playerID] = true
            if sourceTeamID ~= currentSelectedTeamID then
                usedSourceTeams[sourceTeamID] = true
            end

        until true
    end

    sessionVars.set("transferCount", transferCount)
end

-- ── Batch Scouting ─────────────────────────────────────────────────────────

function AITransfers:batchScouting()
    local config = sessionVars.get("scoutParam") or {}
    if not config or #config == 0 then return end

    local params   = self:decodeScoutConfig()
    local minAge   = tonumber(params.MinAge)
    local maxAge   = tonumber(params.MaxAge)
    local role     = params.Role     ~= "Any" and params.Role     or nil
    local position = params.Position ~= "Any" and params.Position or nil
    local status   = params.Status   ~= "Any" and params.Status   or nil
    local trait    = params.Trait    ~= "Any" and params.Trait    or nil

    -- Pre-resolve condition functions to avoid repeated table lookups in loop
    local statusFn = status and statusConditions[status] or nil
    local traitFn  = trait  and attributeConditions[trait] or nil
    local roleMap  = role   and positionGroups[role] or nil

    local scoutedPlayers = sessionVars.get("scoutedPlayers") or {}
    numScouted = numScouted or 0
    if not scoutedPlayers[239085] then scoutedPlayers[239085]=10 end

    local teamCount = #TeamList
    local startIdx  = currentScoutTeamIndex + 1
    if startIdx > teamCount then return end

    for j = startIdx, teamCount do
        local teamID = TeamList[j]
        if teamID ~= currentSelectedTeamID then
            local players = getCachedTeamPlayers(teamID) or {}
            local pn      = #players
            for k = 1, pn do
                local player = players[k]
                local cardID = player.CARD_ID
                if not scoutedPlayers[cardID] then
                    local age = GetPlayerAge(cardID) or 25
                    if age >= minAge and age <= maxAge then
                        local pos       = player.position
                        local matchPos  = not position or pos == position
                        local matchRole = not roleMap or roleMap[pos]
                        if matchPos and matchRole then
                            local matchStatus = not statusFn or statusFn(player)
                            if matchStatus then
                                local matchTrait = not traitFn or traitFn(player)
                                if matchTrait then
                                    numScouted = numScouted + 1
                                end
                            end
                        end
                    end
                end
            end
        end
        currentScoutTeamIndex = j
    end

    currentScoutTeamIndex = teamCount
    sessionVars.set("scoutedPlayers", scoutedPlayers)
end

return AITransfers
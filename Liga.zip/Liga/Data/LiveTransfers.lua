local LiveTransfers = {}
local transferPlayers = transferPlayers == nil and transferPlayer

function LiveTransfers:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.handleTransferSwap = init.transferHandler
  return o
end

function LiveTransfers:liveTransfersHandling(player, team, sourceteam)
    self.handleTransferSwap(player, sourceteam)
end

function LiveTransfers:replaceSoldPlayer(player, team, squads, services)
end 

return LiveTransfers
local Save = {}
local homepage = nil
local runBrowser = nil
local closeBrowser = nil
local services = nil
local ID = 0
local chunkTimer = nil

local function getID(self)
    ID = ID + 1
    return "_ID" .. ID
end

local function buildFullString(value)
    local parts = {}

    local function write(s)
        table.insert(parts, s)
    end

    local esc = { ['"'] = '\\"', ['\\'] = '\\\\', ['\n'] = '\\n', ['\r'] = '\\r', ['\t'] = '\\t', ['\b'] = '\\b', ['\f'] = '\\f' }

    local function quote(str)
        if not str:find('["\\\n\r\t\b\f]') then
            write('"'); write(str); write('"')
        else
            write('"')
            write(str:gsub('["\\\n\r\t\b\f]', esc))
            write('"')
        end
    end

    local function serialize(val, depth)
        if depth > 1000 then
            write("[...deep]")
            return
        end

        local tp = type(val)

        if tp == "string" then
            quote(val)

        elseif tp == "number" then
            if val ~= val then              write('"nan"')
            elseif val == math.huge then    write('"inf"')
            elseif val == -math.huge then   write('"-inf"')
            else
                if math.floor(val) == val and math.abs(val) < 1e14 then
                    write(string.format("%.0f", val))
                else
                    write(tostring(val))
                end
            end

        elseif tp == "boolean" or tp == "nil" then
            write(tostring(val))

        elseif tp == "table" then
            local n = #val
            local isArray = n > 0
            if isArray then
                for i = 1, n do
                    if val[i] == nil then isArray = false; break end
                end
            end

            write("{")
            if isArray then
                for i = 1, n do
                    serialize(val[i], depth + 1)
                    write(",")
                end
                if n > 0 and parts[#parts] == "," then
                    table.remove(parts)
                end
            else
                local first = true
                for k, v in pairs(val) do
                    if not first then write(",") end
                    first = false

                    local kt = type(k)
                    if kt == "string" and k:match("^[%a_][%w_]*$") then
                        write(k)
                    else
                        write("[")
                        serialize(k, depth + 1)
                        write("]")
                    end
                    write("=")
                    serialize(v, depth + 1)
                end
            end
            write("}")

        else
            write('"[unsupported]"')
        end
    end

    serialize(value, 0)
    return table.concat(parts)
end

-- Queue system for chunks
local chunkQueue = {}
local isStreaming = false

local function processNextChunk()
    if #chunkQueue == 0 then
        isStreaming = false
        if chunkTimer then
            chunkTimer:stop()
            chunkTimer = nil
        end
        return
    end
    
    -- Get next chunk from queue
    local chunk = table.remove(chunkQueue, 1)
    
    -- Process the chunk
    local link = "http://127.0.0.1:5000/" .. chunk
    homepage(link)
    runBrowser(nil)
    closeBrowser()
    
    -- If there are more chunks, schedule next one with delay
    if #chunkQueue > 0 and chunkTimer then
        chunkTimer:start()
    else
        isStreaming = false
        if chunkTimer then
            chunkTimer:stop()
            chunkTimer = nil
        end
    end
end

function Save:saveProgress(data, prefix, var)
    if data == "_sT" then
        ID = 0
        local link = "http://127.0.0.1:5000/_sT"
        homepage(link)
        runBrowser(nil)
        closeBrowser()
        return
    elseif data == "_FNSave" then
        ID = 0
        savecount = savecount and (savecount + 1) or 1
        local link = "http://127.0.0.1:5000/_FNSave"-- .. tostring(savecount)
        homepage(link)
        runBrowser(nil)
        closeBrowser() 
        return
     elseif data == "_FN_" then
        ID = 0
        local link = "http://127.0.0.1:5000/_FN_"
        homepage(link)
        runBrowser(nil)
        closeBrowser()
        return
    end

    prefix = prefix or ""

    local full_str
    if type(data) == "table" then
        full_str = buildFullString(data)
    else
        full_str = tostring(data)
    end

    if prefix ~= "" then
        full_str = prefix .. "=" .. full_str
    end

    local CHUNK_SIZE = 5500  

    -- Clear any existing streaming operation
    if isStreaming then
        chunkQueue = {}
        if chunkTimer then
            chunkTimer:stop()
            chunkTimer = nil
        end
        isStreaming = false
    end

    -- Split string into chunks and add to queue
    local pos = 1
    local len = #full_str
    chunkQueue = {}

    while pos <= len do
        local chunk_end = math.min(pos + CHUNK_SIZE - 1, len)
        local chunk = full_str:sub(pos, chunk_end)
        table.insert(chunkQueue, chunk)
        pos = chunk_end + 1
    end

    -- Start streaming if Timer is available
    if Timer and #chunkQueue > 0 then
        isStreaming = true
        
        -- Create timer for chunk streaming
        chunkTimer = Timer:new({
            id = "chunkStreamer",
            interval = 0.2,
            reps = 0,
            onTimerComplete = function()
                processNextChunk()
            end
        })
        
        -- Process first chunk immediately
        processNextChunk()
    else
        
    end
end

function Save:new(init)
    local o = init or {}
    setmetatable(o, self)
    self.__index = self

    o.services = services or {
        BrowserService  = o.api("BrowserService"),
        ViewportService = o.api("ViewportService"),
        MiscService     = o.api("MiscService")
    }

    homepage     = o.services.BrowserService.SetHomePage
    runBrowser   = o.services.BrowserService.OpenBrowser
    closeBrowser = o.services.BrowserService.CloseBrowser
    
    -- Store Timer reference if provided
    if init and init.Timer then
        Timer = init.Timer
    end

    return o
end

function Save:openBrowser()
    -- runBrowser(0, 0, 0, 0)
end

function Save:finalize()
    -- Clean up any ongoing streaming
    if isStreaming then
        chunkQueue = {}
        if chunkTimer then
            chunkTimer:stop()
            chunkTimer:finalize()
            chunkTimer = nil
        end
        isStreaming = false
    end
    closeBrowser()
end

-- Optional: Add update function if needed for timer processing
function Save:update(elapsedTime)
    if chunkTimer and chunkTimer.update then
        chunkTimer:update(elapsedTime)
    end
end

return Save
-- sessionVars.lua
local sessionVars = {}
sessionVars.data = {}
sessionVars.ctx = "fifa"

function sessionVars.setContext(ctx)
  sessionVars.ctx = ctx
  sessionVars.set("currentMode", ctx)
end

function sessionVars.set(key, value, ctx)
  ctx = ctx and "fifa" or sessionVars.ctx
  if not sessionVars.data[ctx] then
    sessionVars.data[ctx] = {}
  end
  sessionVars.data[ctx][key] = value
end

function sessionVars.delete(ctx)
  ctx = ctx or sessionVars.ctx
  sessionVars.data[ctx] = nil
end

function sessionVars.get(key, ctx)
  ctx = ctx and "fifa" or sessionVars.ctx
  return sessionVars.data[ctx] and sessionVars.data[ctx][key]
end

function sessionVars.reset()
  sessionVars.data = {}
end

return sessionVars
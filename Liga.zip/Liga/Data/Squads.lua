local sessionVars = ...
local Squads = {}
local services = services or nil
function Squads:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  services = init.services
  o.services = services
  return o
end

-- Swaps a player with a substitute (if starter) or removes them (if substitute).
-- @param playerId The CARD_ID of the player to swap or remove.
-- @param team The team identifier.
-- @return A table of player IDs representing the modified squad.
-- @argument mode (1 = transfer in games session to only replace starter, 2 = to load transfer from previous game session, swaps and remove starter from team)
function Squads:swapSoldPlayer(playerId, team, mode)
  mode = mode or 2
  local squad = self.services.SquadManagementService.GetCurrentPlayerLineup(0, team, 0)
  local players = {}
  local playerIndex, repIndex = 0, 0
  local playerPosition = ""
  local playerRole = "Starter"

  -- Build initial player ID list and find player
  for i, player in ipairs(squad) do
    players[i] = player.CARD_ID
    if player.CARD_ID == playerId then
      playerIndex = i
      playerPosition = player.position
      playerRole = i > 11 and "Sub/Res" or "Starter"
    end
  end

  -- If player not found, return original squad
  if playerIndex == 0 then
    print("Player ID " .. playerId .. " not found in squad")
    return players
  end

  -- If starter, find substitute with same position
  if playerRole == "Starter" then
    for i, player in ipairs(squad) do
      if i > 11 and player.position == playerPosition then
        repIndex = i
        break
      end
    end
    -- If no substitute found, return original squad
    if repIndex == 0 then
      print("No substitute found for position " .. playerPosition)
      return players
    end
    -- Swap players
    players[playerIndex], players[repIndex] = players[repIndex], players[playerIndex]
  else
    if mode == 2 then
      table.remove(players, playerIndex)
    end
  end

  return players
end

function Squads.getCachedTeamPlayers(teamID)
    local TeamCachedData  = sessionVars.get("TeamCachedData")
    return TeamCachedData[teamID] and TeamCachedData[teamID]["players"] or {}
end

function Squads.getBaseCachedTeamPlayers(teamID)
    local TeamCachedData  = sessionVars.get("fifaSquad", true)
    return TeamCachedData[teamID] and TeamCachedData[teamID]["players"] or {}
end

function Squads.resetSquad(teamIDs)
  if type(teamIDs) == "table" then
    if #teamIDs > 0 then
      for i = 1, #teamIDs do
        local teamID = teamIDs[i]
        local obj = Squads.getBaseCachedTeamPlayers(teamID)
        local playerIDs = {}
        for k = 1, #obj do
          playerIDs[k] = obj[k].CARD_ID
        end
        services.SquadManagementService.SetCurrentPlayerLineup(0, teamID, 0, 0, {})
      end
    end
  end
end
  
return Squads
local sessionVars, Modes, playerData, Squads = ...
local MatchHandler = {}
local DateUtils = nil
local inMatchData = {}
function MatchHandler:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.DateUtils = init.DateUtils
  DateUtils = init.DateUtils
  return o
end

function MatchHandler:getMatchesForDate(dateStr)
    local matches = {}
    local insert = table.insert
    local standardDate = DateUtils:parseDate(dateStr or "01/08/24")
    if not standardDate then
        return matches
    end

    local targetTime = os.time({
        day = standardDate.day,
        month = standardDate.month,
        year = standardDate.year,
        hour = 0, min = 0, sec = 0
    })

    local matchData = sessionVars.get("MatchData") or {}
    for i, match in ipairs(matchData) do
        if match.matchType == "League" or match.matchType == "Friendly" or match.matchType == "Competition" then
            local matchDateStr = DateUtils:convertMatchDateToStandard(match.date)
            if matchDateStr then
                local matchDate = DateUtils:parseDate(matchDateStr)
                if matchDate then
                    local matchTime = os.time({
                        day = matchDate.day,
                        month = matchDate.month,
                        year = matchDate.year,
                        hour = 0, min = 0, sec = 0
                    })
                    if matchTime == targetTime then
                        insert(matches, {index = i, match = match})
                    end
                end
            end
        end
    end

    return matches
end

function MatchHandler:getMatchesForDateWithoutIndex(dateStr)
    local matches = {}
    local insert = table.insert
    local standardDate = DateUtils:parseDate(dateStr or "01/08/24")
    if not standardDate then
        print("Invalid date in getMatchesForDate: " .. tostring(dateStr))
        return matches
    end

    local targetTime = os.time({
        day = standardDate.day,
        month = standardDate.month,
        year = standardDate.year,
        hour = 0, min = 0, sec = 0
    })

    local matchData = sessionVars.get("MatchData") or {}
    for i, match in ipairs(matchData) do
        if match.matchType == "League" or match.matchType == "Friendly" or match.matchType == "Competition" then
            local matchDateStr = DateUtils:convertMatchDateToStandard(match.date)
            if matchDateStr then
                local matchDate = DateUtils:parseDate(matchDateStr)
                if matchDate then
                    local matchTime = os.time({
                        day = matchDate.day,
                        month = matchDate.month,
                        year = matchDate.year,
                        hour = 0, min = 0, sec = 0
                    })
                    if matchTime == targetTime then
                        insert(matches, match)
                    end
                end
            end
        end
    end

    return matches
end

function MatchHandler:getMatchesForMatchday(matchday)
    local matches = {}
    local insert = table.insert

    if not matchday then return matches end

    local matchData = sessionVars.get("MatchData") or {}
    for i, match in ipairs(matchData) do
        if (match.matchType == "League" or match.matchType == "Friendly" or match.matchType == "Competition") 
            and match.matchday == matchday and match.played then
            
            insert(matches, match)
        end
    end

    return matches
end

function MatchHandler:getTeamMatchIndex(teamID)
    local dateStr = GLOBAL_DATE_PLACEHOLDER
    local standardDate = DateUtils:parseDate(dateStr or "01/08/24")
    if not standardDate then
        print("Invalid date in getMatchesForDate: " .. tostring(dateStr))
        return 0
    end

    local targetTime = os.time({
        day = standardDate.day,
        month = standardDate.month,
        year = standardDate.year,
        hour = 0, min = 0, sec = 0
    })

    local matchData = sessionVars.get("MatchData") or {}
    for i, match in ipairs(matchData) do
        if match.matchType == "League" or match.matchType == "Friendly" or match.matchType == "Competition" then
            local matchDateStr = DateUtils:convertMatchDateToStandard(match.date)
            if matchDateStr then
                local matchDate = DateUtils:parseDate(matchDateStr)
                if matchDate then
                    local matchTime = os.time({
                        day = matchDate.day,
                        month = matchDate.month,
                        year = matchDate.year,
                        hour = 0, min = 0, sec = 0
                    })
                    if matchTime == targetTime then
                        if match.homeID == teamID or match.awayID == teamID then
                          return i
                        end
                    end
                end
            end
        end
    end
end

function MatchHandler:setMatchScores(homeScore, awayScore, pensData, idx, squadService)
  --squadService.SetCurrentPlayerLineup(0, currentSelectedTeamID, 0, 0, {})
  local matchData = sessionVars.get("MatchData")
  if matchData and matchData[idx] then
    matchData[idx].homeScore = homeScore
    matchData[idx].awayScore = awayScore
    if pensData then
      matchData[idx].pen = true
      matchData[idx].homePenScore = pensData.homepen
      matchData[idx].awayPenScore = pensData.awaypen
    end
    matchData[idx].played = true
    if matchData[idx].matchType == "Competition" then
      Modes:progress(matchData[idx].leagueID, matchData[idx])
    end
    --playerData:updateRecord(matchData[idx].homeID)
    --playerData:updateRecord(matchData[idx].awayID)
    --Squads.resetSquad({matchData[idx].homeID, matchData[idx].awayID})
    sessionVars.set("MatchData", matchData)
  end
end

function MatchHandler:updateStats(stat, playerID, leagueID, side, isOg)
  if stat == "goal" then
    local gSide = side == 0 and "home" or "away"
    local playerGoals = sessionVars.get("PlayerGoals") or {}
    if not playerGoals[leagueID] then
      playerGoals[leagueID] = {}
    end
    local leagueGoals = playerGoals[leagueID]
    leagueGoals[playerID] = (leagueGoals[playerID] or 0) + 1
    --if not isOg and (inMatchData.lastBallHolder and inMatchData.lastSideHolder) and (gSide == inMatchData.lastSideHolder) then           
      --local playerAssists = sessionVars.get("PlayerAssists") or {}
      --if not playerAssists[leagueID] then
        --playerAssists[leagueID] = {}
      --end
      --local leagueAssists = playerAssists[leagueID]
      --leagueAssists[inMatchData.lastBallHolder] = (leagueAssists[inMatchData.lastBallHolder] or 0) + 1
      --sessionVars.set("PlayerAssists", playerAssists)
    --end
    sessionVars.set("PlayerGoals", playerGoals)
  elseif stat == "rc" then
    local redMatchCount = sessionVars.get("redMatchCount")
    redMatchCount[playerID] = 2
    isSuspended[playerID] = 1
    sessionVars.set("redMatchCount", redMatchCount)
  end
end

function MatchHandler:setLastBallHolder(playerID, side)
  inMatchData.lastBallHolder = inMatchData.currentBallHolder or nil
  inMatchData.lastSideHolder = inMatchData.currentSideHolder or nil
  inMatchData.currentBallHolder = playerID
  inMatchData.currentSideHolder = side
end
 
 return MatchHandler
    
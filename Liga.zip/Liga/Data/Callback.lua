local Callback = {}
local clbck, arg1, arg2, arg3 = nil, nil, nil, nil

function Callback:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.obj = init.obj or {}
  o.save = init.save or {}
  return o
end

function Callback:registerCallback(cb)
  clbck = cb
end

function Callback:performCallback(obj)
  if clbck then
    if self.save then
      self.save:saveProgress("_N--clbck is available, it is a " .. type(clbck)) 
    end
    clbck(obj)
  else
    self.save:saveProgress("_N--clbck is not available")
  end
  clbck, arg1, arg2, arg3 = nil, nil, nil, nil
end

return Callback
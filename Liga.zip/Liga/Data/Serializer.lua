-- Singleton Module for compact serializing
local Save = ...
local Serializer = {}
local sessionVars = nil
local Date = nil
local step = nil

function Serializer:new(init, obj)
  local o = obj or (init or {})
  setmetatable(o, self)
  self.__index = self
  o.nav = init.nav
  sessionVars = init.sessionVars
  Date = init.Date
  return o
end

function Serializer:saveProgress()
  local leagueMatchData = sessionVars.get("LeagueMatchData")
  local TeamCachedData = sessionVars.get("TeamCachedData")
  local sheetData = sessionVars.get("sheetData")
  local transferOffers = sessionVars.get("transferOffers") or {}
  local transferListed = sessionVars.get("transferListed") or {}
  local loanListed     = sessionVars.get("loanListed") or {}
  local notListed      = sessionVars.get("notListed") or {}
  for i = 1, 2 do
  --Save:saveProgress("_FNSave")
  Save:saveProgress("_sT") 
  Save:saveProgress("_N") 
  Save:saveProgress("save = {matchData = {}, sheetData = {}}")
  for k, v in pairs (leagueMatchData) do
    Save:saveProgress(leagueMatchData[k], "_Nsave.matchData[" .. tostring(k) .. "]") 
  end
  Save:saveProgress(sessionVars.get("PlayerGoals"), "_Nsave.playerGoals")
  Save:saveProgress(currentSelectedTeamID, "_Nsave.currentSelectedTeamID", true) 
  Save:saveProgress('"' .. tostring(GLOBAL_DATE_PLACEHOLDER) .. '"', "_Nsave.GLOBAL_DATE_PLACEHOLDER",true) 
  Save:saveProgress(sessionVars.get("LeagueTeams"), "_Nsave.LeagueTeams")
  Save:saveProgress(GLOBAL_FUNDS, "_Nsave.GLOBAL_FUNDS")
  Save:saveProgress(transferHistory, "_Nsave.transferHistory")
  Save:saveProgress(transferOffers, "_Nsave.transferOffers")
  Save:saveProgress(transferListed, "_Nsave.transferListed")
  Save:saveProgress(loanListed, "_Nsave.loanListed")
  Save:saveProgress(notListed, "_Nsave.notListed")
  Save:saveProgress(getTeamLeague(currentSelectedTeamID), "_Nsave.currentLeagueID", true)
  
  if not sheetData then    
    if sessionVars.get("currentPlayersID") then
      Save:saveProgress(sessionVars.get("currentPlayersID"), "_Nsave.currentPlayersID")
    end
  else 
    for k, v in pairs (sheetData) do
      Save:saveProgress(sheetData[k], "_Nsave.sheetData[" .. tostring(k) .. "]") 
    end    
    Save:saveProgress(sessionVars.get("sheetIdx"), "_Nsave.sheetIdx", true)
  end
  
  if sessionVars.get("currentFormationID") then
    Save:saveProgress(sessionVars.get("currentFormationID"), "_Nsave.currentFormationID", true)
  end
  if Date:IsTransferWindowOpen() then
    Save:saveProgress(sessionVars.get("transferCount"), "_Nsave.transferCount", true)
  end
  if Date:isDeadline() then
    Save:saveProgress(sessionVars.get("deadlineTime"), "_Nsave.deadlineTime", true)
  end
  if #sessionVars.get("redMatchCount") > 0 then
    Save:saveProgress(sessionVars.get("redMatchCount"), "_Nsave.redMatchCount")
  end
  Save:saveProgress(isSuspended, "_Nsave.isSuspended")
  Save:saveProgress((sessionVars.get("InCareerMode") and '"manager"' or '"tourney"'), "_Nsave.mode", true)
  Save:saveProgress("_Nsave.saved = true")  
  Save:saveProgress("_Nreturn save")
  
  --self.nav.Event(nil, "evt_show_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/ValidateSave.vvm"})
  --self.nav.Event(nil, "evt_hide_overlay")
  --self.nav.Event(nil, "evt_show_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/ClearCache.vvm", data = {cont = function() self.nav.Event(nil, "evt_hide_overlay") if save then self:completeSave() else self:saveProgress() end save = nil end}})
  end
end

function Serializer:completeSave()
  Save:saveProgress("_Nreturn save")
end

return Serializer
local sessionVars, LeagueNames = ...
local NewsCenter  = {}

-- 缺失定义补丁（修复原版未定义的函数/变量）
local currentSelectedTeamID = sessionVars.get("currentUserTeamID") or 0

local MAX_CACHE = 15
local MAX_DAILY = 20

-- Budget split (must sum ≤ MAX_DAILY)
local BUDGET_USER  = 5
local BUDGET_OTHER = 12
local BUDGET_UCL   = 3

local SRC = {
    {name="Inisial A", img="$A"},
    {name="Sky Sports",      img="$Skysports"},
    {name="BBC Sport",       img="$Bbcsport"},
    {name="433",    img="$433"},
    {name="BeIN Sports",      img="$beIN"},
    {name="ESPN FC",         img="$Espnfc"},
}
local SRC_TRANSFER = {SRC[1], SRC[2]}
local SRC_RESULT   = {SRC[2], SRC[3], SRC[4]}
local SRC_STATS    = {SRC[5], SRC[4], SRC[6]}
local SRC_GENERAL  = {SRC[2], SRC[3]}

-- Source khusus untuk berita transfer pemain resmi/rumor transfer masuk
local SRC_TM       = {name="Transfermarkt", img="$Transfer_markt"}

-- ─── Persistent Module State ──────────────────────────────────────────────────

local todayQueue          = todayQueue          or {career={}, tournament={}}
local NewsCache           = NewsCache           or {career={}, tournament={}}
local cacheCursor         = cacheCursor         or {career=0,  tournament=0}
local lastGenDate         = lastGenDate         or {career="", tournament=""}
local lastPublished       = lastPublished       or {career={}, tournament={}}
-- [md][leagueID] = last matchday whose results were published as news
local lastReportedMD      = lastReportedMD      or {career={}, tournament={}}
-- [md][leagueID][cat] = true  (per-league per-day category guard)
local todayCategories     = todayCategories     or {career={}, tournament={}}

local publishFn   = nil
local subscribeFn = nil

-- ─── Helpers ──────────────────────────────────────────────────────────────────

local function getMode()
    return sessionVars.get("InCareerMode") and "career" or "tournament"
end

local function doPublish(bnd, data)
    if not publishFn then return end
    publishFn(bnd, data)
    lastPublished[getMode()][bnd] = data
end

local function pick(tbl)
    if not tbl or #tbl == 0 then return nil end
    return tbl[math.random(#tbl)]
end

local function ordinal(n)
    n = tonumber(n) or 0
    local v = n % 100
    if v >= 11 and v <= 13 then return tostring(n).."th" end
    local r = n % 10
    if r == 1 then return tostring(n).."st"
    elseif r == 2 then return tostring(n).."nd"
    elseif r == 3 then return tostring(n).."rd"
    else return tostring(n).."th" end
end

local function shorten(str, maxLen)
    return str or ""
end

local function formatFunds(funds)
    if funds >= 1e6 then
        local m = funds / 1e6
        return m < 10 and ("£%.2fM"):format(m) or ("£%.1fM"):format(m):gsub("%.0M", "M")
    elseif funds >= 1e3 then
        return ("£%dK"):format(funds / 1e3)
    else
        return "£" .. funds
    end
end

local function fmtDate(dateStr)
    local d,m = (dateStr or "01/08/24"):match("^(%d%d)/(%d%d)")
    if d and m then return m.."/"..d end
    return "08/01"
end

local function fmtInteraction()
    return tostring(math.random(2,95)).."K", tostring(math.random(40,800))
end

-- Modifikasi makeItem untuk mendukung slot obj5-7, text4, obj8, dan text5
local function makeItem(headline, source, category, a, b, c, text1, a5, b6, c7, text4, a8, text5)
    local likes, comments = fmtInteraction()
    return {
        headline = headline or "",
        date     = GLOBAL_DATE_PLACEHOLDER or "01/08/24",
        source   = source or SRC[2],
        likes    = likes,
        comments = comments,
        category = category or "general",
        obj1     = a,
        obj2     = b,
        obj3     = c,
        text1    = text1 or "",
        obj5     = a5,
        obj6     = b6,
        obj7     = c7,
        text4    = text4 or "",
        obj8     = a8, -- Menampung asset background transfer
        text5    = text5 or "", -- Slot teks status transfer (DONE DEAL, LOAN, RUMOUR)
        isNew    = true,   -- overridden to false when cycling history
    }
end

-- Convenience wrappers yang mempertahankan aturan slot default
-- 1 object
local function item1(h,src,cat,o1,t1)     return makeItem(h,src,cat, o1,  nil, nil, t1) end
-- 2 objects → obj2+obj3
local function item2(h,src,cat,o2,o3,t1)  return makeItem(h,src,cat, nil, o2,  o3,  t1) end
-- 3 objects → obj1+obj2+obj3
local function item3(h,src,cat,o1,o2,o3,t1) return makeItem(h,src,cat, o1, o2, o3, t1) end

-- Wrapper khusus untuk berita transfer menggunakan obj5, obj6, obj7, text4, otomatis menyertakan obj8 dan text5
local function itemTransfer3(h,src,cat,o5,o6,o7,t4,t5) 
    return makeItem(h,src,cat, nil, nil, nil, "", o5, o6, o7, t4, {name="$bg_transfer"}, t5) 
end

-- ─── Season Context ───────────────────────────────────────────────────────────

local function getSeasonProgress()
    local _,m = (GLOBAL_DATE_PLACEHOLDER or "01/08/24"):match("(%d%d)/(%d%d)")
    local mo = tonumber(m) or 8
    local pos = mo >= 8 and (mo-8) or (mo+4)
    return math.min(1.0, pos/9.0)
end

local function isTransferWindow()
    local _,m = (GLOBAL_DATE_PLACEHOLDER or "01/08/24"):match("(%d%d)/(%d%d)")
    local mo = tonumber(m) or 0
    return mo == 8 or mo == 1
end

local function isDeadlineDay()
    local d,m = (GLOBAL_DATE_PLACEHOLDER or "01/08/24"):match("^(%d%d)/(%d%d)")
    local day,mo = tonumber(d) or 0, tonumber(m) or 0
    return (day==31 and mo==8) or (day==31 and mo==1)
end

local function getWindowName()
    local _,m = (GLOBAL_DATE_PLACEHOLDER or "01/08/24"):match("(%d%d)/(%d%d)")
    return (tonumber(m) or 0)==8 and "Summer" or "January"
end

-- ─── Team / League Name Helpers ───────────────────────────────────────────────

local function tName(loc, id)
    if not loc or not id then return "Unknown" end
    local s = loc.LocalizeString("TeamName_Abbr15_"..tostring(id))
    return (s and s~="") and s or ("Team"..tostring(id))
end

-- Returns a short league label for prefixing headlines ("LA LIGA", "BUNDESLIGA", etc.)
local function leagueLabel(id)
    if not id then return "" end
   return (LeagueNames[id] or "")
end

-- Prepends league label to headline for non-user-league stories
local function prefixed(label, headline)
    if not label or label=="" then return headline end
    return label..": "..headline
end

-- ─── World-State Builder ──────────────────────────────────────────────────────

local function buildWorldContext(loc, leagueID, isUserLeague, isUCL)
    local label = (not isUserLeague) and leagueLabel(leagueID) or ""
    if isUCL then label = "UCL" end

    local ctx = {
        leagueID      = leagueID,
        loc           = loc,
        isUserLeague  = isUserLeague,
        isUCL         = isUCL,
        label         = label,          -- empty for user league
        teams         = {},
        stats         = {},
        standings     = {},
        recentPlayed  = {},             -- up to 30, newest matchday first
        todayMatches  = {},             -- matches from latestPlayedMD only
        allUnplayed   = {},
        allUnplayedKO = {},             -- unplayed knockout matches (UCL)
        topScorers    = {},
        streaks       = {},
        totalGoals    = 0,
        totalPlayed   = 0,
        biggestMatch  = nil,
        conceded      = {},
        progress      = getSeasonProgress(),
        latestPlayedMD = 0,
    }

    local leagueTeams = (sessionVars.get("LeagueTeams") or {})[leagueID]
    if not leagueTeams then return ctx end

    -- Flatten team list (handles both array and WC-grouped formats)
    if leagueTeams[1] and type(leagueTeams[1])=="number" then
        for _,id in ipairs(leagueTeams) do table.insert(ctx.teams,id) end
    else
        for _,v in pairs(leagueTeams) do
            if type(v)=="table" then
                for _,id in ipairs(v) do table.insert(ctx.teams,id) end
            end
        end
    end
    if #ctx.teams==0 then return ctx end

    for _,id in ipairs(ctx.teams) do
        ctx.stats[id]    = {id=id,pts=0,w=0,d=0,l=0,gf=0,ga=0,mp=0,form={}}
        ctx.conceded[id] = 0
    end

    local matchData = (sessionVars.get("LeagueMatchData") or {})[leagueID] or {}
    local bigScore  = 0

    -- Single pass: build stats + find latestPlayedMD
    for i=1,#matchData do
        local m = matchData[i]
        if not m then
        elseif m.played and not m.isKnockout then
            local h,a   = m.homeID, m.awayID
            local hs = tonumber(m.homeScore) or 0
            local as = tonumber(m.awayScore) or 0
            local sh,sa = ctx.stats[h], ctx.stats[a]
            if sh and sa then
                sh.gf=sh.gf+hs; sh.ga=sh.ga+as; sh.mp=sh.mp+1
                sa.gf=sa.gf+as; sa.ga=sa.ga+hs; sa.mp=sa.mp+1
                ctx.conceded[h]=ctx.conceded[h]+as
                ctx.conceded[a]=ctx.conceded[a]+hs
                if hs>as then
                    sh.pts=sh.pts+3; sh.w=sh.w+1; sa.l=sa.l+1
                    table.insert(sh.form,1,"W"); table.insert(sa.form,1,"L")
                elseif as>hs then
                    sa.pts=sa.pts+3; sa.w=sa.w+1; sh.l=sh.l+1
                    table.insert(sh.form,1,"L"); table.insert(sa.form,1,"W")
                else
                    sh.pts=sh.pts+1; sa.pts=sa.pts+1
                    sh.d=sh.d+1; sa.d=sa.d+1
                    table.insert(sh.form,1,"D"); table.insert(sa.form,1,"D")
                end
                ctx.totalGoals  = ctx.totalGoals  + hs+as
                ctx.totalPlayed = ctx.totalPlayed + 1
                local combined  = hs+as
                if combined>bigScore then bigScore=combined; ctx.biggestMatch=m end
                if #ctx.recentPlayed<30 then table.insert(ctx.recentPlayed,m) end
            end
            local md_num = m.matchday or 0
            if md_num > ctx.latestPlayedMD then ctx.latestPlayedMD = md_num end
        elseif m.played and m.isKnockout then
            local md_num = m.matchday or 0
            if md_num > ctx.latestPlayedMD then ctx.latestPlayedMD = md_num end
            if #ctx.recentPlayed<30 then table.insert(ctx.recentPlayed,m) end
        elseif not m.played and not m.isKnockout then
            table.insert(ctx.allUnplayed, m)
        elseif not m.played and m.isKnockout then
            table.insert(ctx.allUnplayedKO, m)
        end
    end

    -- todayMatches = matches from the latest played matchday (result news gate)
    for i=1,#matchData do
        local m = matchData[i]
        if m and m.played and (m.matchday or 0)==ctx.latestPlayedMD then
            table.insert(ctx.todayMatches, m)
        end
    end

    -- Sort recent played newest-first (safe comparator)
    table.sort(ctx.recentPlayed, function(a,b)
        return (a.matchday or 0) > (b.matchday or 0)
    end)

    -- Standings
    local sorted = {}
    for _,id in ipairs(ctx.teams) do
        local s = ctx.stats[id]
        table.insert(sorted,{id=id,pts=s.pts,w=s.w,d=s.d,l=s.l,gf=s.gf,ga=s.ga,mp=s.mp,gd=s.gf-s.ga,form=s.form})
    end
    table.sort(sorted, function(a,b)
        if a.pts~=b.pts then return a.pts>b.pts end
        if a.gd ~=b.gd  then return a.gd >b.gd  end
        return a.gf>b.gf
    end)
    for i=1,#sorted do sorted[i].pos=i end
    ctx.standings = sorted

    -- Top scorers
    local playerGoals = (sessionVars.get("PlayerGoals") or {})[leagueID] or {}
    if next(playerGoals) then
        for _,tid in ipairs(ctx.teams) do
            local lineup = getCachedTeamPlayers(tid) or {}
            for j=1,#lineup do
                local p = lineup[j]
                local g = playerGoals[p.CARD_ID] or 0
                if g>0 then
                    table.insert(ctx.topScorers,{name=p.playerName,id=p.CARD_ID,goals=g,teamID=tid})
                end
            end
        end
        table.sort(ctx.topScorers, function(a,b) return a.goals>b.goals end)
    end

    -- Streaks
    local teamML = {}
    for _,id in ipairs(ctx.teams) do teamML[id]={} end
    for i=1,#ctx.recentPlayed do
        local m = ctx.recentPlayed[i]
        if not m.isKnockout then
            if teamML[m.homeID] then table.insert(teamML[m.homeID],m) end
            if teamML[m.awayID] then table.insert(teamML[m.awayID],m) end
        end
    end
    for _,id in ipairs(ctx.teams) do
        local wins,unbeaten = 0,0
        for _,m in ipairs(teamML[id]) do
            local isH = m.homeID==id
            local tf  = isH and (m.homeScore or 0) or (m.awayScore or 0)
            local opp = isH and (m.awayScore or 0) or (m.homeScore or 0)
            if tf>opp then wins=wins+1; unbeaten=unbeaten+1
            elseif tf==opp then wins=0; unbeaten=unbeaten+1
            else break end
        end
        ctx.streaks[id]={wins=wins,unbeaten=unbeaten}
    end

    return ctx
end

-- ─── Queue / Cache ────────────────────────────────────────────────────────────

local function appendToday(md, item)
    table.insert(todayQueue[md], item)
end

local function pushBreaking(md, item)
    table.insert(todayQueue[md], 1, item)
end

local function archiveItem(md, item)
    table.insert(NewsCache[md], 1, item)
    while #NewsCache[md]>MAX_CACHE do table.remove(NewsCache[md]) end
end

-- Returns item, isNew(bool)
local function nextItem(md)
    local q = todayQueue[md]
    if #q>0 then
        local item = table.remove(q,1)
        archiveItem(md, item)
        return item, true
    end
    local cache = NewsCache[md]
    if #cache==0 then return nil, false end
    cacheCursor[md] = (cacheCursor[md] % #cache)+1
    return cache[cacheCursor[md]], false
end

-- Per-league per-day category guard
local function catUsed(md, leagueID, cat)
    return todayCategories[md][leagueID] and todayCategories[md][leagueID][cat]==true
end
local function markCat(md, leagueID, cat)
    if not todayCategories[md][leagueID] then todayCategories[md][leagueID]={} end
    todayCategories[md][leagueID][cat]=true
end

-- Result-news matchday gate
local function resultIsFresh(md, leagueID, latestMD)
    if latestMD==0 then return false end
    local last = (lastReportedMD[md][leagueID] or 0)
    return latestMD > last
end
local function markResultReported(md, leagueID, latestMD)
    lastReportedMD[md][leagueID] = latestMD
end

-- ─── Generators ───────────────────────────────────────────────────────────────

local function genDeadlineDay(ctx, _)
    if not isDeadlineDay() then return nil end
    local win = getWindowName()
    local t = {
        "DEADLINE DAY! Clubs scramble for last-minute deals as the "..win.." window shuts tonight",
        "IT'S DEADLINE DAY! Phone lines melting — who moves before midnight?",
        win.." window closes TODAY — expect chaos as clubs make desperate final moves",
        "FINAL HOURS of the "..win.." window — stay tuned for breaking deals all day",
    }
    return item1(prefixed(ctx.label, pick(t)), pick(SRC_TRANSFER), "deadline_day", nil, "")
end

-- Modifikasi genTransferRumor menggunakan layout obj5-7, bg obj8, source Transfermarkt (SRC_TM) dan text5 = "RUMOUR"
local function genTransferRumor(ctx, _)
    if not isTransferWindow() or isDeadlineDay() then return nil end
    local s = ctx.standings
    if #s<6 then return nil end
    local midLo = math.max(2, math.floor(#s*0.35))
    local midHi = math.min(#s-1, math.floor(#s*0.72))
    if midLo>=midHi then return nil end
    local srcTeam  = s[math.random(midLo,midHi)]
    local destTeam = s[math.random(1,math.min(4,#s))]
    if srcTeam.id==destTeam.id then return nil end
    local lineup = getCachedTeamPlayers(srcTeam.id) or {}
    if #lineup==0 then return nil end
    local topN = math.min(4,#lineup)
    local copy = {}
    for i=1,topN do copy[i]=lineup[i] end
    table.sort(copy, function(a,b) return (a.rating or 0)>(b.rating or 0) end)
    local player = copy[math.random(1,#copy)]
    if not player then return nil end
    local dName = tName(ctx.loc, destTeam.id)
    local sName = tName(ctx.loc, srcTeam.id)
    local pName = player.playerName or "Unknown"
    local t = {
        pName.." on "..dName.."'s shortlist — talks at an early stage",
        dName.." tracking "..pName.."; "..sName.." holding firm on valuation",
        dName.." have made discreet enquiries over "..sName.."'s "..pName.." — EXCLUSIVE",
        pName.."'s agent spotted in talks with "..dName.." officials this week",
        pName.." linked with a blockbuster move to "..dName.." as the window heats up",
    }
    
    -- Mengubah wrapper ke itemTransfer3 dan menambahkan parameter text5 = "RUMOUR"
    return itemTransfer3(prefixed(ctx.label, pick(t)), SRC_TM, "rumor",
        {name="$Head",  id=player.CARD_ID},
        {name="$Crest", id=destTeam.id},
        {name="$Crest", id=srcTeam.id},
        "RUMOUR",
        "RUMOUR")
end

local function genBargainHint(ctx, _)
    if not isTransferWindow() then return nil end
    local s = ctx.standings
    local n = #s
    if n<8 then return nil end
    local botStart = math.floor(n*0.55)
    for i=botStart,n do
        local t_  = s[i]
        local lu  = getCachedTeamPlayers(t_.id) or {}
        if #lu>0 then
            local bestP,bestR = nil,0
            for j=1,#lu do
                local r=lu[j].rating or 0
                if r>bestR then bestR=r; bestP=lu[j] end
            end
            if bestP and bestR>=76 then
                local pName = bestP.playerName or "Unknown"
                local tN    = tName(ctx.loc, t_.id)
                local bi    = math.random(1,math.min(6,n))
                local buyer = s[bi]
                if buyer and buyer.id~=t_.id then
                    local bName = tName(ctx.loc, buyer.id)
                    local opts = {
                        "BARGAIN ALERT! "..pName.." available from "..tN.." at cut price — "..bName.." circling",
                        bName.." eye a steal: "..pName.." could leave "..tN.." for a fraction of their value",
                        "WINDOW BARGAIN: "..pName.." could leave "..tN.." cheaply — clubs have been alerted",
                    }
                    return item2(prefixed(ctx.label, pick(opts)), pick(SRC_TRANSFER), "bargain",
                        {name="$Head",  id=bestP.CARD_ID},
                        {name="$Crest", id=t_.id},
                        "")
                end
            end
        end
    end
    return nil
end

local function genShockingResult(ctx, _)
    local s = ctx.standings
    if #s<4 or #ctx.todayMatches==0 then return nil end
    local posMap = {}
    for _,t_ in ipairs(s) do posMap[t_.id]=t_.pos end
    local bestUpset,bestGap = nil,0
    for i=1,#ctx.todayMatches do
        local m  = ctx.todayMatches[i]
        if not m.isKnockout then
            local hp = posMap[m.homeID] or 0
            local ap = posMap[m.awayID] or 0
            local hs = tonumber(m.homeScore) or 0
            local as = tonumber(m.awayScore) or 0
            if hs>as+1 and hp>ap+3 then
                local gap=hp-ap; if gap>bestGap then bestGap=gap; bestUpset=m end
            end
            if as>hs+1 and ap>hp+3 then
                local gap=ap-hp; if gap>bestGap then bestGap=gap; bestUpset=m end
            end
        end
    end
    if not bestUpset then return nil end
    local hs = tonumber(bestUpset.homeScore) or 0
    local as = tonumber(bestUpset.awayScore) or 0
    local winner,loser,ws,ls
    if hs>as then winner,loser,ws,ls=bestUpset.homeID,bestUpset.awayID,hs,as
    else           winner,loser,ws,ls=bestUpset.awayID,bestUpset.homeID,as,hs end
    local wName=tName(ctx.loc,winner); local lName=tName(ctx.loc,loser)
    local wPos=posMap[winner] or 0;    local lPos=posMap[loser] or 0
    local t = {
        "SHOCK RESULT! "..wName.." stun "..lName.." "..ws.."-"..ls.." — nobody saw that coming",
        "GIANT KILLING! "..ordinal(wPos).."-place "..wName.." dismantle "..lName.." "..ws.."-"..ls,
        lName.." HUMILIATED! "..wName.." run riot "..ws.."-"..ls.." against "..ordinal(lPos).." place",
        "CHAOS! "..wName.." thrash "..ordinal(lPos).."-place "..lName.." "..ws.."-"..ls,
    }
    return item2(prefixed(ctx.label, pick(t)), pick(SRC_RESULT), "shock_result",
        {name="$Crest",id=winner},
        {name="$Crest",id=loser},
        tostring(ws).."-"..tostring(ls))
end

local function genBigMatchResult(ctx, _)
    local s = ctx.standings
    if #s<3 or #ctx.todayMatches==0 then return nil end
    local top4={}
    for i=1,math.min(4,#s) do top4[s[i].id]=s[i].pos end
    for i=1,#ctx.todayMatches do
        local m = ctx.todayMatches[i]
        if not m.isKnockout and top4[m.homeID] and top4[m.awayID] then
            local hs = tonumber(m.homeScore) or 0
            local as = tonumber(m.awayScore) or 0
            local hN=tName(ctx.loc,m.homeID); local aN=tName(ctx.loc,m.awayID)
            local headline
            if hs==as then
                headline="TOP-OF-TABLE STALEMATE: "..hN.." and "..aN.." cancel each other out in a six-pointer"
            elseif hs>as then
                headline=hN.." edge title rivals "..aN.." "..hs.."-"..as.." in a match-of-the-season candidate"
            else
                headline=aN.." down "..hN.." "..as.."-"..hs.." in a blockbuster clash at the summit"
            end
            return item2(prefixed(ctx.label, headline), pick(SRC_RESULT), "big_match",
                {name="$Crest",id=m.homeID},
                {name="$Crest",id=m.awayID},
                tostring(hs).."-"..tostring(as))
        end
    end
    return nil
end

local function genUpcomingBigMatch(ctx, _)
    local s = ctx.standings
    if #s<3 or #ctx.allUnplayed==0 then return nil end
    local top6={}
    for i=1,math.min(6,#s) do top6[s[i].id]=s[i] end
    local nextFix,bestMD = nil,9999
    for i=1,#ctx.allUnplayed do
        local m=ctx.allUnplayed[i]
        if top6[m.homeID] and top6[m.awayID] then
            local md_=m.matchday or 0
            if md_<bestMD then bestMD=md_; nextFix=m end
        end
    end
    if not nextFix then return nil end
    local hN=tName(ctx.loc,nextFix.homeID); local aN=tName(ctx.loc,nextFix.awayID)
    local hp=top6[nextFix.homeID].pos;      local ap=top6[nextFix.awayID].pos
    local t = {
        "MUST-WATCH: "..hN.." host "..aN.." in a top-"..math.max(hp,ap).." clash — who blinks first?",
        ordinal(hp).." vs "..ordinal(ap).." — "..hN.." vs "..aN.." is the fixture everyone wants",
        hN.." face "..aN.." with massive points on the line — could define the title race",
        "ALL EYES ON: "..hN.." vs "..aN.." — the biggest fixture on the horizon",
    }
    return item2(prefixed(ctx.label, pick(t)), pick(SRC_GENERAL), "match_hype",
        {name="$Crest",id=nextFix.homeID},
        {name="$Crest",id=nextFix.awayID},
        "")
end

local function genGoldenBoot(ctx, _)
    if #ctx.topScorers==0 or ctx.topScorers[1].goals<3 then return nil end
    local top=ctx.topScorers[1]; local second=ctx.topScorers[2]
    local headline
    if second then
        local gap=top.goals-second.goals
        if gap==0 then
            headline="GOLDEN BOOT DEADLOCK: "..top.name.." and "..second.name.." both on "..top.goals.." goals — it is ON"
        elseif gap==1 then
            headline=top.name.." leads the boot race with "..top.goals.." goals — just one ahead of "..second.name
        elseif gap<=3 then
            headline=top.name.." on "..top.goals.." goals, "..gap.." clear of "..second.name.." — race wide open"
        else
            headline=top.name.." running away with the Golden Boot — "..top.goals.." goals and "..gap.." clear"
        end
    else
        headline="GOLDEN BOOT: "..top.name.." on "..top.goals.." goals with no rival in sight"
    end
    return item2(prefixed(ctx.label, headline), pick(SRC_STATS), "golden_boot",
        {name="$Head",  id=top.id},
        {name="$Crest", id=top.teamID},
        tostring(top.goals).." goals")
end

local function genStreakNews(ctx, _)
    local s=ctx.standings; if #s<4 then return nil end
    local bestWin,bestUB=0,0; local bWE,bUBE=nil,nil
    for _,t_ in ipairs(s) do
        if t_.mp>=4 then
            local sk=ctx.streaks[t_.id]
            if sk then
                if sk.wins>bestWin     then bestWin=sk.wins;     bWE=t_  end
                if sk.unbeaten>bestUB  then bestUB=sk.unbeaten;  bUBE=t_ end
            end
        end
    end
    if bestWin>=5 and bWE then
        local n=tName(ctx.loc,bWE.id)
        local t={
            n.." ON FIRE — "..bestWin.." consecutive wins and climbing to "..ordinal(bWE.pos),
            "UNSTOPPABLE! "..n.." make it "..bestWin.." straight wins — serious title ambitions forming",
            n.." extend their winning run to "..bestWin.." games. Nobody can stop them right now",
            "FORM OF THE SEASON: "..n.." win again — that is "..bestWin.." in a row",
        }
        return item1(prefixed(ctx.label, pick(t)), pick(SRC_STATS), "win_streak",
            {name="$Crest",id=bWE.id},
            tostring(bestWin).." wins")
    elseif bestUB>=8 and bUBE then
        local n=tName(ctx.loc,bUBE.id)
        local t={
            n.." unbeaten in "..bestUB.." — the most consistent side in the division",
            "IRON WALL: "..n.." go "..bestUB.." matches without defeat — the league is watching",
            n.." extend unbeaten run to "..bestUB.." — that back line is a fortress",
        }
        return item1(prefixed(ctx.label, pick(t)), pick(SRC_STATS), "unbeaten_run",
            {name="$Crest",id=bUBE.id},
            tostring(bestUB).." unbeaten")
    end
    return nil
end

local function genUnderdogStory(ctx, _)
    local s=ctx.standings; if #s<8 then return nil end
    for _,t_ in ipairs(s) do
        if t_.pos>=4 and t_.pos<=8 and t_.mp>=8 then
            local wr=t_.w/t_.mp
            local sk=ctx.streaks[t_.id]
            if (sk and sk.wins>=3) or wr>=0.60 then
                local n=tName(ctx.loc,t_.id)
                local opts={
                    "SURPRISE PACKAGE! "..n.." sit "..ordinal(t_.pos).." and refusing to be written off",
                    n.." defy the odds at "..ordinal(t_.pos).." with "..t_.pts.."pts — neutrals love them",
                    "WHO SAW THIS COMING? "..n.." are "..ordinal(t_.pos).." and absolutely flying",
                    n.." — story of the season: "..t_.w.." wins from "..t_.mp.." and loving every second",
                }
                return item1(prefixed(ctx.label, pick(opts)), pick(SRC_GENERAL), "underdog",
                    {name="$Crest",id=t_.id},
                    tostring(t_.pts).." pts")
            end
        end
    end
    return nil
end

local function genTitleRace(ctx, _)
    if ctx.progress<0.45 or #ctx.standings<2 then return nil end
    local first=ctx.standings[1]; local second=ctx.standings[2]
    if not first or not second or first.mp<10 then return nil end
    local gap=first.pts-second.pts; if gap>9 then return nil end
    local remFirst=0
    for i=1,#ctx.allUnplayed do
        local m=ctx.allUnplayed[i]
        if m.homeID==first.id or m.awayID==first.id then remFirst=remFirst+1 end
    end
    local fName=tName(ctx.loc,first.id); local sName=tName(ctx.loc,second.id)
    local headline
    if gap==0 then
        headline="DEAD HEAT AT THE TOP! "..fName.." and "..sName.." level — title race wide open with "..remFirst.." games left"
    elseif gap<=2 then
        headline="KNIFE EDGE: "..fName.." lead "..sName.." by "..gap.."pt"..(gap>1 and "s" or "").." with "..remFirst.." to go"
    elseif gap<=5 then
        headline=fName.." in the driving seat: "..gap.."pts over "..sName.." — but "..remFirst.." games remain"
    else
        headline=fName.." pulling clear at "..gap.."pts ahead of "..sName.." — a miracle run needed now"
    end
    return item2(prefixed(ctx.label, headline), pick(SRC_GENERAL), "title_race",
        {name="$Crest",id=first.id},
        {name="$Crest",id=second.id},
        tostring(gap).."pt gap")
end

local function genRelegationBattle(ctx, _)
    if ctx.progress<0.50 or #ctx.standings<8 then return nil end
    local s=ctx.standings
    local numRel=math.max(2,math.floor(#s*0.15))
    local safeIdx=#s-numRel
    if safeIdx<1 then return nil end
    local safety=s[safeIdx]; local bottom=s[#s]
    if not bottom or bottom.mp<8 then return nil end
    local gap=safety.pts-bottom.pts
    local remBot=0
    for i=1,#ctx.allUnplayed do
        local m=ctx.allUnplayed[i]
        if m.homeID==bottom.id or m.awayID==bottom.id then remBot=remBot+1 end
    end
    local bName=tName(ctx.loc,bottom.id); local sName=tName(ctx.loc,safety.id)
    local headline
    if gap>=12 then
        headline="CRISIS: "..bName.." sit "..gap.."pts from safety with only "..remBot.." games left — it looks bleak"
    elseif gap>=7 then
        headline="SURVIVAL PANIC at "..bName.." — "..gap.."pts behind "..sName.." and pressure mounting"
    elseif gap>=4 then
        headline="RELEGATION DOGFIGHT: "..bName.." and "..sName.." "..gap.."pts apart — every game is a final"
    else
        headline=bName.." fighting for survival — just "..gap.."pts from safety. The Great Escape is ON"
    end
    return item2(prefixed(ctx.label, headline), pick(SRC_RESULT), "relegation",
        {name="$Crest",id=bottom.id},
        {name="$Crest",id=safety.id},
        tostring(gap).."pt deficit")
end

local function genLeagueStats(ctx, _)
    if ctx.totalPlayed<8 then return nil end
    local avg=ctx.totalGoals/ctx.totalPlayed
    local opts={}
    if avg>=3.3 then
        table.insert(opts,"GOAL FEAST: The league is averaging "..string.format("%.1f",avg).." goals per game — defences are suffering")
        table.insert(opts,string.format("%.1f",avg).." goals per match on average — best entertainment in the business")
    elseif avg<=1.8 then
        table.insert(opts,"TACTICAL CHESS: Only "..string.format("%.1f",avg).." goals per game — clean sheets rule this division")
    end
    local bm=ctx.biggestMatch
    if bm then
        local hs,as=bm.homeScore or 0, bm.awayScore or 0
        if hs+as>=7 then
            local hN=tName(ctx.loc,bm.homeID); local aN=tName(ctx.loc,bm.awayID)
            table.insert(opts,"SEASON'S BIGGEST SCORELINE: "..hN.." "..hs.."-"..as.." "..aN.." — can anything top that?")
        end
    end
    local bestDefID,bestDefGA=nil,99999
    local bestAttID,bestAttGF=nil,0
    for _,t_ in ipairs(ctx.standings) do
        local ga=ctx.conceded[t_.id] or 0
        if ga<bestDefGA then bestDefGA=ga; bestDefID=t_.id end
        if t_.gf>bestAttGF then bestAttGF=t_.gf; bestAttID=t_.id end
    end
    if bestDefID and bestDefGA<=math.floor(ctx.totalPlayed*0.60) then
        table.insert(opts,tName(ctx.loc,bestDefID).." — only "..bestDefGA.." goals conceded all season: the best defence in the division")
    end
    if bestAttID and bestAttGF>=15 then
        table.insert(opts,tName(ctx.loc,bestAttID).." — "..bestAttGF.." goals scored: the most devastating attack in the league")
    end
    if #opts==0 then return nil end
    local badge=(avg>=3.3 or avg<=1.8) and (string.format("%.1f",avg).." gpg") or ""
    return item1(prefixed(ctx.label, pick(opts)), pick(SRC_STATS), "league_stats", nil, badge)
end

local function genLeagueWinner(ctx, _)
    if ctx.progress<0.82 or #ctx.standings<2 then return nil end
    local first=ctx.standings[1]; local second=ctx.standings[2]
    if not first or first.mp<15 then return nil end
    local remSec=0
    for i=1,#ctx.allUnplayed do
        local m=ctx.allUnplayed[i]
        if m.homeID==second.id or m.awayID==second.id then remSec=remSec+1 end
    end
    if first.pts<=second.pts+remSec*3 then return nil end
    local n=tName(ctx.loc,first.id)
    local t={
        "CHAMPIONS! "..n.." are confirmed league champions — a season to remember!",
        n.." ARE TITLE WINNERS! "..first.pts.."pts and they have done it in style",
        "TITLE CONFIRMED: "..n.." clinch the league with games to spare — the party has started",
        n.." lift the trophy — dominant, brilliant, and fully worthy champions",
    }
    return item1(prefixed(ctx.label, pick(t)), pick(SRC_GENERAL), "title_won",
        {name="$Crest",id=first.id},
        tostring(first.pts).." pts")
end

-- User-league only
local function genUserTeamNews(ctx, _)
    if not ctx.isUserLeague then return nil end
    local userID=currentSelectedTeamID
    if not userID then return nil end
    local uStat=nil
    for _,t_ in ipairs(ctx.standings) do
        if t_.id==userID then uStat=t_; break end
    end
    if not uStat or uStat.mp<3 then return nil end
    local n=tName(ctx.loc,userID); local posStr=ordinal(uStat.pos)
    local sk=ctx.streaks[userID] or {wins=0,unbeaten=0}
    local opts={}
    if sk.wins>=4 then
        table.insert(opts,n.." on a "..sk.wins.."-game winning streak — the talk of the division")
        table.insert(opts,"YOUR "..n.." are the form team right now — "..sk.wins.." wins in a row")
    elseif sk.unbeaten>=6 then
        table.insert(opts,n.." unbeaten in "..sk.unbeaten.." — solid foundations under your management")
    end
    local f1=uStat.form[1] or ""; local f2=uStat.form[2] or ""; local f3=uStat.form[3] or ""
    local last3=f1..f2..f3
    if last3=="LLL" then table.insert(opts,"DIFFICULT SPELL for "..n.." — three straight defeats and pressure building at "..posStr)
    elseif last3=="DDD" then table.insert(opts,n.." drawing too many — three stalemates and points left on the table") end
    if uStat.pos==1 then
        table.insert(opts,n.." top of the table with "..uStat.pts.."pts — can you go all the way?")
    elseif uStat.pos<=4 then
        table.insert(opts,n.." in the top four at "..posStr.." — "..uStat.pts.."pts, Champions League in sight")
    elseif uStat.pos>(#ctx.standings-3) then
        table.insert(opts,n.." are "..posStr.." — just "..uStat.pts.."pts and a relegation fight shaping up")
    end
    local gdStr=uStat.gd>=0 and ("+"..uStat.gd) or tostring(uStat.gd)
    if uStat.gd>=12 then table.insert(opts,n.." boasting a "..gdStr.." GD — the most clinical side in the division") end
    if #opts==0 then table.insert(opts,n.." at "..posStr.." with "..uStat.pts.."pts from "..uStat.mp.." games") end
    return item1(pick(opts), pick(SRC_GENERAL), "user_team",
        {name="$Crest",id=userID},
        tostring(uStat.pts).." pts")
end

-- UCL-specific generators
local function genUCLKnockoutResult(ctx, _)
    if not ctx.isUCL then return nil end
    for i=1,#ctx.todayMatches do
        local m=ctx.todayMatches[i]
        if m.isKnockout then
            local hs = tonumber(m.homeScore) or 0
            local as = tonumber(m.awayScore) or 0
            local hN=tName(ctx.loc,m.homeID); local aN=tName(ctx.loc,m.awayID)
            local headline
            if hs>as then
                headline="UCL: "..hN.." ADVANCE! Dominant "..hs.."-"..as.." win sends "..aN.." crashing out"
            elseif as>hs then
                headline="UCL: "..aN.." progress in style! "..hN.." are OUT — "..as.."-"..hs.." on the night"
            else
                headline="UCL THRILLER: "..hN.." and "..aN.." level "..hs.."-"..as.." — nerves shredded"
            end
            local w = hs>as and m.homeID or (as>hs and m.awayID or m.homeID)
            local l = hs>as and m.awayID or (as>hs and m.homeID or m.awayID)
            return item2(headline, pick(SRC_RESULT), "ucl_ko_result",
                {name="$Crest",id=w},
                {name="$Crest",id=l},
                tostring(hs).."-"..tostring(as))
        end
    end
    return nil
end

local function genUCLKnockoutHype(ctx, _)
    if not ctx.isUCL or #ctx.allUnplayedKO==0 then return nil end
    local nextKO,bestMD=nil,9999
    for i=1,#ctx.allUnplayedKO do
        local m=ctx.allUnplayedKO[i]
        local md_=m.matchday or 0
        if md_<bestMD then bestMD=md_; nextKO=m end
    end
    if not nextKO then return nil end
    local hN=tName(ctx.loc,nextKO.homeID); local aN=tName(ctx.loc,nextKO.awayID)
    local roundName
    if bestMD>=13 then roundName="FINAL"
    elseif bestMD>=11 then roundName="SEMI-FINAL"
    elseif bestMD>=9  then roundName="QUARTER-FINAL"
    else roundName="KNOCKOUT ROUND" end
    local t={
        "UCL "..roundName..": "..hN.." take on "..aN.." — all of Europe is watching",
        "Champions League "..roundName.." arrives: "..hN.." vs "..aN.." — who advances?",
        "ALL OF EUROPE WATCHING: "..hN.." face "..aN.." in the UCL "..roundName,
    }
    return item2(pick(t), pick(SRC_RESULT), "ucl_ko_hype",
        {name="$Crest",id=nextKO.homeID},
        {name="$Crest",id=nextKO.awayID},
        roundName)
end

local function genUCLWinner(ctx, _)
    if not ctx.isUCL then return nil end
    local matchData=(sessionVars.get("LeagueMatchData") or {})[ctx.leagueID] or {}
    local finalM,maxMD=nil,0
    for i=1,#matchData do
        local m=matchData[i]
        if m and m.played and m.isKnockout and (m.matchday or 0)>maxMD then
            maxMD=m.matchday; finalM=m
        end
    end
    if not finalM then return nil end
    for i=1,#matchData do
        local m=matchData[i]
        if m and not m.played and m.isKnockout and (m.matchday or 0)>maxMD then
            return nil
        end
    end
    local hs = tonumber(finalM.homeScore) or 0
    local as = tonumber(finalM.awayScore) or 0
    local wID=hs>as and finalM.homeID or (as>hs and finalM.awayID or nil)
    if not wID then return nil end
    local n=tName(ctx.loc,wID)
    local t={
        n.." ARE CHAMPIONS OF EUROPE! Unforgettable UCL triumph after an incredible Final",
        "UCL WINNERS: "..n.." lift the trophy in a Final for the ages — Europe's best!",
        n.." CONQUER EUROPE! Champions League glory confirmed — what a season!",
    }
    return item1(pick(t), pick(SRC_RESULT), "ucl_won",
        {name="$Crest",id=wID},
        "CHAMPIONS")
end

-- ─── Generator Registries ────────────────────────────────────────────────────

local GEN_USER = {
    {fn=genDeadlineDay,      minP=0,    maxP=1,    bw=100, cat="deadline_day"},
    {fn=genLeagueWinner,     minP=0.82, maxP=1,    bw=95,  cat="title_won"},
    {fn=genTitleRace,        minP=0.45, maxP=1,    bw=78,  cat="title_race"},
    {fn=genRelegationBattle, minP=0.50, maxP=1,    bw=74,  cat="relegation"},
    {fn=genBigMatchResult,   minP=0,    maxP=1,    bw=68,  cat="big_match"},
    {fn=genShockingResult,   minP=0,    maxP=1,    bw=63,  cat="shock_result"},
    {fn=genGoldenBoot,       minP=0,    maxP=1,    bw=58,  cat="golden_boot"},
    {fn=genTransferRumor,    minP=0,    maxP=1,    bw=55,  cat="rumor"},
    {fn=genStreakNews,       minP=0,    maxP=1,    bw=50,  cat="streak"},
    {fn=genUserTeamNews,     minP=0,    maxP=1,    bw=50,  cat="user_team"},
    {fn=genBargainHint,      minP=0,    maxP=1,    bw=42,  cat="bargain"},
    {fn=genUpcomingBigMatch, minP=0,    maxP=0.95, bw=38,  cat="match_hype"},
    {fn=genUnderdogStory,    minP=0.15, maxP=1,    bw=36,  cat="underdog"},
    {fn=genLeagueStats,      minP=0.20, maxP=1,    bw=32,  cat="league_stats"},
}

local GEN_OTHER = {
    {fn=genLeagueWinner,     minP=0.82, maxP=1,    bw=95,  cat="title_won"},
    {fn=genTitleRace,        minP=0.45, maxP=1,    bw=78,  cat="title_race"},
    {fn=genRelegationBattle, minP=0.50, maxP=1,    bw=74,  cat="relegation"},
    {fn=genShockingResult,   minP=0,    maxP=1,    bw=68,  cat="shock_result"},
    {fn=genBigMatchResult,   minP=0,    maxP=1,    bw=63,  cat="big_match"},
    {fn=genGoldenBoot,       minP=0,    maxP=1,    bw=55,  cat="golden_boot"},
    {fn=genStreakNews,       minP=0,    maxP=1,    bw=45,  cat="streak"},
    {fn=genUnderdogStory,    minP=0.15, maxP=1,    bw=35,  cat="underdog"},
}

local GEN_UCL = {
    {fn=genUCLWinner,         minP=0.70, maxP=1,    bw=95,  cat="ucl_won"},
    {fn=genUCLKnockoutResult, minP=0.40, maxP=1,    bw=88,  cat="ucl_ko_result"},
    {fn=genUCLKnockoutHype,   minP=0.35, maxP=0.98, bw=75,  cat="ucl_ko_hype"},
    {fn=genShockingResult,    minP=0,    maxP=1,    bw=60,  cat="shock_result"},
    {fn=genBigMatchResult,    minP=0,    maxP=1,    bw=55,  cat="big_match"},
    {fn=genGoldenBoot,        minP=0,    maxP=1,    bw=45,  cat="golden_boot"},
}

-- ─── Generate For One League ─────────────────────────────────────────────────

local function generateForLeague(md, ctx, registry, budget)
    if budget<=0 or #ctx.standings==0 then return 0 end
    local progress = ctx.progress
    local needFresh = resultIsFresh(md, ctx.leagueID, ctx.latestPlayedMD)

    local eligible={}
    for i=1,#registry do
        local g=registry[i]
        if progress>=g.minP and progress<=g.maxP then
            table.insert(eligible,{fn=g.fn, cat=g.cat, key=g.bw+math.random(20)})
        end
    end
    table.sort(eligible, function(a,b) return a.key>b.key end)

    local added=0
    local resultCats={shock_result=true, big_match=true, ucl_ko_result=true}

    for i=1,#eligible do
        if added>=budget then break end
        local g=eligible[i]
        if resultCats[g.cat] and not needFresh then
        elseif not catUsed(md, ctx.leagueID, g.cat) then
            local item=g.fn(ctx, md)
            if item then
                appendToday(md, item)
                markCat(md, ctx.leagueID, g.cat)
                added=added+1
                if resultCats[g.cat] then
                    markResultReported(md, ctx.leagueID, ctx.latestPlayedMD)
                    needFresh=false
                end
            end
        end
    end
    return added
end

-- ─── Daily Generation ─────────────────────────────────────────────────────────

function NewsCenter:generateDailyNews()
    local md          = getMode()
    local currentDate = GLOBAL_DATE_PLACEHOLDER or "01/08/24"
    if lastGenDate[md]==currentDate then return end

    lastGenDate[md]     = currentDate
    todayCategories[md] = {}
    todayQueue[md]      = {}

    local userLeagueID = sessionVars.get("currentUserLeagueID")
    local uclLeagueID  = sessionVars.get("UCLLeagueID")

    local allLeagues   = sessionVars.get("LeagueTeams") or {}
    local otherIDs     = {}
    for id,_ in pairs(allLeagues) do
        if id~=userLeagueID and id~=uclLeagueID then
            table.insert(otherIDs, id)
        end
    end

    local totalAdded = 0

    -- Phase 1: User league
    if userLeagueID then
        local ctx = buildWorldContext(self.loc, userLeagueID, true, false)
        totalAdded = totalAdded + generateForLeague(md, ctx, GEN_USER, BUDGET_USER)
    end

    -- Phase 2: One random other domestic league
    if totalAdded < MAX_DAILY and #otherIDs > 0 then
        local picked = otherIDs[math.random(#otherIDs)]
        local ctx = buildWorldContext(self.loc, picked, false, false)
        totalAdded = totalAdded + generateForLeague(md, ctx, GEN_OTHER, BUDGET_OTHER)
    end

    -- Phase 3: UCL
    if totalAdded < MAX_DAILY and uclLeagueID then
        local ctx = buildWorldContext(self.loc, uclLeagueID, false, true)
        totalAdded = totalAdded + generateForLeague(md, ctx, GEN_UCL, BUDGET_UCL)
    end
end

-- ─── External Queue API ───────────────────────────────────────────────────────

function NewsCenter:getTransferHeadline(mode, playerName, newTeam, oldTeam, transferValue, _)
    local valStr=formatFunds(transferValue)
    if mode==2 then
        return "HERE WE GO! "..playerName.." joins "..newTeam.." on loan from "..oldTeam
    end
    if transferValue and transferValue>=50000000 then
        return "BLOCKBUSTER! "..playerName.." completes "..valStr.." move to "..newTeam.." from "..oldTeam
    end
    return "HERE WE GO! "..playerName.." joins "..newTeam.." — "..oldTeam.." accept "..valStr.." bid"
end

-- Modifikasi fungsi antrean transfer agar bnd_sourceImg & bnd_sourceName menggunakan SRC_TM (Transfermarkt)
-- Serta mengubah text4 dan mengatur text5 ("DONE DEAL", "LOAN", atau "RUMOUR") sesuai instruksi baru
function NewsCenter:queueTransferNews(player, oldTeamID, newTeamID, oldTeam, newTeam, transferValue, Date, mode)
    local md = getMode(); mode = mode or 3
    local headline = self:getTransferHeadline(mode, player.playerName, newTeam, oldTeam, transferValue, Date)
    if mode==3 then
        headline = pick({
            player.playerName.." to "..newTeam.."? Talks confirmed by sources close to the player",
            "RUMOUR MILL: "..player.playerName.." and "..newTeam.." in early discussions",
        })
    end
    
    -- Menentukan teks untuk bnd_text4 (Nominal Transfer, RUMOUR, atau LOAN)
    local text4Value = ""
    if mode == 2 then
        text4Value = "LOAN"                  -- Jika mode pinjaman, paksa teks menjadi LOAN
    elseif mode ~= 3 then
        text4Value = formatFunds(transferValue) -- Jika transfer permanen resmi, tampilkan harga
    end

    -- Filter Penentuan teks khusus untuk bnd_text5 berdasarkan kondisi mode transfer
    local text5Value = ""
    if mode == 3 then
        text5Value = "RUMOUR"
    elseif mode == 2 then
        text5Value = "LOAN"
    else
        text5Value = "DONE DEAL"
    end
    
    -- Parameter source diganti menjadi SRC_TM dan menyuntikkan text5Value ke system itemTransfer3
    local item = itemTransfer3(headline, SRC_TM,
        mode==3 and "rumor" or "transfer",
        {name="$Head",  id=player.CARD_ID},
        {name="$Crest", id=newTeamID},
        {name="$Crest", id=oldTeamID},
        text4Value,
        text5Value) -- Menggunakan variabel text5Value yang baru dibuat
    pushBreaking(md, item)
end

function NewsCenter:queueMatchNews(loc, mType, data)
    local md=getMode(); local source=pick(SRC_RESULT)
    if mType=="Final" then
        local hs=data.pen and (data.homeScore+(data.homePenScores or 0)) or (data.homeScore or 0)
        local as=data.pen and (data.awayScore+(data.awayPenScores or 0)) or (data.awayScore or 0)
        local wID=hs>as and data.homeID or (as>hs and data.awayID or nil)
        if wID then
            local n=loc.LocalizeString("TeamName_Abbr15_"..tostring(wID)) or ("Team"..tostring(wID))
            local t={
                "CHAMPIONS! "..n.." win the Final and are crowned champions — history made!",
                n.." ARE CHAMPIONS! A Final performance for the ages — they have done it!",
                "CUP GLORY: "..n.." lift the trophy — unforgettable scenes after a brilliant Final",
            }
            pushBreaking(md, item1(pick(t), source, "final",
                {name="$Crest",id=wID},
                tostring(hs).."-"..tostring(as)))
        end
    end
end

-- ─── Display ─────────────────────────────────────────────────────────────────

-- Modifikasi fungsi publikasi item untuk menyertakan data pengikatan bnd_object5-8, bnd_text4, dan bnd_text5
local function publishItem(item, isNew_)
    doPublish("bnd_headline",   shorten(item.headline, 38))
    doPublish("bnd_isNew",      isNew_==true)
    doPublish("bnd_likeNo",     item.likes)
    doPublish("bnd_commentNo",  item.comments)
    doPublish("bnd_newsDate",   fmtDate(item.date))
    doPublish("bnd_sourceImg",  item.source and item.source.img or "")
    doPublish("bnd_sourceName", item.source and item.source.name or "")
    doPublish("bnd_object1",    item.obj1 or {})
    doPublish("bnd_object2",    item.obj2 or {})
    doPublish("bnd_object3",    item.obj3 or {})
    doPublish("bnd_text1",      item.text1 or "")
    
    -- Slot data khusus berita transfer pemain
    doPublish("bnd_object5",    item.obj5 or {})
    doPublish("bnd_object6",    item.obj6 or {})
    doPublish("bnd_object7",    item.obj7 or {})
    doPublish("bnd_text4",      item.text4 or "")
    doPublish("bnd_object8",    item.obj8 or {}) -- Mengikat asset background khusus transfer
    doPublish("bnd_text5",      item.text5 or "") -- Mengikat teks dinamis info status transfer
end

function NewsCenter:displayNews()
    local md=getMode()
    self:generateDailyNews()
    local item, isNew_ = nextItem(md)
    if not item then
        doPublish("bnd_headline",   "Welcome to a brand new Season")
        doPublish("bnd_isNew",      false)
        doPublish("bnd_likeNo",     "9K")
        doPublish("bnd_commentNo",  "100")
        doPublish("bnd_newsDate",   fmtDate(GLOBAL_DATE_PLACEHOLDER or "01/08/24"))
        doPublish("bnd_sourceImg",  "")
        doPublish("bnd_sourceName", "Premier League")
        doPublish("bnd_object1",    {})
        doPublish("bnd_object2",    {})
        doPublish("bnd_object3",    {})
        doPublish("bnd_text1",      "")
        doPublish("bnd_object5",    {})
        doPublish("bnd_object6",    {})
        doPublish("bnd_object7",    {})
        doPublish("bnd_text4",      "")
        doPublish("bnd_object8",    {}) -- Bersihkan background transfer jika kosong
        doPublish("bnd_text5",      "") -- Bersihkan text5 info transfer jika kosong
        return
    end
    publishItem(item, isNew_)
end

-- ─── View Toggle ─────────────────────────────────────────────────────────────

function NewsCenter:toggleView()
    if self.newsView==1 then
        doPublish("bnd_isTab1", false)
        self.newsView=2
    else
        doPublish("bnd_isNotDateSim", true)
        doPublish("bnd_isTab1",       true)
        self.newsView=1
    end
    local md=getMode(); local cache=NewsCache[md]
    if #cache>0 then publishItem(cache[1], false) end
end

-- ─── UI Bindings ─────────────────────────────────────────────────────────────

local UIbnds = {
    "bnd_headline","bnd_likeNo","bnd_commentNo",
    "bnd_newsDate","bnd_sourceImg","bnd_sourceName",
    "bnd_object1","bnd_object2","bnd_object3","bnd_text1",
    "bnd_object5","bnd_object6","bnd_object7","bnd_text4",
    "bnd_object8", "bnd_text5", -- Daftarkan UI binding untuk background transfer dan text5 status transfer
}

function NewsCenter:subscribeUIBnds()
    for i=1,#UIbnds do
        local bnd=UIbnds[i]
        subscribeFn(bnd, function() self:clearUI() end)
    end
end

function NewsCenter:clearUI()
    local md=getMode()
    local function rep(bnd, fallback)
        local stored=lastPublished[md][bnd]
        doPublish(bnd, (stored~=nil) and stored or fallback)
    end
    rep("bnd_headline",   "Welcome to a brand new Season")
    rep("bnd_isNew",      false)
    rep("bnd_likeNo",     "9K")
    rep("bnd_commentNo",  "100")
    rep("bnd_newsDate",   fmtDate(GLOBAL_DATE_PLACEHOLDER or "01/08/24"))
    rep("bnd_sourceImg",  "")
    rep("bnd_sourceName", "Premier League")
    rep("bnd_object1",    {})
    rep("bnd_object2",    {})
    rep("bnd_object3",    {})
    rep("bnd_text1",      "")
    rep("bnd_object5",    {})
    rep("bnd_object6",    {})
    rep("bnd_object7",    {})
    rep("bnd_text4",      "")
    rep("bnd_object8",    {}) -- Mengembalikan ke tabel kosong saat UI dibersihkan
    rep("bnd_text5",      "") -- Mengembalikan text5 ke string kosong saat UI dibersihkan
end

function NewsCenter:setupDisplay()
    local md=getMode()
    local slots={
        "bnd_object1","bnd_object2","bnd_object3","bnd_text1",
        "bnd_object5","bnd_object6","bnd_object7","bnd_text4",
        "bnd_object8","bnd_text5" -- Pasang fungsi subscribe setup display untuk slot text5
    }
    for i=1,#slots do
        local bnd=slots[i]
        subscribeFn(bnd, function()
            local isText = (bnd=="bnd_text1" or bnd=="bnd_text4" or bnd=="bnd_text5")
            doPublish(bnd, lastPublished[md][bnd] or (isText and "" or {}))
        end)
    end
    subscribeFn("news_position", function()
        doPublish("news_position", lastPublished[md]["news_position"] or 20)
    end)
    subscribeFn("news_alpha", function()
        doPublish("news_alpha", lastPublished[md]["news_alpha"] or 1)
    end)
end

-- ─── Backwards-Compat Stubs ───────────────────────────────────────────────────

function NewsCenter:shortenString(str)  return shorten(str,38)   end
function NewsCenter:formatDate(dateStr) return fmtDate(dateStr)  end

function NewsCenter:parseDate(dateStr)
    local d,m,y=(dateStr or ""):match("^(%d%d)/(%d%d)/(%d%d)$")
    if not d then return nil end
    return {day=tonumber(d),month=tonumber(m),year=2000+tonumber(y)}
end

-- ─── Constructor ─────────────────────────────────────────────────────────────

function NewsCenter:new(init)
    local o=init or {}
    setmetatable(o,self); self.__index=self
    o.loc      = init.loc
    o.anim     = init.anim
    publishFn  = function(bnd,data)
        o.im.Publish(bnd,data)
        lastPublished[getMode()][bnd]=data
    end
    subscribeFn = o.im.Subscribe
    o.newsView  = 1
    o.im.RegisterAction("act_opennews", function() o:toggleView() end)
    o:setupDisplay()
    return o
end

-- ─── Finalize ────────────────────────────────────────────────────────────────

function NewsCenter:finalize()
    todayQueue      = {career={}, tournament={}}
    NewsCache       = {career={}, tournament={}}
    cacheCursor     = {career=0,  tournament=0}
    lastGenDate     = {career="", tournament=""}
    todayCategories = {career={}, tournament={}}
    lastReportedMD  = {career={}, tournament={}}
    lastPublished   = {career={}, tournament={}}
end

return NewsCenter
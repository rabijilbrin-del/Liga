local Timer, Date = ... 
local DateAdvancement = {}

-- Constants
local DAYS_IN_MONTH = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
local MONTH_NAMES_SHORT = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"}
local DAY_NAMES = {"SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"}
local BND_DATE1 = "bnd_date1"
local BND_DATE2 = "bnd_date2"
local BND_DATE3 = "bnd_date3"
local BND_IS_DATE_SIM = "bnd_isDateSim"
local BND_IS_NOT_DATE_SIM = "bnd_isNotDateSim"

-- Utility functions
local function isLeapYear(year)
    return year % 4 == 0 and (year % 100 ~= 0 or year % 400 == 0)
end

local function getDaysInMonth(month, year)
    if month == 2 and isLeapYear(year) then return 29 end
    return DAYS_IN_MONTH[month]
end

local function parseDate(dateStr)
    local day, month, year = dateStr:match("^(%d%d)/(%d%d)/(%d%d)$")
    day, month, year = tonumber(day), tonumber(month), tonumber(year)
    if not (day and month and year) then return nil end
    return {day = day, month = month, year = 2000 + year}
end

local function getNextDay(dateStr)
    local date = parseDate(dateStr)
    if not date then return nil end
    local day, month, year = date.day, date.month, date.year
    day = day + 1
    if day > getDaysInMonth(month, year) then
        day = 1
        month = month + 1
        if month > 12 then
            month = 1
            year = year + 1
        end
    end
    return {day = day, month = month, year = year}
end

local function getPreviousDay(dateStr)
    local date = parseDate(dateStr)
    if not date then return nil end
    local day, month, year = date.day, date.month, date.year
    day = day - 1
    if day < 1 then
        month = month - 1
        if month < 1 then
            month = 12
            year = year - 1
        end
        day = getDaysInMonth(month, year)
    end
    return {day = day, month = month, year = year}
end

local function formatDateAsDayName(date)
    if not date then return "UNKNOWN, JAN 01" end
    local time = os.time({day = date.day, month = date.month, year = date.year, hour = 0, min = 0, sec = 0})
    local dayIndex = tonumber(os.date("%w", time))
    local dayName = DAY_NAMES[dayIndex + 1]
    local monthName = MONTH_NAMES_SHORT[date.month]
    return string.format("%s, %s %02d", dayName, monthName, date.day)
end

local function isValidMatchDateYY(dateStr)
    if not dateStr or not dateStr:match("^%d%d%d%d%d%d$") then return false end
    local month, day, year = dateStr:match("^(%d%d)(%d%d)(%d%d)$")
    month, day, year = tonumber(month), tonumber(day), tonumber(year)
    if not (month and day and year) then return false end
    if month < 1 or month > 12 or day < 1 or year < 0 or year > 99 then return false end
    return day <= getDaysInMonth(month, year)
end

local function daysToNextMatch(currentDateStr, matchDates)
    local currentDate = parseDate(currentDateStr or "01/08/24")
    if not currentDate then return nil end
    local currentTime = os.time({
        day = currentDate.day,
        month = currentDate.month,
        year = currentDate.year,
        hour = 0, min = 0, sec = 0
    })

    local nextMatchTime = nil
    for _, dateStr in ipairs(matchDates or {}) do
        if isValidMatchDateYY(dateStr) then
            local month, day, year = dateStr:match("^(%d%d)(%d%d)(%d%d)$")
            month, day, year = tonumber(month), tonumber(day), tonumber(year) + 2000
            local matchTime = os.time({
                day = day, month = month, year = year, hour = 0, min = 0, sec = 0
            })
            if matchTime > currentTime then
                if not nextMatchTime or matchTime < nextMatchTime then
                    nextMatchTime = matchTime
                end
            elseif matchTime == currentTime then
                return 0
            end
        end
    end

    if not nextMatchTime then return nil end
    local secondsPerDay = 24 * 60 * 60
    return math.floor((nextMatchTime - currentTime) / secondsPerDay)
end

-- DateAdvancement class
function DateAdvancement:new(init)
    local o = init or {}
    setmetatable(o, self)
    self.__index = self
    o.im = o.im or {} -- In-memory event system
    o.nav = o.nav or {} -- Navigation system
    o.Date = Date:new() -- Date management module
    o.models = o.models or {} -- For AITransfers
    o.transferSystem = o.transferSystem or {} -- For liveTransfersHandling
    o.isAutoAdvancing = false
    o.isAnimating = false
    o.dateYPositions = {0, -50, -100}
    o.dateTimer = nil
    o.transfersDoneForDate = {}
    o.lastTransferDate = nil
    o.dateAdvanceCount = 0
    return o
end

function DateAdvancement:publishDates()
    local currentDate = GLOBAL_DATE_PLACEHOLDER or "01/08/24"
    local nextDate = getNextDay(currentDate)
    local prevDate = getPreviousDay(currentDate)
    self.im.Publish(BND_DATE1, formatDateAsDayName(nextDate))
    self.im.Publish(BND_DATE2, formatDateAsDayName(parseDate(currentDate)))
    self.im.Publish(BND_DATE3, formatDateAsDayName(prevDate))
end

function DateAdvancement:dateAnim()
    for i = 1, 3 do
        self.im.Publish("bnd_date" .. i .. "Y", self.dateYPositions[i])
    end
    self.im.Publish(BND_IS_DATE_SIM, self.isAnimating)
    self.im.Publish(BND_IS_NOT_DATE_SIM, not self.isAnimating)
end

function DateAdvancement:animateDateSwipe(callback)
    if self.dateTimer then
        self.dateTimer:finalize()
        self.dateTimer = nil
    end
    self.isAnimating = true
    self:dateAnim()

    local startY = {50, -50, -100}
    local endY = {-100, 0, -50}
    local duration = 0.1
    local stepInterval = 0.025
    local steps = math.floor(duration / stepInterval)
    local stepSizes = {
        (endY[1] - startY[1]) / steps,
        (endY[2] - startY[2]) / steps,
        (endY[3] - startY[3]) / steps
    }

    local function animateStep(step)
        if not self.isAnimating then
            self.dateTimer = nil
            self:dateAnim()
            return
        end
        if step > steps then
            self.dateYPositions = {0, -50, -100}
            self:publishDates()
            self.isAnimating = false
            self:dateAnim()
            if callback then callback() end
            return
        end
        self.dateYPositions = {
            startY[1] + stepSizes[1] * step,
            startY[2] + stepSizes[2] * step,
            startY[3] + stepSizes[3] * step
        }
        self:dateAnim()
        self.dateTimer = Timer:new({
            id = "dateTimer_" .. step,
            interval = stepInterval,
            reps = 1,
            onTimerComplete = function() animateStep(step + 1) end
        })
        self.dateTimer:start()
    end

    self.dateTimer = Timer:new({
        id = "dateTimer_delay",
        interval = 1.0,
        reps = 1,
        onTimerComplete = function()
            if self.isAnimating then
                animateStep(1)
            else
                self.dateTimer = nil
                self:dateAnim()
            end
        end
    })
    self.dateTimer:start()
end

function DateAdvancement:advanceDateStep(callback)
    if not self.isAutoAdvancing then return end
    if self.dateAdvanceCount >= 365 then
        self:reset()
        self.nav.Event(nil, "evt_end", {title = "ERROR", message = "Maximum date advances reached", buttons = {{label = "Close", clickEvents = {"evt_hide_popup"}}}})
        return
    end
    self.dateAdvanceCount = self.dateAdvanceCount + 1

    local currentDate = GLOBAL_DATE_PLACEHOLDER or "01/08/24"
    local day, month = currentDate:match("(%d%d)/(%d%d)/%d%d")
    day, month = tonumber(day), tonumber(month)

    -- Process transfers if not already done
    if self.lastTransferDate and not self.transfersDoneForDate[currentDate] then
        local transfers = self.models.AITransfers:batchRandomTransfers()
        for _, transferData in ipairs(transfers) do
            self.transferSystem:liveTransfersHandling(transferData.playerID, transferData.destTeamID, transferData.sourceTeamID)
        end
        self.transfersDoneForDate[currentDate] = true
    end

    -- Advance date
    self.Date:advanceDate()
    self.lastTransferDate = currentDate

    -- Check for season end
    if day == 3 and month == 6 then
        self:reset()
        self.nav.Event(nil, "evt_end", {title = "SEASON END", message = "Season has ended", buttons = {{label = "Close", clickEvents = {"evt_hide_popup"}}}})
        return
    elseif day == 2 and month == 6 then
        self:reset()
        self.nav.Event(nil, "evt_show_popup", {title = "SEASON END", message = "Mission mode completed\nEnd season", buttons = {{label = "Close", clickEvents = {"evt_hide_popup", "evt_restart"}}}})
        return
    end

    -- Check for match day
    local daysToFixture = daysToNextMatch(GLOBAL_DATE_PLACEHOLDER, matchDates)
    if daysToFixture == 0 then
        self:reset()
        self:animateDateSwipe(function()
            self:dateAnim()
            if callback then callback() end
        end)
        return
    end

    -- Continue advancing
    self:animateDateSwipe(function()
        self:advanceDateStep(callback)
    end)
end

function DateAdvancement:advanceDate(playMatchCallback)
    if matchday then
        playMatchCallback()
        return
    end
    if self.isAutoAdvancing then
        self:reset()
        self:dateAnim()
        playMatchCallback()
        return
    end
    self.isAutoAdvancing = true
    self.dateAdvanceCount = 0
    self:advanceDateStep(playMatchCallback)
end

function DateAdvancement:reset()
    if self.dateTimer then
        self.dateTimer:finalize()
        self.dateTimer = nil
    end
    self.isAutoAdvancing = false
    self.isAnimating = false
    self.transfersDoneForDate = {}
    self.lastTransferDate = nil
    self.dateAdvanceCount = 0
end

function DateAdvancement:finalize()
    if self.dateTimer then
        self.dateTimer:finalize()
        self.dateTimer = nil
    end
    self.im.Unsubscribe(BND_DATE1)
    self.im.Unsubscribe(BND_DATE2)
    self.im.Unsubscribe(BND_DATE3)
    self.im.Unsubscribe(BND_IS_DATE_SIM)
    self.im.Unsubscribe(BND_IS_NOT_DATE_SIM)
    for i = 1, 3 do
        self.im.Unsubscribe("bnd_date" .. i .. "Y")
    end
end

function DateAdvancement:update(elapsedTime)
    if self.dateTimer then
        self.dateTimer:update(elapsedTime)
    end
end

return DateAdvancement
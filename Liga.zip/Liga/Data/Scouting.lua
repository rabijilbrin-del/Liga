local Scouting = {}
local subobjnum = {2, 2, 1, 1}
local ScoutingParams = {
[1] = {
[1] = {"Any", "DEF", "MID", "ATT"},
[2] = {"Any", "GK", "RB", "LB", "CB", "RM", "LM", "CM", "CAM", "CDM", "CF", "LW", "RW", "RF", "LF", "ST"}
},
[2] = {
[1] = 17,
[2] = 50
},
[3] = {
[1] = {"Any", "Starter", "Wonderkid", "Veteran", "Sporadic"}
},
[4] = {
[1] = {"Any", "Dribbler", "Prolific", "Dueler", "Speedster", "Fox in the Box", "Poacher", "Playmaker", "Maestro", "Anchor", "Defensive minded"}
}
}

-- Define position groups
local positionGroups = {
    ["ATT"] = {["ST"] = true, ["CF"] = true, ["LF"] = true, ["RF"] = true, ["LW"] = true, ["RW"] = true, ["LM"] = true, ["RM"] = true},
    ["MID"] = {["CAM"] = true, ["CM"] = true, ["CDM"] = true},
    ["DEF"] = {["LB"] = true, ["RB"] = true, ["CB"] = true, ["LWB"] = true, ["RWB"] = true}
}

-- Define attribute conditions
local attributeConditions = {
    ["Dribbler"] = function(player) return player.stat1 >= 80 and player.stat4 >= 82 and player.position ~= "GK" end,
    ["Prolific"] = function(player) return player.stat1 >= 75 and player.stat2 >= 75 and player.stat3 >= 75 and player.position ~= "GK" end,
    ["Dueler"] = function(player) return player.stat5 >= 75 and player.stat6 >= 84 and player.position ~= "GK" end,
    ["Speedster"] = function(player) return player.stat1 >= 85 and player.position ~= "GK" end,
    ["Fox in the Box"] = function(player) return player.stat2 >= 83 and player.stat3 >= 80 and player.stat1 >= 75 and player.position ~= "GK" end,
    ["Poacher"] = function(player) return player.stat2 >= 85 and player.position ~= "GK" end,
    ["Playmaker"] = function(player) return player.stat3 >= 85 and player.stat4 >= 75 and player.position ~= "GK" end,
    ["Maestro"] = function(player) return player.stat3 >= 85 and player.position ~= "GK" end,
    ["Anchor"] = function(player) return player.stat3 >= 80 and player.stat5 >= 75 and player.stat6 >= 75 and player.position ~= "GK" end,
    ["Defensive minded"] = function(player) return player.stat5 >= 83 and player.stat6 >= 80 and player.position ~= "GK" end
}

-- Define status conditions
local statusConditions = {
    ["Starter"] = function(player) return (player.rating or 50) >= 75 end,
    ["Wonderkid"] = function(player) return GetPlayerAge(player.CARD_ID) < 23 and (player.rating or 50) >= 70 end,
    ["Veteran"] = function(player) return GetPlayerAge(player.CARD_ID) > 30 end,
    ["Sporadic"] = function(player) return (player.rating or 50) < 70 end
}

function Scouting:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  return o
end

function Scouting:decodeScoutConfig(sessionVars)
    local config = sessionVars.get("scoutParam") or {1, 1, 1, 1, 1, 1}
    local result = {}
    local minBase, maxBase = 17, 50
    local idx = 0

    local function resolve(par, sub, idxVal)
        if par == 2 then
            return tostring(minBase + (idxVal - 1))
        else
            local paramSet = ScoutingParams[par][sub]
            if type(paramSet) == "table" then
                return paramSet[idxVal] or "Any"
            else
                return tostring(paramSet)
            end
        end
    end

    for par = 1, 4 do
        for sub = 1, subobjnum[par] do
            idx = idx + 1
            local label
            if par == 1 and sub == 1 then
                label = "Role"
            elseif par == 1 and sub == 2 then
                label = "Position"
            elseif par == 2 and sub == 1 then
                label = "MinAge"
            elseif par == 2 and sub == 2 then
                label = "MaxAge"
            elseif par == 3 and sub == 1 then
                label = "Status"
            elseif par == 4 and sub == 1 then
                label = "Trait"
            else
                label = "Param" .. par .. "_" .. sub
            end
            result[label] = resolve(par, sub, config[idx])
        end
    end
    return result
end

function Scouting:getScoutedPlayers(sessionVars)
    local dateStr = sessionVars.get("currentDate") or "01/01/25"
    local _, month, _ = dateStr:match("(%d%d)/(%d%d)/(%d%d)")
    month = tonumber(month)

    local config = sessionVars.get("scoutParam") or {}
    if not config or #config == 0 then
        return {}
    end

    local params = self:decodeScoutConfig(sessionVars)
    local minAge = tonumber(params.MinAge) or 17
    local maxAge = tonumber(params.MaxAge) or 50
    local role = params.Role ~= "Any" and params.Role or nil
    local position = params.Position ~= "Any" and params.Position or nil
    local status = params.Status ~= "Any" and params.Status or nil
    local trait = params.Trait ~= "Any" and params.Trait or nil

    local scoutedPlayers = sessionVars.get("scoutedPlayers") or {}
    local TeamList = sessionVars.get("CareerModeTeams") or {}
    local currentTeamID = currentSelectedTeamID or 0
    local scouted = 0
    local THRESHOLD = 300

    for i = 1, #TeamList do
        local teamID = TeamList[i]
        if teamID and teamID ~= currentTeamID then
            local players = getCachedTeamPlayers(teamID) or {}
            for _, player in ipairs(players) do
                local cardID = player.CARD_ID
                if cardID and not scoutedPlayers[cardID] then
                    local age = GetPlayerAge(cardID) or 25
                    if age >= minAge and age <= maxAge then
                        local pos = player.position
                        local matchPos = not position or pos == position
                        local matchRole = not role or (positionGroups[role] and positionGroups[role][pos])

                        if matchPos and matchRole then
                            local matchStatus = not status or (statusConditions[status] and statusConditions[status](player))
                            if matchStatus then
                                local matchTrait = not trait or (attributeConditions[trait] and attributeConditions[trait](player))
                                if matchTrait then
                                    scoutedPlayers[cardID] = teamID
                                    scouted = scouted + 1                                  
                                end
                            end
                        end
                    end
                end
                
            end
        end
    end

    sessionVars.set("scoutedPlayers", scoutedPlayers)
    return scoutedPlayers
end

return Scouting
          

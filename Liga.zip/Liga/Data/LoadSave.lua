local LoadSave = {}
local Save, sessionVars, CareerModeLeagues = nil, nil

function LoadSave:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  Save = init.Save
  sessionVars = init.sessionVars
  CareerModeLeagues = init.CareerModeLeagues
  o.services = init.services
  return o
end

function LoadSave:loadSavedGame(step)
  sessionVars.set("currentSelectedTeamID", (Save.currentSelectedTeamID or currentSelectedTeamID))
  currentSelectedTeamID= sessionVars.get("currentSelectedTeamID")
  sessionVars.set("GLOBAL_DATE_PLACEHOLDER", (Save.GLOBAL_DATE_PLACEHOLDER or GLOBAL_DATE_PLACEHOLDER))
  sessionVars.set("PlayerGoals", (Save.playerGoals or {}))
  sessionVars.set("LeagueTeams", (Save.LeagueTeams or {}))
  sessionVars.set("transferCount", (Save.transferCount or 0))
  sessionVars.set("deadlineTime", (Save.deadlineTime or nil))
  sessionVars.set("sheetData", (Save.sheetData or nil))
  sessionVars.set("sheetIdx", (Save.sheetIdx or nil))
  sessionVars.set("redMatchCount", (Save.redMatchCount or {}))
  sessionVars.set("isSuspended", (Save.isSuspended or {}))
  sessionVars.set("loanListed", (Save.loanListed or {}))
  sessionVars.set("notListed", (Save.notListed or {}))
  sessionVars.set("transferListed", (Save.transferListed or {}))
  sessionVars.set("transferOffers", (Save.transferOffers or {}))
  sessionVars.set("currentUserLeagueID", (Save.currentLeagueID or getTeamLeague(currentSelectedTeamID)))
  sessionVars.set("GLOBAL_FUNDS", (Save.GLOBAL_FUNDS or GLOBAL_FUNDS))
  
  --load Matches
  local leagueMatchData = {}
  local matchData = {}
  local idx = 0
  for k, v in pairs (Save.matchData) do
    leagueMatchData[k] = v
    for i = 1, #v do
      idx = idx + 1
      matchData[idx] = v[i]
    end
  end
  sessionVars.set("MatchData", matchData)
  sessionVars.set("LeagueMatchData", leagueMatchData)

  --load Transfers
local transferHist = {}
if Save.transferHistory then
  transferHist = Save.transferHistory
  local count = #transferHist
  local cnt = Save.transferCount or 200
  local numToSkip = count > cnt and (count - cnt) or 0

  local latestIndex = {}
  for i = 1, count do
    latestIndex[transferHist[i].Player] = i
  end

  for i = 1, count do
    local record = transferHist[i]
    local isLoan = (record.isLoan == 1 or record.isLoan == 2)

    if latestIndex[record.Player] == i then
      transferPlayer(record.Player, record.oldTeam, record.newTeam, isLoan, record.isLoan)
      
      if isLoan then   
        local loanedPlayers = sessionVars.get("loanedPlayers") or {}
        loanedPlayers[record.Player] = {
          duration = record.isLoan,
          mainTeam = record.oldTeam,
          loanTeam = record.newTeam
        }
        sessionVars.set("loanedPlayers", loanedPlayers)  
      end 
    end

    if i <= numToSkip then
      transferredPlayers[record.Player] = nil
    end 
       
  end
end

  --load Squad Data
  if sessionVars.get("sheetData") and sessionVars.get("sheetData")[(sessionVars.get("sheetIdx") or 1)] then
    Save.currentPlayersID = sessionVars.get("sheetData")[(sessionVars.get("sheetIdx") or 1)].players
  end
  
  if Save.currentPlayersID and #Save.currentPlayersID > 11 then
    local squadPlayers = Save.currentPlayersID
    local TeamCachedData = sessionVars.get("TeamCachedData")
    self.services.SquadManagementService.SetCurrentPlayerLineup(0, currentSelectedTeamID, 0, 0, squadPlayers)
    local players = self.services.SquadManagementService.GetCurrentPlayerLineup(0, currentSelectedTeamID, 0)    
    TeamCachedData[currentSelectedTeamID].players = players  
    sessionVars.set("TeamCachedData", TeamCachedData)
    sessionVars.set("currentPlayersID", squadPlayers)
  end
  
  if Save.currentFormationID then
    self.services.TacticsService.SetFormation(0, currentSelectedTeamID, Save.currentFormationID)
    sessionVars.set("currentFormationID", Save.currentFormationID)
  end
  
  sessionVars.set("transferCount", (Save.transferCount or 0))
  
end

return LoadSave
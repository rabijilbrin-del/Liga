local sessionVars, NewsCenter, TeamStats = ...
local UCLTourney = {}

local UCL_LEAGUE_ID = 2236
local loc = nil

function UCLTourney:new(init)
    local o = init or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

--==================================================
-- HELPERS
--==================================================

local function safeGet(key, default)
    local v = sessionVars.get(key)
    if v == nil then return default end
    return v
end

local function toMMDDYY(dateStr)
    local y, m, d = dateStr:match("(%d+)-(%d+)-(%d+)")
    if not y then return nil end
    return string.format("%02d%02d%s", tonumber(m), tonumber(d), y:sub(3))
end

local function makeDate(y, m, d)
    return string.format("%04d-%02d-%02d", y, m, d)
end

local function getCurrentGameYear()
    local _, _, yy = GLOBAL_DATE_PLACEHOLDER:match("(%d%d)/(%d%d)/(%d%d)")
    return 2000 + tonumber(yy)
end

-- weekNum = 1..5
-- weekday = 2 Tuesday, 3 Wednesday
-- Lua wday: Sunday=1 Monday=2 Tuesday=3 Wednesday=4...
local function getWeekdayDate(year, month, weekNum, weekday)
    local target = weekday + 1

    local firstStamp = os.time({
        year = year,
        month = month,
        day = 1,
        hour = 12
    })

    local first = os.date("*t", firstStamp)
    local offset = (target - first.wday + 7) % 7
    local day = 1 + offset + ((weekNum - 1) * 7)

    local finalStamp = os.time({
        year = year,
        month = month,
        day = day,
        hour = 12
    })

    local dt = os.date("*t", finalStamp)
    return makeDate(dt.year, dt.month, dt.day)
end

local function pairKey(a, b)
    if a > b then a, b = b, a end
    return a .. "_" .. b
end

local function shuffle(t)
    for i = #t, 2, -1 do
        local j = math.random(i)
        t[i], t[j] = t[j], t[i]
    end
    return t
end

local function shuffleCopy(t)
    local c = {}
    for i = 1, #t do c[i] = t[i] end
    return shuffle(c)
end

local function knockoutWinner(m)
    local h = m.homeScore + (m.homePenScore or 0)
    local a = m.awayScore + (m.awayPenScore or 0)

    if h > a then return m.homeID end
    if a > h then return m.awayID end
end

--==================================================
-- MATCH INSERT
--==================================================

local function addMatch(homeID, awayID, dateStr, matchday, isKO, round)
    if not homeID or not awayID then return false end

    local matchData = safeGet("MatchData", {})
    local leagueMatchData = safeGet("LeagueMatchData", {})

    leagueMatchData[UCL_LEAGUE_ID] =
        leagueMatchData[UCL_LEAGUE_ID] or {}

    local convDate = toMMDDYY(dateStr)
    if not convDate then return false end

    for _, m in ipairs(leagueMatchData[UCL_LEAGUE_ID]) do
        if m.matchday == matchday and (
            (m.homeID == homeID and m.awayID == awayID) or
            (m.homeID == awayID and m.awayID == homeID)
        ) then
            return false
        end
    end

    local entry = {
        homeID = homeID,
        awayID = awayID,
        date = convDate,
        matchType = "Competition",
        matchday = matchday,
        homeScore = 0,
        awayScore = 0,
        played = false,
        leagueID = UCL_LEAGUE_ID,
        matchRound = round,
        isKnockout = isKO or false
    }

    table.insert(matchData, entry)
    table.insert(leagueMatchData[UCL_LEAGUE_ID], entry)

    sessionVars.set("MatchData", matchData)
    sessionVars.set("LeagueMatchData", leagueMatchData)

    return true
end

--==================================================
-- SWISS FIXTURE GENERATION
--==================================================

local function greedyMatch(shuffled, canPlayFn)
    local used = {}
    local result = {}

    for i = 1, #shuffled do
        local t1 = shuffled[i]

        if not used[t1] then
            used[t1] = true
            local found = false

            for j = i + 1, #shuffled do
                local t2 = shuffled[j]

                if not used[t2] and canPlayFn(t1, t2) then
                    used[t2] = true
                    result[#result + 1] = {
                        home = t1,
                        away = t2
                    }
                    found = true
                    break
                end
            end

            if not found then return nil end
        end
    end

    return result
end

local function generateSwissFixtures(teams, countryMap, playedPairs)
    local fixtures = {}

    local function canPlay(t1, t2)
        if playedPairs[pairKey(t1, t2)] then return false end

        if countryMap[t1] and countryMap[t2]
            and countryMap[t1] == countryMap[t2] then
            return false
        end

        return true
    end

    for md = 1, 8 do
        local chosen = nil

        for _ = 1, 3000 do
            chosen = greedyMatch(shuffleCopy(teams), canPlay)
            if chosen then break end
        end

        fixtures[md] = chosen

        for _, p in ipairs(chosen) do
            playedPairs[pairKey(p.home, p.away)] = true
        end
    end

    return fixtures
end

--==================================================
-- TABLE
--==================================================

local function calculateTable(matches, teams)
    local stats = {}

    for _, id in ipairs(teams) do
        stats[id] = {
            teamID = id,
            pts = 0,
            gs = 0,
            gc = 0
        }
    end

    for _, m in ipairs(matches) do
        if m.played then
            local h = stats[m.homeID]
            local a = stats[m.awayID]

            if h and a then
                h.gs = h.gs + m.homeScore
                h.gc = h.gc + m.awayScore
                a.gs = a.gs + m.awayScore
                a.gc = a.gc + m.homeScore

                if m.homeScore > m.awayScore then
                    h.pts = h.pts + 3
                elseif m.awayScore > m.homeScore then
                    a.pts = a.pts + 3
                else
                    h.pts = h.pts + 1
                    a.pts = a.pts + 1
                end
            end
        end
    end

    local ordered = {}
    for _, v in pairs(stats) do
        ordered[#ordered + 1] = v
    end

    table.sort(ordered, function(a, b)
        if a.pts ~= b.pts then return a.pts > b.pts end

        local gdA = a.gs - a.gc
        local gdB = b.gs - b.gc

        if gdA ~= gdB then return gdA > gdB end
        return a.gs > b.gs
    end)

    return ordered
end

local function matchdayExists(matches, md)
    for _, m in ipairs(matches) do
        if m.matchday == md then return true end
    end
end

local function isRoundComplete(matches, md)
    local total = 0
    local played = 0

    for _, m in ipairs(matches) do
        if m.matchday == md then
            total = total + 1
            if m.played then played = played + 1 end
        end
    end

    return total > 0 and total == played
end

--==================================================
-- GENERATE TOURNAMENT
--==================================================

function UCLTourney:generate(startYear, teams, api)
    math.randomseed(os.time())

    local leagueMatchData = safeGet("LeagueMatchData", {})
    leagueMatchData[UCL_LEAGUE_ID] = {}
    sessionVars.set("LeagueMatchData", leagueMatchData)

    local leagueTeams = safeGet("LeagueTeams", {})
    teams = teams or leagueTeams[UCL_LEAGUE_ID]

    if not teams or #teams == 0 then
        return false, "No teams supplied"
    end

    local cs = api("CountryService")
    local countryMap = {}

    for _, id in ipairs(teams) do
        local lid = cs.GetLeagueInfoByTeamId(id).id
        countryMap[id] =
            cs.GetCountryInfoByLeagueId(lid).id
    end

    local playedPairs = {}
    local fixtures =
        generateSwissFixtures(teams, countryMap, playedPairs)

    -- LEAGUE PHASE (Tue/Wed by week slot)
    local dates = {
        getWeekdayDate(startYear,     9, 3, 2), -- Sep week3 Tue
        getWeekdayDate(startYear,    10, 1, 3), -- Oct week1 Wed
        getWeekdayDate(startYear,    10, 4, 2), -- Oct week4 Tue
        getWeekdayDate(startYear,    11, 1, 3), -- Nov week1 Wed
        getWeekdayDate(startYear,    11, 4, 2), -- Nov week4 Tue
        getWeekdayDate(startYear,    12, 2, 3), -- Dec week2 Wed
        getWeekdayDate(startYear+1,   1, 3, 2), -- Jan week3 Tue
        getWeekdayDate(startYear+1,   1, 4, 3), -- Jan week4 Wed
    }

    for md = 1, 8 do
        for _, m in ipairs(fixtures[md]) do
            addMatch(m.home, m.away, dates[md], md, false)
        end
    end

    leagueTeams[UCL_LEAGUE_ID] = teams
    sessionVars.set("LeagueTeams", leagueTeams)

    return true
end

--==================================================
-- GENERATE NEXT ROUND
--==================================================

function UCLTourney:generateNextRound(currentMatchday)
    local allMatches = safeGet("LeagueMatchData", {})
    local matches = allMatches[UCL_LEAGUE_ID] or {}

    if matchdayExists(matches, currentMatchday + 1) then return end

    local leagueTeams = safeGet("LeagueTeams", {})
    local teams = leagueTeams[UCL_LEAGUE_ID]
    if not teams then return end

    local _, _, yy = GLOBAL_DATE_PLACEHOLDER:match("(%d%d)/(%d%d)/(%d%d)")
    local year = 2000 + tonumber(yy)

    -- After January, knockouts are same calendar year
    if currentMatchday <= 8 then
        if year < 2001 then return end
    end

    --======================
    -- PLAYOFF ROUND
    --======================
    if currentMatchday == 8 then
        local rank = calculateTable(matches, teams)

        local playoff = {}
        for i = 9, 24 do
            playoff[#playoff + 1] = rank[i].teamID
        end

        shuffle(playoff)

        local d1 = getWeekdayDate(year, 2, 2, 2)
        local d2 = getWeekdayDate(year, 2, 2, 3)

        for i = 1, 8 do
            local useDate = (i <= 4) and d1 or d2
            addMatch(
                playoff[i],
                playoff[17 - i],
                useDate,
                9,
                true,
                "RO32"
            )
        end
        return
    end

    --======================
    -- ROUND OF 16
    --======================
    if currentMatchday == 9 then
        local winners = {}

        for _, m in ipairs(matches) do
            if m.matchday == 9 and m.played then
                winners[#winners + 1] = knockoutWinner(m)
            end
        end

        if #winners < 8 then return end

        local rank = calculateTable(matches, teams)
        local top8 = {}

        for i = 1, 8 do
            top8[i] = rank[i].teamID
        end

        local d1 = getWeekdayDate(year, 3, 1, 2)
        local d2 = getWeekdayDate(year, 3, 1, 3)

        for i = 1, 8 do
            local useDate = (i <= 4) and d1 or d2
            addMatch(
                winners[i],
                top8[i],
                useDate,
                10,
                true,
                "RO16"
            )
        end
        return
    end

    --======================
    -- QUARTER FINALS
    --======================
    if currentMatchday == 10 then
        local w = {}

        for _, m in ipairs(matches) do
            if m.matchday == 10 and m.played then
                w[#w + 1] = knockoutWinner(m)
            end
        end

        if #w < 8 then return end

        local d1 = getWeekdayDate(year, 4, 2, 2)
        local d2 = getWeekdayDate(year, 4, 2, 3)

        for i = 1, 4 do
            addMatch(
                w[i * 2 - 1],
                w[i * 2],
                (i <= 2) and d1 or d2,
                11,
                true,
                "Quarter Finals"
            )
        end
        return
    end

    --======================
    -- SEMI FINALS
    --======================
    if currentMatchday == 11 then
        local w = {}

        for _, m in ipairs(matches) do
            if m.matchday == 11 and m.played then
                w[#w + 1] = knockoutWinner(m)
            end
        end

        if #w < 4 then return end

        addMatch(
            w[1], w[2],
            getWeekdayDate(year, 4, 4, 2),
            12, true, "Semi Finals"
        )

        addMatch(
            w[3], w[4],
            getWeekdayDate(year, 4, 4, 3),
            12, true, "Semi Finals"
        )

        return
    end

    --======================
    -- FINAL
    --======================
    if currentMatchday == 12 then
        local w = {}

        for _, m in ipairs(matches) do
            if m.matchday == 12 and m.played then
                w[#w + 1] = knockoutWinner(m)
            end
        end

        if #w < 2 then return end

        addMatch(
            w[1], w[2],
            getWeekdayDate(year, 5, 5, 2),
            13, true, "Final"
        )
    end
end

--==================================================
-- PROCESS MATCH
--==================================================

function UCLTourney:processMatch(match)
    if sessionVars.get("InTourneyMode") then
        if match.matchday == 13 then
            sessionVars.set("Champion", knockoutWinner(match))
            sessionVars.set("EndTourney", true)

        elseif match.matchday == 8 then
            if TeamStats:getTeamPosition(
                UCL_LEAGUE_ID,
                currentSelectedTeamID
            ) >= 25 then
                sessionVars.set("EndTourney", true)
            end

        elseif match.isKnockout and
            (match.homeID == currentSelectedTeamID
            or match.awayID == currentSelectedTeamID) then

            if knockoutWinner(match) ~= currentSelectedTeamID then
                sessionVars.set("EndTourney", true)
            end
        end
    end

    local allMatches = safeGet("LeagueMatchData", {})
    local matches = allMatches[UCL_LEAGUE_ID] or {}

    if isRoundComplete(matches, match.matchday) then
        self:generateNextRound(match.matchday)
    end
end

function UCLTourney:setLoc(locparam)
    loc = locparam
end

function UCLTourney:getLoc()
    return loc
end

return UCLTourney
local Timer = ...
local DateAnimation = {}

function DateAnimation:new(init)
    local o = init or {}
    setmetatable(o, self)
    self.__index = self
    o.im = init.im -- Interface manager for publishing bindings
    o.publishDate1 = init.publishDate1 -- Callback to update bnd_date1
    o.publishDate2 = init.publishDate2 -- Callback to update bnd_date2
    o.publishDate3 = init.publishDate3 -- Callback to update bnd_date3
    o.dateYPositions = {0, -50, -100} -- Y positions for bnd_date1Y, bnd_date2Y, bnd_date3Y
    o.isAnimating = false -- Tracks animation state
    o.dateTimer = nil -- Current animation timer

    -- Binding names
    o.BND_DATE1 = init.BND_DATE1 or "bnd_date1"
    o.BND_DATE2 = init.BND_DATE2 or "bnd_date2"
    o.BND_DATE3 = init.BND_DATE3 or "bnd_date3"
    o.BND_IS_DATE_SIM = init.BND_IS_DATE_SIM or "bnd_isDateSim"
    o.BND_IS_NOT_DATE_SIM = init.BND_IS_NOT_DATE_SIM or "bnd_isNotDateSim"

    -- Subscribe to binding updates
    for i = 1, 3 do
        o.im.Subscribe("bnd_date" .. i .. "Y", function() o:updateBindings() end)
    end
    o.im.Subscribe(o.BND_IS_DATE_SIM, function() o:updateBindings() end)
    o.im.Subscribe(o.BND_IS_NOT_DATE_SIM, function() o:updateBindings() end)

    o:updateBindings() -- Initial publish
    return o
end

function DateAnimation:updateBindings()
    for i = 1, 3 do
        self.im.Publish("bnd_date" .. i .. "Y", self.dateYPositions[i])
    end
    self.im.Publish(self.BND_IS_DATE_SIM, self.isAnimating)
    self.im.Publish(self.BND_IS_NOT_DATE_SIM, not self.isAnimating)
end

function DateAnimation:animateSwipe(callback)
    if self.dateTimer then
        self.dateTimer:finalize()
        self.dateTimer = nil
    end
    self.isAnimating = true
    self:updateBindings() -- Set bnd_isDateSim=true

    local startY = {50, -50, -100} -- date1 starts below bottom
    local endY = {-100, 0, -50} -- date1 to date3, date2 to date1, date3 to date2
    local duration = 0.1
    local stepInterval = 0.025
    local steps = math.floor(duration / stepInterval)
    local stepSizes = {
        (endY[1] - startY[1]) / steps,
        (endY[2] - startY[2]) / steps,
        (endY[3] - startY[3]) / steps
    }

    local function animateStep(step)
        if not self.isAnimating then
            self.dateTimer = nil
            self:updateBindings()
            return
        end

        if step > steps then
            self.dateYPositions = {0, -50, -100}
            self.publishDate1()
            self.publishDate2()
            self.publishDate3()
            self.dateTimer = nil
            self.isAnimating = false
            self:updateBindings() -- Set bnd_isDateSim=false
            if callback then callback() end
            return
        end

        self.dateYPositions = {
            startY[1] + stepSizes[1] * step,
            startY[2] + stepSizes[2] * step,
            startY[3] + stepSizes[3] * step
        }
        self:updateBindings()

        self.dateTimer = Timer:new({
            id = "dateTimer_" .. step,
            interval = stepInterval,
            reps = 1,
            onTimerComplete = function()
                animateStep(step + 1)
            end
        })
        self.dateTimer:start()
    end

    self.dateTimer = Timer:new({
        id = "dateTimer_delay",
        interval = 1.0,
        reps = 1,
        onTimerComplete = function()
            if self.isAnimating then
                animateStep(1)
            else
                self.dateTimer = nil
                self:updateBindings()
            end
        end
    })
    self.dateTimer:start()
end

function DateAnimation:finalize()
    if self.dateTimer then
        self.dateTimer:finalize()
        self.dateTimer = nil
    end
    self.isAnimating = false
    for i = 1, 3 do
        self.im.Unsubscribe("bnd_date" .. i .. "Y")
    end
    self.im.Unsubscribe(self.BND_IS_DATE_SIM)
    self.im.Unsubscribe(self.BND_IS_NOT_DATE_SIM)
    self:updateBindings()
end

return DateAnimation
-- TeamStats.lua
local sessionVars = ...
local TeamStats = {}
TeamStats.__index = TeamStats
local loc = nil

function TeamStats:new(init)
    local o = init or {}
    setmetatable(o, self)
    loc = loc or init.loc
    return o
end

-- Private: calculate stats for a team list
local function _calculateGroupStats(matchData, teamList)
    local teamStats = {}
    for _, id in ipairs(teamList) do
        teamStats[id] = {
            wins = 0, draws = 0, losses = 0,
            goalsScored = 0, goalsConceded = 0,
            points = 0, matchesPlayed = 0,
            teamName = loc.LocalizeString("TeamName_Abbr15_" .. id) or ("Team" .. id)
        }
    end
    for _, match in ipairs(matchData) do
        local h, a = match.homeID, match.awayID
        local hs, as = match.homeScore or 0, match.awayScore or 0
        local played = match.played
        if played and teamStats[h] and teamStats[a] and not (match.isKnockout) then
            teamStats[h].matchesPlayed = teamStats[h].matchesPlayed + 1
            teamStats[a].matchesPlayed = teamStats[a].matchesPlayed + 1
            teamStats[h].goalsScored = teamStats[h].goalsScored + hs
            teamStats[h].goalsConceded = teamStats[h].goalsConceded + as
            teamStats[a].goalsScored = teamStats[a].goalsScored + as
            teamStats[a].goalsConceded = teamStats[a].goalsConceded + hs
            if hs > as then
                teamStats[h].wins = teamStats[h].wins + 1
                teamStats[h].points = teamStats[h].points + 3
                teamStats[a].losses = teamStats[a].losses + 1
            elseif hs < as then
                teamStats[a].wins = teamStats[a].wins + 1
                teamStats[a].points = teamStats[a].points + 3
                teamStats[h].losses = teamStats[h].losses + 1
            else
                teamStats[h].draws = teamStats[h].draws + 1
                teamStats[a].draws = teamStats[a].draws + 1
                teamStats[h].points = teamStats[h].points + 1
                teamStats[a].points = teamStats[a].points + 1
            end
        end
    end
    return teamStats
end

-- Private: find group for any teamID (WC only)
local function _findGroup(leagueID, teamID)
    if leagueID ~= 1000 then return nil end
    local groups = {"A","B","C","D","E","F","G","H","I","J","K","L"}
    for _, g in ipairs(groups) do
        local list = sessionVars.get("LeagueTeams")[leagueID][g] or {}
        for _, id in ipairs(list) do
            if id == teamID then return g end
        end
    end
    return nil
end

-- Private: get team list for context team (uses currentSelectedTeamID if no teamID given)
local function _getContextTeamList(leagueID, teamID)
    teamID = teamID or currentSelectedTeamID
    if not teamID then return {} end
    if leagueID == 1000 then
        local group = _findGroup(leagueID, teamID)
        return group and (sessionVars.get("LeagueTeams")[leagueID][group] or {}) or {}
    else
        return sessionVars.get("LeagueTeams")[leagueID] or {}
    end
end

-- getTeamStats: works with any teamID
function TeamStats:getTeamStats(leagueID, teamID)
    local matchData = (sessionVars.get("LeagueMatchData") or {})[leagueID] or {}
    local teamList = _getContextTeamList(leagueID, teamID)
    if #teamList == 0 then return nil end
    local teamStats = _calculateGroupStats(matchData, teamList)
    if not teamStats[teamID] then return nil end

    local sorted = {}
    for _, id in ipairs(teamList) do
        local s = teamStats[id]
        table.insert(sorted, {
            teamID = id,
            points = s.points,
            gd = s.goalsScored - s.goalsConceded,
            name = s.teamName
        })
    end
    table.sort(sorted, function(a,b)
        if a.points ~= b.points then return a.points > b.points end
        if a.gd ~= b.gd then return a.gd > b.gd end
        return a.name < b.name
    end)

    local pos = 0
    for i, t in ipairs(sorted) do
        if t.teamID == teamID then pos = i; break end
    end

    local s = teamStats[teamID]
    return {
        position = pos,
        teamName = s.teamName,
        matchesPlayed = s.matchesPlayed,
        wins = s.wins, draws = s.draws, losses = s.losses,
        goalsScored = s.goalsScored,
        goalsConceded = s.goalsConceded,
        goalDifference = s.goalsScored - s.goalsConceded,
        points = s.points
    }
end

function TeamStats:getTeamPosition(leagueID, teamID)
    local stats = self:getTeamStats(leagueID, teamID)
    return stats and stats.position or 0
end

-- getTeamStatByPosition & publishStats now use currentSelectedTeamID as context (no params needed)
function TeamStats:getTeamStatByPosition(position, leagueID)
    leagueID = leagueID or sessionVars.get("currentUserLeagueID")
    local matchData = (sessionVars.get("LeagueMatchData") or {})[leagueID] or {}
    local teamList = _getContextTeamList(leagueID)  -- uses currentSelectedTeamID
    if #teamList == 0 or position < 1 or position > #teamList then return nil, nil end

    local teamStats = _calculateGroupStats(matchData, teamList)
    local sorted = {}
    for _, id in ipairs(teamList) do
        local s = teamStats[id]
        table.insert(sorted, {
            teamID = id,
            points = s.points,
            gd = s.goalsScored - s.goalsConceded,
            name = s.teamName
        })
    end
    table.sort(sorted, function(a,b)
        if a.points ~= b.points then return a.points > b.points end
        if a.gd ~= b.gd then return a.gd > b.gd end
        return a.name < b.name
    end)

    local t = sorted[position]
    return t and t.teamID or nil, t and t.points or nil
end

function TeamStats:publishStats(publish, name, count, leagueID)
    leagueID = leagueID or sessionVars.get("currentUserLeagueID")
    for i = 1, count or 4 do
        local id, pts = self:getTeamStatByPosition(i, leagueID)
        if id then
            if name == "objname" then publish(name..i, loc.LocalizeString("TeamName_Abbr15_" .. id))
            elseif name == "objvalue" then publish(name..i, pts or 0)
            elseif name == "objimg" then publish(name..i, {name = "$Crest", id = id}) end
        end
    end
end

-- NEW: full group standings (sorted table) using current context
function TeamStats:getGroupStandings(leagueID)
    leagueID = leagueID or sessionVars.get("currentUserLeagueID")
    local matchData = (sessionVars.get("LeagueMatchData") or {})[leagueID] or {}
    local teamList = _getContextTeamList(leagueID)
    if #teamList == 0 then return {} end

    local teamStats = _calculateGroupStats(matchData, teamList)
    local sorted = {}
    for _, id in ipairs(teamList) do
        local s = teamStats[id]
        table.insert(sorted, {
            teamID = id,
            teamName = s.teamName,
            position = 0,  -- will fill later
            matchesPlayed = s.matchesPlayed,
            wins = s.wins,
            draws = s.draws,
            losses = s.losses,
            goalsScored = s.goalsScored,
            goalsConceded = s.goalsConceded,
            goalDifference = s.goalsScored - s.goalsConceded,
            points = s.points
        })
    end
    table.sort(sorted, function(a,b)
        if a.points ~= b.points then return a.points > b.points end
        if a.goalDifference ~= b.goalDifference then return a.goalDifference > b.goalDifference end
        return a.teamName < b.teamName
    end)
    for i, entry in ipairs(sorted) do entry.position = i end
    return sorted
end

return TeamStats
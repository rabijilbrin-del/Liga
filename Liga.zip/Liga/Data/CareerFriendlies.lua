-- CareerFriendlies.lua
local sessionVars = ...
local CareerFriendlies = {}
local FRIENDLYID = 175
CareerFriendlies.__index = CareerFriendlies

function CareerFriendlies:new()
    return setmetatable({}, self)
end

local function shuffle(tbl)
    for i = #tbl, 2, -1 do
        local j = math.random(i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
    return tbl
end

local function toMMDDYY(dateStr)
    local y, m, d = dateStr:match("(%d+)-(%d+)-(%d+)")
    if not y then return nil end
    return string.format("%02d%02d%s", tonumber(m), tonumber(d), y:sub(3))
end

local function addMatch(homeID, awayID, dateStr, leagueID)
    local matchData = sessionVars.get("MatchData") or {}
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    leagueMatchData[leagueID] = leagueMatchData[leagueID] or {}

    local convDate = toMMDDYY(dateStr)
    if not convDate then return end

    local entry = {
        homeID = homeID,
        awayID = awayID,
        date = convDate,
        matchType = "Friendly",
        matchday = 0,
        homeScore = 0,
        awayScore = 0,
        played = false,
        leagueID = leagueID
    }

    table.insert(matchData, entry)
    table.insert(leagueMatchData[leagueID], entry)

    sessionVars.set("MatchData", matchData)
    sessionVars.set("LeagueMatchData", leagueMatchData)
end

-- Proper rotation (no chaos)
local function rotate(others)
    local last = table.remove(others, #others)
    table.insert(others, 1, last)
end

function CareerFriendlies:generate(teams, leagueID)
    assert(#teams == 8, "Exactly 8 teams required")
    math.randomseed(os.time() + math.random(1, 100000))

    local schedule = {}

    local fixed = teams[1]
    local others = {}
    for i = 2, 8 do table.insert(others, teams[i]) end

    -- Generate 7 clean rounds
    for round = 1, 7 do
        local roundMatches = {}

        -- fixed team always plays
        table.insert(roundMatches, {home = fixed, away = others[1]})

        -- proper circle method pairings
        for i = 1, 3 do
            local a = others[i + 1]
            local b = others[8 - i]
            table.insert(roundMatches, {home = a, away = b})
        end

        schedule[round] = roundMatches

        -- rotate remaining teams
        rotate(others)
    end

    -- Shuffle rounds to randomize dates
    shuffle(schedule)

    -- Friendly window Jul 5 – Aug 3 (29 days)
    local startDate = os.time({year = 2025, month = 7, day = 5, hour = 12})
    local endDate   = startDate + 29 * 86400

    local lastPlayed = {}
    for _, t in ipairs(teams) do lastPlayed[t] = -999999 end

    local current = startDate

    -- Assign dates to each round
    for _, roundMatches in ipairs(schedule) do
        shuffle(roundMatches)

        -- ensure 4-day spacing for each team
        while true do
            local canPlay = true
            for _, m in ipairs(roundMatches) do
                local nextAllowed = math.max(lastPlayed[m.home], lastPlayed[m.away]) + 4 * 86400
                if current < nextAllowed then
                    canPlay = false
                    break
                end
            end
            if canPlay and current <= endDate then break end

            current = current + 86400
            if current > endDate then return end
        end

        local dateStr = os.date("%Y-%m-%d", current)

        -- add matches
        for _, m in ipairs(roundMatches) do
            addMatch(m.home, m.away, dateStr, leagueID)
            lastPlayed[m.home] = current
            lastPlayed[m.away] = current
        end

        -- spacing before next round
        current = current + (current + 4 * 86400 <= endDate and 4 * 86400 or 86400)
    end
end

function CareerFriendlies:haveAllFriendliesBeenPlayed(leagueID)
    leagueID = leagueID or FRIENDLYID
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    local friendlies = leagueMatchData[leagueID] or {}

    -- If no friendlies exist for this league, return true (nothing to play)
    if #friendlies == 0 then
        return true
    end

    -- Check if ALL matches in this league's friendlies have played = true
    for _, match in ipairs(friendlies) do
        if match.matchType == "Friendly" and not match.played then
            return false
        end
    end

    return true
end

function CareerFriendlies:isLastFriendlyMatchdayPlayed(leagueID)
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    local friendlies = leagueMatchData[leagueID] or {}

    if #friendlies == 0 then
        return true
    end

    -- Find the latest date among friendlies
    local latestDate = 0
    for _, match in ipairs(friendlies) do
        if match.matchType == "Friendly" then
            local matchTime = os.time({year = "20" .. match.date:sub(5,6), month = tonumber(match.date:sub(1,2)), day = tonumber(match.date:sub(3,4))})
            if matchTime > latestDate then
                latestDate = matchTime
            end
        end
    end

    if latestDate == 0 then return true end

    -- Check if all matches on that latest date are played
    for _, match in ipairs(friendlies) do
        if match.matchType == "Friendly" then
            local matchTime = os.time({year = "20" .. match.date:sub(5,6), month = tonumber(match.date:sub(1,2)), day = tonumber(match.date:sub(3,4))})
            if matchTime == latestDate and not match.played then
                return false
            end
        end
    end

    return true
end

return CareerFriendlies
local sessionVars, fixtures, CareerModeLeagues, TeamStats, TeamData, Timer = ...
local SeasonInit = {}
SeasonInit.__index = SeasonInit

function SeasonInit:new(init)
  local o = init or {}
  setmetatable(o, self)
  o.fixtures = fixtures:new({api = o.api, save = o.save})
  o.nav = init.nav
  o.TeamData = TeamData:new({api = o.api})
  o.brain = init.brain:new()
  o.Timer = init.Timer
  o.overlayTimer = nil
  o.initTimer = nil
  o.loader = nil
  
  return o
end

function SeasonInit:setNewSeason(callback, cls)
  self.nav.Event(nil, "evt_show_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/LoadingScreen.vvm", data = {getInstance = function(inst) self.loader = inst
    self:initSeason()
    callback(cls)
  end}})
  self.nav.Event(nil, "evt_hide_overlay")
  
end


function SeasonInit:initSeason()
    --self.loader.im.Publish("bnd_progress", 20)
    local allTeams = sessionVars.get("CareerModeTeams")
    -- Capture champions from standings before relegation/promotion reshuffles leagues
    local lastSeasonChampions = self.brain:captureChampions(TeamStats)
    self:cumulateTeamsByStats()
    self:handleRelegationAndPromotion()
    sessionVars.set("currentUserLeagueID", getTeamLeague(currentSelectedTeamID))
    sessionVars.set("MatchData", {})
    sessionVars.set("LeagueMatchData", {})
    sessionVars.set("PlayerGoals", {})
    revertLoansByDuration(1)
    revertLoansByDuration(2)
    transferredPlayers = {}
    self.fixtures:resetMatchData()
    --self.loader.im.Publish("bnd_progress", 140)
    local day, month, year = GLOBAL_DATE_PLACEHOLDER:match("(%d%d)/(%d%d)/(%d%d)")
    day, month, year = tonumber(day), tonumber(month), tonumber(year)
    local startYear = 2000 + year
    local leagueTeams = sessionVars.get("LeagueTeams")
    local userLeagueID = sessionVars.get("currentUserLeagueID")
      for i = 1, #CareerModeLeagues do
        local leagueID = CareerModeLeagues[i]
        local teams = leagueTeams[leagueID]
        self.TeamData:updateTeamsStrength(leagueID)
        if leagueID ~= userLeagueID then
            self.fixtures:generateSchedule(teams, "AI", startYear, leagueID)
        else
            self.fixtures:generateSchedule(teams, "automatic", startYear, leagueID)          
        end
      end
    --self.loader.im.Publish("bnd_progress", 290)
    local ctx = self.brain:buildFinanceContext(lastSeasonChampions)
    GLOBAL_FUNDS = self.brain:calculateTeamFunds(nil, allTeams, true, ctx)
    --self.loader.im.Publish("bnd_progress", 320)
    --self.nav.Event(nil, "evt_hide_overlay")
end  

function SeasonInit:handleRelegationAndPromotion()
    local leaguebucket = {
        {13, 14, 60},
        {16, 17},
        {19, 20},
        {31, 32},
        {53, 54},
        {39, 2221},
        {2235, 2254}
    }

    local leagueTeams = sessionVars.get("LeagueTeams")
    local insert = table.insert
    local remove = table.remove

    for i = 1, #leaguebucket do
        local currentLeagueBuck = leaguebucket[i]
        -- Collect moves to be applied after processing all leagues in the bucket
        local moves = {
            relegated = {}, -- {leagueID = {teamID, ...}, ...}
            promoted = {}   -- {leagueID = {teamID, ...}, ...}
        }
        
        -- Step 1: Identify teams to be promoted/relegated without modifying leagueTeams
        for j = 1, #currentLeagueBuck do
            local currentLeague = currentLeagueBuck[j]
            local nextLeague = j < #currentLeagueBuck and currentLeagueBuck[j + 1] or nil
            local prevLeague = j > 1 and currentLeagueBuck[j - 1] or nil
            local currentTeams = leagueTeams[currentLeague]
            local leagueSize = #currentTeams
            
            -- Handle relegation (identify bottom 3 teams)
            if nextLeague then
                local relegatedTeams = {}
                for t = 1, leagueSize do
                    local team = currentTeams[t]
                    local position = TeamStats:getTeamPosition(currentLeague, team)
                    if position >= (leagueSize - 2) then -- Bottom 3 teams
                        insert(relegatedTeams, team)
                    end
                end
                moves.relegated[currentLeague] = relegatedTeams
            end
            
            -- Handle promotion (identify top 3 teams)
            if prevLeague then
                local promotedTeams = {}
                for t = 1, leagueSize do
                    local team = currentTeams[t]
                    local position = TeamStats:getTeamPosition(currentLeague, team)
                    if position <= 3 then -- Top 3 teams
                        insert(promotedTeams, team)
                    end
                end
                moves.promoted[currentLeague] = promotedTeams
            end
        end
        
        -- Step 2: Apply all moves after collecting them
        for j = 1, #currentLeagueBuck do
            local currentLeague = currentLeagueBuck[j]
            local nextLeague = j < #currentLeagueBuck and currentLeagueBuck[j + 1] or nil
            local prevLeague = j > 1 and currentLeagueBuck[j - 1] or nil
            local currentTeams = leagueTeams[currentLeague]
            
            -- Apply relegation moves (to next league)
            if nextLeague and moves.relegated[currentLeague] then
                local nextLeagueTeams = leagueTeams[nextLeague]
                for _, team in ipairs(moves.relegated[currentLeague]) do
                    insert(nextLeagueTeams, team)
                    updateTeamLeague(nextLeague, team)
                    -- Remove team from current league
                    for k = #currentTeams, 1, -1 do
                        if currentTeams[k] == team then
                            remove(currentTeams, k)
                            break
                        end
                    end
                end
            end
            
            -- Apply promotion moves (to previous league)
            if prevLeague and moves.promoted[currentLeague] then
                local prevLeagueTeams = leagueTeams[prevLeague]
                for _, team in ipairs(moves.promoted[currentLeague]) do
                    insert(prevLeagueTeams, team)
                    updateTeamLeague(prevLeague, team)
                    -- Remove team from current league
                    for k = #currentTeams, 1, -1 do
                        if currentTeams[k] == team then
                            remove(currentTeams, k)
                            break
                        end
                    end
                end
            end
        end
    end
    
    -- Update sessionVars with modified league teams
    sessionVars.set("LeagueTeams", leagueTeams)
end

function SeasonInit:cumulateTeamsByStats()
  local UCLTeams = {}
  local UCLID = 2236
  local leagueTeams = sessionVars.get("LeagueTeams")
  local constantTeams = {191, 819, 417, 101059}
  local leaguesConfig = { [13] = 5, [16] = 5, [19] = 5, [31] = 5, [53] = 5, [4] = 2, [10] = 2, [308] = 1, [39] = 1, [68] = 1}
  local teamIdx = 0
  
  for k, v in pairs(leaguesConfig) do
    for i = 1, v do
      local id, pts = TeamStats:getTeamStatByPosition(i, k)
      teamIdx = teamIdx + 1
      UCLTeams[teamIdx] = id
    end
  end
  
  local neededTeams = 36 - teamIdx
  
  for i = 1, neededTeams do
    UCLTeams[teamIdx + i] = constantTeams[i]
  end
  
  leagueTeams[UCLID] = UCLTeams 
  sessionVars.set("LeagueTeams", leagueTeams)
end

return SeasonInit
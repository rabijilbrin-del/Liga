local sessionVars = ...
local Date = {}
local DAYS_IN_MONTH = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}

function Date:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.haltAdvance = init.haltAdvance
  o.Modes = init.Modes
  o.api = init.api
  return o
end

function Date:advanceDate()
    local day, month, year = GLOBAL_DATE_PLACEHOLDER:match("(%d%d)/(%d%d)/(%d%d)")
    day, month, year = tonumber(day), tonumber(month), tonumber(year)
    local WCYear = year % 4 == 2
        day = day + 1
        if day > self:getDaysInMonth(month, year) then
            day = 1
            month = month + 1
            if month > 12 then
                month = 1
                year = year + 1
        end
    end
    local Syear = year + 2000
    
    if sessionVars.get("EndTourney") and not(displayMatchdayFixtures) then
      self.haltAdvance()
    end
    
  if sessionVars.get("InCareerMode") then
    if day == 1 and month == 1 then
      revertLoansByDuration(1)
    elseif day == 1 and (month == 2 or month == 9) then
      sessionVars.set("transferOffers", {})
      sessionVars.set("transferCount", 0)
    end
    
  
    if (day == 2 and month == 7) and not WCYear then
      --self.haltAdvance()
      --self.Modes:initializeMode("Friendlies")
    elseif (day == 5 and month == 6) and WCYear then
      --self.Modes:initializeMode("WC")
    elseif (day == 2 and month == 9) then
     local teams = { 241,243,481,461,483,240,1,5,9,10,11,18,69,65,66,219,73,32,22,21,34,112172,1831,175,38,39,110374,44,45,46,47,48,52,245,1906,246 }
      self.Modes:initializeMode("UCL", Syear, (sessionVars.get("LeagueTeams")[2236]) or teams, self.api)
    end 
  end

    local newDate = string.format("%02d/%02d/%02d", day, month, year)
    if GLOBAL_DATE_PLACEHOLDER ~= newDate then
        GLOBAL_DATE_PLACEHOLDER = newDate
        print("New Date: " .. newDate)
    end
end

-- Utility function to check if a year is a leap year
function Date:isLeapYear(year)
    return year % 4 == 0 and (year % 100 ~= 0 or year % 400 == 0)
end

-- Utility function to get days in a given month
function Date:getDaysInMonth(month, year)
    if month == 2 and self:isLeapYear(year) then
        return 29
    end
    return DAYS_IN_MONTH[month]
end

-- Utility function to validate a date (DD/MM/YY)
function Date:isValidDate(day, month, year)
    if not (day and month and year) then return false end
    if month < 1 or month > 12 then return false end
    local maxDays = self:getDaysInMonth(month, year)
    return day >= 1 and day <= maxDays
end

-- Utility function to validate a match date (mmddyy)
function Date:isValidMatchDateYY(dateStr)
    if not dateStr or not dateStr:match("^%d%d%d%d%d%d$") then return false end
    local month, day, year = dateStr:match("^(%d%d)(%d%d)(%d%d)$")
    month, day, year = tonumber(month), tonumber(day), tonumber(year)
    if not (month and day and year) then return false end
    if month < 1 or month > 12 or day < 1 or year < 0 or year > 99 then return false end
    local maxDays = self:getDaysInMonth(month, year)
    return day <= maxDays
end

function Date:isDeadline()
  if not sessionVars.get("InCareerMode") then
    return false
  end
  local day, month, year = GLOBAL_DATE_PLACEHOLDER:match("(%d%d)/(%d%d)/(%d%d)")
  day, month, year = tonumber(day), tonumber(month), tonumber(year)
  if (day == 31 and month == 8) or (day == 31 and month == 1) then
    return true
  end
 return false
end

function Date:isSeasonEnd()
  local day, month, year = GLOBAL_DATE_PLACEHOLDER:match("(%d%d)/(%d%d)/(%d%d)")
  day, month, year = tonumber(day), tonumber(month), tonumber(year)
  local WCYear = year % 4 == 2
  if (day == 30 and month == 6) and not WCYear then
    return true
  elseif WCYear and (day == 25 and month == 7) then
    return true
  end
 return false
end

function Date:IsTransferWindowOpen()
  if not sessionVars.get("InCareerMode") then
    return false
  end
  
  local day, month, year = GLOBAL_DATE_PLACEHOLDER:match("(%d%d)/(%d%d)/(%d%d)")
  day, month, year = tonumber(day), tonumber(month), tonumber(year)
  if month == 8 or month == 1 then
    return true
  end
 return false
end

return Date
local Utils = {}

-- @formats playerNames like A. Sanchez to Sanchez only
function Utils.shortenPlayerName(name)
  if not name or type(name) ~= "string" then
    return nil
  end
  local dotIndex = name:find("%. ")
  if dotIndex then
    return name:sub(dotIndex + 2)
  end
  local spaceIndex = name:find(" ")
  if spaceIndex then
    return name:sub(spaceIndex + 1)
  end
  return name
end

function Utils.shortenString(str, maxLength)
  if type(str) ~= "string" then
    return str
  end

  maxLength = maxLength or 33
  if #str > maxLength then
    return str:sub(1, maxLength) .. "..."
  end

  return str
end

function Utils.formatString(sentence, maxWordsPerLine)
    if not sentence or sentence == "" then return "" end
    local words = {}
    local lineLength = 0
    for word in sentence:gmatch("%S+") do
        if lineLength == 0 then
            table.insert(words, word)
            lineLength = #word
        elseif lineLength + 1 + #word <= maxWordsPerLine then
            table.insert(words, " ")
            table.insert(words, word)
            lineLength = lineLength + 1 + #word
        else
            table.insert(words, "\n")
            table.insert(words, word)
            lineLength = #word
        end
    end
    local result = table.concat(words)
    return result
end

return Utils
local playerData = {}
local playerDOBDict, playerHeightDict, playerWeightDict, playerPrefFootDict, sessionVars = ...

function playerData:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  return o
end

local function isLeapYear(year)
    return (year % 4 == 0 and year % 100 ~= 0) or (year % 400 == 0)
end

local monthDays = {
    normal = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
    leap = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
}

local function daysSince1900(day, month, year)
    local days = 0
    for y = 1900, year - 1 do
        days = days + (isLeapYear(y) and 366 or 365)
    end
    local mdays = isLeapYear(year) and monthDays.leap or monthDays.normal
    for m = 1, month - 1 do
        days = days + mdays[m]
    end
    return days + day
end

local refDay, refMonth, refYear = 14, 11, 1997
local refNumber = 151607
local refDays = daysSince1900(refDay, refMonth, refYear)

local function numberToAge(num, mode)
    if not num then
        return 17 -- Default age if no valid number is provided
    end
    local date = mode == "career" and GLOBAL_DATE_PLACEHOLDER or "01/08/25"
    local currentDay, currentMonth, currentYear = string.match(date, "(%d%d)/(%d%d)/(%d%d)")
    currentDay, currentMonth, currentYear = tonumber(currentDay), tonumber(currentMonth), tonumber("20" .. currentYear)
    
    local days = refDays + num - refNumber
    local year = 1900
    while days > (isLeapYear(year) and 366 or 365) do
        days = days - (isLeapYear(year) and 366 or 365)
        year = year + 1
    end
    local mdays = isLeapYear(year) and monthDays.leap or monthDays.normal
    local month = 1
    while days > mdays[month] do
        days = days - mdays[month]
        month = month + 1
    end
    local day = days
    
    local age = currentYear - year
    if currentMonth < month or (currentMonth == month and currentDay < day) then
        age = age - 1
    end
    return age >= 0 and age or 17 -- Ensure age is non-negative, default to 17 if invalid
end

function GetPlayerAge(card_id, mode)
    mode = mode or "career"
    if not card_id or not playerDOBDict or not playerDOBDict.data then
        return 17 -- Default age if card_id or dictionary is invalid
    end
    
    local dobNum = playerDOBDict.data[card_id]
    if not dobNum then
        return 17 -- Default age if DOB is not present
    end
    
    local num = tonumber(dobNum)
    if not num then
        return 17 -- Default age if DOB is not a valid number
    end
    
    return numberToAge(num, mode)
end

function GetPlayerData(info, card_id, mode)
    mode = mode or "career"
    if not card_id then
        if info == "height" then return 175
        elseif info == "weight" then return 130
        elseif info == "prefFoot" then return 1
        elseif info == "age" then return 17
        end
        return 0
    end

    local playerInfo = 0
    if info == "height" then
        playerInfo = (playerHeightDict and playerHeightDict.data and tonumber(playerHeightDict.data[card_id])) or 175
    elseif info == "weight" then
        playerInfo = (playerWeightDict and playerWeightDict.data and tonumber(playerWeightDict.data[card_id])) or 130
    elseif info == "prefFoot" then
        playerInfo = (playerPrefFootDict and playerPrefFootDict.data and tonumber(playerPrefFootDict.data[card_id])) or 1
    elseif info == "age" then
        playerInfo = GetPlayerAge(card_id, mode) 
    end
    
    return playerInfo
end

local function flattenTbl(tbl)
    if type(tbl) ~= "table" then
        return {}
    end

    local result = {}
    local result_idx = 1
    local seen = {}

    local function recurse(t)
        if type(t) ~= "table" then
            if t ~= nil then
                result[result_idx] = t
                result_idx = result_idx + 1
            end
            return
        end

        if seen[t] then
            error("Circular reference detected")
        end
        seen[t] = true

        -- Array part in order
        local len = #t
        for i = 1, len do
            recurse(t[i])
        end

        -- Hash part: collect and sort keys
        local keys = {}
        for k in pairs(t) do
            if not (type(k) == "number" and k >= 1 and k <= len and math.floor(k) == k) then
                keys[#keys + 1] = k  -- manual append to keys, because why not
            end
        end
        table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)

        for i = 1, #keys do
            recurse(t[keys[i]])
        end

        seen[t] = nil
    end

    recurse(tbl)
    return result
end

function playerData:GetPlayersGoalsByPosition(leagueID, rank)
    local playerGoals = sessionVars.get("PlayerGoals") or {}
    local leagueGoals = playerGoals[leagueID] or {}

    if next(leagueGoals) == nil or not rank or rank < 1 then
        return nil, nil, 0
    end


    local TeamList = flattenTbl(sessionVars.get("LeagueTeams")[leagueID])
    local combinedLineup = {}
    for _, teamID in ipairs(TeamList) do
        local lineup = getCachedTeamPlayers(teamID)
        if lineup and #lineup > 0 then
            for _, player in ipairs(lineup) do
                player.teamID = teamID
                table.insert(combinedLineup, player)
            end
        end
    end

    if #combinedLineup == 0 then
        return nil, nil, 0
    end

    for _, player in ipairs(combinedLineup) do
        player.goalCount = leagueGoals[player.CARD_ID] or 0
    end

    table.sort(combinedLineup, function(a, b)
        return a.goalCount > b.goalCount
    end)

    if rank > #combinedLineup then
        return nil, nil, 0
    end

    local player = combinedLineup[rank]
    return player.playerName, player.CARD_ID, player.goalCount
end

function playerData:updateRecord(teamID)
  local players = getCachedTeamPlayers(teamID) or {}
  local redMatchCount = sessionVars.get("redMatchCount") or {}
  
  local function updateRec(id)
    if redMatchCount[id] then
      local newCount= (redMatchCount[id] - 1)
      redMatchCount[id] = (newCount ~= 0) and newCount or nil
      isSuspended[id] = (redMatchCount[id]) and 1 or nil
    end
  end
  
  for i = 1, #players do
    updateRec(players[i].CARD_ID)
  end
  
  sessionVars.set("redMatchCount", redMatchCount)
end

function playerData:publishStats(publish, name, count)
local id, point = nil, nil
local userLeagueID = sessionVars.get("currentUserLeagueID")
  for i = 1, count do
    plN, id, goals = self:GetPlayersGoalsByPosition(userLeagueID, i)
    if name == "objname" then
      publish(name.. i, plN)
    elseif name == "objvalue" then 
      publish(name.. i, goals)
    elseif name == "objimg" then
      publish(name.. i, { name = "$Head", id = id })
    end
  end
end

return playerData
local sessionVars = ...
local TeamData = {}
TeamData.__index = TeamData
local getLeagueData = nil

function TeamData:new(init)
  local o = init or {}
  setmetatable(o, self)
  getLeagueData = o.api("TeamService").GetTeams
  return o
end

function TeamData:getTeamStrength(teamID)
  local tP = sessionVars.get("TeamStrength")[teamID]
  return tP.attack or 50, tP.midfield or 50, tP.defense or 50
end
  
function TeamData:updateTeamsStrength(leagueID)
  local tP = sessionVars.get("TeamStrength") or {}
  local teamIDs = getLeagueData(leagueID, 0, 0, false)
  for _, teamData in ipairs(teamIDs) do   
    if not tP[teamData.id] then
      tP[teamData.id] = {attack = 0, midfield = 0, defense = 0}
    end
    tP[teamData.id].attack = teamData.offense
    tP[teamData.id].midfield = teamData.midfield
    tP[teamData.id].defense = teamData.defense
  end
  sessionVars.set("TeamStrength", tP)
end

function TeamData:getTeamLeague(teamID)
    local TeamCachedData = sessionVars.get("TeamCachedData")
    return TeamCachedData[teamID] and TeamCachedData[teamID].league or 1
end

function TeamData:getAllTeamStrength()
  return sessionVars.get("TeamStrength")
end

return TeamData
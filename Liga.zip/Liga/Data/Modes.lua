local Modes = {}

local FCPopup, sessionVars, CareerFriendlies, WCTourney, UCLTourney, Save = ...

local _nav = _nav or nil
local api = nil
local loc = nil

function Modes:new(init)
    local o = init or {}
    setmetatable(o,self)
    self.__index = self
    o.nav = init.nav or {}
    loc = loc or init.loc
    o.loc = loc or init.loc
    api = api or init.api
    o.api = api or init.api    
    UCLTourney = UCLTourney:new({loc = loc, api = api})
    
    if init.loc then
        WCTourney:setLoc(init.loc)
        UCLTourney:setLoc(init.loc)
    end

    return o
end

function Modes:initializeMode(mode,Syear,teams,api)
    GLOBAL_DATE_PLACEHOLDER = GLOBAL_DATE_PLACEHOLDER or sessionVars.get("GLOBAL_DATE_PLACEHOLDER")
    local day,month,year = GLOBAL_DATE_PLACEHOLDER:match("(%d%d)/(%d%d)/(%d%d)")
    day = tonumber(day)
    month = tonumber(month)
    year = tonumber(year)
    year = year + 2000
    Syear = Syear or year
    _nav = self.nav

    if mode == "Friendlies" then
        _nav.Event(nil,"evt_FriendlyInvites")
    elseif mode == "WC" then
        WCTourney:generate(teams)
    elseif mode == "UCL" then
        UCLTourney:generate(Syear,teams, api)
    end
end

function Modes:storeTempData(tempKey,tbl)
    if type(tbl) ~= "table" then
        return
    end
    local tempSave = sessionVars.get("tempSave") or {}
    if not tempSave[tempKey] then
        tempSave[tempKey] = {}
    end
    local data = tempSave[tempKey]
    local idx = #data
    for i = 1,#tbl do
        data[idx + i] = tbl[i]
    end
    sessionVars.set("tempSave",tempSave)
end

function Modes:progress(leagueID, match)
    if leagueID == 1000 then
        if WCTourney:isCurrentRoundComplete() then
            WCTourney:progressToNextRound()
        end    
    elseif leagueID == 2236 then        
        UCLTourney:processMatch(match)
    end
end

function Modes:displayPopup(message,buttonData,callback)
    FCPopup:getResponse(message,buttonData,callback)
end

function Modes:validateInput(message,buttonData,id,callback,action)
    FCPopup = FCPopup:new({nav = _nav})
    self:displayPopup(message,buttonData,function(clickResponse)
        if action[clickResponse] == "Advance" then
            if id then
                CareerFriendlies:generate(callback(),175)
            end
            _nav.Event(nil,"evt_hideScreen")
        end
    end)
end

function Modes:getNav()
    return _nav
end

return Modes
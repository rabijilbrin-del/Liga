local TeamData, MatchHandler, Modes, sessionVars, playerData = ...
local MatchSimulator = {}
MatchSimulator.__index = MatchSimulator
local teamPower = nil

function MatchSimulator:new(params)
    local o = params or {}
    setmetatable(o, self)
    o.currentSelectedTeamID = params.currentSelectedTeamID or 0
    o.services = params.services
    return o
end

-- Poisson distribution for realistic goal modeling
local function poisson(lambda)
    local L = math.exp(-lambda)
    local k, p = 0, 1
    repeat
        k = k + 1
        p = p * math.random()
    until p <= L
    return math.max(0, k - 1)
end

local function computeExpected(homeStrength, awayStrength)
    local homeAttack = homeStrength.attack or 50
    local homeMidfield = homeStrength.midfield or 50
    local homeDefense = homeStrength.defense or 50
    local awayAttack = awayStrength.attack or 50
    local awayMidfield = awayStrength.midfield or 50
    local awayDefense = awayStrength.defense or 50

    local homeOverall = (homeAttack * 0.35 + homeMidfield * 0.35 + homeDefense * 0.3)
    local awayOverall = (awayAttack * 0.35 + awayMidfield * 0.35 + awayDefense * 0.3)
    local powerDifference = math.abs(homeOverall - awayOverall)
    local isHomeFavorite = homeOverall > awayOverall

    local homeAdvantage = 1.10
    local leagueAvgGoals = 2.6
    local homeExpected = (homeAttack / 100) * (awayDefense / 100) ^ (-1.3) * leagueAvgGoals * 0.55 * homeAdvantage
    local awayExpected = (awayAttack / 100) * (homeDefense / 100) ^ (-1.3) * leagueAvgGoals * 0.45

    local randFactor = 0.95 + math.random() * 0.1
    homeExpected = homeExpected * randFactor
    randFactor = 0.95 + math.random() * 0.1
    awayExpected = awayExpected * randFactor

    if powerDifference > 0 then
        local favoriteExpected, underdogExpected
        if isHomeFavorite then
            favoriteExpected = homeExpected
            underdogExpected = awayExpected
        else
            favoriteExpected = awayExpected
            underdogExpected = homeExpected
        end

        favoriteExpected = favoriteExpected * (1 + powerDifference / 50)
        underdogExpected = underdogExpected * (1 - powerDifference / 100)

        if isHomeFavorite then
            homeExpected = favoriteExpected
            awayExpected = underdogExpected
        else
            homeExpected = underdogExpected
            awayExpected = favoriteExpected
        end
    end

    homeExpected = math.max(0.2, math.min(3.5, homeExpected))
    awayExpected = math.max(0.2, math.min(3.5, awayExpected))

    return homeExpected, awayExpected
end

local function generateGoals(homeStrength, awayStrength)
    local homeAttack = homeStrength.attack or 50
    local homeMidfield = homeStrength.midfield or 50
    local homeDefense = homeStrength.defense or 50
    local awayAttack = awayStrength.attack or 50
    local awayMidfield = awayStrength.midfield or 50
    local awayDefense = awayStrength.defense or 50

    local homeOverall = (homeAttack * 0.35 + homeMidfield * 0.35 + homeDefense * 0.3)
    local awayOverall = (awayAttack * 0.35 + awayMidfield * 0.35 + awayDefense * 0.3)
    local powerDifference = math.abs(homeOverall - awayOverall)
    local isHomeFavorite = homeOverall > awayOverall

    local homeExpected, awayExpected = computeExpected(homeStrength, awayStrength)

    local homeScore = poisson(homeExpected)
    local awayScore = poisson(awayExpected)

    if homeScore + awayScore > 6 then
        if math.random() < 0.8 then
            homeScore = math.max(0, math.floor(homeScore * 0.7))
            awayScore = math.max(0, math.floor(awayScore * 0.7))
        end
    end

    if homeScore == 0 and awayScore == 0 and math.random() < 0.75 then
        if isHomeFavorite or math.random() < 0.55 then
            homeScore = 1
        else
            awayScore = 1
        end
    end

    local diffThreshold = 4
    if powerDifference > diffThreshold then
        local favoriteWins = isHomeFavorite and (homeScore > awayScore) or (awayScore > homeScore)
        if not favoriteWins then
            local isHomeUnderdog = not isHomeFavorite
            local forceWinProb = isHomeUnderdog and 0.8 or 0.95
            if math.random() < forceWinProb then
                local favScore = isHomeFavorite and homeScore or awayScore
                local undScore = isHomeFavorite and awayScore or homeScore
                if favScore < undScore then
                    favScore = undScore + 1
                elseif favScore == undScore then
                    favScore = favScore + 1
                end
                if isHomeFavorite then
                    homeScore = favScore
                    awayScore = undScore
                else
                    homeScore = undScore
                    awayScore = favScore
                end
            end
        end
    end

    return homeScore, awayScore
end

-- Goal scorers ONLY for regular time goals
local function assignGoalscorers(self, teamID, numGoals, playerGoals, leagueID)
    if numGoals == 0 then return {} end  -- Early exit if no goals

    local position_multipliers = {
        ["ST"] = 4.0, ["CF"] = 3.8, ["LF"] = 3.5, ["RF"] = 3.5, ["LW"] = 3.0, ["RW"] = 3.0,
        ["CAM"] = 2.5, ["LM"] = 2.0, ["RM"] = 2.0, ["CM"] = 1.8, ["CDM"] = 1.0,
        ["LB"] = 0.7, ["RB"] = 0.7, ["LWB"] = 0.9, ["RWB"] = 0.9, ["CB"] = 0.6, ["GK"] = 0
    }

    local players = getCachedTeamPlayers(teamID) or self.services.SquadManagementService.GetCurrentPlayerLineup(0, teamID, 0) or {}
    local starters, substitutes = {}, {}
    for i = 1, math.min(22, #players) do
        if i <= 11 then starters[#starters + 1] = players[i]
        else substitutes[#substitutes + 1] = players[i] end
    end

    local specialPlayer = nil
    local maxRating = 0
    for i = 8, 11 do
        if starters[i] and (starters[i].rating or 0) > maxRating then
            maxRating = starters[i].rating or 0
            specialPlayer = starters[i]
        end
    end

    playerGoals[leagueID] = playerGoals[leagueID] or {}
    local scorers = {}
    for i = 1, numGoals do
        local subProb = 0.2 + (i / numGoals) * 0.3
        local isStarter = math.random() > subProb
        local squad = isStarter and starters or substitutes
        if #squad == 0 then
            squad = starters
            isStarter = true
        end

        local weights = {}
        local totalW = 0
        for _, player in ipairs(squad) do
            local playerID = player.CARD_ID
            local rating = player.rating or 50
            local posWeight = position_multipliers[player.position] or 1
            local baseW = posWeight * (rating / 50)
            local goalW = ((playerGoals[leagueID][playerID] or 0) * 0.3) * (rating / 50)
            local randFactor = 0.9 + math.random() * 0.2
            local playerW = (baseW + goalW) * randFactor
            if not isStarter then playerW = playerW * 0.4 end
            if player == specialPlayer then playerW = playerW * 1.15 end
            weights[player] = playerW
            totalW = totalW + playerW
        end

        local selected = squad[1]
        if totalW > 0 then
            local r = math.random() * totalW
            local cum = 0
            for _, player in ipairs(squad) do
                cum = cum + weights[player]
                if r <= cum then
                    selected = player
                    break
                end
            end
        end

        local playerID = selected.CARD_ID
        local playerName = selected.playerName
        playerGoals[leagueID][playerID] = (playerGoals[leagueID][playerID] or 0) + 1
        scorers[i] = playerName
    end
    return scorers
end

local function roundToNearestTen(value)
    return math.floor(value / 10 + 0.5) * 10
end

local function simulatePenaltyShootout(homeStrength, awayStrength)
    local homeOverall = (homeStrength.attack * 0.35 + homeStrength.midfield * 0.35 + homeStrength.defense * 0.3)
    local awayOverall = (awayStrength.attack * 0.35 + awayStrength.midfield * 0.35 + awayStrength.defense * 0.3)
    local diff = (homeOverall - awayOverall) / 50

    local homePens = 0
    local awayPens = 0

    for i = 1, 5 do
        if math.random() < 0.75 + diff * 0.05 then homePens = homePens + 1 end
        if math.random() < 0.75 - diff * 0.05 then awayPens = awayPens + 1 end
    end

    while homePens == awayPens do
        if math.random() < 0.75 + diff * 0.05 then homePens = homePens + 1 end
        if math.random() < 0.75 - diff * 0.05 then awayPens = awayPens + 1 end
    end

    return homePens, awayPens
end

function MatchSimulator:simMatch(match, simUserMatch, type)
  if not simUserMatch then
    if match.match.homeID == self.currentSelectedTeamID or match.match.awayID == self.currentSelectedTeamID then
        return false
    end
  end

    if match.match.played then
        print("Match " .. match.index .. " already simulated, skipping")
        return false
    end

    local userLeagueID = sessionVars.get("currentUserLeagueID")
    local leagueID = match.match.leagueID or "default"
    local homeStrength = teamPower[match.match.homeID] or {attack=50, midfield=50, defense=50}
    local awayStrength = teamPower[match.match.awayID] or {attack=50, midfield=50, defense=50}

    if userLeagueID and leagueID == userLeagueID then
        local function computeTeamStrength(self, teamID)
            local players = getCachedTeamPlayers(teamID) or self.services.SquadManagementService.GetCurrentPlayerLineup(0, teamID, 0) or {}
            if not players or #players == 0 then return end
            local a, m, d, ac, mc, dc = 0, 0, 0, 0, 0, 0
            for _, p in ipairs(players) do
                local r = p.rating or 50
                if p.position == "ST" or p.position == "CF" or p.position == "LW" or p.position == "RW" then
                    a = a + r; ac = ac + 1
                elseif p.position == "CAM" or p.position == "CM" or p.position == "CDM" or p.position == "LM" or p.position == "RM" then
                    m = m + r; mc = mc + 1
                else
                    d = d + r; dc = dc + 1
                end
            end
            local atk = (ac > 0 and a / ac or 50)
            local mid = (mc > 0 and m / mc or 50)
            local def = (dc > 0 and d / dc or 50)
            local depthBoost = (#players >= 18) and ((#players / 22) * 0.1) or 0
            return {
                attack = atk * (1 + depthBoost),
                midfield = mid * (1 + depthBoost),
                defense = def * (1 + depthBoost)
            }
        end
        homeStrength = computeTeamStrength(self, match.match.homeID) or homeStrength
        awayStrength = computeTeamStrength(self, match.match.awayID) or awayStrength
    end

    -- Generate regular time scores
    local homeScore, awayScore = generateGoals(homeStrength, awayStrength)

    -- Assign scorers ONLY for regular time goals
    local playerGoals = sessionVars.get("PlayerGoals") or {}
    local homeScorers = assignGoalscorers(self, match.match.homeID, homeScore, playerGoals, leagueID)
    local awayScorers = assignGoalscorers(self, match.match.awayID, awayScore, playerGoals, leagueID)
    local sMatchData = {}

    local matchData = sessionVars.get("MatchData")
    if matchData and matchData[match.index] then
        matchData[match.index].homeScore = homeScore
        matchData[match.index].awayScore = awayScore
        matchData[match.index].played = true

        -- Knockout: force winner via pens if tied
        local isKnockout = match.match.isKnockout == true
        if isKnockout and homeScore == awayScore then
            local homePenScore, awayPenScore = simulatePenaltyShootout(homeStrength, awayStrength)
            matchData[match.index].pen = true
            matchData[match.index].homePenScore = homePenScore
            matchData[match.index].awayPenScore = awayPenScore
            -- Regular time scores stay the same, winner decided by pens
        end

        -- Stats block (possession, shots, etc.)
        if type == "specific" then
            local homeAttack = homeStrength.attack or 50
            local homeMidfield = homeStrength.midfield or 50
            local homeDefense = homeStrength.defense or 50
            local awayAttack = awayStrength.attack or 50
            local awayMidfield = awayStrength.midfield or 50
            local awayDefense = awayStrength.defense or 50

            local homeOverall = (homeAttack * 0.35 + homeMidfield * 0.35 + homeDefense * 0.3)
            local awayOverall = (awayAttack * 0.35 + awayMidfield * 0.35 + awayDefense * 0.3)

            local homeExpected, awayExpected = computeExpected(homeStrength, awayStrength)

            local possDiff = (homeOverall - awayOverall) * 0.4
            local homePoss = 50 + possDiff + (math.random() * 6 - 3)
            homePoss = math.max(35, math.min(65, homePoss))
            local awayPoss = 100 - homePoss

            if homeScore > awayScore then
                local adjust = math.random(1, 3)
                homePoss = math.min(65, homePoss + adjust * (homeScore - awayScore))
                awayPoss = 100 - homePoss
            elseif awayScore > homeScore then
                local adjust = math.random(1, 3)
                awayPoss = math.min(65, awayPoss + adjust * (awayScore - homeScore))
                homePoss = 100 - awayPoss
            end

            homePoss = math.max(35, math.min(65, homePoss))
            awayPoss = 100 - homePoss
            homePoss = roundToNearestTen(homePoss)
            awayPoss = 100 - homePoss

            local homeShotLambda = math.max(3, homeExpected * 3.5 + math.random() * 3)
            local awayShotLambda = math.max(3, awayExpected * 3.5 + math.random() * 3)
            local homeShots = poisson(homeShotLambda)
            local awayShots = poisson(awayShotLambda)

            if homeScore > awayScore then
                local extra = math.random(1, 3) * (homeScore - awayScore)
                homeShots = math.max(homeShots, awayShots + extra)
            elseif awayScore > homeScore then
                local extra = math.random(1, 3) * (awayScore - homeScore)
                awayShots = math.max(awayShots, homeShots + extra)
            end

            homeShots = math.max(homeShots, homeScore * 2)
            awayShots = math.max(awayShots, awayScore * 2)
            homeShots = math.min(20, homeShots)
            awayShots = math.min(20, awayShots)

            local homeChanceLambda = math.max(1, homeShots * 0.3)
            local awayChanceLambda = math.max(1, awayShots * 0.3)
            local homeChances = poisson(homeChanceLambda)
            local awayChances = poisson(awayChanceLambda)

            if homeScore > awayScore then homeChances = math.max(homeChances, awayChances)
            elseif awayScore > homeScore then awayChances = math.max(awayChances, homeChances) end

            homeChances = math.max(homeChances, homeScore)
            awayChances = math.max(awayChances, awayScore)
            homeChances = math.min(homeChances, homeShots)
            awayChances = math.min(awayChances, awayShots)
                        
            --specific MatchData table 

            sMatchData.possessionHome = homePoss
            sMatchData.possessionAway = awayPoss
            sMatchData.shotsHome = homeShots
            sMatchData.shotsAway = awayShots
            sMatchData.chancesHome = homeChances
            sMatchData.chancesAway = awayChances
            sMatchData.homeScorers = homeScorers
            sMatchData.awayScorers = awayScorers
        end

        sessionVars.set("PlayerGoals", playerGoals)
        sessionVars.set("MatchData", matchData)
        playerData:updateRecord(match.match.homeID)
        playerData:updateRecord(match.match.awayID)

        if type == "specific" then
            return matchData[match.index], sMatchData
        end
    end

    return true
end

function MatchSimulator:simulateDayMatches(dateStr, simUserMatch)
    teamPower = TeamData:getAllTeamStrength()
    local matches = MatchHandler:getMatchesForDate(dateStr)
    for _, match in ipairs(matches)do 
      if not match.match.played then 
        self:simMatch(match, simUserMatch)
		if match.match.matchType == "Competition" then
		    Modes:progress(match.match.leagueID, match.match)   -- <-- added second argument
		end       
      end
    end
end

function MatchSimulator:simulateMatch(homeID, awayID)
    local data, sMatchData = {}, {}
    local dateStr = GLOBAL_DATE_PLACEHOLDER
    teamPower = TeamData:getAllTeamStrength()
    local matches = MatchHandler:getMatchesForDate(dateStr)
    for _, match in ipairs(matches) do
        if match.match.homeID == homeID and match.match.awayID == awayID then
            data, sMatchData = self:simMatch(match, nil, "specific")
            if match.match.matchType == "Competition" then
		      Modes:progress(match.match.leagueID, match.match)
	  	end
        end
    end
    return data, sMatchData
end

return MatchSimulator
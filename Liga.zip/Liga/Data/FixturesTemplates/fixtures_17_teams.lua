return {
    -- Matchday 1
    {
        { home = 1, away = 2 },
        { home = 3, away = 4 },
        { home = 5, away = 6 },
        { home = 7, away = 8 },
        { home = 9, away = 10 },
        { home = 11, away = 12 },
        { home = 13, away = 14 },
        { home = 15, away = 16 }
        -- Team 17 has a bye
    },
    -- Matchday 2
    {
        { home = 2, away = 3 },
        { home = 4, away = 5 },
        { home = 6, away = 7 },
        { home = 8, away = 9 },
        { home = 10, away = 11 },
        { home = 12, away = 13 },
        { home = 14, away = 15 },
        { home = 16, away = 17 }
        -- Team 1 has a bye
    },
    -- Matchday 3
    {
        { home = 1, away = 3 },
        { home = 5, away = 2 },
        { home = 7, away = 4 },
        { home = 9, away = 6 },
        { home = 11, away = 8 },
        { home = 13, away = 10 },
        { home = 15, away = 12 },
        { home = 17, away = 14 }
        -- Team 16 has a bye
    },
    -- Matchday 4
    {
        { home = 3, away = 5 },
        { home = 2, away = 7 },
        { home = 4, away = 9 },
        { home = 6, away = 11 },
        { home = 8, away = 13 },
        { home = 10, away = 15 },
        { home = 12, away = 17 },
        { home = 14, away = 16 }
        -- Team 1 has a bye
    },
    -- Matchday 5
    {
        { home = 1, away = 5 },
        { home = 7, away = 3 },
        { home = 9, away = 2 },
        { home = 11, away = 4 },
        { home = 13, away = 6 },
        { home = 15, away = 8 },
        { home = 17, away = 10 },
        { home = 16, away = 12 }
        -- Team 14 has a bye
    },
    -- Matchday 6
    {
        { home = 5, away = 7 },
        { home = 3, away = 9 },
        { home = 2, away = 11 },
        { home = 4, away = 13 },
        { home = 6, away = 15 },
        { home = 8, away = 17 },
        { home = 10, away = 16 },
        { home = 12, away = 14 }
        -- Team 1 has a bye
    },
    -- Matchday 7
    {
        { home = 1, away = 7 },
        { home = 9, away = 5 },
        { home = 11, away = 3 },
        { home = 13, away = 2 },
        { home = 15, away = 4 },
        { home = 17, away = 6 },
        { home = 16, away = 8 },
        { home = 14, away = 10 }
        -- Team 12 has a bye
    },
    -- Matchday 8
    {
        { home = 7, away = 9 },
        { home = 5, away = 11 },
        { home = 3, away = 13 },
        { home = 2, away = 15 },
        { home = 4, away = 17 },
        { home = 6, away = 16 },
        { home = 8, away = 14 },
        { home = 10, away = 12 }
        -- Team 1 has a bye
    },
    -- Matchday 9
    {
        { home = 1, away = 9 },
        { home = 11, away = 7 },
        { home = 13, away = 5 },
        { home = 15, away = 3 },
        { home = 17, away = 2 },
        { home = 16, away = 4 },
        { home = 14, away = 6 },
        { home = 12, away = 8 }
        -- Team 10 has a bye
    },
    -- Matchday 10
    {
        { home = 9, away = 11 },
        { home = 7, away = 13 },
        { home = 5, away = 15 },
        { home = 3, away = 17 },
        { home = 2, away = 16 },
        { home = 4, away = 14 },
        { home = 6, away = 12 },
        { home = 8, away = 10 }
        -- Team 1 has a bye
    },
    -- Matchday 11
    {
        { home = 1, away = 11 },
        { home = 13, away = 9 },
        { home = 15, away = 7 },
        { home = 17, away = 5 },
        { home = 16, away = 3 },
        { home = 14, away = 2 },
        { home = 12, away = 4 },
        { home = 10, away = 6 }
        -- Team 8 has a bye
    },
    -- Matchday 12
    {
        { home = 11, away = 13 },
        { home = 9, away = 15 },
        { home = 7, away = 17 },
        { home = 5, away = 16 },
        { home = 3, away = 14 },
        { home = 2, away = 12 },
        { home = 4, away = 10 },
        { home = 6, away = 8 }
        -- Team 1 has a bye
    },
    -- Matchday 13
    {
        { home = 1, away = 13 },
        { home = 15, away = 11 },
        { home = 17, away = 9 },
        { home = 16, away = 7 },
        { home = 14, away = 5 },
        { home = 12, away = 3 },
        { home = 10, away = 2 },
        { home = 8, away = 4 }
        -- Team 6 has a bye
    },
    -- Matchday 14
    {
        { home = 13, away = 15 },
        { home = 11, away = 17 },
        { home = 9, away = 16 },
        { home = 7, away = 14 },
        { home = 5, away = 12 },
        { home = 3, away = 10 },
        { home = 2, away = 8 },
        { home = 4, away = 6 }
        -- Team 1 has a bye
    },
    -- Matchday 15
    {
        { home = 1, away = 15 },
        { home = 17, away = 13 },
        { home = 16, away = 11 },
        { home = 14, away = 9 },
        { home = 12, away = 7 },
        { home = 10, away = 5 },
        { home = 8, away = 3 },
        { home = 6, away = 2 }
        -- Team 4 has a bye
    },
    -- Matchday 16
    {
        { home = 15, away = 17 },
        { home = 13, away = 16 },
        { home = 11, away = 14 },
        { home = 9, away = 12 },
        { home = 7, away = 10 },
        { home = 5, away = 8 },
        { home = 3, away = 6 },
        { home = 2, away = 4 }
        -- Team 1 has a bye
    },
    -- Matchday 17 (Reverse of Matchday 1)
    {
        { home = 2, away = 1 },
        { home = 4, away = 3 },
        { home = 6, away = 5 },
        { home = 8, away = 7 },
        { home = 10, away = 9 },
        { home = 12, away = 11 },
        { home = 14, away = 13 },
        { home = 16, away = 15 }
        -- Team 17 has a bye
    },
    -- Matchday 18 (Reverse of Matchday 2)
    {
        { home = 3, away = 2 },
        { home = 5, away = 4 },
        { home = 7, away = 6 },
        { home = 9, away = 8 },
        { home = 11, away = 10 },
        { home = 13, away = 12 },
        { home = 15, away = 14 },
        { home = 17, away = 16 }
        -- Team 1 has a bye
    },
    -- Matchday 19 (Reverse of Matchday 3)
    {
        { home = 3, away = 1 },
        { home = 2, away = 5 },
        { home = 4, away = 7 },
        { home = 6, away = 9 },
        { home = 8, away = 11 },
        { home = 10, away = 13 },
        { home = 12, away = 15 },
        { home = 14, away = 17 }
        -- Team 16 has a bye
    },
    -- Matchday 20 (Reverse of Matchday 4)
    {
        { home = 5, away = 3 },
        { home = 7, away = 2 },
        { home = 9, away = 4 },
        { home = 11, away = 6 },
        { home = 13, away = 8 },
        { home = 15, away = 10 },
        { home = 17, away = 12 },
        { home = 16, away = 14 }
        -- Team 1 has a bye
    },
    -- Matchday 21 (Reverse of Matchday 5)
    {
        { home = 5, away = 1 },
        { home = 3, away = 7 },
        { home = 2, away = 9 },
        { home = 4, away = 11 },
        { home = 6, away = 13 },
        { home = 8, away = 15 },
        { home = 10, away = 17 },
        { home = 12, away = 16 }
        -- Team 14 has a bye
    },
    -- Matchday 22 (Reverse of Matchday 6)
    {
        { home = 7, away = 5 },
        { home = 9, away = 3 },
        { home = 11, away = 2 },
        { home = 13, away = 4 },
        { home = 15, away = 6 },
        { home = 17, away = 8 },
        { home = 16, away = 10 },
        { home = 14, away = 12 }
        -- Team 1 has a bye
    },
    -- Matchday 23 (Reverse of Matchday 7)
    {
        { home = 7, away = 1 },
        { home = 5, away = 9 },
        { home = 3, away = 11 },
        { home = 2, away = 13 },
        { home = 4, away = 15 },
        { home = 6, away = 17 },
        { home = 8, away = 16 },
        { home = 10, away = 14 }
        -- Team 12 has a bye
    },
    -- Matchday 24 (Reverse of Matchday 8)
    {
        { home = 9, away = 7 },
        { home = 11, away = 5 },
        { home = 13, away = 3 },
        { home = 15, away = 2 },
        { home = 17, away = 4 },
        { home = 16, away = 6 },
        { home = 14, away = 8 },
        { home = 12, away = 10 }
        -- Team 1 has a bye
    },
    -- Matchday 25 (Reverse of Matchday 9)
    {
        { home = 9, away = 1 },
        { home = 7, away = 11 },
        { home = 5, away = 13 },
        { home = 3, away = 15 },
        { home = 2, away = 17 },
        { home = 4, away = 16 },
        { home = 6, away = 14 },
        { home = 8, away = 12 }
        -- Team 10 has a bye
    },
    -- Matchday 26 (Reverse of Matchday 10)
    {
        { home = 11, away = 9 },
        { home = 13, away = 7 },
        { home = 15, away = 5 },
        { home = 17, away = 3 },
        { home = 16, away = 2 },
        { home = 14, away = 4 },
        { home = 12, away = 6 },
        { home = 10, away = 8 }
        -- Team 1 has a bye
    },
    -- Matchday 27 (Reverse of Matchday 11)
    {
        { home = 11, away = 1 },
        { home = 9, away = 13 },
        { home = 7, away = 15 },
        { home = 5, away = 17 },
        { home = 3, away = 16 },
        { home = 2, away = 14 },
        { home = 4, away = 12 },
        { home = 6, away = 10 }
        -- Team 8 has a bye
    },
    -- Matchday 28 (Reverse of Matchday 12)
    {
        { home = 13, away = 11 },
        { home = 15, away = 9 },
        { home = 17, away = 7 },
        { home = 16, away = 5 },
        { home = 14, away = 3 },
        { home = 12, away = 2 },
        { home = 10, away = 4 },
        { home = 8, away = 6 }
        -- Team 1 has a bye
    },
    -- Matchday 29 (Reverse of Matchday 13)
    {
        { home = 13, away = 1 },
        { home = 11, away = 15 },
        { home = 9, away = 17 },
        { home = 7, away = 16 },
        { home = 5, away = 14 },
        { home = 3, away = 12 },
        { home = 2, away = 10 },
        { home = 4, away = 8 }
        -- Team 6 has a bye
    },
    -- Matchday 30 (Reverse of Matchday 14)
    {
        { home = 15, away = 13 },
        { home = 17, away = 11 },
        { home = 16, away = 9 },
        { home = 14, away = 7 },
        { home = 12, away = 5 },
        { home = 10, away = 3 },
        { home = 8, away = 2 },
        { home = 6, away = 4 }
        -- Team 1 has a bye
    },
    -- Matchday 31 (Reverse of Matchday 15)
    {
        { home = 15, away = 1 },
        { home = 13, away = 17 },
        { home = 11, away = 16 },
        { home = 9, away = 14 },
        { home = 7, away = 12 },
        { home = 5, away = 10 },
        { home = 3, away = 8 },
        { home = 2, away = 6 }
        -- Team 4 has a bye
    },
    -- Matchday 32 (Reverse of Matchday 16)
    {
        { home = 17, away = 15 },
        { home = 16, away = 13 },
        { home = 14, away = 11 },
        { home = 12, away = 9 },
        { home = 10, away = 7 },
        { home = 8, away = 5 },
        { home = 6, away = 3 },
        { home = 4, away = 2 }
        -- Team 1 has a bye
    }
}
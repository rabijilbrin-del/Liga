return {
    -- Matchday 1
    {
        { home = 1, away = 2 },
        { home = 3, away = 4 },
        { home = 5, away = 6 },
        { home = 7, away = 8 },
        { home = 9, away = 10 },
        { home = 11, away = 12 }
    },
    -- Matchday 2
    {
        { home = 2, away = 3 },
        { home = 4, away = 5 },
        { home = 6, away = 7 },
        { home = 8, away = 9 },
        { home = 10, away = 11 },
        { home = 12, away = 1 }
    },
    -- Matchday 3
    {
        { home = 1, away = 3 },
        { home = 5, away = 2 },
        { home = 7, away = 4 },
        { home = 9, away = 6 },
        { home = 11, away = 8 },
        { home = 12, away = 10 }
    },
    -- Matchday 4
    {
        { home = 3, away = 5 },
        { home = 2, away = 7 },
        { home = 4, away = 9 },
        { home = 6, away = 11 },
        { home = 8, away = 12 },
        { home = 10, away = 1 }
    },
    -- Matchday 5
    {
        { home = 1, away = 5 },
        { home = 7, away = 3 },
        { home = 9, away = 2 },
        { home = 11, away = 4 },
        { home = 12, away = 6 },
        { home = 10, away = 8 }
    },
    -- Matchday 6
    {
        { home = 5, away = 7 },
        { home = 3, away = 9 },
        { home = 2, away = 11 },
        { home = 4, away = 12 },
        { home = 6, away = 10 },
        { home = 8, away = 1 }
    },
    -- Matchday 7
    {
        { home = 1, away = 7 },
        { home = 9, away = 5 },
        { home = 11, away = 3 },
        { home = 12, away = 2 },
        { home = 10, away = 4 },
        { home = 8, away = 6 }
    },
    -- Matchday 8
    {
        { home = 7, away = 9 },
        { home = 5, away = 11 },
        { home = 3, away = 12 },
        { home = 2, away = 10 },
        { home = 4, away = 8 },
        { home = 6, away = 1 }
    },
    -- Matchday 9
    {
        { home = 1, away = 9 },
        { home = 11, away = 7 },
        { home = 12, away = 5 },
        { home = 10, away = 3 },
        { home = 8, away = 2 },
        { home = 6, away = 4 }
    },
    -- Matchday 10
    {
        { home = 9, away = 11 },
        { home = 7, away = 12 },
        { home = 5, away = 10 },
        { home = 3, away = 8 },
        { home = 2, away = 6 },
        { home = 4, away = 1 }
    },
    -- Matchday 11
    {
        { home = 1, away = 11 },
        { home = 12, away = 9 },
        { home = 10, away = 7 },
        { home = 8, away = 5 },
        { home = 6, away = 3 },
        { home = 4, away = 2 }
    },
    -- Matchday 12 (Reverse of Matchday 1)
    {
        { home = 2, away = 1 },
        { home = 4, away = 3 },
        { home = 6, away = 5 },
        { home = 8, away = 7 },
        { home = 10, away = 9 },
        { home = 12, away = 11 }
    },
    -- Matchday 13 (Reverse of Matchday 2)
    {
        { home = 3, away = 2 },
        { home = 5, away = 4 },
        { home = 7, away = 6 },
        { home = 9, away = 8 },
        { home = 11, away = 10 },
        { home = 1, away = 12 }
    },
    -- Matchday 14 (Reverse of Matchday 3)
    {
        { home = 3, away = 1 },
        { home = 2, away = 5 },
        { home = 4, away = 7 },
        { home = 6, away = 9 },
        { home = 8, away = 11 },
        { home = 10, away = 12 }
    },
    -- Matchday 15 (Reverse of Matchday 4)
    {
        { home = 5, away = 3 },
        { home = 7, away = 2 },
        { home = 9, away = 4 },
        { home = 11, away = 6 },
        { home = 12, away = 8 },
        { home = 1, away = 10 }
    },
    -- Matchday 16 (Reverse of Matchday 5)
    {
        { home = 5, away = 1 },
        { home = 3, away = 7 },
        { home = 2, away = 9 },
        { home = 4, away = 11 },
        { home = 6, away = 12 },
        { home = 8, away = 10 }
    },
    -- Matchday 17 (Reverse of Matchday 6)
    {
        { home = 7, away = 5 },
        { home = 9, away = 3 },
        { home = 11, away = 2 },
        { home = 12, away = 4 },
        { home = 10, away = 6 },
        { home = 1, away = 8 }
    },
    -- Matchday 18 (Reverse of Matchday 7)
    {
        { home = 7, away = 1 },
        { home = 5, away = 9 },
        { home = 3, away = 11 },
        { home = 2, away = 12 },
        { home = 4, away = 10 },
        { home = 6, away = 8 }
    },
    -- Matchday 19 (Reverse of Matchday 8)
    {
        { home = 9, away = 7 },
        { home = 11, away = 5 },
        { home = 12, away = 3 },
        { home = 10, away = 2 },
        { home = 8, away = 4 },
        { home = 1, away = 6 }
    },
    -- Matchday 20 (Reverse of Matchday 9)
    {
        { home = 9, away = 1 },
        { home = 7, away = 11 },
        { home = 5, away = 12 },
        { home = 3, away = 10 },
        { home = 2, away = 8 },
        { home = 4, away = 6 }
    },
    -- Matchday 21 (Reverse of Matchday 10)
    {
        { home = 11, away = 9 },
        { home = 12, away = 7 },
        { home = 10, away = 5 },
        { home = 8, away = 3 },
        { home = 6, away = 2 },
        { home = 1, away = 4 }
    },
    -- Matchday 22 (Reverse of Matchday 11)
    {
        { home = 11, away = 1 },
        { home = 9, away = 12 },
        { home = 7, away = 10 },
        { home = 5, away = 8 },
        { home = 3, away = 6 },
        { home = 2, away = 4 }
    }
}
-- WorldCup.lua

local sessionVars, NewsCenter = ...
local WorldCup = {}
local WORLD_CUP_LEAGUE_ID = 1000
local loc = nil
local DEFAULT_TEAMS = {
    A = { 1386, 111099, 974, 1331 },
    B = { 111455, 1343, 111527, 1364 },
    C = { 1370, 111111, 112048, 1359 },
    D = { 1387, 1375, 1415, 1365 },
    E = { 1337, 112054, 111112, 111465 },
    F = { 105035, 1411, 1363, 1391 },
    G = { 1325, 111130, 111115, 111473 },
    H = { 1362, 111456, 111114, 1377 },
    I = { 1335, 1667, 111451, 1352 },
    J = { 1369, 111448, 1322, 111513 },
    K = { 1354, 1357, 111485, 111109 },
    L = { 1318, 1328, 111462, 111475 }
}

-- Stats calculator (standalone)
local function _calculateGroupStats(self, matchData, teamList)
    local teamStats = {}
    for _, id in ipairs(teamList) do
        teamStats[id] = {
            wins = 0, draws = 0, losses = 0,
            goalsScored = 0, goalsConceded = 0,
            points = 0, matchesPlayed = 0,
            teamName = self:getLoc().LocalizeString("TeamName_Abbr15_" .. id)
        }
    end
    for _, match in ipairs(matchData) do
        local h, a = match.homeID, match.awayID
        local hs, as = match.homeScore or 0, match.awayScore or 0
        if match.played and teamStats[h] and teamStats[a] then
            teamStats[h].matchesPlayed = teamStats[h].matchesPlayed + 1
            teamStats[a].matchesPlayed = teamStats[a].matchesPlayed + 1
            teamStats[h].goalsScored = teamStats[h].goalsScored + hs
            teamStats[h].goalsConceded = teamStats[h].goalsConceded + as
            teamStats[a].goalsScored = teamStats[a].goalsScored + as
            teamStats[a].goalsConceded = teamStats[a].goalsConceded + hs
            if hs > as then
                teamStats[h].wins = teamStats[h].wins + 1
                teamStats[h].points = teamStats[h].points + 3
                teamStats[a].losses = teamStats[a].losses + 1
            elseif hs < as then
                teamStats[a].wins = teamStats[a].wins + 1
                teamStats[a].points = teamStats[a].points + 3
                teamStats[h].losses = teamStats[h].losses + 1
            else
                teamStats[h].draws = teamStats[h].draws + 1
                teamStats[a].draws = teamStats[a].draws + 1
                teamStats[h].points = teamStats[h].points + 1
                teamStats[a].points = teamStats[a].points + 1
            end
        end
    end
    return teamStats
end

local function getOrderedGroup(self, matchData, groupLetter, groupTeams)
    local stats = _calculateGroupStats(self, matchData, groupTeams)
    local ordered = {}
    for _, id in ipairs(groupTeams) do
        local s = stats[id]
        table.insert(ordered, {
            teamID = id,
            group = groupLetter,
            points = s.points,
            gd = s.goalsScored - s.goalsConceded,
            goals = s.goalsScored,
            name = s.teamName
        })
    end
    table.sort(ordered, function(a, b)
        if a.points ~= b.points then return a.points > b.points end
        if a.gd ~= b.gd then return a.gd > b.gd end
        if a.goals ~= b.goals then return a.goals > b.goals end
        return a.name < b.name
    end)
    return ordered
end

function WorldCup:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  return o
end

local function toMMDDYY(dateStr)
    local y, m, d = dateStr:match("(%d+)-(%d+)-(%d+)")
    if not y then return nil end
    return string.format("%02d%02d%s", tonumber(m), tonumber(d), y:sub(3))
end

-- addMatch with Knockout flag for KO rounds
local function addMatch(homeID, awayID, dateStr, leagueID, matchday)
    local matchData = sessionVars.get("MatchData") or {}
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    leagueMatchData[leagueID] = leagueMatchData[leagueID] or {}

    local convDate = toMMDDYY(dateStr)
    if not convDate then return end

    local entry = {
        homeID = homeID,
        awayID = awayID,
        date = convDate,
        matchType = "Competition",
        matchday = matchday,
        homeScore = 0,
        awayScore = 0,
        played = false,
        leagueID = leagueID,
        isKnockout = (matchday >= 4) 
    }

    table.insert(matchData, entry)
    table.insert(leagueMatchData[leagueID], entry)

    sessionVars.set("MatchData", matchData)
    sessionVars.set("LeagueMatchData", leagueMatchData)
end

-- Group stage fixtures (unchanged)
local function generateGroupFixtures(groupTeams)
    local t1, t2, t3, t4 = groupTeams[1], groupTeams[2], groupTeams[3], groupTeams[4]
    return {
        [1] = {{home = t1, away = t2}, {home = t3, away = t4}},
        [2] = {{home = t1, away = t3}, {home = t4, away = t2}},
        [3] = {{home = t1, away = t4}, {home = t2, away = t3}}
    }
end

local function shuffle(tbl)
    for i = #tbl, 2, -1 do
        local j = math.random(i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
end

function WorldCup:setLoc(locparam)
  loc = loc or locparam
end

function WorldCup:getLoc()
  return loc
end

-- Group stage generation
function WorldCup:generate(WCTeams)
    WCTeams = WCTeams or DEFAULT_TEAMS
    local leagueID = WORLD_CUP_LEAGUE_ID
    local teams = sessionVars.get("LeagueTeams") or {}
    teams[leagueID] = WCTeams
    sessionVars.set("LeagueTeams", teams)

    math.randomseed(os.time() + math.random(1, 100000))

    local allMatchdays = {[1] = {}, [2] = {}, [3] = {}}

    for groupLetter, groupTeams in pairs(WCTeams) do
        assert(#groupTeams == 4, "Each group must have exactly 4 teams")
        local groupFixtures = generateGroupFixtures(groupTeams)
        for md = 1, 3 do
            for _, m in ipairs(groupFixtures[md]) do
                table.insert(allMatchdays[md], m)
            end
        end
    end

    for md = 1, 3 do shuffle(allMatchdays[md]) end

    local startDate = os.time({year = 2026, month = 6, day = 11, hour = 12})
    local endDate   = os.time({year = 2026, month = 6, day = 27, hour = 23})

    local lastPlayed = {}
    for _, groupTeams in pairs(WCTeams) do
        for _, id in ipairs(groupTeams) do lastPlayed[id] = -999999999 end
    end

    local current = startDate
    for matchday = 1, 3 do
        local matchesThisDay = allMatchdays[matchday]
        while true do
            local canPlay = true
            for _, m in ipairs(matchesThisDay) do
                local nextAllowed = math.max(lastPlayed[m.home] or 0, lastPlayed[m.away] or 0) + 4 * 86400
                if current < nextAllowed then canPlay = false; break end
            end
            if canPlay and current <= endDate then break end
            current = current + 86400
            if current > endDate then print("Warning: Could not schedule group matches"); return end
        end

        local dateStr = os.date("%Y-%m-%d", current)
        for _, m in ipairs(matchesThisDay) do
            addMatch(m.home, m.away, dateStr, leagueID, matchday)
            lastPlayed[m.home] = current
            lastPlayed[m.away] = current
        end
        current = current + 5 * 86400
    end
end

-- REUSABLE KO generator: works for Ro32 → Ro16 → QF → SF → Final
-- Call it with currentMatchday (e.g. 3 for groups → Ro32, 4 for Ro32 → Ro16, etc.)
function WorldCup:generateNextKnockoutRound(currentMatchday)
    local leagueID = WORLD_CUP_LEAGUE_ID
    local matches = (sessionVars.get("LeagueMatchData") or {})[leagueID] or {}
    local nextMatchday = currentMatchday + 1

    -- Special: groups done → Ro32 (need qualifiers logic)
    if currentMatchday == 3 then
        local wcTeams = (sessionVars.get("LeagueTeams") or {})[leagueID] or DEFAULT_TEAMS
        local winners = {}
        local runners = {}
        local thirds = {}
        local letters = {"A","B","C","D","E","F","G","H","I","J","K","L"}

        for _, letter in ipairs(letters) do
            local standing = getOrderedGroup(self, matches, letter, wcTeams[letter])
            table.insert(winners, standing[1].teamID)
            table.insert(runners, standing[2].teamID)
            if standing[3] then table.insert(thirds, standing[3]) end
        end

        -- Rank thirds
        table.sort(thirds, function(a,b)
            if a.points ~= b.points then return a.points > b.points end
            if a.gd ~= b.gd then return a.gd > b.gd end
            if a.goals ~= b.goals then return a.goals > b.goals end
            return a.name < b.name
        end)
        local bestThirds = {}
        for i = 1, 8 do bestThirds[i] = thirds[i] and thirds[i].teamID end

        -- Deterministic Ro32: winners vs best thirds + runners paired
        local teams = {}
        for _, w in ipairs(winners) do table.insert(teams, w) end
        for _, t in ipairs(bestThirds) do table.insert(teams, t) end
        for _, r in ipairs(runners) do table.insert(teams, r) end

        -- Fixed order pairing
        local fixtures = {}
        for i = 1, 16 do
            table.insert(fixtures, {home = teams[i], away = teams[i+16]})
        end

        local dates = {"2026-06-30", "2026-07-01", "2026-07-02", "2026-07-03"}
        local d = 1
        for _, f in ipairs(fixtures) do
            addMatch(f.home, f.away, dates[d], leagueID, nextMatchday)
            d = (d % 4) + 1
        end
        return
    end

    -- Normal KO rounds: just pair winners of current round
    local winners = {}
    for _, m in ipairs(matches) do
        if m.matchday == currentMatchday and m.played then
            local homeScore = m.pen and (m.homePenScores + m.homeScore) or m.homeScore
            local awayScore = m.pen and (m.awayPenScores + m.awayScore) or m.awayScore
            local winner = (homeScore or 0) > (awayScore or 0) and m.homeID or m.awayID
            table.insert(winners, winner)
        end
    end

    -- Sequential pairing (deterministic)
    local dates = {
        [5] = {"2026-07-06", "2026-07-07"},
        [6] = {"2026-07-10", "2026-07-11"},
        [7] = {"2026-07-14", "2026-07-15"},
        [8] = {"2026-07-19"}
    }
    local roundDates = dates[nextMatchday] or {"2026-07-19"}
    local d = 1

    for i = 1, #winners, 2 do
        if winners[i+1] then
            addMatch(winners[i], winners[i+1], roundDates[d], leagueID, nextMatchday)
            d = (d % #roundDates) + 1
        end
    end
end

-- Auto progress: checks if current round finished → generates next
function WorldCup:progressToNextRound()
    local leagueID = WORLD_CUP_LEAGUE_ID
    local matches = (sessionVars.get("LeagueMatchData") or {})[leagueID] or {}

    local maxPlayed = 0
    for _, m in ipairs(matches) do
        if m.played and m.matchday > maxPlayed then maxPlayed = m.matchday end
    end

    if maxPlayed == 0 then return false end

    local roundDone = true
    for _, m in ipairs(matches) do
        if m.matchday == maxPlayed and not m.played then 
            roundDone = false 
            break 
        end
    end

    if not roundDone then return false end

    -- If the round that just finished is the Final (matchday 8)
    if maxPlayed == 8 then
        -- Find the final match entry
        for _, match in ipairs(matches) do
            if match.matchday == 8 and match.played then
                local test = {homeID = 9, awayID = 1, homeScore = 3, awayScore = 1}
                NewsCenter:queueMatchNews(self:getLoc(), "Final", match)
                break  -- there's only one final
            end
        end
        return false  -- tournament over
    end

    if maxPlayed >= 8 then return false end  -- safety, shouldn't hit

    -- Otherwise generate next knockout round as before
    self:generateNextKnockoutRound(maxPlayed)
    return true
end

function WorldCup:isCurrentRoundComplete()
    local leagueID = WORLD_CUP_LEAGUE_ID
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    local matches = leagueMatchData[leagueID] or {}

    if #matches == 0 then return true end

    for _, match in ipairs(matches) do
        if match.leagueID == leagueID and not match.played then
            return false
        end
    end

    return true
end

function WorldCup:getCurrentRound()
    local matches = (sessionVars.get("LeagueMatchData") or {})[WORLD_CUP_LEAGUE_ID] or {}
    local maxPlayed = 0
    for _, m in ipairs(matches) do
        if m.played and m.matchday > maxPlayed then maxPlayed = m.matchday end
    end
    if maxPlayed <= 3 then return "Group Stage"
    elseif maxPlayed == 4 then return "Round of 32"
    elseif maxPlayed == 5 then return "Round of 16"
    elseif maxPlayed == 6 then return "Quarter-Finals"
    elseif maxPlayed == 7 then return "Semi-Finals"
    elseif maxPlayed >= 8 then return "Final"
    else return "Group Stage" end
end

return WorldCup
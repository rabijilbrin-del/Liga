-- DateUtils.lua
-- A utility module for handling date-related operations

local DateUtils = {}

-- Constants
DateUtils.DAYS_IN_MONTH = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
DateUtils.MONTH_NAMES_SHORT = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"}
DateUtils.MONTH_NAMES_FULL = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}
DateUtils.DAY_NAMES = {"SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"}

-- Utility function to check if a year is a leap year
function DateUtils:isLeapYear(year)
    return year % 4 == 0 and (year % 100 ~= 0 or year % 400 == 0)
end

-- Utility function to get days in a given month
function DateUtils:getDaysInMonth(month, year)
    if month == 2 and self:isLeapYear(year) then return 29 end
    return self.DAYS_IN_MONTH[month]
end

-- Parse date from DD/MM/YY format to a table
function DateUtils:parseDate(dateStr)
    local day, month, year = dateStr:match("^(%d%d)/(%d%d)/(%d%d)$")
    if not (day and month and year) then 
        print("Invalid date format: " .. tostring(dateStr))
        return nil 
    end
    day, month, year = tonumber(day), tonumber(month), tonumber(year)
    if month < 1 or month > 12 or day < 1 or day > self:getDaysInMonth(month, 2000 + year) then
        print("Invalid date values: " .. tostring(dateStr))
        return nil
    end
    return {day = day, month = month, year = 2000 + year}
end

-- Convert MMDDYY to DD/MM/YY for comparison
function DateUtils:convertMatchDateToStandard(dateStr)
    if not dateStr or not dateStr:match("^%d%d%d%d%d%d$") then
        print("Invalid match date format: " .. tostring(dateStr))
        return nil
    end
    local month, day, year = dateStr:match("^(%d%d)(%d%d)(%d%d)$")
    month, day, year = tonumber(month), tonumber(day), tonumber(year)
    if not (month and day and year) or month < 1 or month > 12 or day < 1 or day > self:getDaysInMonth(month, 2000 + year) then
        print("Invalid date values: " .. tostring(dateStr))
        return nil
    end
    return string.format("%02d/%02d/%02d", day, month, year)
end

-- Compare two dates (DD/MM/YY format) for sorting
function DateUtils:compareDates(dateStr1, dateStr2)
    local date1 = self:parseDate(dateStr1)
    local date2 = self:parseDate(dateStr2)
    if not date1 or not date2 then return false end
    local time1 = os.time({day = date1.day, month = date1.month, year = date1.year})
    local time2 = os.time({day = date2.day, month = date2.month, year = date2.year})
    return time1 < time2
end

-- Get the next day
function DateUtils:getNextDay(dateStr)
    local date = self:parseDate(dateStr)
    if not date then return nil end
    local day, month, year = date.day, date.month, date.year
    day = day + 1
    if day > self:getDaysInMonth(month, year) then
        day = 1
        month = month + 1
        if month > 12 then
            month = 1
            year = year + 1
        end
    end
    return {day = day, month = month, year = year}
end

-- Get the previous day
function DateUtils:getPreviousDay(dateStr)
    local date = self:parseDate(dateStr)
    if not date then return nil end
    local day, month, year = date.day, date.month, date.year
    day = day - 1
    if day < 1 then
        month = month - 1
        if month < 1 then
            month = 12
            year = year - 1
        end
        day = self:getDaysInMonth(month, year)
    end
    return {day = day, month = month, year = year}
end

-- Format date as "DAYNAME, MON DD"
function DateUtils:formatDateAsDayName(date)
    if not date or not date.day or not date.month or not date.year or date.month < 1 or date.month > 12 then
        print("Invalid date for formatting: " .. tostring(date))
        return "UNKNOWN, JAN 01"
    end
    local time = os.time({day = date.day, month = date.month, year = date.year, hour = 0, min = 0, sec = 0})
    local dayIndex = tonumber(os.date("%w", time))
    local dayName = self.DAY_NAMES[dayIndex + 1] or "UNKNOWN"
    local monthName = self.MONTH_NAMES_SHORT[date.month] or "JAN"
    return string.format("%s, %s %02d", dayName, monthName, date.day)
end

-- Format date as "Month Day" (e.g., "August 13")
function DateUtils:formatDateAsMonthDay(dateStr)
    local date = self:parseDate(dateStr)
    if not date then return "" end
    return string.format("%s %d", self.MONTH_NAMES_FULL[date.month], date.day)
end

-- Validate match date in MMDDYY format
function DateUtils:isValidMatchDate(dateStr)
    if not dateStr or not dateStr:match("^%d%d%d%d%d%d$") then return false end
    local month, day, year = dateStr:match("^(%d%d)(%d%d)(%d%d)$")
    month, day, year = tonumber(month), tonumber(day), tonumber(year)
    if not (month and day and year) then return false end
    if month < 1 or month > 12 or day < 1 or year < 0 or year > 99 then return false end
    local maxDays = self:getDaysInMonth(month, year)
    return day <= maxDays
end

-- Check if a date has been reached
function DateUtils:isDateReached(currentDateStr, targetDateStr)
    local current = self:parseDate(currentDateStr or "01/08/24")
    local target = self:parseDate(targetDateStr)
    if not current or not target then return false end
    return os.time({ day = current.day, month = current.month, year = current.year }) >=
           os.time({ day = target.day, month = target.month, year = target.year })
end

-- Create a new DateUtils instance
function DateUtils:new()
    local o = {}
    setmetatable(o, self)
    self.__index = self
    return o
end

return DateUtils
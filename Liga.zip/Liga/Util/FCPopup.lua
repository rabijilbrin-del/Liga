local FCPopup = {}
local popupData = {}
local responseId = nil
local _nav = _nav or nil
local responseCallback = nil

function FCPopup:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.nav = init.nav
  o.popupData = {}
  return o
end

function FCPopup:displayPopup(msg, btnData, callback)
  popupData.message = msg
  popupData.buttonData = btnData
  _nav = _nav or self.nav
  responseCallback = callback
  _nav.Event(nil, "evt_show_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/Popup/Popup.vvm"})
end

function FCPopup:getPopupData()
  return popupData
end

function FCPopup:setResponse(rId)
  responseId = rId
  _nav.Event(nil, "evt_hide_overlay")
  if responseCallback then
    responseCallback(rId) 
    responseCallback = nil
  end
end

function FCPopup:getResponse(msg, btnData, callback)
    self:displayPopup(msg, btnData, callback)
    local _response = responseId
    responseId = nil
    return _response
end

return FCPopup
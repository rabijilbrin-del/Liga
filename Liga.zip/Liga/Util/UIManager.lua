local sessionVars = ...
local UIManager = {}

function initTheme(im)
  im.Subscribe("theme", function() UIManager.setTheme(im) end)
  im.Subscribe("priColor", function() UIManager.setTheme(im) end)
  im.Subscribe("bnd_rectColor", function() UIManager.setTheme(im) end)
end

function UIManager.setTheme(im, id)
  id = id or sessionVars.get("currentUserLeagueID")
  im.Publish("theme", {name = "$CareerTable", id = id})
  im.Publish("priColor", UIManager.getPriColor())
  im.Publish("bnd_rectColor", UIManager.getPriColor())
end

function UIManager.getPriColor()
  local id = sessionVars.get("currentUserLeagueID")
  local priColor = nil
    if id == 13 then
      priColor = 0x120019 --epl
    elseif id == 2236 then
      priColor = 0x00052C --ucl
    elseif id == 2235 then
      priColor = 0x001630 --bri super league      
    elseif id == 16 then
      priColor = 0x00013A --ligue1        
    elseif id == 31 then
      priColor = 0x00013A --serieA      
    elseif id == 19 then
      priColor = 0x1D1B1B --bundesliga   
    elseif id == 53 then
      priColor = 0x380303 --laliga           
    else
      priColor = 0xFF25262F --default
    end
  return priColor
end

function UIManager.getLeagueTheme()
  return "0x51128A"
end

function UIManager.handleLeagueUI(screenName, im, bnds)
  if #bnds < 1 then
    return
  end

  local color = UIManager.getPriColor()
  local image = "$eplBg"
  local leagueID = 13
  local changed = false

  if not sessionVars.get("UIData") then
    sessionVars.set("UIData", {})
  end
  local UIData = sessionVars.get("UIData")

  if not UIData[screenName] then
    UIData[screenName] = {}
  end
  local currentData = UIData[screenName][leagueID]
  if not currentData then
    UIData[screenName][leagueID] = {color = color, image = image}
    changed = true
  end
  currentData = UIData[screenName][leagueID]

  for i = 1, #bnds do
    if bnds[i] and bnds[i].type == "generic" then
      im.Subscribe(bnds[i].bnd, function() im.Publish(bnds[i].bnd, currentData.color) end)
    elseif bnds[i] and bnds[i].type == "img" then
      im.Subscribe(bnds[i].bnd, function() im.Publish(bnds[i].bnd, currentData.image) end)
    end
  end

  if changed then
    sessionVars.set("UIData", UIData)
  end
end

return UIManager
  
-- MatchSelect.lua  (Liga)
-- All coroutine.yield() calls removed from:
--   fitnessRecovery, processTransfersTask, updateTeamFormCache,
--   AITransfers:processPendingTransfers
-- These are now plain functions; scheduling / time-budget is enforced
-- externally by the BackgroundProcessor's tick deadline.

local SeasonInit, PlayerAge, playerData, Brain, data, LiveTransfers, Squads,
      AITransfers, CareerFriendlies, glInstancePasser, Timer, FCPopup, Date,
      Modes, NewsCenter, UI, sessionVars, DateUtils, BackgroundProcessor,
      TaskRow, MatchSimulator, MatchHandler, TeamData, TeamStats, Save,
      UIManager, Serializer, LeagueNames, Callback, Notification = ...

local Liga = {}
gamemode = "careerMode"
local TeamList      = sessionVars.get("TeamList")
local ACT_ADVANCE   = "act_advance"
local ACT_EXIT      = "act_exit"
local BND_REALTIME  = "bnd_realtime"
local PROGRESS      = "act_progressdate"
local BND_DATE1     = "bnd_date1"
local BND_DATE2     = "bnd_date2"
local BND_DATE3     = "bnd_date3"
local bndTeamCrest = "bnd_team_crest"
local bndTeamName = "bnd_team_name"
local BND_IS_DATE_SIM     = "bnd_isDateSim"
local BND_IS_NOT_DATE_SIM = "bnd_isNotDateSim"
local UIbnds = {"bnd_headline","bnd_likeNo","bnd_commentNo","bnd_newsDate",
                "bnd_sourceImg","bnd_sourceName"}

-- ── Helpers ────────────────────────────────────────────────────────────────

local function ordinal(n)
    local suffix = "TH"
    if n % 100 < 11 or n % 100 > 13 then
        local d = n % 10
        if     d == 1 then suffix = "ST"
        elseif d == 2 then suffix = "ND"
        elseif d == 3 then suffix = "RD"
        end
    end
    return tostring(n) .. suffix
end

local function getMatchupInfo(daysToFixture, matchType)
    if daysToFixture == 0 then return "Matchday" end
    return daysToFixture <= 7
        and ("Next Fixture in " .. daysToFixture
             .. (daysToFixture > 1 and " days" or " day"))
        or "No upcoming fixtures"
end

local function publishMatchDetails(self, daysToFixture, matchDateStr, homeID, awayID, homeName, awayName, matchType, lgId)
local now = os.clock()

    if self.lastMatchDetailsPublish and (now - self.lastMatchDetailsPublish) < 0.1 then
        return
    end

    self.lastMatchDetailsPublish = now        
    if not self.im then return end
    UIManager.setTheme(self.im, lgId)
    local matchDateLabel = daysToFixture <= 7
        and self.DateUtils:formatDateAsMonthDay(matchDateStr) or ""
    local leagueLabel    = daysToFixture <= 7
        and (LeagueNames[lgId]
             or self.loc.LocalizeString("LeagueName_Abbr15_" .. lgId)) or ""
    local matchTag = daysToFixture <= 7
        and (matchType == "League"      and "League"   or
             matchType == "Friendly"    and "#Friendly" or
             matchType == "Competition" and "#Cup"      or "#Match")
        or ""
    self.HomeCrest = self.HomeCrest or { id = 0 }
    self.AwayCrest = self.AwayCrest or { id = 0 }
    self.HomeCrest.id = homeID or 0
    self.AwayCrest.id = awayID or 0
    self.im.Publish("bnd_matchup_label",  getMatchupInfo(daysToFixture, matchType or "League"))
    self.im.Publish("bnd_matchdate_label",daysToFixture == 0 and "Today" or matchDateLabel)
    self.im.Publish("bnd_league_label",   leagueLabel)
    self.im.Publish("matchleague",        daysToFixture <= 7
        and {name="$LeagueLogo", id=lgId} or {})
    self.im.Publish("bnd_matchtag",       matchTag)
    self.im.Publish("bnd_home_crest",     daysToFixture <= 7 and self.HomeCrest or {})
    self.im.Publish("bnd_away_crest",     daysToFixture <= 7 and self.AwayCrest or {})
    self.im.Publish("bnd_home_name",      daysToFixture <= 7 and (homeName or ""):upper() or "")
    self.im.Publish("bnd_away_name",      daysToFixture <= 7 and (awayName or ""):upper() or "")
end

local function findCurrentDayMatch(self, dateStr, currentSelectedTeamID)
    local standardDate = self.DateUtils:parseDate(dateStr or "01/08/25")
    if not standardDate then return nil, nil, nil end
    local currentTime = os.time({
        day=standardDate.day, month=standardDate.month, year=standardDate.year,
        hour=0, min=0, sec=0
    })
    local matches = sessionVars.get("MatchData") or {}
    for i, match in ipairs(matches) do
        if (match.matchType == "League" or match.matchType == "Friendly"
        or  match.matchType == "Competition")
        and (match.homeID == currentSelectedTeamID
        or   match.awayID == currentSelectedTeamID) then
            local matchDateStr = self.DateUtils:convertMatchDateToStandard(match.date)
            if matchDateStr then
                local matchDate = self.DateUtils:parseDate(matchDateStr)
                if matchDate then
                    local matchTime = os.time({
                        day=matchDate.day, month=matchDate.month, year=matchDate.year,
                        hour=0, min=0, sec=0
                    })
                    if matchTime == currentTime then
                        return match.homeID, match.awayID, i
                    end
                end
            end
        end
    end
    return nil, nil, nil
end

local function daysToNextMatch(self, currentDateStr, currentSelectedTeamID)
    local currentDate = self.DateUtils:parseDate(currentDateStr or "01/08/25")
    if not currentDate then
        return nil, nil, nil, nil, nil, "Invalid current date"
    end
    local currentTime = os.time({
        day=currentDate.day, month=currentDate.month, year=currentDate.year,
        hour=0, min=0, sec=0
    })
    local matches        = sessionVars.get("MatchData") or {}
    local nextMatchTime  = nil
    local nextMatchDateStr= nil
    local homeID, awayID, matchType, lgId

    for i, match in ipairs(matches) do
        if (match.matchType == "League" or match.matchType == "Friendly"
        or  match.matchType == "Competition")
        and (match.homeID == currentSelectedTeamID
        or   match.awayID == currentSelectedTeamID) then
            local matchDateStr = self.DateUtils:convertMatchDateToStandard(match.date)
            if matchDateStr and self.DateUtils:isValidMatchDate(match.date) then
                local matchDate = self.DateUtils:parseDate(matchDateStr)
                if matchDate then
                    local matchTime = os.time({
                        day=matchDate.day, month=matchDate.month, year=matchDate.year,
                        hour=0, min=0, sec=0
                    })
                    if matchTime >= currentTime
                    and (not nextMatchTime or matchTime < nextMatchTime) then
                        nextMatchTime    = matchTime
                        nextMatchDateStr = matchDateStr
                        homeID           = match.homeID
                        awayID           = match.awayID
                        lgId             = match.leagueID
                        matchType        = match.matchType
                    end
                end
            end
        end
    end

    if not nextMatchTime then
        return nil, nil, nil, getTeamLeague(currentSelectedTeamID), nil, "No future match dates found"
    end
    local daysDiff = math.floor((nextMatchTime - currentTime) / 86400)
    return daysDiff, nextMatchDateStr, homeID, awayID, lgId, matchType, nil
end

local function formatDeadlineColor(minutes)
    return minutes <= 60 and "0xFF0D00" or "0xFFE300"
end

-- ── Module-level state ─────────────────────────────────────────────────────

ligaId         = 1
loaded         = loaded or "no"
mode           = 1
currentMatch   = { HomeTeamID=0, AwayTeamID=0, HomeKitIndex=0, AwayKitIndex=1 }
local matchesPlayed = 0
local matchday      = false

-- ── Constructor ────────────────────────────────────────────────────────────

function Liga:new(init)
    local o = init or {}
    setmetatable(o, self)
    self.__index = self
    initTheme(o.im)
    o.services = {
        settingsService       = o.api("SettingsService"),
        SquadManagementService= o.api("SquadMgtService"),
    }       
 
if not sessionVars.get("notifNavHooked") then

    local origNav = o.nav.Event

    o.nav.Event = function(c1, c2, c3)
        origNav(c1, c2, c3)

        if Notification and Notification.update then
            Notification:update(c2)
        end
    end

    sessionVars.set("notifNavHooked", true)
end
     
    if displayMatchdayFixtures then
        o.nav.Event(nil, "evt_show_overlay", {
            vvm  = "/flows/mainflow/gamemodes/Liga/Screens/MatchResults/MatchResults.vvm",
            data = {nav = o.nav}
        })
        return o
    end
    if o.data.currentScreenFlow == "onCareerModeEntri" then return o end

    local displaynews = sessionVars.get("InCareerMode")
    o.save         = Save:new({api = o.api, Timer = Timer})
    o.save:openBrowser()
    -- SeasonInit is constructed below (after o.Modes) so it can receive a Modes ref
  o.im.Subscribe(bndTeamCrest, function()  
    o.im.Publish(bndTeamCrest, {name = "$Crest64x64", id = currentSelectedTeamID})   
  end)
  
  o.im.Subscribe(bndTeamName, function()  
        o.im.Publish(bndTeamName, o.loc.LocalizeString("TeamName_Abbr15_"..currentSelectedTeamID))       
    end) 
    o.backgroundProcessor = BackgroundProcessor:new({
        im           = o.im,
        save         = o.save,
        Timer        = Timer,
        idleTimeout  = 0,
        maxFrameTime = 0,
        debugOverlay = {
            enabled = false,    
            publish = function(data) end,
        },
    })

    o.passedInstance = glInstancePasser:loadInstance()
    o.round          = 1
    o.test           = o.passedInstance.test
    o.allTeams       = o.passedInstance.allTeams
    o.brain          = Brain:new()
    o.squads         = Squads:new({services = o.services})
    o.transferSystem = LiveTransfers:new({
        transferHandler = function(...) return o:_handleTransfer(...) end
    })
    o.FCPopup    = FCPopup:new({nav = o.nav})
    o.Modes      = Modes:new({nav=o.nav, loc=o.loc, api=o.api})
    -- Now construct SeasonInit with Modes so it can trigger UCL init each new season
    o.SeasonInit = SeasonInit:new({
        api=o.api, nav=o.nav, brain=Brain, save=o.save, Timer=Timer, Modes=o.Modes
    })
    o.Date       = Date:new({haltAdvance=function() o:NoMatch() end, Modes=o.Modes, api = o.api})
    o.DateUtils  = DateUtils:new()
    o.uiValues   = {80, 390, 700}
    o.newsCenter = NewsCenter:new({im=o.im, loc=o.loc})
    o.serializer = Serializer:new({
        sessionVars=sessionVars, nav=o.nav, Date=o.Date, Timer=Timer
    })

    o.models = {
        PlayerAge  = PlayerAge:new({api=o.api, loc=o.loc, nav=o.nav}),
        playerData = playerData:new({api=o.api, loc=o.loc, nav=o.nav}),
        AITransfers= AITransfers:new({
            services=o.services, loc=o.loc, nav=o.nav,
            squads=o.squads, save=o.save
        }),
    }
    o.TeamStats = TeamStats:new({loc = o.loc})    
    o.Notification = Notification:new({im = o.im, nav = o.nav})
    
    -- Wrap UI registration methods to capture user interactions.
    local origRA = o.im.RegisterAction
    o.im.RegisterAction = function(actionName, handler)
        origRA(actionName, function(actionName, data)
            o:onUserInteraction()
            if handler then handler(actionName, data) end
        end)
    end

    local origRDA = o.im.RegisterDataAction
    o.im.RegisterDataAction = function(binding, actionName, handler)
        origRDA(binding, actionName, function(binding, actionName, data)
            o:onUserInteraction()
            if handler then handler(binding, actionName, data) end
        end)
    end

    local origAAH = o.nav.AddActionHandler
    o.nav.AddActionHandler = function(name, param1, param2, handler)
        origAAH(name, param1, param2, function()
            o:onUserInteraction()
            if handler then handler() end
        end)
    end

    o.ui = UI:new({
        im                 = o.im,
        nav                = o.nav,
        backgroundProcessor= o.backgroundProcessor,
        playerData         = playerData,
        swipeTabs          = function(sx, tx, cb) o:_swipeTab(sx, tx, cb) end,
        animateTabButtons  = function(tn, cfg, dir, atype, sx, cb)
            o:_animateTabButtons(tn, cfg, dir, atype, sx, cb)
        end,
        TeamStats  = o.TeamStats,
        serializer = o.serializer,
    })

    o.UItasks  = TaskRow.new({im=o.im, nav=o.nav})
    o.nav.AddActionHandler("Test", false, nil, function() o:testScript() end)

    o.currentOptions    = o.services.settingsService.GetCurrentOptions()
    o.Banner            = { name="$Tab_CupInfo", id=1 }
    o.HomeCrest         = { name="$Crest", id=0 }
    o.AwayCrest         = { name="$Crest", id=0 }
    o.dateTimer         = nil
    o.deadlineTimer     = nil
    o.matchdayTimer     = nil
    o.dateYPositions    = {-100, -20, 60}
    o.isDateSim         = false
    o.isAutoAdvancing   = false
    o.isAnimating       = false
    o.isMatchdayAnimating = false
    o.swipeTimer        = nil
    o.btnTimer          = nil
    o.isSwipeAnimating  = false
    o.isBtnAnimating    = false
    o.transfersDoneForDate = {}
    o.lastTransferDate  = nil
    o.swipeX            = 0
    o.lastInteractionTime = os.clock()
    o.newsTimer         = nil
    o.isNewsAnimating   = false
    o.simMode           = false
    o.deadlineTime      = sessionVars.get("deadlineTime") or 10 * 60

    o.matchSimulator = MatchSimulator:new({
        DateUtils             = o.DateUtils,
        sessionVars           = sessionVars,
        services              = o.services,
        currentSelectedTeamID = currentSelectedTeamID,
        Modes                 = o.Modes,
    })
    o.matchHandler = MatchHandler:new({
        DateUtils   = o.DateUtils,
        sessionVars = sessionVars,
    })

    -- ── Register background tasks ─────────────────────────────────────────
    o.backgroundProcessor:registerIntervalTask(
        function() o:processTransfersTask() end,
        "Transfers", 0.5, 1, true
    )
    o.backgroundProcessor:registerIntervalTask(
        function() o:processScoutingTask() end,
        "Scouting", 0.5, 1, true
    )
    if displaynews then
        o.backgroundProcessor:registerIntervalTask(function()
            local rand = math.random(1, 10)
            local dir  = rand < 6 and 1 or -1
            o:displayNews(dir)
        end, "newsUpdate", 5, 5, true)
    end

    -- Seed RNG
    math.randomseed(os.clock() * 1352 + os.time())
    local random2 = math.random(1)

    o.im.Subscribe("bnd_ads", function()
        o.Banner.id = random2
        o.im.Publish("bnd_ads", o.Banner)
    end)

    o.publishDate1 = function()
        local nextDate = o.DateUtils:getNextDay(GLOBAL_DATE_PLACEHOLDER or "01/08/25")
        o.im.Publish(BND_DATE1, o.DateUtils:formatDateAsDayName(nextDate))
    end
    o.publishDate2 = function()
        if Date:isDeadline() then
            o.im.Publish(BND_DATE2, "DEADLINE DAY")
        else
            local currentDate = o.DateUtils:parseDate(GLOBAL_DATE_PLACEHOLDER or "01/08/25")
            o.im.Publish(BND_DATE2, o.DateUtils:formatDateAsDayName(currentDate))
        end
    end
    o.publishDate3 = function()
        local prevDate = o.DateUtils:getPreviousDay(GLOBAL_DATE_PLACEHOLDER or "01/08/25")
        o.im.Publish(BND_DATE3, o.DateUtils:formatDateAsDayName(prevDate))
    end

    o.im.Subscribe("bnd_dateAA3",      function() o.im.Publish("bnd_dateAA3", 1)  end)
    o.im.Subscribe("dateTS1",          function() o.im.Publish("dateTS1", 20)      end)
    o.im.Subscribe("displaynews",      function() o.im.Publish("displaynews", displaynews) end)
    o.im.Subscribe("dateTS2",          function() o.im.Publish("dateTS2", 40)      end)
    o.im.Subscribe("bnd_showAdvanceBtn",function() o.im.Publish("bnd_showAdvanceBtn", true) end)
    o.im.Subscribe(BND_DATE1,          o.publishDate1)
    o.im.Subscribe(BND_DATE2,          o.publishDate2)
    o.im.Subscribe(BND_DATE3,          o.publishDate3)
    o.im.Subscribe(BND_IS_DATE_SIM,    function() o:dateAnim() end)
    o.im.Subscribe("bnd_isdeadline",   function() o.im.Publish("bnd_isdeadline", Date:isDeadline()) end)
    o.im.Subscribe("bnd_deadlinetime", function() o:publishDeadlineTime() end)
    o.im.Subscribe("bnd_deadlinecolor",function() o.im.Publish("bnd_deadlinecolor", formatDeadlineColor(o.deadlineTime)) end)
    o.im.Subscribe(BND_IS_NOT_DATE_SIM,function() o:dateAnim() end)
    o.im.Subscribe("bnd_epl_visible",  function() o:publishBg() end)
    o.im.Subscribe("bnd_home_crest",   function() o:publishFinishLabel() end)
    o.im.Subscribe("bnd_away_crest",   function() o:publishFinishLabel() end)
    o.im.Subscribe("matchleague",      function() o:publishFinishLabel() end)
    o.im.Subscribe("bnd_home_name",    function() o:publishFinishLabel() end)
    o.im.Subscribe("bnd_away_name",    function() o:publishFinishLabel() end)
    o.im.Subscribe("bnd_homeRank",     function() o:publishFinishLabel() end)
    o.im.Subscribe("bnd_homeRankX",    function() o:publishFinishLabel() end)
    o.im.Subscribe("bnd_awayRank",     function() o:publishFinishLabel() end)
    o.im.Subscribe("bnd_awayRankX",    function() o:publishFinishLabel() end)
    o.im.Subscribe("simmode",          function() o:toggleSim("init") end)

    o.crestAnimBnds = {"crestsizeW","crestsizeH","cresthomeX","crestawayX","crestalpha"}
    for i = 1, #o.crestAnimBnds do
        o.im.Subscribe(o.crestAnimBnds[i], function()
            o.im.Publish("crestsizeW",  55)
            o.im.Publish("crestsizeH",  55)
            o.im.Publish("cresthomeX", -230)
            o.im.Publish("crestawayX", -160)
            o.im.Publish("crestalpha",   1)
        end)
    end

    o.im.RegisterAction(ACT_ADVANCE, function(actionName, data)
        if data then o:PlayMatch(data) end
    end)
    o.im.RegisterAction(ACT_EXIT,    function() o:exitCareer() end)
    o.im.RegisterAction("act_togglesim", function() o:toggleSim() end)

    o.im.Subscribe("bnd_finish_label",   function() o:publishFinishLabel() end)
    o.im.Subscribe("bnd_date_label",     function() o:publishFinishLabel() end)
    o.im.Subscribe("bnd_matchup_label",  function() o:publishFinishLabel() end)
    o.im.Subscribe("bnd_matchdate_label",function() o:publishFinishLabel() end)
    o.im.Subscribe("bnd_matchtag",       function() o:publishFinishLabel() end)
    o.im.Subscribe("bnd_league_label",   function() o:publishFinishLabel() end)
    o.im.Subscribe("bnd_advance_label",  function() o:publishFinishLabel() end)
    o.im.Subscribe("bnd_month_label",    function() o:publishFinishLabel() end)
    o.newsCenter:subscribeUIBnds()

    for i = 1, 3 do
        o.im.Subscribe("bnd_date" .. i .. "Y", function() o:dateAnim() end)
    end
    o.im.Subscribe("deadlineclock", function() o:publishDeadlineTime() end)
    o.nav.AddActionHandler("killScreen", false, nil, function() o:finalize() end)
    o.im.RegisterAction(PROGRESS, function()
        o:NoMatch(); o:publishDate1(); o:publishDate2(); o:publishDate3()
    end)

    o:fitnessRecovery(GLOBAL_DATE_PLACEHOLDER)
    glInstancePasser:getInstance(o)
    o.newsCenter:displayNews()
    o:dateAnim()
    o.backgroundProcessor:start()
    collectgarbage("collect")
    return o
end

-- ── Sim Mode Toggle ────────────────────────────────────────────────────────

function Liga:toggleSim(data)
    if data ~= "init" then self.simMode = not self.simMode end
    self.im.Publish("simmode", "Sim Mode: " .. (self.simMode and "ON" or "OFF"))
end

-- ── News Display ───────────────────────────────────────────────────────────

function Liga:displayNews(dir, callback)
    dir = dir or 1
    if self.newsTimer then
        self.newsTimer:finalize(); self.newsTimer = nil
    end
    self.isNewsAnimating = true
    local phaseDuration  = 0.15
    local stepInterval   = 0.016
    local stepsPerPhase  = math.max(1, math.floor(phaseDuration / stepInterval))
    local totalSteps     = stepsPerPhase * 2

    local phase1StartPos  = 20
    local phase1TargetPos = dir == 1 and -80 or 120
    local phase2StartPos  = dir == 1 and 120 or -80
    local phase2TargetPos = 20

    local function animateStep(step)
        if not self.isNewsAnimating then
            self.newsTimer = nil
            if callback then callback() end
            return
        end
        if step > totalSteps then
            self.newsTimer = nil
            self.isNewsAnimating = false
            self.im.Publish("news_position", phase2TargetPos)
            self.im.Publish("news_alpha", 1)
            if callback then callback() end
            return
        end
        local isPhase1  = step <= stepsPerPhase
        local phaseStep = isPhase1 and step or (step - stepsPerPhase)
        local t         = phaseStep / stepsPerPhase
        local easedT    = 1 - (1 - t) * (1 - t)

        if isPhase1 then
            local pos   = phase1StartPos + (phase1TargetPos - phase1StartPos) * easedT
            local alpha = 1 + (0 - 1) * easedT
            self.im.Publish("news_position", math.floor(pos + 0.5))
            self.im.Publish("news_alpha",    math.floor(alpha * 100 + 0.5) / 100)
        else
            if phaseStep == 1 then
                self.newsCenter:displayNews()
                self.im.Publish("news_position", phase2StartPos)
                self.im.Publish("news_alpha", 1)
            end
            local pos = phase2StartPos + (phase2TargetPos - phase2StartPos) * easedT
            self.im.Publish("news_position", math.floor(pos + 0.5))
            self.im.Publish("news_alpha", 1)
        end

        self.newsTimer = Timer:new({
            id="newsTimer_"..step, interval=stepInterval, reps=1,
            onTimerComplete = function() animateStep(step + 1) end
        })
        self.newsTimer:start()
    end

    self.newsTimer = Timer:new({
        id="newsTimer_start", interval=0, reps=1,
        onTimerComplete = function()
            if self.isNewsAnimating then
                animateStep(1)
            else
                self.newsTimer = nil
                if callback then callback() end
            end
        end
    })
    self.newsTimer:start()
end

-- ── Fitness Recovery ───────────────────────────────────────────────────────
-- Runs once at startup (not via BackgroundProcessor); plain loop, no yields.

function Liga:fitnessRecovery(currentDate)
    local batchSize = 10
    local lineup    = self.services.SquadManagementService
                        .GetCurrentPlayerLineup(0, currentSelectedTeamID, 0) or {}
    local teamPlayers = {}

    for i = 1, #lineup, batchSize do
        for j = i, math.min(i + batchSize - 1, #lineup) do
            teamPlayers[lineup[j].playerName] = true
        end
        -- No coroutine.yield() — plain loop
    end

    local recoveryKeys = {}
    for playerName in pairs(injuryRecoveryDate or {}) do
        table.insert(recoveryKeys, playerName)
    end

    for i = 1, #recoveryKeys, batchSize do
        for j = i, math.min(i + batchSize - 1, #recoveryKeys) do
            local playerName  = recoveryKeys[j]
            local recoveryDate= injuryRecoveryDate[playerName]
            if self.DateUtils:isDateReached(currentDate, recoveryDate) then
                isSuspended[playerName]        = 0
                injuryRecoveryDate[playerName]  = nil
                if teamPlayers[playerName] then
                    self:backFromInjury(playerName)
                end
            end
        end
        -- No coroutine.yield()
    end
end

-- ── Team Form Cache ────────────────────────────────────────────────────────
-- Plain function; called inside interval tasks — no yields needed.

function updateTeamFormCache(self)

    local batchSize = 10

    local matches   = sessionVars.get("MatchData") or {}

    if not GLOBAL_MATCHUP_COUNT or GLOBAL_MATCHUP_COUNT < 5 then return end



    TeamFormCache = {}

    for i = 1, #TeamList, batchSize do

        for j = i, math.min(i + batchSize - 1, #TeamList) do

            local teamID = TeamList[j]

            TeamFormCache[teamID] = { wins=0, draws=0, losses=0 }

        end

        -- No coroutine.yield()

    end



    local matchesPerDay  = math.floor(#TeamList / 2)

    local currentMatchday= GLOBAL_MATCHUP_COUNT + 1

    local startMatchday  = math.max(1, currentMatchday - 5)

    local startIndex     = (startMatchday - 1) * matchesPerDay + 1

    local endIndex       = math.min((currentMatchday - 1) * matchesPerDay, #matches)



    for i = startIndex, endIndex, batchSize do

        for j = i, math.min(i + batchSize - 1, endIndex) do

            local match = matches[j]

            local currentLeagueID = sessionVars.get("currentUserLeagueID")

            if match

            and match.leagueID == currentLeagueID

            and (match.matchType == "League"

            or match.matchType == "Competition") then

                local hID = match.homeID

                local aID = match.awayID

                local hs  = match.homeScore or 0

                local as  = match.awayScore or 0

                if TeamFormCache[hID] then

                    if     hs > as then TeamFormCache[hID].wins   = TeamFormCache[hID].wins   + 1

                    elseif hs == as then TeamFormCache[hID].draws  = TeamFormCache[hID].draws  + 1

                    else                 TeamFormCache[hID].losses = TeamFormCache[hID].losses + 1

                    end

                end

                if TeamFormCache[aID] then

                    if     as > hs then TeamFormCache[aID].wins   = TeamFormCache[aID].wins   + 1

                    elseif hs == as then TeamFormCache[aID].draws  = TeamFormCache[aID].draws  + 1

                    else                 TeamFormCache[aID].losses = TeamFormCache[aID].losses + 1

                    end

                end

            end

        end

        -- No coroutine.yield()

    end

end

-- ── Misc module-level patches ──────────────────────────────────────────────

function NewsCenter:refreshNewsCache()
    self.newsCenter:displayNews()
end

-- processPendingTransfers — plain loop, no yields
function AITransfers:processPendingTransfers()
    local batchSize = 10
    local transfers = self:getPendingTransfers() or {}
    for i = 1, #transfers, batchSize do
        for j = i, math.min(i + batchSize - 1, #transfers) do
            -- process transfer[j] here
        end
        -- No coroutine.yield()
    end
end

-- ── Interval Task Handlers ─────────────────────────────────────────────────
-- These are plain functions registered as interval tasks.
-- Time budgeting is enforced by the BackgroundProcessor tick deadline.

function Liga:processTransfersTask()
    if not Date:IsTransferWindowOpen() then return end
    -- batchTransfers() does all the work internally — no post-processing needed.
    self.models.AITransfers:batchTransfers()
end

function Liga:processScoutingTask()
    self.models.AITransfers:batchScouting()
end

-- ── User Interaction ───────────────────────────────────────────────────────

function Liga:onUserInteraction()
    self.lastInteractionTime = os.clock()
    self.backgroundProcessor:pause()
end

-- ── UI Helpers ─────────────────────────────────────────────────────────────

function Liga:clearUI()
    for i = 1, #UIbnds do self.im.Publish(UIbnds[i], "") end
end

function Liga:dateAnim()
    if Date:isDeadline() then
        self.isAnimating = false
        self.im.Publish(BND_IS_DATE_SIM,     false)
        self.im.Publish(BND_IS_NOT_DATE_SIM, true)
        return
    end
    for i = 1, 3 do
        self.im.Publish("bnd_date" .. i .. "Y", self.dateYPositions[i])
    end
    self.im.Publish("dateTS1",          20)
    self.im.Publish("dateTS2",          40)
    self.im.Publish(BND_IS_DATE_SIM,     self.isAnimating)
    self.im.Publish(BND_IS_NOT_DATE_SIM, not self.isAnimating)
end

function Liga:testScript()
    self.nav.Event(nil, "evt_back")
end

function Liga:_handleTransfer(player, team)
    self.transferSystem:replaceSoldPlayer(player, team, self.squads, self.services)
end

function Liga:publishBg()
    self.im.Publish("bnd_epl_visible", self.eplvisible)
end

function Liga:isDateReached(currentDate, recoveryDate)
    return self.DateUtils:isDateReached(currentDate, recoveryDate)
end

local function safeTableConcat(tbl)
    local result = {}
    for i, v in ipairs(tbl) do result[i] = tostring(v) end
    return table.concat(result, ", ")
end

function Liga:publishDeadlineTime()
    local hours   = math.floor(self.deadlineTime / 60)
    self.im.Publish("bnd_isdeadline",   Date:isDeadline())
    self.im.Publish("deadlineclock",    "$clock" .. ((10 - hours) + 1))
    self.im.Publish("bnd_deadlinetime", string.format("%02d:%02d", hours, 0))
    self.im.Publish("bnd_deadlinecolor",formatDeadlineColor(self.deadlineTime))
end

local function formatPositionText(spacecount, textcount)
    local x = 105
    x = x + ((textcount - spacecount) * 26)
    x = x + (spacecount * 2)
    return x
end

-- ── Finish Label Publisher ─────────────────────────────────────────────────

function Liga:publishFinishLabel()
    local inTourneyMode   = sessionVars.get("InTourneyMode")
    local tourneyLeagueID = inTourneyMode and getTeamLeague(currentSelectedTeamID) or nil
    local userLeagueID    = sessionVars.get("currentUserLeagueID")
    local dateString      = GLOBAL_DATE_PLACEHOLDER or "01/08/25"

    local function resetCrests()
        self.im.Publish("crestsizeW",  55)
        self.im.Publish("crestsizeH",  55)
        self.im.Publish("cresthomeX", -230)
        self.im.Publish("crestawayX", -160)
        self.im.Publish("crestalpha",   1)
    end

    if not dateString then
        self.im.Publish("bnd_date_label",    "")
        self.im.Publish("bnd_month_label",   "")
        self.im.Publish("bnd_matchup_label", "No date available")
        self.im.Publish("bnd_homeRank",  ""); self.im.Publish("bnd_awayRank",  "")
        self.im.Publish("bnd_homeRankX", ""); self.im.Publish("bnd_awayRankX", "")
        self.im.Publish("bnd_home_crest",  {}); self.im.Publish("bnd_away_crest",  {})
        self.im.Publish("matchleague",     {})
        self.im.Publish("bnd_home_name",   ""); self.im.Publish("bnd_away_name",   "")
        self.im.Publish("bnd_league_label",""); self.im.Publish("bnd_matchdate_label","")
        resetCrests(); return
    end

    local currentDay, currentMonth, currentYear =
        dateString:match("^(%d%d)/(%d%d)/(%d%d)$")
    currentDay   = tonumber(currentDay)
    currentMonth = tonumber(currentMonth)
    currentYear  = tonumber(currentYear)

    if not currentDay then
        self.im.Publish("bnd_date_label",    "")
        self.im.Publish("bnd_month_label",   "")
        self.im.Publish("bnd_matchup_label", "Invalid date")
        self.im.Publish("bnd_homeRank",  ""); self.im.Publish("bnd_awayRank",  "")
        self.im.Publish("bnd_homeRankX", ""); self.im.Publish("bnd_awayRankX", "")
        self.im.Publish("bnd_home_crest",  {}); self.im.Publish("bnd_away_crest",  {})
        self.im.Publish("matchleague",     {})
        self.im.Publish("bnd_home_name",   ""); self.im.Publish("bnd_away_name",   "")
        self.im.Publish("bnd_league_label",""); self.im.Publish("bnd_matchdate_label","")
        resetCrests(); return
    end

    if Date:isSeasonEnd() then
        self.im.Publish("bnd_date_label",    "")
        self.im.Publish("bnd_month_label",   "")
        self.im.Publish("bnd_matchup_label", "Season Ended")
        self.im.Publish("bnd_matchdate_label","")
        self.im.Publish("bnd_league_label",  "")
        self.im.Publish("bnd_matchtag",      "")
        self.im.Publish("bnd_home_crest",  {}); self.im.Publish("bnd_away_crest",  {})
        self.im.Publish("matchleague",     {})
        self.im.Publish("bnd_home_name",   ""); self.im.Publish("bnd_away_name",   "")
        self.im.Publish("bnd_homeRank",    ""); self.im.Publish("bnd_awayRank",    "")
        self.im.Publish("bnd_homeRankX",   ""); self.im.Publish("bnd_awayRankX",   "")
        resetCrests()
        self.im.Publish("bnd_advance_label", "Start New Season")
        return
    elseif Date:isDeadline() then
        self.im.Publish("bnd_date_label",    "")
        self.im.Publish("bnd_month_label",   "")
        self.im.Publish("bnd_matchup_label", "")
        self.im.Publish("bnd_matchdate_label","Time remaining")
        self.im.Publish("bnd_league_label",  "")
        self.im.Publish("bnd_matchtag",      "")
        self.im.Publish("bnd_home_crest",  {}); self.im.Publish("bnd_away_crest",  {})
        self.im.Publish("matchleague",     {})
        self.im.Publish("bnd_home_name",   ""); self.im.Publish("bnd_away_name",   "")
        self.im.Publish("bnd_homeRank",    ""); self.im.Publish("bnd_awayRank",    "")
        self.im.Publish("bnd_homeRankX",   ""); self.im.Publish("bnd_awayRankX",   "")
        resetCrests()
        self.im.Publish("bnd_advance_label",
            self.deadlineTime <= 0 and "Deadline Passed"
            or (self.isAnimating and "Advancing..." or "Advance One Hour"))
        return
    elseif sessionVars.get("EndTourney") then
        self.im.Publish("bnd_date_label",    "")
        self.im.Publish("bnd_month_label",   "")
        self.im.Publish("bnd_matchup_label", "Season Results")
        self.im.Publish("bnd_matchdate_label","")
        self.im.Publish("bnd_league_label",  "")
        self.im.Publish("bnd_matchtag",      "")
        self.im.Publish("bnd_home_crest",  {name="$LeagueLogo", id=userLeagueID})
        self.im.Publish("bnd_away_crest",  {name="$Crest", id=currentSelectedTeamID})
        self.im.Publish("matchleague",     {})
        self.im.Publish("bnd_home_name",   LeagueNames[userLeagueID])
        self.im.Publish("bnd_away_name",
            sessionVars.get("Champion") == currentSelectedTeamID
            and "CHAMPION" or "ELIMINATED")
        self.im.Publish("bnd_homeRank",  ""); self.im.Publish("bnd_awayRank",  "")
        self.im.Publish("bnd_homeRankX", ""); self.im.Publish("bnd_awayRankX", "")
        resetCrests()
        self.im.Publish("bnd_advance_label", "End Tournament")
        return
    end

    local homeID, awayID, matchIndex =
        findCurrentDayMatch(self, dateString, currentSelectedTeamID)
    matchday = homeID ~= nil
    local daysToFixture, matchDateStr, nextHomeID, nextAwayID,
          nextLeagueID, nextMatchType, errorMsg =
        daysToNextMatch(self, dateString, currentSelectedTeamID)
    local currentMonthName = self.DateUtils.MONTH_NAMES_FULL[currentMonth] or "Unknown"

    if matchday then
        self.im.Publish("bnd_date_label",  "")
        self.im.Publish("bnd_month_label", "")
        local matches       = sessionVars.get("MatchData") or {}
        local selectedMatch = matchIndex and matches[matchIndex]
        local effectiveLeagueID = tourneyLeagueID
            or (selectedMatch and selectedMatch.leagueID)
            or getTeamLeague(currentSelectedTeamID)
            or sessionVars.get("currentUserLeagueID")
            or 13
        if effectiveLeagueID and effectiveLeagueID ~= 0 then
            sessionVars.set("currentUserLeagueID", effectiveLeagueID)
        end

        if not selectedMatch then
            self.im.Publish("bnd_matchup_label","No match scheduled today")
            self.im.Publish("bnd_matchdate_label","")
            self.im.Publish("bnd_league_label",  "")
            self.im.Publish("bnd_matchtag",      "")
            self.im.Publish("bnd_home_crest",  {}); self.im.Publish("bnd_away_crest",  {})
            self.im.Publish("matchleague",     {})
            self.im.Publish("bnd_home_name",   ""); self.im.Publish("bnd_away_name",   "")
            self.im.Publish("bnd_homeRank",    ""); self.im.Publish("bnd_awayRank",    "")
            self.im.Publish("bnd_homeRankX",   ""); self.im.Publish("bnd_awayRankX",   "")
            resetCrests()
        else
            local homeName = selectedMatch.homeID
                and self.loc and self.loc.LocalizeString("TeamName_Abbr15_"..selectedMatch.homeID) or ""
            local awayName = selectedMatch.awayID
                and self.loc and self.loc.LocalizeString("TeamName_Abbr15_"..selectedMatch.awayID) or ""
            local len1, len2     = #homeName, #awayName
            local sp1 = select(2, homeName:gsub("%s",""))
            local sp2 = select(2, awayName:gsub("%s",""))
            local homerank = self.TeamStats:getTeamPosition(effectiveLeagueID, nextHomeID)
            local awayrank = self.TeamStats:getTeamPosition(effectiveLeagueID, nextAwayID)
            self.im.Publish("bnd_homeRank",  ordinal(homerank))
            self.im.Publish("bnd_awayRank",  ordinal(awayrank))
            self.im.Publish("bnd_homeRankX", formatPositionText(sp1, len1))
            self.im.Publish("bnd_awayRankX", formatPositionText(sp2, len2))
            local mds = self.DateUtils:convertMatchDateToStandard(selectedMatch.date)
            publishMatchDetails(self, 0, mds, selectedMatch.homeID, selectedMatch.awayID,
                homeName, awayName, selectedMatch.matchType, effectiveLeagueID)
        end
    else
        local effectiveNextLeagueID = tourneyLeagueID or nextLeagueID
            or getTeamLeague(currentSelectedTeamID)
            or sessionVars.get("currentUserLeagueID")
            or 13
        if effectiveNextLeagueID and effectiveNextLeagueID ~= 0 then
            sessionVars.set("currentUserLeagueID", effectiveNextLeagueID)
        end
        self.im.Publish("bnd_date_label",  currentDay)
        self.im.Publish("bnd_month_label", currentMonthName)

        if daysToFixture and daysToFixture <= 7 then
            local homeName = nextHomeID
                and self.loc and self.loc.LocalizeString("TeamName_Abbr15_"..nextHomeID) or ""
            local awayName = nextAwayID
                and self.loc and self.loc.LocalizeString("TeamName_Abbr15_"..nextAwayID) or ""
            local len1, len2 = #homeName, #awayName
            local sp1 = select(2, homeName:gsub("%s",""))
            local sp2 = select(2, awayName:gsub("%s",""))
            local homerank = self.TeamStats:getTeamPosition(effectiveNextLeagueID, nextHomeID)
            local awayrank = self.TeamStats:getTeamPosition(effectiveNextLeagueID, nextAwayID)
            self.im.Publish("bnd_homeRank",  ordinal(homerank))
            self.im.Publish("bnd_awayRank",  ordinal(awayrank))
            self.im.Publish("bnd_homeRankX", formatPositionText(sp1, len1))
            self.im.Publish("bnd_awayRankX", formatPositionText(sp2, len2))
            publishMatchDetails(self, daysToFixture, matchDateStr, nextHomeID, nextAwayID,
                homeName, awayName, nextMatchType, effectiveNextLeagueID)
        else
            local safeLeague = tourneyLeagueID
                or getTeamLeague(currentSelectedTeamID)
                or sessionVars.get("currentUserLeagueID")
                or 13
            if safeLeague and safeLeague ~= 0 then
                sessionVars.set("currentUserLeagueID", safeLeague)
            end
            self.im.Publish("bnd_matchup_label",  errorMsg or "No upcoming matches")
            self.im.Publish("bnd_matchdate_label", "")
            self.im.Publish("bnd_league_label",    "")
            self.im.Publish("bnd_matchtag",        "")
            self.im.Publish("bnd_home_crest",  {}); self.im.Publish("bnd_away_crest",  {})
            self.im.Publish("matchleague",     {})
            self.im.Publish("bnd_home_name",   non or "")
            self.im.Publish("bnd_away_name",   "")
            self.im.Publish("bnd_homeRank",    ""); self.im.Publish("bnd_awayRank",    "")
            self.im.Publish("bnd_homeRankX",   ""); self.im.Publish("bnd_awayRankX",   "")
            resetCrests()
        end

        self.isMatchdayAnimating = false
        if self.matchdayTimer then
            self.matchdayTimer:finalize(); self.matchdayTimer = nil
        end
    end

    if not Date:isSeasonEnd() and not Date:isDeadline() then
        self.im.Publish("bnd_advance_label",
            self.isAutoAdvancing and "Stop simulation"
            or (matchday and "Matchday" or "Advance"))
    end
    if dateString ~= "25/07/25" then
        self.UItasks:_rowDisplay("hide")
    end
end

-- ── Play Match ─────────────────────────────────────────────────────────────

function Liga:PlayMatch()
    local currentDate = GLOBAL_DATE_PLACEHOLDER or "01/08/25"
    local homeID, awayID, matchIndex =
        findCurrentDayMatch(self, currentDate, currentSelectedTeamID)
    if not homeID then
        self.im.Publish("bnd_matchup_label", "No match scheduled today")
        return
    end

    local matches         = sessionVars.get("MatchData") or {}
    local currentMatchData= matches[matchIndex]
    currentLigaData = currentLigaData or {}
    currentLigaData.Index   = ligaId
    currentLigaData.round   = matchIndex
    currentLigaData.homeID  = currentMatchData.homeID
    currentLigaData.awayID  = currentMatchData.awayID
    currentLigaData.leagueID= currentMatchData.leagueID
    currentLigaData.difficulty = currentMatchData.difficulty or 1
    currentMatch.MatchType  = currentMatchData.matchType
    currentMatch.HomeTeamID = currentMatchData.homeID
    currentMatch.AwayTeamID = currentMatchData.awayID
    currentMatch.isKnockout = currentMatchData.isKnockout or false

    local players      = getCachedTeamPlayers(currentSelectedTeamID)
    local squadSize    = #players
    local ineligible   = false
    local ineligibleCount = 0

    for i = 1, squadSize do
        local id = players[i].CARD_ID
        if isSuspended[id] == 1 or isSuspended[id] == 2 then
            ineligibleCount = ineligibleCount + 1
            if i <= 16 then ineligible = true end
        end
    end

    if ineligible then
        local count = ineligibleCount + 16
        if count > squadSize then ineligible = false end
    end

    if ineligible then
        self:Ineligible()
    else
        self:KickOff(currentMatchData.isKnockout)
    end
end

-- ── Deadline Animation ─────────────────────────────────────────────────────

function Liga:animateDeadlineTime(callback)
    if self.deadlineTimer then
        self.deadlineTimer:finalize(); self.deadlineTimer = nil
    end
    self.isAnimating = true
    self.im.Publish("bnd_showAdvanceBtn", false)
    self.im.Publish("bnd_isNotDateSim",   false)

    local stepInterval  = 0.083
    local totalSteps    = 60
    local currentHours  = math.floor(self.deadlineTime / 60)

    local function setDeadlineUI()
        self.im.Publish("bnd_date_label",    "")
        self.im.Publish("bnd_month_label",   "")
        self.im.Publish("bnd_matchup_label", "")
        self.im.Publish("bnd_matchdate_label","Time remaining")
        self.im.Publish("bnd_league_label",  "")
        self.im.Publish("bnd_matchtag",      "")
        self.im.Publish("bnd_home_crest",  {}); self.im.Publish("bnd_away_crest",  {})
        self.im.Publish("bnd_home_name",   ""); self.im.Publish("bnd_away_name",   "")
        self.im.Publish("bnd_homeRank",    ""); self.im.Publish("bnd_awayRank",    "")
        self.im.Publish("bnd_homeRankX",   ""); self.im.Publish("bnd_awayRankX",   "")
        self.im.Publish("crestsizeW",  55); self.im.Publish("crestsizeH",  55)
        self.im.Publish("cresthomeX", -230);self.im.Publish("crestawayX", -160)
        self.im.Publish("crestalpha",   1)
    end

    local function animateStep(step)
        if not self.isAnimating then
            self.deadlineTimer = nil; self.isAnimating = false
            self.im.Publish("bnd_showAdvanceBtn", true)
            self.im.Publish("bnd_isNotDateSim",   true)
            self:publishDeadlineTime(); setDeadlineUI()
            self.im.Publish("bnd_advance_label",
                self.deadlineTime <= 0 and "Deadline Passed" or "Advance One Hour")
            if callback then callback(false) end; return
        end

        if step > totalSteps then
            self.deadlineTime = currentHours * 60
            self:publishDeadlineTime(); setDeadlineUI()
            if currentHours <= 0 then
                self.deadlineTime = 0
                self.im.Publish("bnd_advance_label",  "Deadline Passed")
                self.im.Publish("bnd_isdeadline",     false)
                self.im.Publish("bnd_deadlinetime",   "00:00")
                self.im.Publish("bnd_deadlinecolor",  "0xFF0D00")
                self.im.Publish("bnd_showAdvanceBtn", true)
                self.im.Publish("bnd_isNotDateSim",   true)
                sessionVars.set("deadlineTime", nil)
                self.deadlineTime = 10 * 60
                self.Date:advanceDate()
                self:publishFinishLabel()
                self.deadlineTimer = nil; self.isAnimating = false
                if callback then callback(true) end; return
            end
            self.im.Publish("bnd_showAdvanceBtn", true)
            self.im.Publish("bnd_isNotDateSim",   true)
            self.im.Publish("bnd_advance_label",  "Advance One Hour")
            sessionVars.set("deadlineTime", self.deadlineTime)
            self.deadlineTimer = nil; self.isAnimating = false
            if callback then callback(false) end; return
        end

        local currentMinutes = 59 - (step - 1)
        self.im.Publish("bnd_deadlinetime",
            string.format("%02d:%02d", currentHours, currentMinutes))
        self.im.Publish("bnd_deadlinecolor",
            formatDeadlineColor(currentHours * 60 + currentMinutes))
        setDeadlineUI()

        self.deadlineTimer = Timer:new({
            id="deadlineTimer_"..step, interval=stepInterval, reps=1,
            onTimerComplete = function() animateStep(step + 1) end
        })
        self.deadlineTimer:start()
    end

    self.deadlineTimer = Timer:new({
        id="deadlineTimer_start", interval=0, reps=1,
        onTimerComplete = function()
            if self.isAnimating then
                if self.deadlineTime % 60 == 0 then
                    currentHours = currentHours - 1
                    if currentHours < 0 then
                        self.deadlineTime = 0
                        self.im.Publish("bnd_advance_label",  "Deadline Passed")
                        self.im.Publish("bnd_isdeadline",     false)
                        self.im.Publish("bnd_deadlinetime",   "00:00")
                        self.im.Publish("bnd_deadlinecolor",  "0xFF0D00")
                        self.im.Publish("bnd_showAdvanceBtn", true)
                        self.im.Publish("bnd_isNotDateSim",   true)
                        setDeadlineUI()
                        self.Date:advanceDate()
                        self.deadlineTime = 10 * 60
                        self:publishFinishLabel()
                        self.deadlineTimer = nil; self.isAnimating = false
                        if callback then callback(true) end; return
                    end
                    self.deadlineTime = currentHours * 60 + 59
                else
                    self.deadlineTime = currentHours * 60 + 59
                end
                self:publishDeadlineTime(); setDeadlineUI()
                animateStep(1)
            else
                self.deadlineTimer = nil
                self.im.Publish("bnd_showAdvanceBtn", true)
                self.im.Publish("bnd_isNotDateSim",   true)
                self:publishDeadlineTime(); setDeadlineUI()
                sessionVars.set("deadlineTime", self.deadlineTime)
                self.im.Publish("bnd_advance_label",
                    self.deadlineTime <= 0 and "Deadline Passed" or "Advance One Hour")
                if callback then callback(false) end
            end
        end
    })
    self.deadlineTimer:start()
end

-- ── Date Swipe Animation ───────────────────────────────────────────────────

function Liga:animateDateSwipe(callback)
    if self.dateTimer then self.dateTimer:finalize(); self.dateTimer = nil end
    self.isAnimating = true
    self.backgroundProcessor:setAnimating(true, true)
    self.dateYPositions = {-100, -50, 0}
    self.im.Publish("bnd_date1Y", self.dateYPositions[1])
    self.im.Publish("bnd_date2Y", self.dateYPositions[2])
    self.im.Publish("bnd_date3Y", self.dateYPositions[3])
    self.im.Publish("bnd_dateAA3", 1)
    self.im.Publish("dateTS1", 20); self.im.Publish("dateTS2", 40)
    self:dateAnim()

    local totalDuration  = 0.3
    local phaseDuration  = 0.15
    local stepInterval   = 0.016
    local totalSteps     = math.max(1, math.floor(totalDuration / stepInterval))
    local stepsPerPhase  = math.max(1, math.floor(phaseDuration / stepInterval))
    local startY12       = {-100, -50}
    local targetY12      = {-50,   0}
    local startTS1, targetTS1 = 20, 40
    local startTS2, targetTS2 = 40, 20
    local p1StartY3, p1TargetY3, p1StartA, p1TargetA = 0, 30, 1, 0
    local p2StartY3, p2TargetY3, p2StartA, p2TargetA = -130, -100, 0, 1
    local hasAdvancedDate, pendingMatchdayAnimation = false, false

    local function animateStep(step)
        if not self.isAnimating then
            self.dateTimer = nil; self.isAnimating = false
            self:dateAnim()
            if callback then callback() end; return
        end

        if step > totalSteps then
            self.dateYPositions = {-100, -50, 0}
            for i = 1, 3 do
                self.im.Publish("bnd_date"..i.."Y", self.dateYPositions[i])
            end
            self.im.Publish("bnd_dateAA3", p2TargetA)
            self.im.Publish("dateTS1", 20); self.im.Publish("dateTS2", 40)
            self:publishDate1(); self:publishDate2(); self:publishDate3()
            self:publishFinishLabel()
            if pendingMatchdayAnimation then
                self:matchdayAnim(function()
                    self.dateTimer = nil; self.isAnimating = false
                    self:dateAnim(); self:publishFinishLabel()
                    if callback then callback() end
                end, function() end)
            else
                self.dateTimer = nil; self.isAnimating = false
                self:dateAnim(); self:publishFinishLabel()
                if callback then callback() end
            end
            return
        end

        local t        = step / totalSteps
        local easedT   = 1 - (1 - t) * (1 - t)
        local isPhase1 = step <= stepsPerPhase
        local phaseStep= isPhase1 and step or (step - stepsPerPhase)
        local phaseT   = phaseStep / stepsPerPhase
        local ePT      = 1 - (1 - phaseT) * (1 - phaseT)

        local cY12 = {
            startY12[1] + (targetY12[1] - startY12[1]) * easedT,
            startY12[2] + (targetY12[2] - startY12[2]) * easedT,
        }
        local cTS1 = startTS1 + (targetTS1 - startTS1) * easedT
        local cTS2 = startTS2 + (targetTS2 - startTS2) * easedT
        self.im.Publish("bnd_date1Y", math.floor(cY12[1]+0.5))
        self.im.Publish("bnd_date2Y", math.floor(cY12[2]+0.5))
        self.im.Publish("dateTS1",    math.floor(cTS1+0.5))
        self.im.Publish("dateTS2",    math.floor(cTS2+0.5))

        local cY3, cA
        if isPhase1 then
            cY3 = p1StartY3 + (p1TargetY3 - p1StartY3) * ePT
            cA  = p1StartA  + (p1TargetA  - p1StartA)  * ePT
        else
            if phaseStep == 1 and not hasAdvancedDate then
                self.Date:advanceDate(); hasAdvancedDate = true
                local nextDate = self.DateUtils:getNextDay(GLOBAL_DATE_PLACEHOLDER)
                self.im.Publish(BND_DATE3,
                    self.DateUtils:formatDateAsDayName(nextDate))
                local hID = findCurrentDayMatch(
                    self, GLOBAL_DATE_PLACEHOLDER, currentSelectedTeamID)
                matchday = hID ~= nil
                if matchday then pendingMatchdayAnimation = true end
                self.im.Publish("bnd_date3Y",  p2StartY3)
                self.im.Publish("bnd_dateAA3", p2StartA)
            end
            cY3 = p2StartY3 + (p2TargetY3 - p2StartY3) * ePT
            cA  = p2StartA  + (p2TargetA  - p2StartA)  * ePT
        end
        self.im.Publish("bnd_date3Y",  math.floor(cY3+0.5))
        self.im.Publish("bnd_dateAA3", math.floor(cA*100+0.5)/100)

        self.dateTimer = Timer:new({
            id="dateTimer_"..step, interval=stepInterval, reps=1,
            onTimerComplete = function() animateStep(step + 1) end
        })
        self.dateTimer:start()
    end

    self.dateTimer = Timer:new({
        id="dateTimer_start", interval=0, reps=1,
        onTimerComplete = function()
            if self.isAnimating then
                hasAdvancedDate = false; pendingMatchdayAnimation = false
                animateStep(1)
            else
                self.dateTimer = nil; self.isAnimating = false
                self.backgroundProcessor:setAnimating(false)
                self.dateYPositions = {-100, -20, 60}
                self:dateAnim(); self:publishFinishLabel()
                if callback then callback() end
            end
        end
    })
    self.dateTimer:start()
end

-- ── Tab Button Animation ───────────────────────────────────────────────────

function Liga:animateTabButtons(tabsNum, btnTabsXConfig, direction,
        animationType, startOrTargetX, callback)
    if not tabsNum or not btnTabsXConfig or tabsNum < 1 or not startOrTargetX then
        if callback then callback() end; return
    end
    if self.btnTimer then self.btnTimer:finalize(); self.btnTimer = nil end
    self.isBtnAnimating = true
    self.backgroundProcessor:setAnimating(true, true)

    local stepInterval  = animationType == "fadeOut" and 0.033 or 0.016
    local steps         = math.max(1, math.floor(0.05 / stepInterval))
    local buttonDelay   = animationType == "fadeOut" and 0.01 or 0
    local buttonOrder   = {}
    for i = 1, tabsNum do
        buttonOrder[i] = direction == 1 and i or (tabsNum + 1 - i)
    end

    local function animateStep(step)
        if not self.isBtnAnimating then
            self.btnTimer = nil
            if callback then callback() end; return
        end

        local btnIdx  = math.floor((step - 1) / steps) + 1
        local stepInB = (step - 1) % steps + 1

        if btnIdx > tabsNum then
            self.btnTimer = nil; self.isBtnAnimating = false
            if callback then callback() end; return
        end

        local bIdx   = buttonOrder[btnIdx]
        local startX = animationType == "fadeOut" and btnTabsXConfig[bIdx] or startOrTargetX
        local targetX= animationType == "fadeOut" and startOrTargetX or btnTabsXConfig[bIdx]
        local t      = stepInB / steps
        local ePT    = 1 - (1 - t) * (1 - t)
        local currX  = startX + (targetX - startX) * ePT
        self.im.Publish("bnd_btnX"..bIdx, math.floor(currX+0.5))
        if stepInB == steps then
            self.im.Publish("bnd_btnX"..bIdx, targetX)
        end

        local nextInterval = stepInB == steps and buttonDelay or stepInterval
        self.btnTimer = Timer:new({
            id="btnTimer_"..animationType.."_"..step,
            interval = step == 1 and stepInterval or nextInterval,
            reps=1,
            onTimerComplete = function() animateStep(step + 1) end
        })
        self.btnTimer:start()
    end

    self.btnTimer = Timer:new({
        id="btnTimer_"..animationType.."_start", interval=0, reps=1,
        onTimerComplete = function()
            if self.isBtnAnimating then
                animateStep(1)
            else
                self.btnTimer = nil
                self.backgroundProcessor:setAnimating(false)
                if callback then callback() end
            end
        end
    })
    self.btnTimer:start()
end

function Liga:_animateTabButtons(tabsNum, btnTabsXConfig, direction,
        animationType, startOrTargetX, callback)
    self:animateTabButtons(tabsNum, btnTabsXConfig, direction,
        animationType, startOrTargetX, callback)
end

-- ── Swipe Tabs Animation ───────────────────────────────────────────────────

function Liga:swipeTabs(startX, targetX, callback)
    if self.swipeTimer then self.swipeTimer:finalize(); self.swipeTimer = nil end
    self.isSwipeAnimating = true
    self.backgroundProcessor:setAnimating(true, true)

    local duration  = 0.09
    local stepInt   = 0.016
    local steps     = math.floor(duration / stepInt)
    local stepSize  = (targetX - startX) / steps

    local function animateSwipeStep(step)
        if not self.isSwipeAnimating then
            self.swipeTimer = nil
            self.im.Publish("bnd_tabsPosX", targetX)
            self.isSwipeAnimating = false
            if callback then callback() end; return
        end
        if step > steps then
            self.swipeTimer = nil
            self.im.Publish("bnd_tabsPosX", targetX)
            self.isSwipeAnimating = false
            if callback then callback() end; return
        end
        self.im.Publish("bnd_tabsPosX", startX + stepSize * step)
        self.swipeTimer = Timer:new({
            id="swipeTimer_"..step, interval=stepInt, reps=1,
            onTimerComplete = function() animateSwipeStep(step + 1) end
        })
        self.swipeTimer:start()
    end

    self.swipeTimer = Timer:new({
        id="swipeTimer_start", interval=0, reps=1,
        onTimerComplete = function()
            if self.isSwipeAnimating then
                animateSwipeStep(1)
            else
                self.swipeTimer = nil
                self.backgroundProcessor:setAnimating(false)
                if callback then callback() end
            end
        end
    })
    self.swipeTimer:start()
end

function Liga:_swipeTab(startX, targetX, callback)
    self:swipeTabs(startX, targetX, callback)
end

-- ── NoMatch (date advance logic) ───────────────────────────────────────────

function Liga:NoMatch()
    if self.isAutoAdvancing then
        if self.dateTimer then self.dateTimer:finalize(); self.dateTimer = nil end
        self.isAutoAdvancing = false; self.isAnimating = false
        self.transfersDoneForDate = {}; self.lastTransferDate = nil
        self.dateYPositions = {-100, -20, 60}
        self:dateAnim(); self:publishFinishLabel(); return
    end

    if sessionVars.get("EndTourney") then self:endCareer(); return end
    if matchday then self:PlayMatch(); return end

    local isDeadline  = Date:isDeadline()
    local isSeasonEnd = Date:isSeasonEnd()

    if isSeasonEnd then
        self.SeasonInit:setNewSeason(function(self)
            self.Date:advanceDate()
            self.transfersDoneForDate = {}; self.lastTransferDate = nil
            self.dateAdvanceCount = 0; self.isAutoAdvancing = false
            self.isAnimating = false; self.dateYPositions = {-100,-20,60}
            self:dateAnim(); self:publishFinishLabel()
            self.matchSimulator:simulateDayMatches(GLOBAL_DATE_PLACEHOLDER, self.simMode)
            updateTeamFormCache(self)
        end, self); return
    elseif isDeadline then
        if self.dateTimer then self.dateTimer:finalize(); self.dateTimer = nil end
        self.isAutoAdvancing = false; self.dateYPositions = {-100,-20,60}
        self:dateAnim()
        self:animateDeadlineTime(function(deadlineReached)
            if not deadlineReached then
                self.im.Publish("bnd_advance_label","Advance One Hour")
                self:publishFinishLabel()
            end
        end); return
    end

    self.isAutoAdvancing = true
    if not self.dateAdvanceCount then self.dateAdvanceCount = 0 end

    local function advanceDateStep()
        if not self.isAutoAdvancing then return end
        if self.dateAdvanceCount >= 365 then
            self.isAutoAdvancing = false; self.isAnimating = false
            self.transfersDoneForDate = {}; self.lastTransferDate = nil
            self.dateTimer = nil; self.dateYPositions = {-100,-20,60}
            self:dateAnim(); self:publishFinishLabel()
            error("Maximum date advances reached; check match dates configuration")
            return
        end

        local homeID = findCurrentDayMatch(self, GLOBAL_DATE_PLACEHOLDER,
            self.simMode and 0 or currentSelectedTeamID)
        matchday = homeID ~= nil

        if homeID or Date:isDeadline() or Date:isSeasonEnd() then
            self.isAutoAdvancing = false; self.isAnimating = false
            self.dateAdvanceCount = 0
            self.transfersDoneForDate = {}; self.lastTransferDate = nil
            self.dateYPositions = {-100,-20,60}
            self:dateAnim()

            if Date:isSeasonEnd() then
                self.SeasonInit:setNewSeason(function(self)
                    self.Date:advanceDate(); self:publishFinishLabel()
                    self.matchSimulator:simulateDayMatches(
                        GLOBAL_DATE_PLACEHOLDER, self.simMode)
                    updateTeamFormCache(self)
                    self.nav.Event(nil,"evt_reload")
                end, self)
            elseif Date:isDeadline() then
                if self.dateTimer then self.dateTimer:finalize(); self.dateTimer=nil end
                self.isAutoAdvancing = false; self.dateYPositions = {-100,-20,60}
                self:dateAnim()
                self:animateDeadlineTime(function(deadlineReached)
                    if not deadlineReached then
                        self.im.Publish("bnd_advance_label","Advance One Hour")
                        self:publishFinishLabel()
                    end
                end)
            elseif matchday then
                self.im.Publish("bnd_advance_label","Matchday")
            end
            return
        end

        self.matchSimulator:simulateDayMatches(GLOBAL_DATE_PLACEHOLDER, self.simMode)
        updateTeamFormCache(self)
        self.dateAdvanceCount = self.dateAdvanceCount + 1
        self:animateDateSwipe(function() advanceDateStep() end)
    end

    advanceDateStep()
end

-- ── Matchday Animation ─────────────────────────────────────────────────────

function Liga:matchdayAnim(completionCallback, phase4Callback)
    if self.matchdayTimer then
        self.matchdayTimer:finalize(); self.matchdayTimer = nil
    end
    self.isMatchdayAnimating = true
    self.backgroundProcessor:setAnimating(true)

    local p1Dur, p3Dur, p4Dur, p5Dur, p6Dur = 0.2, 0.3, 1.0, 0.3, 0.1
    local stepInt = 0.016
    local p1Steps = math.max(1, math.floor(p1Dur / stepInt))
    local p3Steps = math.max(1, math.floor(p3Dur / stepInt))
    local p4Steps = math.max(1, math.floor(p4Dur / stepInt))
    local p5Steps = math.max(1, math.floor(p5Dur / stepInt))
    local p6Steps = math.max(1, math.floor(p6Dur / stepInt))
    local total   = p1Steps + p3Steps + p4Steps + p5Steps + p6Steps

    local iW,iH,iHX,iAX,iA = 55,55,-230,-160,1
    local p1TA = 0.5
    local p2W,p2H,p2A,p2HX,p2AX = 200,200,1,-50,150
    local p3HX,p3AX = -150,250
    local p5W,p5H,p5HX,p5AX = 55,55,-230,-160

    self.UItasks:_rowDisplay("hide")
    self.im.Publish("bnd_showAdvanceBtn", false)
    self.im.Publish("bnd_home_name",  ""); self.im.Publish("bnd_away_name",  "")
    self.im.Publish("bnd_homeRank",   ""); self.im.Publish("bnd_awayRank",   "")
    self.im.Publish("bnd_homeRankX",  ""); self.im.Publish("bnd_awayRankX",  "")
    self.im.Publish("bnd_matchup_label",""); self.im.Publish("bnd_matchdate_label","")
    self.im.Publish("bnd_league_label", ""); self.im.Publish("bnd_matchtag",     "")

    local function animateStep(step)
        if not self.isMatchdayAnimating then
            self.matchdayTimer = nil; self.isMatchdayAnimating = false
            self.im.Publish("crestsizeW",iW); self.im.Publish("crestsizeH",iH)
            self.im.Publish("cresthomeX",iHX);self.im.Publish("crestawayX",iAX)
            self.im.Publish("crestalpha",iA)
            self:publishFinishLabel()
            if completionCallback then completionCallback() end; return
        end

        if step > total then
            self.matchdayTimer = nil; self.isMatchdayAnimating = false
            self:publishFinishLabel()
            if completionCallback then completionCallback() end; return
        end

        local isP1 = step <= p1Steps
        local isP3 = step > p1Steps and step <= (p1Steps+p3Steps)
        local isP4 = step > (p1Steps+p3Steps) and step <= (p1Steps+p3Steps+p4Steps)
        local isP5 = step > (p1Steps+p3Steps+p4Steps)
                 and step <= (p1Steps+p3Steps+p4Steps+p5Steps)
        local ps, pt, et

        if isP1 then
            ps = step;  pt = ps/p1Steps;  et = 1-(1-pt)*(1-pt)
            self.im.Publish("crestalpha",
                math.floor((iA+(p1TA-iA)*et)*100+0.5)/100)
            self.im.Publish("crestsizeW",iW); self.im.Publish("crestsizeH",iH)
            self.im.Publish("cresthomeX",iHX);self.im.Publish("crestawayX",iAX)
        elseif isP3 then
            ps = step-p1Steps; pt = ps/p3Steps; et = 1-(1-pt)*(1-pt)
            if ps == 1 then
                self.im.Publish("crestsizeW",p2W); self.im.Publish("crestsizeH",p2H)
                self.im.Publish("crestalpha",p2A)
                self.im.Publish("cresthomeX",p2HX);self.im.Publish("crestawayX",p2AX)
            end
            self.im.Publish("cresthomeX", math.floor(p2HX+(p3HX-p2HX)*et+0.5))
            self.im.Publish("crestawayX", math.floor(p2AX+(p3AX-p2AX)*et+0.5))
            self.im.Publish("crestsizeW",p2W); self.im.Publish("crestsizeH",p2H)
            self.im.Publish("crestalpha",p2A)
        elseif isP4 then
            self.im.Publish("crestsizeW",p2W); self.im.Publish("crestsizeH",p2H)
            self.im.Publish("cresthomeX",p3HX);self.im.Publish("crestawayX",p3AX)
            self.im.Publish("crestalpha",p2A)
        elseif isP5 then
            ps = step-(p1Steps+p3Steps+p4Steps); pt = ps/p5Steps; et = 1-(1-pt)*(1-pt)
            if ps == 1 and phase4Callback then
                phase4Callback(); phase4Callback = nil
            end
            self.im.Publish("crestsizeW", math.floor(p2W+(p5W-p2W)*et+0.5))
            self.im.Publish("crestsizeH", math.floor(p2H+(p5H-p2H)*et+0.5))
            self.im.Publish("cresthomeX", math.floor(p3HX+(p5HX-p3HX)*et+0.5))
            self.im.Publish("crestawayX", math.floor(p3AX+(p5AX-p3AX)*et+0.5))
            self.im.Publish("crestalpha",p2A)
        else
            self.im.Publish("bnd_showAdvanceBtn", true)
            self.im.Publish("crestsizeW",iW); self.im.Publish("crestsizeH",iH)
            self.im.Publish("cresthomeX",iHX);self.im.Publish("crestawayX",iAX)
            self.im.Publish("crestalpha",iA)
            self:publishFinishLabel()
        end

        self.matchdayTimer = Timer:new({
            id="matchdayTimer_"..step, interval=stepInt, reps=1,
            onTimerComplete = function() animateStep(step+1) end
        })
        self.matchdayTimer:start()
    end

    self.matchdayTimer = Timer:new({
        id="matchdayTimer_start", interval=0, reps=1,
        onTimerComplete = function()
            if self.isMatchdayAnimating then
                animateStep(1)
            else
                self.matchdayTimer = nil; self.isMatchdayAnimating = false
                self.backgroundProcessor:setAnimating(false)
                self.im.Publish("bnd_showAdvanceBtn", true)
                self.im.Publish("crestsizeW",iW); self.im.Publish("crestsizeH",iH)
                self.im.Publish("cresthomeX",iHX);self.im.Publish("crestawayX",iAX)
                self.im.Publish("crestalpha",iA)
                self:publishFinishLabel()
                if completionCallback then completionCallback() end
            end
        end
    })
    self.matchdayTimer:start()
end

-- ── Update ─────────────────────────────────────────────────────────────────

function Liga:update(elapsedTime)
    if self.dateTimer     then self.dateTimer:update(elapsedTime)     end
    if self.swipeTimer    then self.swipeTimer:update(elapsedTime)    end
    if self.btnTimer      then self.btnTimer:update(elapsedTime)      end
    if self.deadlineTimer then self.deadlineTimer:update(elapsedTime) end
    if self.matchdayTimer then self.matchdayTimer:update(elapsedTime) end
    if self.backgroundProcessor then
        self.backgroundProcessor:update(elapsedTime)
    end
    if self.newsTimer     then self.newsTimer:update(elapsedTime)     end
end

-- ── Match Actions ──────────────────────────────────────────────────────────

function Liga:KickOff(isKO)
    self.nav.Event(nil, isKO and "evt_advanceko" or "evt_advance")
end

function Liga:Ineligible()
    self.FCPopup:getResponse(
        "Your squad has an ineligible player. \n Fix in Team Management",
        {"Fix"},
        function(r)
            if r == 1 then self.nav.Event(nil,"evt_squad") end
        end
    )
end

function Liga:endCareer()
    self.nav.Event(nil,"evt_back")
    sessionVars.set("InTourneyMode", false)
    sessionVars.delete()
end

function Liga:exitCareer()
    self.FCPopup:getResponse(
        "Leaving without saving can cause unsaved work not to be saved, Do you want to proceed?",
        {"Yes","No"},
        function(r)
            if r == 1 then
                self.nav.Event(nil,"evt_back")
                sessionVars.set("InCareerMode",  false)
                sessionVars.set("InTourneyMode", false)
                sessionVars.set("CareerMode",    true)
                sessionVars.set("GLOBAL_DATE_PLACEHOLDER", GLOBAL_DATE_PLACEHOLDER)
                sessionVars.set("GLOBAL_FUNDS",  GLOBAL_FUNDS)
                sessionVars.set("isSuspended", isSuspended)
                self.ui:reset()
            end
        end
    )
end

-- ── Finalize ───────────────────────────────────────────────────────────────

function Liga:finalize()
    if self.dateTimer     then self.dateTimer:finalize();     self.dateTimer=nil     end
    if self.swipeTimer    then self.swipeTimer:finalize();    self.swipeTimer=nil    end
    if self.btnTimer      then self.btnTimer:finalize();      self.btnTimer=nil      end
    if self.deadlineTimer then self.deadlineTimer:finalize(); self.deadlineTimer=nil end
    if self.backgroundProcessor then
        self.backgroundProcessor:finalize(); self.backgroundProcessor=nil
    end

    self.im.UnregisterAction(ACT_ADVANCE)
    self.im.UnregisterAction(ACT_EXIT)
    self.im.UnregisterAction(PROGRESS)
    self.im.Unsubscribe(BND_DATE1)
    self.im.Unsubscribe(BND_DATE2)
    self.im.Unsubscribe(BND_DATE3)
    for i = 1, 3 do self.im.Unsubscribe("bnd_date"..i.."Y") end
    local unsubs = {
        "bnd_date_label","bnd_matchup_label","bnd_matchtag",
        "bnd_matchdate_label","bnd_league_label","bnd_advance_label",
        "bnd_month_label","bnd_finish_label","bnd_finance","bnd_financeextra",
        "bnd_home_crest","bnd_away_crest","bnd_home_name","bnd_away_name",
        "bnd_epl_visible","bnd_ads",
    }
    for _, name in ipairs(unsubs) do self.im.Unsubscribe(name) end
    if self.models.PlayerAge   then self.models.PlayerAge:finalize()   end
    if self.models.AITransfers then self.models.AITransfers:finalize() end
    self.ui:reset()
end

return Liga
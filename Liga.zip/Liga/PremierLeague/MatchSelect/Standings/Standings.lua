local sessionVars, CareerModeLeagues, Timer, TeamStats = ...
local Liga = {}
local bndMatchList = "bnd_match_list"
local bndMatchList1 = "bnd_match_list1"
local bndBackgroundCareer = "bnd_background_career"
local bndBackgroundCareer2 = "bnd_background_career2"
local bndTableCareer = "bnd_table_career"
local bndLogo = "bnd_logo"
local bndTeamLogo = "bnd_team_logo"
local bndTeamName = "bnd_team_name"
local ACT_ADVANCE = "act_advance"
local ACT_NEXT = "act_next"
local ACT_DECREASE = "act_decrease"
local bndLeagueColor = "bnd_league_color"
local bndBanner = "bnd_banner"
local selectedLeague = nil
local SelectedTeamID = nil
local expandedLeagues = {}
local leagueColors = {
    [0] = 0xFF1E1D27,   -- Premier League (default)
    [13] = 0xFF160219,  -- League 13
    [16] = 0xFF090D15,  -- League 16  
    [19] = 0xFF121212,  -- League 19
    [31] = 0x000627,   -- League 31    
    [53] = 0xFF0D0A14,   -- League 53
    [350] = 0x011B03,   -- League 350              
    [2236] = 0x00073F,   -- League 2236     
    [2235] = 0x00021A   -- League 2235                       
}

local colorBanner = {
    [0] = 0xFF1E1D27,   -- Premier League (default)
    [13] = 0xFF351A45,  -- League 13
    [16] = 0xFF1D273B,  -- League 16  
    [19] = 0xFF121212,  -- League 19
    [31] = 0x001177,   -- League 31        
    [53] = 0xFF5F2C37,   -- League 53
    [350] = 0x003803,   -- League 350    
    [2236] = 0x001CFF,   -- League 2236              
    [2235] = 0x072A7E   -- League 2235                           
}

local leagueNames = {
    [4] = "Pro League",
    [7] = "Serie A",
    [10] = "Eredivisie",
    [13] = "Premier League",
    [14] = "Championship",
    [16] = "Ligue 1",
    [17] = "Ligue 2",
    [19] = "Bundesliga 1",
    [20] = "Bundesliga 2",
    [31] = "Serie A",
    [32] = "Serie B",
    [39] = "MLS",
    [50] = "Premiership",
    [53] = "La Liga",
    [54] = "Segunda",
    [60] = "League One",
    [66] = "Ekstraklasa",
    [68] = "Süper Lig",
    [76] = "Rest of World",
    [77] = "Rest of World 2",
    [78] = "International",
    [83] = "K League 1",
    [308] = "Primeira Liga",
    [341] = "Liga MX",
    [347] = "Premier Division",
    [349] = "J1 League",
    [350] = "Pro League",
    [351] = "A-League",
    [353] = "Primera División",
    [365] = "AFC",
    [1114] = "Premier League",
    [1245] = "Classic Team",
    [1246] = "Classic International",
    [2012] = "Super League",
    [2034] = "Ligue 1",
    [2136] = "International Women",
    [2149] = "Super League",
    [2215] = "Frauen-Bundesliga",
    [2216] = "FA WSL",
    [2218] = "Division 1 Féminine",
    [2221] = "NWSL",
    [2222] = "Liga F",
    [2231] = "Premier League",
    [2235] = "Liga 1",
    [2236] = "Champions League",
    [2237] = "Super League",
    [2238] = "Europe League",
    [2240] = "Champions League Women",
    [2250] = "Botola Pro",
    [2252] = "League 1",
    [2254] = "Pegadaian Liga 2",
    [2255] = "PNM Liga Nusantara",     
    [2260] = "V.League 1",
    [0] = "League" -- Default
}

local function ordinal(n)
    local suffix = "TH"
    if n % 100 < 11 or n % 100 > 13 then
        local d = n % 10
        if     d == 1 then suffix = "ST"
        elseif d == 2 then suffix = "ND"
        elseif d == 3 then suffix = "RD"
        end
    end
    return tostring(n) .. suffix
end

ligaId = 1
if not round then
  round = 1
else 
  round = round
end

if not selectedteam then
  selectedteam = 0
else 
  selectedteam = selectedteam
end

local rivalListData = {}
local matchesPlayed = 0 

function Liga:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.services = {
    settingsService = o.api("SettingsService"),
    SquadManagementService = o.api("SquadMgtService")
  }
  o.teamStats = TeamStats:new({loc = init.loc})
  o.switchPanelOpened = false
  o.currentOptions = o.services.settingsService.GetCurrentOptions()
  o.backgroundTimer = nil
  o.Init()
  o.teamDataList = {}
  o.team = nil
  
  o.im.Subscribe(bndMatchList1, function()
     o:publishMatchRows2()
  end)
  
  o.im.Subscribe("LeagueList", function()
     o:displayLeagues()
  end)
 
  o.im.Subscribe(bndBackgroundCareer, function()  
  local currentLeague = o:getCurrentLeague()
    o.im.Publish(bndBackgroundCareer, {name = "$CareerTable", id = currentLeague})
  end)
  
  o.im.Subscribe(bndBackgroundCareer2, function()  
  local currentLeague = o:getCurrentLeague()
    o.im.Publish(bndBackgroundCareer2, {name = "$CareerTable", id = currentLeague})
  end)
  
  o.im.Subscribe(bndLeagueColor, function()
  local leagueColor = o:getLeagueColor()
  o.im.Publish(bndLeagueColor, leagueColor)
end)

o.im.Subscribe("bnd_league_logo", function()
    local leagueLogo = o:getLeagueLogo()
    o.im.Publish("bnd_league_logo", leagueLogo)
end)

o.im.Subscribe("bnd_league_name", function()
    local leagueName = o:getLeagueName()
    o.im.Publish("bnd_league_name", leagueName)
end)

o.im.Subscribe("bnd_teampos", function()
    o.im.Publish("bnd_teampos", "")
end)

o.im.Subscribe(bndBanner, function()
  local colorBanner = o:getcolorBanner()
  o.im.Publish(bndBanner, colorBanner)
end)
  
  o.im.Subscribe(bndTableCareer, function()  
  local currentLeague = o:getCurrentLeague()
    o.im.Publish(bndTableCareer, {name = "$BgTable", id = currentLeague})
  end)

  o.im.Subscribe(bndLogo, function()  
  local currentLeague = o:getCurrentLeague()
    o.im.Publish(bndLogo, {name = "$LeagueLogo", id = currentLeague})
  end)

  o.im.Subscribe(bndTeamLogo, function()  
    o.im.Publish(bndTeamLogo, {name = "$Crest64x64", id = currentSelectedTeamID})   
  end)
  
  o.im.Subscribe("switchPanelOpened", function()  
    o:switchLeague("init")
  end)
  
  o.im.Subscribe(bndTeamName, function()  
        o.im.Publish(bndTeamName, o.loc.LocalizeString("TeamName_Abbr15_"..currentSelectedTeamID))       
    end)
    
    o.im.Subscribe("bnd_onteam", function()  
        o.im.Publish("bnd_onteam", false)       
    end)
    
    o.im.RegisterAction("switchLeague", function(actionName, dt)
      o:switchLeague()
  end)
  
    o.im.RegisterAction("selectteam", function(actionName, data)
    if data then
      o:selectTeam(data)
    end
  end)
  
  o.im.RegisterAction("selectleague", function(actionName, data)
    if data then
      o:selectLeague(data)
    end
  end)
  
  o.im.RegisterAction("act_jobapply", function(actionName, data)
      o:selectTeam(nil, true)
  end)
  
  o.im.RegisterAction("act_schedule", function(actionName, data)
      o:selectTeam(nil, nil, true)
  end)
  
  o.nav.AddActionHandler("kill", false, nil, function()
      o:finalize()
    end)

  return o
end

function Liga:switchLeague(mode)
  if mode == "init" or self.switchPanelOpened then
    self.im.Publish("switchPanelOpened", false)
    self.switchPanelOpened = false
  else
    self.im.Publish("switchPanelOpened", true)
    self.switchPanelOpened = true
  end
  if self.backgroundTimer then
    self.backgroundTimer:finalize()
    self.backgroundTimer = nil
  end
  self.backgroundTimer = Timer:new({
    id = "backgroundTimer",
    interval = 1,
    reps = 1,
    onTimerComplete = function()
      self.im.Publish(bndBackgroundCareer2, {name = "$CareerTable", id = self:getCurrentLeague()})
      self.backgroundTimer = nil
    end
  })
  self.backgroundTimer:start()
end

function Liga:selectLeague(data)
  local index = data.id + 1
  local selectedLeagueLocal = expandedLeagues[index]

  if not selectedLeagueLocal then
    return
  end

  selectedLeague = selectedLeagueLocal
  local currentLeague = selectedLeagueLocal

  local leagueLogo = self:getLeagueLogo()
  local leagueColor = self:getLeagueColor()
  local leagueName = self:getLeagueName()
  local colorBanner = self:getcolorBanner()

  self.im.Publish(bndBackgroundCareer, {name = "$CareerTable", id = currentLeague})
  self.im.Publish(bndLeagueColor, leagueColor)
  self.im.Publish(bndBanner, colorBanner)
  self.im.Publish("bnd_league_name", leagueName)
  self.im.Publish(bndTableCareer, {name = "$BgTable", id = currentLeague})
  self.im.Publish(bndLogo, {name = "$LeagueLogo", id = currentLeague})
  self.im.Publish("bnd_league_logo", leagueLogo)
  self.im.Publish("bnd_onteam", false)
  self.im.Publish("bnd_teampos", "")

  self:publishMatchRows2()
  self:switchLeague()
end

function Liga:selectTeam(data, apply, schedule)
  if data then
    self.team = self.teamDataList[data.id + 2].data
  end
  
  self.im.Publish("bnd_league_name", self.team.TeamName)
  self.im.Publish("bnd_league_logo", {name = "$Crest", id = self.team.TeamCrest.id})
  self.im.Publish("bnd_teampos", ordinal(self.team.Teampos))
  self.im.Publish("bnd_onteam", (self.team.TeamCrest.id ~= currentSelectedTeamID))
  if apply then
    if self.team.TeamCrest.id ~= currentSelectedTeamID then
      currentSelectedTeamID = self.team.TeamCrest.id
      sessionVars.set("currentPlayersID", {})
      sessionVars.set("currentFormationID", nil)
      sessionVars.set("sheetData", nil)
      sessionVars.set("sheetIdx", nil)
      self.im.Publish("bnd_onteam", (self.team.TeamCrest.id ~= currentSelectedTeamID))
    end
  end
  
  if schedule then
    sessionVars.set("scheduleTeam", self.team.TeamCrest.id)
    self.nav.Event(nil, "evt_calendar")
  end
  
end

function Liga:getLeagueColor()
    local currentLeague = self:getCurrentLeague()
    return leagueColors[currentLeague] or leagueColors[0] 
end

function Liga:getcolorBanner()
    local currentLeague = self:getCurrentLeague()
    return colorBanner[currentLeague] or colorBanner[0] 
end

function Liga:getLeagueLogo()
    local currentLeague = self:getCurrentLeague()
    return {
        name = "$LeagueLogo",  
        id = currentLeague
    }
end

function Liga:getLeagueName()
    local currentLeague = self:getCurrentLeague()
    return leagueNames[currentLeague] or leagueNames[0]
end

function Liga:getCurrentLeague()    
    return selectedLeague or sessionVars.get("currentUserLeagueID")
end

function Liga:Init()
    local userLeagueID = selectedLeague or sessionVars.get("currentUserLeagueID") or 13
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    local matchData = leagueMatchData[userLeagueID] or {}
    
    rivalListData = {}
    local matchCount = #matchData
    for i = 1, matchCount do
        local obj = {
            homeID = matchData[i].homeID,
            awayID = matchData[i].awayID,
            homeScore = matchData[i].homeScore or 0,
            awayScore = matchData[i].awayScore or 0,
            data = {}
        }
        rivalListData[i] = obj
    end
end

function Liga:displayLeagues()
  local v = {}
  expandedLeagues = {}

  -- copy CareerModeLeagues into expanded list
  for i = 1, #CareerModeLeagues do
    expandedLeagues[i] = CareerModeLeagues[i]
  end

  -- append expansion league
  expandedLeagues[#expandedLeagues + 1] = 2236

  for i = 1, #expandedLeagues do
    local currentLg = expandedLeagues[i]

    v[i] = {}
    v[i].data = {}

    v[i].data.flagCrest = {
      name = "$LeagueLogo",
      id = currentLg
    }

    v[i].data.TeamName =
      leagueNames[currentLg]
      or self.loc.LocalizeString("LeagueName_Abbr15_" .. currentLg)

    v[i].data.clickAction = "selectleague"
    v[i].data.TeamNameFontColor = "0xffffff"
  end

  self.im.Publish("LeagueList", v)
end

function Liga:getNextOpponent(teamID)
    local userLeagueID = selectedLeague or sessionVars.get("currentUserLeagueID") or 13
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    local matchData = leagueMatchData[userLeagueID] or {}
    
    for i = 1, #matchData do
        local match = matchData[i]
        local played = match.played or false
        
        if not played then
            if match.homeID == teamID then
                return match.awayID 
            elseif match.awayID == teamID then
                return match.homeID 
            end
        end
    end
    return nil
end

function Liga:publishMatchRows2()
    self.teamDataList = {}

    local userLeagueID = selectedLeague or sessionVars.get("currentUserLeagueID") or 13
    local standings = self.teamStats:getGroupStandings(userLeagueID)

    if not standings or #standings == 0 then
        self.im.Publish(bndMatchList1, {})
        return
    end

    local SelectedTeamID = currentSelectedTeamID
    
    -- Definisi warna
    local normalColor = "0x808080"
    local highlightColor = "0xFFFFFF"

    for i, entry in ipairs(standings) do
        local teamData = {}
        
        -- Logika penentuan warna
        local isSelected = (SelectedTeamID and tonumber(entry.teamID) == tonumber(SelectedTeamID))
        local colorToUse = isSelected and highlightColor or normalColor

        teamData.TeamCrest = {
            name = "$Crest64x64",
            id = entry.teamID
        }

        teamData.TeamName = entry.teamName
        local nameLength = string.len(teamData.TeamName)
        teamData.IconMarginLeft = 400 + (nameLength * 9.5)        
        teamData.TeamWin = tostring(entry.wins)
        teamData.TeamDraw = tostring(entry.draws)
        teamData.TeamLoss = tostring(entry.losses)
        teamData.TeamPoint = entry.points
        teamData.TeamGA = entry.goalsScored
        teamData.TeamGC = entry.goalsConceded
        teamData.TeamGD = entry.goalDifference
        teamData.Teammp = entry.matchesPlayed
        teamData.clickAction = "selectteam"
        teamData.Teampos = tostring(entry.position)

        teamData.TeamNameColor = colorToUse
        teamData.TeamposColor  = colorToUse
        teamData.TeammpColor   = colorToUse
        teamData.TeamWinColor  = colorToUse
        teamData.TeamDrawColor = colorToUse
        teamData.TeamLossColor = colorToUse
        teamData.TeamGAColor   = colorToUse
        teamData.TeamGCColor   = colorToUse
        teamData.TeamGDColor   = colorToUse -- Tambahkan jika ada

        -- Next opponent
        local nextOpponentID = self:getNextOpponent(entry.teamID)
        teamData.NextOpponentCrest = {
            name = "$Crest64x64",
            id = nextOpponentID or 0
        }

        -- ICON CHECKMARK
        if isSelected then
            teamData.Icon = {
                name = "$IconCheckMark",
                id = entry.teamID
            }
        else
            teamData.Icon = nil
        end

        teamData.RightText = ""

        table.insert(self.teamDataList, { data = teamData })
    end

    self.im.Publish(bndMatchList1, self.teamDataList)
end


function Liga:update(elapsedTime)
  if self.backgroundTimer then
    self.backgroundTimer:update(elapsedTime)
  end
end

function Liga:finalize()
  if self.backgroundTimer then
    self.backgroundTimer:finalize()
    self.backgroundTimer = nil
  end
  self.im.UnregisterAction("switchLeague")
  self.im.UnregisterAction("selectleague")
  self.im.UnregisterAction(ACT_NEXT)
  self.im.UnregisterAction(ACT_DECREASE)
  self.im.Unsubscribe(bndLeagueColor)
  self.im.Unsubscribe("bnd_match_list")
  self.im.Unsubscribe("bnd_match_list1")
  self.im.Unsubscribe("bnd_matchday_label")
  self.im.Unsubscribe("bnd_point_label")
  self.im.Unsubscribe("bnd_team_label")
  self.im.Unsubscribe("bnd_matchup_label")
  self.im.Unsubscribe("bnd_matchdate_label")
  self.im.Unsubscribe("bnd_league_label")
  self.im.Unsubscribe("bnd_advance_label")
  self.im.Unsubscribe("bnd_month_label")
  self.im.Unsubscribe("bnd_finish_label")
  selectedLeague = nil
end

return Liga
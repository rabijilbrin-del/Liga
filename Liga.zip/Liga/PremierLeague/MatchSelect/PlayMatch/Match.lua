local Match = {}
local isCoachMode = coachMode 
coachMode = nil
function Match:new(init)
    local o = init or {}
    setmetatable(o, self)
    self.__index = self
    -- Dev1
    o.services = {
        gameSetup = o.api("GameSetupService"),
        gameState = o.api("GameStateService")
    }

    o.nav.AddActionHandler("setTeams", false, nil, function()
        local homeID = currentMatch.HomeTeamID
        local awayID = currentMatch.AwayTeamID

        o.homeTeamID = homeID
        o.awayTeamID = awayID
        o.homeKitIndex = currentMatch.HomeKitIndex
        o.awayKitIndex = currentMatch.AwayKitIndex

        o.services.gameState.PauseAIandRendering(false)

        if homeID == currentSelectedTeamID then
            -- Current team is the home team
            o.services.gameSetup.SetTeam(0, homeID)
            o.services.gameSetup.SetTeam(1, awayID)
            if not isCoachMode then
              o.services.gameState.SetUserSideAsHome()
            end
        elseif awayID == currentSelectedTeamID then
            -- Current team is the away team
            o.services.gameSetup.SetTeam(1, awayID)
            o.services.gameSetup.SetTeam(0, homeID)
            if not isCoachMode then
              o.services.gameState.SetUserSideAsAway()
            end
        end

        o.services.gameSetup.SetPreferredKitId(0, o.homeTeamID * 4096 + o.homeKitIndex)
        o.services.gameSetup.SetPreferredKitId(1, o.awayTeamID * 4096 + o.awayKitIndex)
        o.services.gameSetup.CommitKitSelect()
    end)

    return o
end

return Match
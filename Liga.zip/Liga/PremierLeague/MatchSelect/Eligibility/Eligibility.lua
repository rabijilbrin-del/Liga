local Eligibility = {}

function Eligibility:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o:checkSquadEligibilty()
  o.nav.Event(nil, "evt_back")
  return o
end
function Eligibility:checkSquadEligibility()
    print("[Remover]: checkSquadEligibility()")
    
    local teamLineup = self.services.SquadManagementService.GetCurrentPlayerLineup(0, currentSelectedTeamID, 0)
    
    if not teamLineup or #teamLineup == 0 then
        print("[Remover]: No players available for eligibility check")
        self.eligibleSquad = 0
        SquadElig = self.eligibleSquad
        self:_publishEligibleSquad()
        return
    end

    local hasSuspendedPlayer = false
    
    -- Check players in indexes 1-18 for suspension
    for i = 1, math.min(18, #teamLineup) do
        local player = teamLineup[i]
        if player and player.playerName then
            if isSuspended[player.playerName] == 1 then
                print("[Remover]: Found suspended player " .. player.playerName .. " at index " .. i)
                hasSuspendedPlayer = true
                break
            end
        else
            print("[Remover]: Warning: Invalid player data at index " .. i)
        end
    end

    self.eligibleSquad = hasSuspendedPlayer and 1 or 0
    SquadElig = self.eligibleSquad
    print("[Remover]: Squad eligibility status: " .. self.eligibleSquad)
    self:_publishEligibleSquad()
end

-- New function to publish squad eligibility status
function Eligibility:_publishEligibleSquad()
    print("[Remover]: _publishEligibleSquad() - Status: " .. self.eligibleSquad)
    self.im.Publish(BND_ELIGIBLE_SQUAD, {
        eligibleSquad = self.eligibleSquad,
        teamID = currentSelectedTeamID,
        timestamp = os.time()
    })
end

function Eligibility:finalize()
end

return Eligibility
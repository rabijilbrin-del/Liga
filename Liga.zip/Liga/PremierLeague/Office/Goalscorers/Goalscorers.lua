local sessionVars, CareerModeLeagues, Timer = ...
local Liga = {}
local bndMatchList = "bnd_match_list"
local ACT_ADVANCE = "act_advance"
local bndLogo = "bnd_logo"
local bndBanner = "bnd_banner"
local bndBackgroundCareer = "bnd_background_career"
local bndBackgroundCareer2 = "bnd_background_career2"
local bndLeagueColor = "bnd_league_color"
local bndTableCareer = "bnd_table_career"
local selectedLeague = nil
local expandedLeagues = {}
local leagueColors = {
    [0] = 0xFF1E1D27,   -- Premier League (default)
    [13] = 0xFF160219,  -- League 13
    [16] = 0xFF090D15,  -- League 16  
    [19] = 0xFF121212,  -- League 19
    [31] = 0x000627,   -- League 31    
    [53] = 0xFF0D0A14,   -- League 53
    [350] = 0x011B03,   -- League 350              
    [2236] = 0x00073F,   -- League 2236     
    [2235] = 0x00021A   -- League 2235                       
}
local colorBanner = {
    [0] = 0xFF1E1D27,   -- Premier League (default)
    [13] = 0xFF351A45,  -- League 13
    [16] = 0xFF1D273B,  -- League 16  
    [19] = 0xFF121212,  -- League 19
    [31] = 0x001177,   -- League 31        
    [53] = 0xFF5F2C37,   -- League 53
    [350] = 0x003803,   -- League 350    
    [2236] = 0x001CFF,   -- League 2236              
    [2235] = 0x072A7E   -- League 2235                           
}
local leagueNames = {
    [4] = "Pro League",
    [7] = "Serie A",
    [10] = "Eredivisie",
    [13] = "Premier League",
    [14] = "Championship",
    [16] = "Ligue 1",
    [17] = "Ligue 2",
    [19] = "Bundesliga 1",
    [20] = "Bundesliga 2",
    [31] = "Serie A",
    [32] = "Serie B",
    [39] = "MLS",
    [50] = "Premiership",
    [53] = "La Liga",
    [54] = "Segunda",
    [60] = "League One",
    [66] = "Ekstraklasa",
    [68] = "Süper Lig",
    [76] = "Rest of World",
    [77] = "Rest of World 2",
    [78] = "International",
    [83] = "K League 1",
    [308] = "Primeira Liga",
    [341] = "Liga MX",
    [347] = "Premier Division",
    [349] = "J1 League",
    [350] = "Pro League",
    [351] = "A-League",
    [353] = "Primera División",
    [365] = "AFC",
    [1114] = "Premier League",
    [1245] = "Classic Team",
    [1246] = "Classic International",
    [2012] = "Super League",
    [2034] = "Ligue 1",
    [2136] = "International Women",
    [2149] = "Super League",
    [2215] = "Frauen-Bundesliga",
    [2216] = "FA WSL",
    [2218] = "Division 1 Féminine",
    [2221] = "NWSL",
    [2222] = "Liga F",
    [2231] = "Premier League",
    [2235] = "Liga 1",
    [2236] = "Champions League",
    [2237] = "Super League",
    [2238] = "Europe League",
    [2240] = "Champions League Women",
    [2250] = "Botola Pro",
    [2252] = "League 1",
    [2254] = "Pegadaian Liga 2",
    [2255] = "PNM Liga Nusantara",     
    [2260] = "V.League 1",
    [0] = "League" -- Default
}

function Liga:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.services = {
    settingsService = o.api("SettingsService"),
    SquadManagementService = o.api("SquadMgtService")
  }

  o.currentOptions = o.services.settingsService.GetCurrentOptions()
  o.switchPanelOpened = false

  o.im.Subscribe(bndMatchList, function()
     o:publishMatchRows()
  end)

  o.im.Subscribe("bnd_match_label", function()
    o:publishMatchLabel()
  end)
  
  o.im.Subscribe("LeagueList", function()
     o:displayLeagues()
  end)
 
  o.im.Subscribe(bndBackgroundCareer, function()  
  local currentLeague = o:getCurrentLeague()
    o.im.Publish(bndBackgroundCareer, {name = "$CareerTable", id = currentLeague})
  end)
  
  o.im.Subscribe(bndBackgroundCareer2, function()  
  local currentLeague = o:getCurrentLeague()
    o.im.Publish(bndBackgroundCareer2, {name = "$CareerTable", id = currentLeague})
  end)
  
  o.im.Subscribe(bndLeagueColor, function()
  local leagueColor = o:getLeagueColor()
  o.im.Publish(bndLeagueColor, leagueColor)
end)

o.im.Subscribe(bndBanner, function()
  local colorBanner = o:getcolorBanner()
  o.im.Publish(bndBanner, colorBanner)
end)

o.im.Subscribe("bnd_league_name", function()
    local leagueName = o:getLeagueName()
    o.im.Publish("bnd_league_name", leagueName)
end)
 
 o.im.Subscribe(bndTeamLogo, function()  
    o.im.Publish(bndTeamLogo, {name = "$Crest64x64", id = currentSelectedTeamID})   
  end)
  
  o.im.Subscribe(bndLogo, function()  
  local currentLeague = o:getCurrentLeague()
    o.im.Publish(bndLogo, {name = "$LeagueLogo", id = currentLeague})
  end)

o.im.Subscribe("bnd_league_logo", function()
    local leagueLogo = o:getLeagueLogo()
    o.im.Publish("bnd_league_logo", leagueLogo)
end)
  
  o.im.Subscribe(bndTableCareer, function()  
  local currentLeague = o:getCurrentLeague()
    o.im.Publish(bndTableCareer, {name = "$BgTable", id = currentLeague})
  end)

  o.im.Subscribe("bnd_finish_label", function()
    o:publishFinishLabel()
  end)
  
  o.im.Subscribe("switchPanelOpened", function()  
    o:switchLeague("init")
  end)
  
    o.im.RegisterAction("switchLeague", function(actionName, dt)
      o:switchLeague()
  end)
    
  o.im.RegisterAction("selectleague", function(actionName, data)
    if data then
      o:selectLeague(data)
    end
  end)

  o.im.RegisterAction(ACT_ADVANCE, function(actionName, data)
    if data then
      
    end
  end)

  return o
end

function Liga:switchLeague(mode)
  if mode == "init" or self.switchPanelOpened then
    self.im.Publish("switchPanelOpened", false)
    self.switchPanelOpened = false
  else
    self.im.Publish("switchPanelOpened", true)
    self.switchPanelOpened = true
  end
  if self.backgroundTimer then
    self.backgroundTimer:finalize()
    self.backgroundTimer = nil
  end
  self.backgroundTimer = Timer:new({
    id = "backgroundTimer",
    interval = 1,
    reps = 1,
    onTimerComplete = function()
      self.im.Publish(bndBackgroundCareer2, {name = "$CareerTable", id = self:getCurrentLeague()})
      self.backgroundTimer = nil
    end
  })
  self.backgroundTimer:start()
end

function Liga:displayLeagues()
  local v = {}
  expandedLeagues = {}

  -- copy base leagues
  for i = 1, #CareerModeLeagues do
    expandedLeagues[i] = CareerModeLeagues[i]
  end

  expandedLeagues[#expandedLeagues + 1] = 2236

  for i = 1, #expandedLeagues do
    local currentLg = expandedLeagues[i]

    v[i] = {}
    v[i].data = {}

    v[i].data.flagCrest = {
      name = "$LeagueLogo",
      id = currentLg
    }

    v[i].data.TeamName =
      leagueNames[currentLg]
      or self.loc.LocalizeString("LeagueName_Abbr15_" .. currentLg)

    v[i].data.clickAction = "selectleague"
    v[i].data.TeamNameFontColor = "0xffffff"
  end

  self.im.Publish("LeagueList", v)
end

function Liga:selectLeague(data)
  local index = data.id + 1
  local selectedLeagueLocal = expandedLeagues[index]

  if not selectedLeagueLocal then
    return
  end

  selectedLeague = selectedLeagueLocal
  local currentLeague = selectedLeagueLocal

  local leagueLogo = self:getLeagueLogo()
  local leagueColor = self:getLeagueColor()
  local leagueName = self:getLeagueName()
  local colorBanner = self:getcolorBanner()

  self.im.Publish(bndBackgroundCareer, {name = "$CareerTable", id = currentLeague})
  self.im.Publish(bndLeagueColor, leagueColor)
  self.im.Publish(bndBanner, colorBanner)
  self.im.Publish("bnd_league_name", leagueName)
  self.im.Publish(bndTableCareer, {name = "$BgTable", id = currentLeague})
  self.im.Publish(bndLogo, {name = "$LeagueLogo", id = currentLeague})
  self.im.Publish("bnd_league_logo", leagueLogo)
  self.im.Publish("bnd_onteam", false)

  self:publishMatchRows()
  self:switchLeague()
end

function Liga:getCurrentLeague()    
    return selectedLeague or sessionVars.get("currentUserLeagueID")
end

function Liga:getLeagueLogo()
    local currentLeague = self:getCurrentLeague()
    return {
        name = "$LeagueLogo",  
        id = currentLeague
    }
end

function Liga:getLeagueName()
    local currentLeague = self:getCurrentLeague()
    return leagueNames[currentLeague] or leagueNames[0]
end

function Liga:getcolorBanner()
    local currentLeague = self:getCurrentLeague()
    return colorBanner[currentLeague] or colorBanner[0] 
end

function Liga:getLeagueColor()
    local currentLeague = self:getCurrentLeague()
    return leagueColors[currentLeague] or leagueColors[0] 
end

------------------------------------------------------------------------------------------

function Liga:publishMatchRows()   
    local leagueID = self:getCurrentLeague()
    local TeamList = sessionVars.get("LeagueTeams")[leagueID]
    local playerGoals = sessionVars.get("PlayerGoals") or {}
    local leagueGoals = playerGoals[leagueID] or {}

    -- If no goals are recorded for leagueID = 13, show NoScorer popup
    if next(leagueGoals) == nil then
        print("[Liga:publishMatchRows]: No goals recorded for leagueID = 13.")
        self:NoScorer()
        return
    end

    -- Fetch the lineups for all teams in TeamList
    local combinedLineup = {}
    for _, teamID in ipairs(TeamList) do
        local lineup = getCachedTeamPlayers(teamID)
        if lineup and #lineup > 0 then
            for _, player in ipairs(lineup) do
                player.teamID = teamID -- Track the team ID for each player
                table.insert(combinedLineup, player)
            end
        end
    end

    -- Check if the combined lineup is empty
    if #combinedLineup == 0 then
        print("[Liga:publishMatchRows]: Combined lineup for TeamList is empty or invalid.")
        self:NoScorer()
        return
    end

    -- Add goal counts from playerGoals[13] to each player
    for _, player in ipairs(combinedLineup) do
        player.goalCount = leagueGoals[player.CARD_ID] or 0
    end

    -- Sort the combined lineup by goal count (highest to lowest)
    table.sort(combinedLineup, function(a, b)
        return a.goalCount > b.goalCount
    end)

    -- Limit the combined lineup to the top 50 players
    local topPlayers = {}
    for i = 1, math.min(50, #combinedLineup) do
        topPlayers[i] = combinedLineup[i]
    end

    -- Iterate through the top 50 players and add them to the data
    local filteredRivalListData = {}
    for rank, player in ipairs(topPlayers) do
        local playerName = player.playerName
        local position = tostring(player.position)
        local rating = tostring(player.rating)
        local teamName = self.loc.LocalizeString("TeamName_Abbr3_" .. player.teamID)

        -- Create the row with dynamic rank value
        local row = {
            data = {
                PlayerName = player.playerName,
                        Position = tostring(player.position),
                        Rating = tostring(player.rating),
                        TeamName = self.loc.LocalizeString("TeamName_Abbr15_" .. player.teamID),
                        Goals = player.goalCount,
                        Rank = tostring(rank),
                        PlayerHead = {
                            name = "$Head",
                            id = player.CARD_ID
                        },
                        PlayerNationality = {
                            name = "$Flag128x128",
                            id = player.nationalityID
                        },
                        TeamCrest = {
                            name = "$Crest64x64",
                            id = player.teamID
                },
            }
        }

        filteredRivalListData[rank] = row
    end

    -- Publish the player list
    self.im.Publish(bndMatchList, filteredRivalListData)
end


function Liga:NoScorer()
  local buttonYes = {
    icon = "$FooterIconNo",
    label = "Close",
    clickEvents = {
      "evt_hide_popup",
      "evt_back"
    }
  }
  local popupData = {
    title = "",
    message = "No goalscorers yet",
    buttons = {buttonYes}
  }
  self.nav.Event(nil, "evt_show_popup", popupData)
end

function Liga:finalize()
  self.im.UnregisterAction(ACT_ADVANCE)
  self.im.Unsubscribe("bnd_match_list")
  self.im.Unsubscribe("bnd_match_label")
  self.im.Unsubscribe("bnd_finish_label")
selectedLeague = nil  
end

return Liga

-- Thanks : Ma'ruf Id & Laosiji --
-- @mvnprod.official - Remain Be Creative --
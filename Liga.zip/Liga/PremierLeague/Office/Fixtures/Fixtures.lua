local sessionVars, CareerModeLeagues, Timer = ...
local Liga = {}
local bndMatchList = "bnd_match_list"
local bndLeagueColor = "bnd_league_color"
local bndBanner = "bnd_banner"
local bndBackgroundCareer = "bnd_background_career"
local bndBackgroundCareer2 = "bnd_background_career2"
local rivalListData = {}
local expandedLeagues = {}
local matchround = nil
local selectedLeague = nil
local leagueColors = {
    [0] = 0xFF1E1D27,   -- Premier League (default)
    [13] = 0xFF160219,  -- League 13
    [16] = 0xFF090D15,  -- League 16  
    [19] = 0xFF121212,  -- League 19
    [31] = 0x000627,   -- League 31    
    [53] = 0xFF0D0A14,   -- League 53
    [350] = 0x011B03,   -- League 350              
    [2236] = 0x00073F,   -- League 2236     
    [2235] = 0x00021A   -- League 2235                       
}

local colorBanner = {
    [0] = 0xFF1E1D27,   -- Premier League (default)
    [13] = 0xFF351A45,  -- League 13
    [16] = 0xFF1D273B,  -- League 16  
    [19] = 0xFF121212,  -- League 19
    [31] = 0x001177,   -- League 31        
    [53] = 0xFF5F2C37,   -- League 53
    [350] = 0x003803,   -- League 350    
    [2236] = 0x001CFF,   -- League 2236              
    [2235] = 0x072A7E   -- League 2235                           
}

local leagueNames = {
    [4] = "Pro League",
    [7] = "Serie A",
    [10] = "Eredivisie",
    [13] = "Premier League",
    [14] = "Championship",
    [16] = "Ligue 1",
    [17] = "Ligue 2",
    [19] = "Bundesliga 1",
    [20] = "Bundesliga 2",
    [31] = "Serie A",
    [32] = "Serie B",
    [39] = "MLS",
    [50] = "Premiership",
    [53] = "La Liga",
    [54] = "Segunda",
    [60] = "League One",
    [66] = "Ekstraklasa",
    [68] = "Süper Lig",
    [76] = "Rest of World",
    [77] = "Rest of World 2",
    [78] = "International",
    [83] = "K League 1",
    [308] = "Primeira Liga",
    [341] = "Liga MX",
    [347] = "Premier Division",
    [349] = "J1 League",
    [350] = "Pro League",
    [351] = "A-League",
    [353] = "Primera División",
    [365] = "AFC",
    [1114] = "Premier League",
    [1245] = "Classic Team",
    [1246] = "Classic International",
    [2012] = "Super League",
    [2034] = "Ligue 1",
    [2136] = "International Women",
    [2149] = "Super League",
    [2215] = "Frauen-Bundesliga",
    [2216] = "FA WSL",
    [2218] = "Division 1 Féminine",
    [2221] = "NWSL",
    [2222] = "Liga F",
    [2231] = "Premier League",
    [2235] = "Liga 1",
    [2236] = "Champions League",
    [2237] = "Super League",
    [2238] = "Europe League",
    [2240] = "Champions League Women",
    [2250] = "Botola Pro",
    [2252] = "League 1",
    [2254] = "Pegadaian Liga 2",
    [2255] = "PNM Liga Nusantara",     
    [2260] = "V.League 1",
    [0] = "League" -- Default
}
function Liga:new(init)
    local o = init or {}
    setmetatable(o, self)
    self.__index = self

    initTheme(o.im)

    o.services = {
        settingsService = o.api("SettingsService"),
        SquadManagementService = o.api("SquadMgtService")
    }

    o.round = 1
    o.currentOptions = o.services.settingsService.GetCurrentOptions()
    o.switchPanelOpened = false
  
    if Timer then
        o.startupTimer = Timer:new({
            id = "ligaStartup",
            interval = 0.1,
            reps = 1,
            onTimerComplete = function()
                o:refreshData()
                o:RegisterSubscriptions()
                o:RegisterActions()
                o:publishLabel()
                o:publishMatchRows()
            end
        })
        o.startupTimer:start()
    else
        o:refreshData()
        o:RegisterSubscriptions()
        o:RegisterActions()
        o:publishLabel()
        o:publishMatchRows()
    end
  o.im.Subscribe("LeagueList", function()
     o:displayLeagues()
  end)
 
  o.im.Subscribe(bndBackgroundCareer, function()  
  local currentLeague = o:getCurrentLeague()
    o.im.Publish(bndBackgroundCareer, {name = "$CareerTable", id = currentLeague})
  end)
  
  o.im.Subscribe(bndBackgroundCareer2, function()  
  local currentLeague = o:getCurrentLeague()
    o.im.Publish(bndBackgroundCareer2, {name = "$CareerTable", id = currentLeague})
  end)    
o.im.Subscribe("bnd_league_name", function()
    local leagueName = o:getLeagueName()
    o.im.Publish("bnd_league_name", leagueName)
end)
o.im.Subscribe(bndBanner, function()
  local colorBanner = o:getcolorBanner()
  o.im.Publish(bndBanner, colorBanner)
end)
  o.im.Subscribe(bndLeagueColor, function()
  local leagueColor = o:getLeagueColor()
  o.im.Publish(bndLeagueColor, leagueColor)
end)
o.im.Subscribe("bnd_league_logo", function()
    local leagueLogo = o:getLeagueLogo()
    o.im.Publish("bnd_league_logo", leagueLogo)
end)
  o.im.Subscribe("switchPanelOpened", function()  
    o:switchLeague("init")
  end)
  
    o.im.RegisterAction("switchLeague", function(actionName, dt)
      o:switchLeague()
  end)
    
  o.im.RegisterAction("selectleague", function(actionName, data)
    if data then
      o:selectLeague(data)
    end
  end)
  
    return o
end

function Liga:RegisterSubscriptions()
    self.im.Subscribe(bndMatchList, function()
        self:publishMatchRows()
    end)

    self.im.Subscribe("bnd_match_label", function()
        self:publishMatchLabel()
    end)

    self.im.Subscribe("bnd_point_label", function()
        self:publishMatchLabel()
    end)

    self.im.Subscribe("bnd_finish_label", function()
        self:publishFinishLabel()
    end)

    self.im.Subscribe("bnd_team_label", function()
        self:publishLabel()
    end)

    self.im.Subscribe("bnd_matchup_label", function()
        self:publishFinishLabel()
    end)

    self.im.Subscribe("bnd_matchday_label", function()
        self:publishLabel()
    end)

    self.im.Subscribe("bnd_league_label", function()
        self:publishFinishLabel()
    end)

    self.im.Subscribe("bnd_advance_label", function()
        self:publishFinishLabel()
    end)

    self.im.Subscribe("bnd_month_label", function()
        self:publishFinishLabel()
    end)
end

function Liga:switchLeague(mode)
  if mode == "init" or self.switchPanelOpened then
    self.im.Publish("switchPanelOpened", false)
    self.switchPanelOpened = false
  else
    self.im.Publish("switchPanelOpened", true)
    self.switchPanelOpened = true
  end
  if self.backgroundTimer then
    self.backgroundTimer:finalize()
    self.backgroundTimer = nil
  end
  self.backgroundTimer = Timer:new({
    id = "backgroundTimer",
    interval = 1,
    reps = 1,
    onTimerComplete = function()
      self.im.Publish(bndBackgroundCareer2, {name = "$CareerTable", id = self:getCurrentLeague()})
      self.backgroundTimer = nil
    end
  })
  self.backgroundTimer:start()
end

function Liga:displayLeagues()
  local v = {}
  expandedLeagues = {}

  -- copy base leagues
  for i = 1, #CareerModeLeagues do
    expandedLeagues[i] = CareerModeLeagues[i]
  end

  expandedLeagues[#expandedLeagues + 1] = 2236

  for i = 1, #expandedLeagues do
    local currentLg = expandedLeagues[i]

    v[i] = {}
    v[i].data = {}

    v[i].data.flagCrest = {
      name = "$LeagueLogo",
      id = currentLg
    }

    v[i].data.TeamName =
      leagueNames[currentLg]
      or self.loc.LocalizeString("LeagueName_Abbr15_" .. currentLg)

    v[i].data.clickAction = "selectleague"
    v[i].data.TeamNameFontColor = "0xffffff"
  end

  self.im.Publish("LeagueList", v)
end

function Liga:selectLeague(data)
  local index = data.id + 1
  local selectedLeagueLocal = expandedLeagues[index]

  if not selectedLeagueLocal then
    return
  end

  selectedLeague = selectedLeagueLocal
  local currentLeague = selectedLeagueLocal

  local leagueLogo = self:getLeagueLogo()
  local leagueColor = self:getLeagueColor()
  local leagueName = self:getLeagueName()
  local colorBanner = self:getcolorBanner()

  self.im.Publish(bndBackgroundCareer, {name = "$CareerTable", id = currentLeague})
  self.im.Publish(bndLeagueColor, leagueColor)
  self.im.Publish(bndBanner, colorBanner)
  self.im.Publish("bnd_league_name", leagueName)
  self.im.Publish(bndTableCareer, {name = "$BgTable", id = currentLeague})
  self.im.Publish(bndLogo, {name = "$LeagueLogo", id = currentLeague})
  self.im.Publish("bnd_league_logo", leagueLogo)
  self.im.Publish("bnd_onteam", false)

  self:publishMatchRows()
  self:switchLeague()
end

function Liga:getLeagueColor()
    local currentLeague = self:getCurrentLeague()
    return leagueColors[currentLeague] or leagueColors[0] 
end

function Liga:getcolorBanner()
    local currentLeague = self:getCurrentLeague()
    return colorBanner[currentLeague] or colorBanner[0] 
end

function Liga:getLeagueLogo()
    local currentLeague = self:getCurrentLeague()
    return {
        name = "$LeagueLogo",  
        id = currentLeague
    }
end

function Liga:getLeagueName()
    local currentLeague = self:getCurrentLeague()
    return leagueNames[currentLeague] or leagueNames[0]
end

function Liga:getCurrentLeague()    
    return selectedLeague or sessionVars.get("currentUserLeagueID")
end
function Liga:RegisterActions()
    self.im.RegisterAction("rowClick", function(_, data)
        if data then
            self:rowClick(data)
        end
    end)

    self.im.RegisterAction("nextMd", function()
        self:viewMd(1)
    end)

    self.im.RegisterAction("prevMd", function()
        self:viewMd(-1)
    end)
end

function Liga:getMaxMd()
    local userLeagueID = self:getCurrentLeague()
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    local matchData = leagueMatchData[userLeagueID] or {}
    local maxMd = 1
    for i = 1, #matchData do
        if matchData[i].matchday and matchData[i].matchday > maxMd then
            maxMd = matchData[i].matchday
        end
    end
    return maxMd
end

function Liga:viewMd(dir)
    local maxMd = self:getMaxMd()
    self.round = self.round + dir
    if self.round < 1 then
        self.round = maxMd
    elseif self.round > maxMd then
        self.round = 1
    end

    self:publishMatchRows()
    self:publishLabel()
end

function Liga:refreshData()
    local userLeagueID = self:getCurrentLeague()
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    local matchData = leagueMatchData[userLeagueID] or {}

    rivalListData = {}

    for i = 1, #matchData do
        rivalListData[i] = {
            homeID = matchData[i].homeID,
            awayID = matchData[i].awayID,
            homeScore = matchData[i].homeScore or 0,
            awayScore = matchData[i].awayScore or 0,
            homePenScore = matchData[i].homePenScore or 0,
            awayPenScore = matchData[i].awayPenScore or 0,
            played = matchData[i].played or false,
            matchType = matchData[i].matchType,
            matchday = matchData[i].matchday,
            matchRound = matchData[i].matchRound or false,
            data = {}
        }
    end
end

function Liga:publishLabel()
    self.im.Publish("bnd_matchday_label", (matchround and matchround or ("MATCHDAY " .. self.round)))
end

function Liga:publishMatchRows()
    self:refreshData()

    local filteredRivalListData = {}
    local filteredIndex = 1
    local currentRoundName = nil

    local SelectedTeamID = currentSelectedTeamID

    for i = 1, #rivalListData do
        local v = rivalListData[i]

        if v.matchday == self.round then
            if not currentRoundName and v.matchRound then
                currentRoundName = v.matchRound
            end

            v.data.TeamHomeCrest = {
                name = "$Crest64x64",
                id = v.homeID
            }

            v.data.TeamAwayCrest = {
                name = "$Crest64x64",
                id = v.awayID
            }

            v.data.TeamHomeCrestR = {
                name = "$Crest64x64",
                id = v.homeID
            }

            v.data.TeamAwayCrestR = {
                name = "$Crest64x64",
                id = v.awayID
            }

            v.data.TeamHomeName =
                self.loc.LocalizeString("TeamName_Abbr15_" .. v.homeID)

            v.data.TeamAwayName =
                self.loc.LocalizeString("TeamName_Abbr15_" .. v.awayID)

            -- Checkmark tim yang dipilih
            v.data.HomeIcon =
                (SelectedTeamID and tonumber(v.homeID) == tonumber(SelectedTeamID))
                and {
                    name = "$IconCheckMark",
                    id = v.homeID
                }
                or nil

            v.data.AwayIcon =
                (SelectedTeamID and tonumber(v.awayID) == tonumber(SelectedTeamID))
                and {
                    name = "$IconCheckMark",
                    id = v.awayID
                }
                or nil

            v.data.ClickActions = "rowClick"
            v.data.ClickActionsR = "rowClick"
            v.data.isSelectedLeft = false

            v.data.MatchScore = v.played and
                ((v.homeScore + v.homePenScore) ..
                "    -    " ..
                (v.awayScore + v.awayPenScore))
                or "VS"

            v.data.TeamScoreFontColor = "0xffffff"
            v.data.TeamNameFontColor = "0x4A2C6D"
            v.data.FontColor = "0x4A2C6D"
            v.data.MatchStatus = ""

            v.data.Icon = {
                name = "$",
                id = 1
            }

            v.data.RightText = ""

            filteredRivalListData[filteredIndex] = v
            filteredIndex = filteredIndex + 1
        end
    end

    matchround = currentRoundName

    self.im.Publish(bndMatchList, filteredRivalListData)
end

function Liga:rowClick()
end

function Liga:update(elapsedTime)
    if self.startupTimer then
        self.startupTimer:update(elapsedTime)
    end
end

function Liga:finalize()
    if self.startupTimer then
        self.startupTimer:finalize()
        self.startupTimer = nil
    end

    self.im.Unsubscribe("bnd_match_list")
    self.im.Unsubscribe("bnd_matchday_label")
    self.im.Unsubscribe("bnd_point_label")
    self.im.Unsubscribe("bnd_team_label")
    self.im.Unsubscribe("bnd_matchup_label")
    self.im.Unsubscribe("bnd_matchdate_label")
    self.im.Unsubscribe("bnd_league_label")
    self.im.Unsubscribe("bnd_advance_label")
    self.im.Unsubscribe("bnd_month_label")
    self.im.Unsubscribe("bnd_finish_label")
selectedLeague = nil
    rivalListData = {}
end

return Liga
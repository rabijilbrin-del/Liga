-- Mod By MVN PROD --
-- League Mode Division --
local sessionVars = ...
local Liga = {}
local bndMatchList = "bnd_match_list"
local ACT_ADVANCE = "act_advance"

ligaId = 1
if not round then
    round = 1
else
    round = round
end

if not selectedteam then
    selectedteam = 1
else
    selectedteam = selectedteam
end

currentMatch = {
    HomeTeamID = 0,
    AwayTeamID = 0,
    HomeKitIndex = 0,
    AwayKitIndex = 1
}

-- Dev2
local rivalListData = {}
local matchesPlayed = 0  -- Counter to track the number of matches played

function Liga:new(init)
    local o = init or {}
    setmetatable(o, self)
    self.__index = self
    o.services = {
        settingsService = o.api("SettingsService"),
        SquadManagementService = o.api("SquadMgtService")
    }

    o.currentOptions = o.services.settingsService.GetCurrentOptions()
    o:Init()
    
    o.im.Subscribe(bndMatchList, function()
        o:publishMatchRows()
    end)
    
    o.im.Subscribe("bnd_match_label", function()
        o:publishMatchLabel()
    end)
    
    o.im.Subscribe("bnd_point_label", function()
        o:publishMatchLabel()
    end)
    
    o.im.Subscribe("bnd_finish_label", function()
        o:publishFinishLabel()
    end)
    
    o.im.Subscribe("bnd_team_label", function()
        o:publishLabel()
    end)
    
    o.im.Subscribe("bnd_matchup_label", function()
        o:publishFinishLabel()
    end)
    
    o.im.Subscribe("bnd_matchday_label", function()
        o:publishLabel()
    end)
    
    o.im.Subscribe("bnd_league_label", function()
        o:publishFinishLabel()
    end)
    
    o.im.Subscribe("bnd_advance_label", function()
        o:publishFinishLabel()
    end)
    
    o.im.Subscribe("bnd_month_label", function()
        o:publishFinishLabel()
    end)
    
    o.im.RegisterAction(ACT_ADVANCE, function(actionName, data)
        if data then
            o:PlayMatch(data)
        end
    end)

    return o
end

------------------------------------------------------------------------------------------

function Liga:Init()
    -- Get MatchData for leagueID 13 from LeagueMatchData
    local userLeagueID = sessionVars.get("currentUserLeagueID")
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    local matchData = leagueMatchData[userLeagueID] or {} -- Specific to leagueID 13
    
    rivalListData = {} -- Clear existing data
    local matchCount = #matchData
    for i = 1, matchCount do
        local obj = {
            homeID = matchData[i].homeID,
            awayID = matchData[i].awayID,
            homeScore = matchData[i].homeScore or 0,
            awayScore = matchData[i].awayScore or 0,
            data = {}
        }
        rivalListData[i] = obj -- Direct index assignment
    end
end

------------------------------------------------------------------------------------------

function Liga:publishLabel()
    self.im.Publish("bnd_matchday_label", "MATCHDAY " .. round)
    if selectedteam == 0 then
        self.im.Publish("bnd_team_label", "BY MATCHDAY ")
    else
        self.im.Publish("bnd_team_label", self.loc.LocalizeString("TeamName_Abbr15_" .. TeamList[selectedteam]))
    end
end

function Liga:publishMatchRows()
    local filteredRivalListData = {}
    local userLeagueID = sessionVars.get("currentUserLeagueID")
    local TeamList = sessionVars.get("LeagueTeams")[userLeagueID]
    local matchCount = (#TeamList / 2)
    local filteredIndex = 1

    -- Loop through all matches in rivalListData
    for i = 1, #rivalListData do
        local v = rivalListData[i]
        local shouldIncludeMatch = false

        if selectedteam == 0 then
            shouldIncludeMatch = i >= ((round * matchCount) - (matchCount - 1)) and i <= (round * matchCount)
        else
            shouldIncludeMatch = (v.homeID == TeamList[selectedteam] or v.awayID == TeamList[selectedteam])
        end

        if shouldIncludeMatch then
            -- Populate match data
            v.data.TeamHomeCrest = {
                name = "$Crest64x64",
                id = v.homeID
            }
            v.data.TeamAwayCrest = {
                name = "$Crest64x64",
                id = v.awayID
            }
            v.data.TeamHomeCrestR = {
                name = "$Crest64x64",
                id = v.homeID
            }
            v.data.TeamAwayCrestR = {
                name = "$Crest64x64",
                id = v.awayID
            }
            v.data.TeamHomeName = self.loc.LocalizeString("TeamName_Abbr15_" .. v.homeID)
            v.data.TeamAwayName = self.loc.LocalizeString("TeamName_Abbr15_" .. v.awayID)
            v.data.ClickActions = "act_back"
            v.data.ClickActionsR = "act_back"

            -- Determine how many rows should show scores based on GLOBAL_MATCHUP_COUNT
            local maxRowsWithScores = 380

            if i <= maxRowsWithScores then
                v.data.MatchScore = v.homeScore .. "    -    " .. v.awayScore
            else
                v.data.MatchScore = "VS"
            end

            v.data.TeamScoreFontColor = "0xffffff"
            v.data.TeamNameFontColor = "0x4A2C6D"
            v.data.FontColor = "0x4A2C6D"
            v.data.MatchStatus = ""

            -- Set icon and right text based on match status
            if not v.isUnlock then
                v.data.Icon = { name = "$", id = 1 }
                v.data.RightText = ""
            else
                v.data.Icon = { name = "$", id = 2 }
                v.data.RightText = ""
            end

            -- Add the match to the filtered list using direct index assignment
            filteredRivalListData[filteredIndex] = v
            filteredIndex = filteredIndex + 1
        end
    end
    
    -- Publish only the filtered matches
    self.im.Publish(bndMatchList, filteredRivalListData)
end

function Liga:finalize()
    self.im.UnregisterAction(ACT_ADVANCE)
    self.im.Unsubscribe("bnd_match_list")
    self.im.Unsubscribe("bnd_matchday_label")
    self.im.Unsubscribe("bnd_point_label")
    self.im.Unsubscribe("bnd_team_label")
    self.im.Unsubscribe("bnd_matchup_label")
    self.im.Unsubscribe("bnd_matchdate_label")
    self.im.Unsubscribe("bnd_league_label")
    self.im.Unsubscribe("bnd_advance_label")
    self.im.Unsubscribe("bnd_month_label")
    self.im.Unsubscribe("bnd_finish_label")
    rivalListData = {}
end

return Liga

-- Thanks : Ma'ruf Id & Laosiji --
-- @mvnprod.official - Remain Be Creative --
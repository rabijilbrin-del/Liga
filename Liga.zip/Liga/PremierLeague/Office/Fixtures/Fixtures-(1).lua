-- Mod By MVN PROD --
-- League Mode Division --

local Liga = {}
local bndMatchList = "bnd_match_list"
local ACT_ADVANCE = "act_advance"

ligaId = 1

currentMatch = {
  HomeTeamID = 0,
  AwayTeamID = 0,
  HomeKitIndex = 0,
  AwayKitIndex = 1
}

-- Dev2
local rivalListData = {}
local matchesPlayed = 0  -- Counter to track the number of matches played

function Liga:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.services = {
    settingsService = o.api("SettingsService"),
    SquadManagementService = o.api("SquadMgtService")
  }

  o.currentOptions = o.services.settingsService.GetCurrentOptions()
  o.Init()
  
  o.im.Subscribe(bndMatchList, function()
     o:publishMatchRows()
  end)
  
  o.im.Subscribe("bnd_match_label", function()
    o:publishMatchLabel()
  end)
  
  o.im.Subscribe("bnd_point_label", function()

    o:publishMatchLabel()

  end)
  
  o.im.Subscribe("bnd_finish_label", function()
    o:publishFinishLabel()
  end)
  
  o.im.Subscribe("bnd_date_label", function()
    o:publishFinishLabel()
  end)
  
  o.im.Subscribe("bnd_matchup_label", function()

    o:publishFinishLabel()

  end)
  
  o.im.Subscribe("bnd_matchdate_label", function()

    o:publishFinishLabel()

  end)
  
  o.im.Subscribe("bnd_league_label", function()

    o:publishFinishLabel()

  end)
  
  o.im.Subscribe("bnd_advance_label", function()

    o:publishFinishLabel()

  end)
  
  o.im.Subscribe("bnd_month_label", function()

    o:publishFinishLabel()

  end)
  
  o.im.RegisterAction(ACT_ADVANCE, function(actionName, data)
    if data then
      o:PlayMatch(data)
    end
  end)

  return o
end

------------------------------------------------------------------------------------------

function Liga:Init()
  local LigaGroupingList = LigaGrouping[ligaId]
  for i = 1, table.getn(LigaGroupingList) do
    local obj = {
      homeID = LigaGroupingList[i][1],
      awayID = LigaGroupingList[i][2],
      homeScore = LigaGroupingList[i][4],
      awayScore = LigaGroupingList[i][5],
 
      data = {}
    }
    table.insert(rivalListData, obj)
  end
end

------------------------------------------------------------------------------------------

function Liga:publishMatchRows()
  local filteredRivalListData = {}

  -- Loop through all matches in rivalListData
  for i, v in ipairs(rivalListData) do
    -- Check if the selected team is either the home or away team
      
      -- Populate the match data for the selected team's match
      v.data.HomeTeamCrest = {
        name = "$Crest",
        id = rivalListData[i].homeID
      }
      v.data.Home2TeamCrest = {
        name = "$Crest",
        id = rivalListData[i].homeID
      }
      v.data.AwayTeamCrest = {
        name = "$Crest64x64",
        id = rivalListData[i].awayID
      }
      v.data.HomeTeamName = self.loc.LocalizeString("TeamName_Abbr15_"..rivalListData[i].homeID)
      v.data.AwayTeamName = self.loc.LocalizeString("TeamName_Abbr15_"..rivalListData[i].awayID)
      v.data.HomeTeamShortName = self.loc.LocalizeString("TeamName_Abbr3_"..rivalListData[i].homeID)
      v.data.clickAction = "act_back"
      -- Determine how many rows should show scores based on GLOBAL_MATCHUP_COUNT

    local maxRowsWithScores = GLOBAL_MATCHUP_COUNT * 10

    if i <= maxRowsWithScores then

        rivalListData[i].data.MatchScore = rivalListData[i].homeScore .. "        -        " .. rivalListData[i].awayScore -- Append scores

    else

        rivalListData[i].data.MatchScore = "VS" -- Show "VS" for the remaining rows

    end

      v.data.TeamScoreFontColor = "0xffffff"
      v.data.TeamNameFontColor = "0x4A2C6D"
      v.data.FontColor = "0x4A2C6D"

      -- Set icon and right text based on match status
      if not rivalListData[i].isUnlock then
        v.data.Icon = {
          name = "$",
          id = 1
        }
        v.data.RightText = ""
      else
        v.data.Icon = {
          name = "$IconMatchPlay",
          id = 2
        }
        v.data.RightText = ""
      end

      -- Add the match to the filtered list (only matches involving the selected team)
      table.insert(filteredRivalListData, v)
    end
  
  -- Publish only the filtered matches involving the selected team
  self.im.Publish(bndMatchList, filteredRivalListData)
end

function Liga:finalize()
  self.im.UnregisterAction(ACT_ADVANCE)
  self.im.Unsubscribe("bnd_match_list")
  self.im.Unsubscribe("bnd_match_label")
  self.im.Unsubscribe("bnd_point_label")
  self.im.Unsubscribe("bnd_date_label")
  self.im.Unsubscribe("bnd_matchup_label")
  self.im.Unsubscribe("bnd_matchdate_label")
  self.im.Unsubscribe("bnd_league_label")
  self.im.Unsubscribe("bnd_advance_label")
  self.im.Unsubscribe("bnd_month_label")
  self.im.Unsubscribe("bnd_finish_label")
  rivalListData = {}
  
end

return Liga

-- Thanks : Ma'ruf Id & Laosiji --
-- @mvnprod.official - Remain Be Creative --
local Squads = {}

function Squads:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.services = init.services
  return o
end

-- Swaps a player with a substitute (if starter) or removes them (if substitute).
-- @param playerId The CARD_ID of the player to swap or remove.
-- @param team The team identifier.
-- @return A table of player IDs representing the modified squad.
function Squads:swapSoldPlayer(playerId, team)
  local squad = self.services.SquadManagementService.GetCurrentPlayerLineup(0, team, 0)
  local players = {}
  local playerIndex, repIndex = 0, 0
  local playerPosition = ""
  local playerRole = "Starter"

  for i, player in ipairs(squad) do
    players[i] = player.CARD_ID
    if player.CARD_ID == playerId then
      playerIndex = i
      playerPosition = player.position
      playerRole = i > 11 and "Sub/Res" or "Starter"
    end
  end

  if playerIndex == 0 then
    return players
  end

  if playerRole == "Starter" then
    for i, player in ipairs(squad) do
      if i > 11 and player.position == playerPosition then
        repIndex = i
        break
      end
    end
    if repIndex == 0 then
      return players
    end
    players[playerIndex], players[repIndex] = players[repIndex], players[playerIndex]
  else
    table.remove(players, playerIndex)
  end

  return players
end

return Squads
-- Module for generating fixtures and match dates for LEAGUE DAVUNPES
local sessionVars, CareerModeLeagues, eplLive, fixtures_28_teams, fixtures_24_teams, fixtures_20_teams, fixtures_18_teams, fixtures_17_teams, fixtures_16_teams, fixtures_14_teams, fixtures_12_teams = ...
local Fixtures = {}
Fixtures.__index = Fixtures

function Fixtures:new(init)
    local o = init or {}
    setmetatable(o, self)
    o.save = init.save
    return o
end

function Fixtures:shuffleTeams(teams)
    local shuffled = {}
    for i = 1, #teams do shuffled[i] = teams[i] end
    math.randomseed(os.time())
    for i = #shuffled, 2, -1 do
        local j = math.random(1, i)
        shuffled[i], shuffled[j] = shuffled[j], shuffled[i]
    end
    return shuffled
end

local function map_fixtures(fixtures, team_ids)
    local mapped_fixtures = {}
    for matchday_idx = 1, #fixtures do
        local matchday = fixtures[matchday_idx]
        mapped_fixtures[matchday_idx] = {}
        for i = 1, #matchday do
            local match = matchday[i]
            mapped_fixtures[matchday_idx][i] = {
                home = team_ids[match.home],
                away = team_ids[match.away],
                matchDate = nil
            }
        end
    end
    return mapped_fixtures
end

-- Convert YYYY-MM-DD to MMDDYY
local function convertToMMDDYY(dateStr)
    local year, month, day = dateStr:match("(%d+)-(%d+)-(%d+)")
    if not (year and month and day) then
        print("Invalid date format for conversion: " .. tostring(dateStr))
        return nil
    end
    year = year:sub(-2)
    return string.format("%02d%02d%02d", month, day, year)
end

local function isTeamInAnyLeague(teamID)
    local leagueTeams = sessionVars.get("LeagueTeams")
    if not leagueTeams then
        return false
    end
    
    local targetLeague = leagueTeams[2236]
    if not targetLeague then
        return false
    end
    
    for _, id in ipairs(targetLeague) do
        if id == teamID then
            return true
        end
    end
    
    return false
end

-- Check if a date falls within a forbidden league week (no Monday or Friday matches for teams in leagues 1, 2, or 3)
local function shouldBlockWeekdayForTeam(date, startYear, teamID)
    -- First check if team is in any of the leagues
    if not isTeamInAnyLeague(teamID) then
        return false
    end
    
    -- Then check if it's Monday or Friday
    local wday = os.date("%w", date)  -- 0=Sun, 1=Mon, ..., 6=Sat
    if wday ~= "1" and wday ~= "5" then  -- Not Monday or Friday
        return false
    end
    
    local dateTable = os.date("*t", date)
    local year = dateTable.year
    local month = dateTable.month
    local day = dateTable.day
    local weekNumber = math.floor((day - 1) / 7) + 1
    
    -- Check all specified weeks
    if year == startYear and month == 9 and weekNumber == 3 then  -- Sep 3rd week
        return true
    elseif year == startYear and month == 10 and weekNumber == 1 then  -- Oct 1st week
        return true
    elseif year == startYear and month == 10 and weekNumber == 4 then  -- Oct 4th week
        return true
    elseif year == startYear and month == 11 and weekNumber == 1 then  -- Nov 1st week
        return true
    elseif year == startYear and month == 11 and weekNumber == 4 then  -- Nov 4th week
        return true
    elseif year == startYear and month == 12 and weekNumber == 2 then  -- Dec 2nd week
        return true
    elseif year == startYear + 1 and month == 1 and weekNumber == 3 then  -- Jan 3rd week
        return true
    
    -- Special handling for January 4th/5th week
    elseif year == startYear + 1 and month == 1 and (weekNumber == 4 or weekNumber == 5) then
        -- Determine which week to block (only one of 4th or 5th)
        local weekToBlock = nil
        
        -- Check if 5th week exists and has Tuesday/Wednesday, and not Jan 31st
        if weekNumber == 5 then
            local hasTuesdayWednesday = false
            local weekStartDay = (5 - 1) * 7 + 1
            local weekEndDay = math.min(5 * 7, 31)
            
            for d = weekStartDay, weekEndDay do
                if d ~= 31 then  -- Not January 31st
                    local testDate = os.time({year=year, month=month, day=d})
                    local testWday = os.date("%w", testDate)  -- 0=Sun, 1=Mon, ..., 6=Sat
                    if testWday == "2" or testWday == "3" then  -- Tuesday or Wednesday
                        hasTuesdayWednesday = true
                        break
                    end
                end
            end
            
            if hasTuesdayWednesday then
                weekToBlock = 5
            else
                weekToBlock = 4
            end
        elseif weekNumber == 4 then
            -- Check if 5th week would exist
            local weekStartDay = (5 - 1) * 7 + 1
            if weekStartDay > 31 then  -- No 5th week
                weekToBlock = 4
            else
                -- Check if 5th week meets conditions
                local hasTuesdayWednesday = false
                local weekEndDay = math.min(5 * 7, 31)
                
                for d = weekStartDay, weekEndDay do
                    if d ~= 31 then  -- Not January 31st
                        local testDate = os.time({year=year, month=month, day=d})
                        local testWday = os.date("%w", testDate)  -- 0=Sun, 1=Mon, ..., 6=Sat
                        if testWday == "2" or testWday == "3" then  -- Tuesday or Wednesday
                            hasTuesdayWednesday = true
                            break
                        end
                    end
                end
                
                if hasTuesdayWednesday then
                    weekToBlock = 5
                else
                    weekToBlock = 4
                end
            end
        end
        
        if weekNumber == weekToBlock then
            return true
        end
        
    -- Special handling for May 4th/5th week
    elseif year == startYear + 1 and month == 5 and (weekNumber == 4 or weekNumber == 5) then
        -- Determine which week to block (only one of 4th or 5th)
        local weekToBlock = nil
        
        -- Check if 5th week exists and has Tuesday/Wednesday
        if weekNumber == 5 then
            local hasTuesdayWednesday = false
            local weekStartDay = (5 - 1) * 7 + 1
            local weekEndDay = math.min(5 * 7, 31)
            
            for d = weekStartDay, weekEndDay do
                local testDate = os.time({year=year, month=month, day=d})
                local testWday = os.date("%w", testDate)  -- 0=Sun, 1=Mon, ..., 6=Sat
                if testWday == "2" or testWday == "3" then  -- Tuesday or Wednesday
                    hasTuesdayWednesday = true
                    break
                end
            end
            
            if hasTuesdayWednesday then
                weekToBlock = 5
            else
                weekToBlock = 4
            end
        elseif weekNumber == 4 then
            -- Check if 5th week would exist
            local weekStartDay = (5 - 1) * 7 + 1
            if weekStartDay > 31 then  -- No 5th week
                weekToBlock = 4
            else
                -- Check if 5th week meets conditions
                local hasTuesdayWednesday = false
                local weekEndDay = math.min(5 * 7, 31)
                
                for d = weekStartDay, weekEndDay do
                    local testDate = os.time({year=year, month=month, day=d})
                    local testWday = os.date("%w", testDate)  -- 0=Sun, 1=Mon, ..., 6=Sat
                    if testWday == "2" or testWday == "3" then  -- Tuesday or Wednesday
                        hasTuesdayWednesday = true
                        break
                    end
                end
                
                if hasTuesdayWednesday then
                    weekToBlock = 5
                else
                    weekToBlock = 4
                end
            end
        end
        
        if weekNumber == weekToBlock then
            return true
        end
    end
    
    return false
end

-- Check if a date falls within a rest week
local function isInRestWeek(date, restWeeks)
    for _, rest in ipairs(restWeeks) do
        local restStart = os.time({year = rest.year, month = rest.month, day = rest.day})
        local restEnd = restStart + 7 * 86400
        if date >= restStart and date < restEnd then
            return true
        end
    end
    return false
end

-- Check if a date is a forbidden date (August 31, December 25, January 31)
local function isForbiddenDate(date, startYear)
    local forbidden = {
        os.time({year = startYear, month = 8, day = 31}),
        os.time({year = startYear, month = 12, day = 25}),
        os.time({year = startYear + 1, month = 1, day = 31}),
        os.time({year = startYear + 1, month = 1, day = 30}),
        os.time({year = startYear, month = 8, day = 30})
    }
    for _, f in ipairs(forbidden) do
        if date == f then return true end
    end
    return false
end

-- Helper round function
local function math_round(x)
    return math.floor(x + 0.5)
end

local function parse_date(dateStr)
    local year, month, day = dateStr:match("(%d+)-(%d+)-(%d+)")
    if not (year and month and day) then
        print("Invalid date format: " .. tostring(dateStr))
        return nil
    end
    return os.time({year = tonumber(year), month = tonumber(month), day = tonumber(day), hour = 12})
end

local function format_date(t)
    return os.date("%Y-%m-%d", t)
end

-- Check if a team has sufficient rest between matches
local function hasSufficientRest(team, match_date, matchdays, team_schedules)
    local MIN_REST_DAYS = 3
    local MIN_REST_SECONDS = MIN_REST_DAYS * 86400
    local match_time = parse_date(match_date)
    local schedule = team_schedules[team] or {}

    for _, prev_date in ipairs(schedule) do
        local prev_time = parse_date(prev_date)
        if math.abs(match_time - prev_time) < MIN_REST_SECONDS then
            return false
        end
    end
    return true
end

-- Generate match dates for a given number of matchdays in a block
local function generateMatchDates(startTime, endTime, numMatchdays, restWeeks, startYear, fixtures)
    if numMatchdays == 0 then return {} end

    -- Minimum gap between matchdays (in days)
    local MIN_GAP_DAYS = 4
    local MIN_GAP_SECONDS = MIN_GAP_DAYS * 86400

    -- Collect all possible Saturday dates not in rest weeks or forbidden dates
    local possible_dates = {}
    local current = startTime
    local t = os.date("*t", current)
    local days_to_sat = (7 - t.wday + 7) % 7
    current = current + days_to_sat * 86400

    while current < endTime do
        if not isInRestWeek(current, restWeeks) and not isForbiddenDate(current, startYear) then
            table.insert(possible_dates, {time = current, date = format_date(current)})
        end
        current = current + 7 * 86400
    end

    local num_possible = #possible_dates
    local matchDates = {}
    local team_schedules = {} -- Track each team's match dates

    if num_possible >= numMatchdays then
        -- Spread evenly across possible weekends, ensuring minimum gap
        if numMatchdays == 1 then
            table.insert(matchDates, {possible_dates[1].date})
        else
            local step = (num_possible - 1) / (numMatchdays - 1)
            local selected_times = {}
            for i = 0, numMatchdays - 1 do
                local idx = math_round(i * step) + 1
                local selected_time = possible_dates[idx].time
                -- Ensure minimum gap from previous
                if i > 0 and selected_time - selected_times[i] < MIN_GAP_SECONDS then
                    selected_time = selected_times[i] + MIN_GAP_SECONDS
                    while isInRestWeek(selected_time, restWeeks) or isForbiddenDate(selected_time, startYear) do
                        selected_time = selected_time + 86400
                    end
                    if selected_time >= endTime then
                        selected_time = selected_times[i] + MIN_GAP_SECONDS
                    end
                end
                table.insert(selected_times, selected_time)
            end
            for _, tm in ipairs(selected_times) do
                table.insert(matchDates, {format_date(tm)})
            end
        end
    else
        -- Use all weekends, add midweeks in largest gaps, ensuring minimum gap
        local selected_times = {}
        for _, d in ipairs(possible_dates) do
            table.insert(selected_times, d.time)
        end

        -- Add extra midweeks
        local extra = numMatchdays - num_possible
        local gaps = {}
        table.sort(selected_times)

        -- Initial gaps between selected_times
        for i = 1, #selected_times - 1 do
            local diff_days = (selected_times[i + 1] - selected_times[i]) / 86400
            if diff_days >= MIN_GAP_DAYS + 3 then  -- Ensure room for weekend spreading
                table.insert(gaps, {start = selected_times[i], size = diff_days, index = i})
            end
        end

        -- Before first
        local first_gap = (selected_times[1] - startTime) / 86400
        if first_gap >= MIN_GAP_DAYS + 3 then
            table.insert(gaps, {start = startTime, size = first_gap, index = 0})
        end

        -- After last
        local last_gap = (endTime - selected_times[#selected_times]) / 86400
        if last_gap >= MIN_GAP_DAYS + 3 then
            table.insert(gaps, {start = selected_times[#selected_times], size = last_gap, index = #selected_times})
        end

        for _ = 1, extra do
            if #gaps == 0 then
                -- Fallback: add dates at the end with minimum gap
                local last_time = selected_times[#selected_times] or startTime
                local new_time = last_time + MIN_GAP_SECONDS
                while isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear) do
                    new_time = new_time + 86400
                end
                table.insert(selected_times, new_time)
            else
                -- Sort gaps descending by size
                table.sort(gaps, function(a, b) return a.size > b.size end)
                local largest = gaps[1]

                -- Prefer Tuesday (wday 2) or Wednesday (wday 3)
                local mid_time = largest.start + math.floor(largest.size / 2) * 86400
                local tt = os.date("*t", mid_time)
                local days_to_tue = (2 - tt.wday + 7) % 7
                local tue_time = mid_time + days_to_tue * 86400
                local wed_time = tue_time + 86400

                local new_time = tue_time
                if isInRestWeek(tue_time, restWeeks) or isForbiddenDate(tue_time, startYear) then
                    new_time = wed_time
                end

                -- Ensure minimum gap from previous and next matchdays
                local prev_time = largest.index > 0 and selected_times[largest.index] or (startTime - MIN_GAP_SECONDS)
                local next_time = largest.index < #selected_times and selected_times[largest.index + 1] or endTime
                if new_time - prev_time < MIN_GAP_SECONDS then
                    new_time = prev_time + MIN_GAP_SECONDS
                elseif next_time - new_time < MIN_GAP_SECONDS then
                    new_time = next_time - MIN_GAP_SECONDS
                end

                -- Avoid rest weeks and forbidden dates
                local tries = 0
                while (isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear)) and tries < 3 do
                    new_time = new_time + 7 * 86400
                    tries = tries + 1
                end
                if tries == 3 then
                    new_time = largest.start + math.floor(largest.size * 0.5) * 86400
                end

                -- Ensure within gap and maintain minimum gap
                local gap_end = largest.start + largest.size * 86400
                if new_time >= gap_end - MIN_GAP_SECONDS or new_time <= largest.start + MIN_GAP_SECONDS then
                    new_time = largest.start + math.floor(largest.size * 0.5) * 86400
                end
                if isForbiddenDate(new_time, startYear) then
                    new_time = new_time + 86400
                    while isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear) do
                        new_time = new_time + 86400
                    end
                end

                -- Insert into selected_times
                local insert_idx = largest.index + 1
                table.insert(selected_times, insert_idx, new_time)

                -- Split gap
                local new_gap1_size = (new_time - largest.start) / 86400
                local new_gap2_size = largest.size - new_gap1_size
                if new_gap1_size >= MIN_GAP_DAYS + 3 then
                    largest.size = new_gap1_size
                else
                    table.remove(gaps, 1)
                end
                if new_gap2_size >= MIN_GAP_DAYS + 3 then
                    table.insert(gaps, {start = new_time, size = new_gap2_size, index = largest.index + 1})
                end

                -- Adjust indices
                for _, g in ipairs(gaps) do
                    if g.index > largest.index then g.index = g.index + 1 end
                end
            end
        end

        -- Convert back to dates
        table.sort(selected_times)
        for _, tm in ipairs(selected_times) do
            table.insert(matchDates, {format_date(tm)})
        end
    end

    return matchDates
end


local function generateRoundRobin(teamCount)
    local teams = {}
    for i = 1, teamCount do teams[i] = i end

    local odd = (teamCount % 2 ~= 0)
    if odd then
        table.insert(teams, -1)
        teamCount = teamCount + 1
    end

    local rounds = {}
    local half = teamCount / 2

    for round = 1, teamCount - 1 do
        rounds[round] = {}

        for i = 1, half do
            local home = teams[i]
            local away = teams[teamCount - i + 1]

            if home ~= -1 and away ~= -1 then
                table.insert(rounds[round], {home = home, away = away})
            end
        end

        local last = table.remove(teams)
        table.insert(teams, 2, last)
    end

    local secondLeg = {}
    for r = 1, #rounds do
        secondLeg[r] = {}
        for _, match in ipairs(rounds[r]) do
            table.insert(secondLeg[r], {home = match.away, away = match.home})
        end
    end

    for _, round in ipairs(secondLeg) do
        table.insert(rounds, round)
    end

    return rounds
end

function Fixtures:generateAIfixtures(team_ids, startYear, leagueID)
    local templates = {
        [12] = fixtures_12_teams,
        [14] = fixtures_14_teams,
        [16] = fixtures_16_teams,
        [17] = fixtures_17_teams,
        [18] = fixtures_18_teams,
        [20] = fixtures_20_teams,
        [24] = fixtures_24_teams,
        [28] = fixtures_28_teams,
    }
    local template = templates[#team_ids]
    if not template then
        print("Generating dynamic fixture for " .. #team_ids .. " teams")
        template = generateRoundRobin(#team_ids)
    end

    local shuffled_team_ids = self:shuffleTeams(team_ids)
    local mapped_fixtures = map_fixtures(template, shuffled_team_ids)

    if #team_ids == 17 then
        for matchday_idx = 1, #mapped_fixtures do
            local matchday = mapped_fixtures[matchday_idx]
            local playing_teams = {}
            for i = 1, #matchday do
                local match = matchday[i]
                playing_teams[match.home] = true
                playing_teams[match.away] = true
            end
            for i = 1, #shuffled_team_ids do
                local team_id = shuffled_team_ids[i]
                if not playing_teams[team_id] then
                    matchday[#matchday + 1] = { team = team_id, status = "bye" }
                end
            end
        end
    end

    -- Season starts between August 7-12, ends May 25
    local startDay = math.random(7, 12)
    local seasonStart = os.time({year = startYear, month = 8, day = startDay})
    local firstHalfEnd = os.time({year = startYear, month = 12, day = 31})
    local secondHalfStart = os.time({year = startYear + 1, month = 1, day = 1})
    local seasonEnd = os.time({year = startYear + 1, month = 5, day = 25})

    -- Define 4 rest weeks (7 days each)
    local restWeeks = {
        {year = startYear, month = 9, day = 15},
        {year = startYear, month = 10, day = 15},
        {year = startYear + 1, month = 3, day = 15},
        {year = startYear + 1, month = 4, day = 15}
    }

    -- Split matchdays evenly between halves
    local numMatchdays = #template
    local matchdaysPerHalf = math.floor(numMatchdays / 2)

    -- Generate match dates for each half
    local firstHalfDates = generateMatchDates(seasonStart, firstHalfEnd, matchdaysPerHalf, {restWeeks[1], restWeeks[2]}, startYear, mapped_fixtures)
    local secondHalfDates = generateMatchDates(secondHalfStart, seasonEnd, numMatchdays - matchdaysPerHalf, {restWeeks[3], restWeeks[4]}, startYear, mapped_fixtures)
    local matchDates = {}
    for i = 1, matchdaysPerHalf do
        matchDates[i] = firstHalfDates[i]
    end
    for i = 1, #secondHalfDates do
        matchDates[matchdaysPerHalf + i] = secondHalfDates[i]
    end

    -- Track team schedules to ensure minimum rest
    local team_schedules = {}
    for _, team_id in ipairs(shuffled_team_ids) do
        team_schedules[team_id] = {}
    end

    -- Expand matchDates to possible dates for spreading across weekend
    local MIN_GAP_SECONDS = 4 * 86400
    for idx = 1, #matchDates do
        local anchor = matchDates[idx][1]
        local anchor_time = parse_date(anchor)
        local wday = tonumber(os.date("%w", anchor_time))  -- 0=Sun, 1=Mon, ..., 6=Sat
        local possible_times = {}
        if idx == #matchDates then
            -- Last matchday: all matches on the same day
            if not isForbiddenDate(anchor_time, startYear) then
                table.insert(possible_times, anchor_time)
            else
                -- Shift to next valid day
                local new_time = anchor_time + 86400
                while isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear) do
                    new_time = new_time + 86400
                end
                table.insert(possible_times, new_time)
            end
        elseif wday == 6 then  -- Saturday
            local fri_time = anchor_time - 86400
            if not isInRestWeek(fri_time, restWeeks) and not isForbiddenDate(fri_time, startYear) then
                table.insert(possible_times, fri_time)
            end
            if not isForbiddenDate(anchor_time, startYear) then
                table.insert(possible_times, anchor_time)
            end
            local sun_time = anchor_time + 86400
            if not isInRestWeek(sun_time, restWeeks) and not isForbiddenDate(sun_time, startYear) then
                table.insert(possible_times, sun_time)
            end
        else
            if not isForbiddenDate(anchor_time, startYear) then
                table.insert(possible_times, anchor_time)
            else
                -- Find next valid day within the same week
                local new_time = anchor_time + 86400
                while (isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear)) and (new_time - anchor_time) / 86400 < 7 do
                    new_time = new_time + 86400
                end
                if (new_time - anchor_time) / 86400 >= 7 then
                    new_time = anchor_time - 86400
                    while (isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear)) and (anchor_time - new_time) / 86400 < 7 do
                        new_time = new_time - 86400
                    end
                end
                table.insert(possible_times, new_time)
            end
        end
        if #possible_times == 0 then
            -- Fallback: use anchor or shift to next valid day
            local new_time = anchor_time
            while isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear) do
                new_time = new_time + 86400
            end
            table.insert(possible_times, new_time)
        end
        local possible_str = {}
        for _, t in ipairs(possible_times) do
            table.insert(possible_str, format_date(t))
        end
        matchDates[idx] = possible_str
    end

    -- Assign match dates and check team rest periods
    local allMatches = {}
    local matchIndex = 1
    for matchday_idx = 1, #mapped_fixtures do
        local matchday = mapped_fixtures[matchday_idx]
        local possible = matchDates[matchday_idx]
        for i = 1, #matchday do
            if not matchday[i].status then
                local matchDate = possible[(i - 1) % #possible + 1]
                local home_team = matchday[i].home
                local away_team = matchday[i].away
                
                -- Check if weekday should be blocked for either team
                local match_time = parse_date(matchDate)
                if shouldBlockWeekdayForTeam(match_time, startYear, home_team) or 
                   shouldBlockWeekdayForTeam(match_time, startYear, away_team) then
                    -- Skip this date and find alternative
                    local base_time = match_time
                    local new_time = base_time + 86400
                    local tries = 0
                    while (isInRestWeek(new_time, restWeeks) or 
                           isForbiddenDate(new_time, startYear) or
                           shouldBlockWeekdayForTeam(new_time, startYear, home_team) or
                           shouldBlockWeekdayForTeam(new_time, startYear, away_team) or
                           not hasSufficientRest(home_team, format_date(new_time), mapped_fixtures, team_schedules) or
                           not hasSufficientRest(away_team, format_date(new_time), mapped_fixtures, team_schedules)) and 
                           tries < 14 do  -- Try for up to 2 weeks
                        new_time = new_time + 86400
                        tries = tries + 1
                    end
                    
                    if tries >= 14 then
                        -- Couldn't find suitable date, use original (this shouldn't happen often)
                        matchDate = matchDate
                    else
                        matchDate = format_date(new_time)
                    end
                end
                
                -- Verify sufficient rest for both teams
                if hasSufficientRest(home_team, matchDate, mapped_fixtures, team_schedules) and
                   hasSufficientRest(away_team, matchDate, mapped_fixtures, team_schedules) then
                    matchday[i].matchDate = matchDate
                    allMatches[matchIndex] = {
                        home = home_team,
                        away = away_team,
                        matchDate = matchDate,
                        matchday = matchday_idx
                    }
                    -- Update team schedules
                    table.insert(team_schedules[home_team], matchDate)
                    table.insert(team_schedules[away_team], matchDate)
                    matchIndex = matchIndex + 1
                else
                    -- Find next valid date for this match
                    local base_time = parse_date(matchDate)
                    local new_time = base_time + 86400
                    while (isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear) or
                           shouldBlockWeekdayForTeam(new_time, startYear, home_team) or
                           shouldBlockWeekdayForTeam(new_time, startYear, away_team) or
                           not hasSufficientRest(home_team, format_date(new_time), mapped_fixtures, team_schedules) or
                           not hasSufficientRest(away_team, format_date(new_time), mapped_fixtures, team_schedules)) and
                           (new_time - base_time) / 86400 < 7 do
                        new_time = new_time + 86400
                    end
                    local new_date = format_date(new_time)
                    matchday[i].matchDate = new_date
                    allMatches[matchIndex] = {
                        home = home_team,
                        away = away_team,
                        matchDate = new_date,
                        matchday = matchday_idx
                    }
                    table.insert(team_schedules[home_team], new_date)
                    table.insert(team_schedules[away_team], new_date)
                    matchIndex = matchIndex + 1
                end
            end
        end
    end

    self:insertMatchToFixtures(allMatches, "League", leagueID)
    return mapped_fixtures
end

function Fixtures:generateAutomaticFixturesWithDates(teams, startYear, leagueID)
    local numTeams = #teams
    local matchdays = {}
    local homeAwayBalance = {}
    for i = 1, numTeams do homeAwayBalance[teams[i]] = {home = 0, away = 0} end

    if numTeams % 2 ~= 0 then
        teams[numTeams + 1] = "BYE"
        numTeams = numTeams + 1
    end

    local function canPlayAtGround(team, isHome)
        local balance = homeAwayBalance[team]
        return isHome and balance.home < 2 or balance.away < 2
    end

    local function updateBalance(team, isHome)
        local balance = homeAwayBalance[team]
        if isHome then
            balance.home = balance.home + 1
            balance.away = 0
        else
            balance.away = balance.away + 1
            balance.home = 0
        end
    end

    -- Season starts between August 7-12, ends May 25
    local startDay = math.random(7, 12)
    local seasonStart = os.time({year = startYear, month = 8, day = startDay})
    local firstHalfEnd = os.time({year = startYear, month = 12, day = 31})
    local secondHalfStart = os.time({year = startYear + 1, month = 1, day = 1})
    local seasonEnd = os.time({year = startYear + 1, month = 5, day = 25})

    -- Define 4 rest weeks (7 days each)
    local restWeeks = {
        {year = startYear, month = 9, day = 15},
        {year = startYear, month = 10, day = 15},
        {year = startYear + 1, month = 3, day = 15},
        {year = startYear + 1, month = 4, day = 15}
    }

    -- Split matchdays evenly between halves
    local numMatchdays = (numTeams - 1) * 2 -- Double round-robin
    local matchdaysPerHalf = math.floor(numMatchdays / 2)

    -- Generate match dates for each half
    local firstHalfDates = generateMatchDates(seasonStart, firstHalfEnd, matchdaysPerHalf, {restWeeks[1], restWeeks[2]}, startYear)
    local secondHalfDates = generateMatchDates(secondHalfStart, seasonEnd, numMatchdays - matchdaysPerHalf, {restWeeks[3], restWeeks[4]}, startYear)
    local matchDates = {}
    for i = 1, matchdaysPerHalf do
        matchDates[i] = firstHalfDates[i]
    end
    for i = 1, #secondHalfDates do
        matchDates[matchdaysPerHalf + i] = secondHalfDates[i]
    end

    -- Track team schedules
    local team_schedules = {}
    for _, team in ipairs(teams) do
        if team ~= "BYE" then
            team_schedules[team] = {}
        end
    end

    -- Generate first half fixtures
    for i = 1, numTeams - 1 do
        local matchday = {matches = {}}
        for j = 1, numTeams / 2 do
            local home, away = teams[j], teams[numTeams - j + 1]
            if not canPlayAtGround(home, true) or not canPlayAtGround(away, false) then
                home, away = away, home
            end
            if home ~= "BYE" and away ~= "BYE" then
                matchday.matches[#matchday.matches + 1] = {home = home, away = away}
                updateBalance(home, true)
                updateBalance(away, false)
            end
        end
        matchdays[i] = matchday
        table.insert(teams, 2, table.remove(teams))
    end

    -- Generate second half fixtures
    local secondHalfFixtures = {}
    for i = 1, numTeams - 1 do
        local matchday = {matches = {}}
        for j = 1, #matchdays[i].matches do
            local match = matchdays[i].matches[j]
            matchday.matches[#matchday.matches + 1] = {home = match.away, away = match.home}
        end
        secondHalfFixtures[i] = matchday
    end

    for i = 1, #secondHalfFixtures do
        matchdays[numTeams - 1 + i] = secondHalfFixtures[i]
    end

    -- Assign individual match dates with rest period checks
    local MIN_GAP_SECONDS = 4 * 86400
    for idx = 1, #matchDates do
        local anchor = matchDates[idx][1]
        local anchor_time = parse_date(anchor)
        local wday = tonumber(os.date("%w", anchor_time))  -- 0=Sun, 1=Mon, ..., 6=Sat
        local possible_times = {}
        if idx == #matchDates then
            -- Last matchday: all matches on the same day
            if not isForbiddenDate(anchor_time, startYear) then
                table.insert(possible_times, anchor_time)
            else
                -- Shift to next valid day
                local new_time = anchor_time + 86400
                while isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear) do
                    new_time = new_time + 86400
                end
                table.insert(possible_times, new_time)
            end
        elseif wday == 6 then  -- Saturday
            local fri_time = anchor_time - 86400
            if not isInRestWeek(fri_time, restWeeks) and not isForbiddenDate(fri_time, startYear) then
                table.insert(possible_times, fri_time)
            end
            if not isForbiddenDate(anchor_time, startYear) then
                table.insert(possible_times, anchor_time)
            end
            local sun_time = anchor_time + 86400
            if not isInRestWeek(sun_time, restWeeks) and not isForbiddenDate(sun_time, startYear) then
                table.insert(possible_times, sun_time)
            end
        else
            if not isForbiddenDate(anchor_time, startYear) then
                table.insert(possible_times, anchor_time)
            else
                -- Find next valid day within the same week
                local new_time = anchor_time + 86400
                while (isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear)) and (new_time - anchor_time) / 86400 < 7 do
                    new_time = new_time + 86400
                end
                if (new_time - anchor_time) / 86400 >= 7 then
                    new_time = anchor_time - 86400
                    while (isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear)) and (anchor_time - new_time) / 86400 < 7 do
                        new_time = new_time - 86400
                    end
                end
                table.insert(possible_times, new_time)
            end
        end
        if #possible_times == 0 then
            -- Fallback: use anchor or shift to next valid day
            local new_time = anchor_time
            while isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear) do
                new_time = new_time + 86400
            end
            table.insert(possible_times, new_time)
        end
        local possible_str = {}
        for _, t in ipairs(possible_times) do
            table.insert(possible_str, format_date(t))
        end
        matchDates[idx] = possible_str

        -- Assign match dates with rest period checks
        local matches = matchdays[idx].matches
        for j = 1, #matches do
            local matchDate = possible_str[(j - 1) % #possible_str + 1]
            local home_team = matches[j].home
            local away_team = matches[j].away
            local match_time = parse_date(matchDate)
            
            -- Check if weekday should be blocked for either team
            if shouldBlockWeekdayForTeam(match_time, startYear, home_team) or 
               shouldBlockWeekdayForTeam(match_time, startYear, away_team) then
                -- Skip this date and find alternative
                local base_time = match_time
                local new_time = base_time + 86400
                local tries = 0
                while (isInRestWeek(new_time, restWeeks) or 
                       isForbiddenDate(new_time, startYear) or
                       shouldBlockWeekdayForTeam(new_time, startYear, home_team) or
                       shouldBlockWeekdayForTeam(new_time, startYear, away_team) or
                       not hasSufficientRest(home_team, format_date(new_time), matchdays, team_schedules) or
                       not hasSufficientRest(away_team, format_date(new_time), matchdays, team_schedules)) and 
                       tries < 14 do  -- Try for up to 2 weeks
                    new_time = new_time + 86400
                    tries = tries + 1
                end
                
                if tries >= 14 then
                    -- Couldn't find suitable date, use original (this shouldn't happen often)
                    matchDate = matchDate
                else
                    matchDate = format_date(new_time)
                end
            end
            
            if hasSufficientRest(home_team, matchDate, matchdays, team_schedules) and
               hasSufficientRest(away_team, matchDate, matchdays, team_schedules) then
                matches[j].matchDate = matchDate
                table.insert(team_schedules[home_team], matchDate)
                table.insert(team_schedules[away_team], matchDate)
            else
                -- Find next valid date for this match
                local base_time = parse_date(matchDate)
                local new_time = base_time + 86400
                while (isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear) or
                       shouldBlockWeekdayForTeam(new_time, startYear, home_team) or
                       shouldBlockWeekdayForTeam(new_time, startYear, away_team) or
                       not hasSufficientRest(home_team, format_date(new_time), matchdays, team_schedules) or
                       not hasSufficientRest(away_team, format_date(new_time), matchdays, team_schedules)) and
                       (new_time - base_time) / 86400 < 7 do
                    new_time = new_time + 86400
                end
                local new_date = format_date(new_time)
                matches[j].matchDate = new_date
                table.insert(team_schedules[home_team], new_date)
                table.insert(team_schedules[away_team], new_date)
            end
        end
    end

    self:insertMatchToFixtures(self:getAllMatches(matchdays), "League", leagueID)
    return matchdays
end

function Fixtures:generateManualFixturesWithDates(manualFixtures, startYear, leagueID)
    local matchdays = {}
    local maxMatchday = 0
    for i = 1, #manualFixtures do
        maxMatchday = math.max(maxMatchday, manualFixtures[i].matchday)
    end

    -- Season starts between August 7-12, ends May 25
    local startDay = math.random(7, 12)
    local seasonStart = os.time({year = startYear, month = 8, day = startDay})
    local firstHalfEnd = os.time({year = startYear, month = 12, day = 31})
    local secondHalfStart = os.time({year = startYear + 1, month = 1, day = 1})
    local seasonEnd = os.time({year = startYear + 1, month = 5, day = 25})

    -- Define 4 rest weeks (7 days each)
    local restWeeks = {
        {year = startYear, month = 9, day = 15},
        {year = startYear, month = 10, day = 15},
        {year = startYear + 1, month = 3, day = 15},
        {year = startYear + 1, month = 4, day = 15}
    }

    -- Split matchdays evenly between halves
    local numMatchdays = maxMatchday * 2 -- Double round-robin
    local matchdaysPerHalf = math.floor(numMatchdays / 2)

    -- Generate match dates for each half
    local firstHalfDates = generateMatchDates(seasonStart, firstHalfEnd, matchdaysPerHalf, {restWeeks[1], restWeeks[2]}, startYear)
    local secondHalfDates = generateMatchDates(secondHalfStart, seasonEnd, numMatchdays - matchdaysPerHalf, {restWeeks[3], restWeeks[4]}, startYear)
    local matchDates = {}
    for i = 1, matchdaysPerHalf do
        matchDates[i] = firstHalfDates[i]
    end
    for i = 1, #secondHalfDates do
        matchDates[matchdaysPerHalf + i] = secondHalfDates[i]
    end

    -- Track team schedules
    local team_schedules = {}
    for _, fixture in ipairs(manualFixtures) do
        team_schedules[fixture.home] = team_schedules[fixture.home] or {}
        team_schedules[fixture.away] = team_schedules[fixture.away] or {}
    end

    -- Expand matchDates to possible dates for spreading across weekend
    local MIN_GAP_SECONDS = 4 * 86400
    for idx = 1, #matchDates do
        local anchor = matchDates[idx][1]
        local anchor_time = parse_date(anchor)
        local wday = tonumber(os.date("%w", anchor_time))  -- 0=Sun, 1=Mon, ..., 6=Sat
        local possible_times = {}
        if idx == #matchDates then
            -- Last matchday: all matches on the same day
            if not isForbiddenDate(anchor_time, startYear) then
                table.insert(possible_times, anchor_time)
            else
                -- Shift to next valid day
                local new_time = anchor_time + 86400
                while isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear) do
                    new_time = new_time + 86400
                end
                table.insert(possible_times, new_time)
            end
        elseif wday == 6 then  -- Saturday
            local fri_time = anchor_time - 86400
            if not isInRestWeek(fri_time, restWeeks) and not isForbiddenDate(fri_time, startYear) then
                table.insert(possible_times, fri_time)
            end
            if not isForbiddenDate(anchor_time, startYear) then
                table.insert(possible_times, anchor_time)
            end
            local sun_time = anchor_time + 86400
            if not isInRestWeek(sun_time, restWeeks) and not isForbiddenDate(sun_time, startYear) then
                table.insert(possible_times, sun_time)
            end
        else
            if not isForbiddenDate(anchor_time, startYear) then
                table.insert(possible_times, anchor_time)
            else
                -- Find next valid day within the same week
                local new_time = anchor_time + 86400
                while (isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear)) and (new_time - anchor_time) / 86400 < 7 do
                    new_time = new_time + 86400
                end
                if (new_time - anchor_time) / 86400 >= 7 then
                    new_time = anchor_time - 86400
                    while (isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear)) and (anchor_time - new_time) / 86400 < 7 do
                        new_time = new_time - 86400
                    end
                end
                table.insert(possible_times, new_time)
            end
        end
        if #possible_times == 0 then
            -- Fallback: use anchor or shift to next valid day
            local new_time = anchor_time
            while isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear) do
                new_time = new_time + 86400
            end
            table.insert(possible_times, new_time)
        end
        local possible_str = {}
        for _, t in ipairs(possible_times) do
            table.insert(possible_str, format_date(t))
        end
        matchDates[idx] = possible_str
    end

    for i = 1, #manualFixtures do
        local fixture = manualFixtures[i]
        local matchdayIndex = fixture.matchday
        matchdays[matchdayIndex] = matchdays[matchdayIndex] or {matches = {}}
        matchdays[matchdayIndex].matches[#matchdays[matchdayIndex].matches + 1] = {home = fixture.home, away = fixture.away}
    end

    local firstHalfCount = maxMatchday
    local secondHalfFixtures = {}
    for i = 1, firstHalfCount do
        local matchday = {matches = {}}
        for j = 1, #matchdays[i].matches do
            local match = matchdays[i].matches[j]
            matchday.matches[#matchday.matches + 1] = {home = match.away, away = match.home}
        end
        secondHalfFixtures[i] = matchday
    end

    for i = 1, #secondHalfFixtures do
        matchdays[firstHalfCount + i] = secondHalfFixtures[i]
    end

    -- Assign individual match dates with rest period checks
    for idx = 1, #matchdays do
        local possible = matchDates[idx]
        local matches = matchdays[idx].matches
        for j = 1, #matches do
            local matchDate = possible[(j - 1) % #possible + 1]
            local home_team = matches[j].home
            local away_team = matches[j].away
            local match_time = parse_date(matchDate)
            
            -- Check if weekday should be blocked for either team
            if shouldBlockWeekdayForTeam(match_time, startYear, home_team) or 
               shouldBlockWeekdayForTeam(match_time, startYear, away_team) then
                -- Skip this date and find alternative
                local base_time = match_time
                local new_time = base_time + 86400
                local tries = 0
                while (isInRestWeek(new_time, restWeeks) or 
                       isForbiddenDate(new_time, startYear) or
                       shouldBlockWeekdayForTeam(new_time, startYear, home_team) or
                       shouldBlockWeekdayForTeam(new_time, startYear, away_team) or
                       not hasSufficientRest(home_team, format_date(new_time), matchdays, team_schedules) or
                       not hasSufficientRest(away_team, format_date(new_time), matchdays, team_schedules)) and 
                       tries < 14 do  -- Try for up to 2 weeks
                    new_time = new_time + 86400
                    tries = tries + 1
                end
                
                if tries >= 14 then
                    -- Couldn't find suitable date, use original (this shouldn't happen often)
                    matchDate = matchDate
                else
                    matchDate = format_date(new_time)
                end
            end
            
            if hasSufficientRest(home_team, matchDate, matchdays, team_schedules) and
               hasSufficientRest(away_team, matchDate, matchdays, team_schedules) then
                matches[j].matchDate = matchDate
                table.insert(team_schedules[home_team], matchDate)
                table.insert(team_schedules[away_team], matchDate)
            else
                -- Find next valid date for this match
                local base_time = parse_date(matchDate)
                local new_time = base_time + 86400
                while (isInRestWeek(new_time, restWeeks) or isForbiddenDate(new_time, startYear) or
                       shouldBlockWeekdayForTeam(new_time, startYear, home_team) or
                       shouldBlockWeekdayForTeam(new_time, startYear, away_team) or
                       not hasSufficientRest(home_team, format_date(new_time), matchdays, team_schedules) or
                       not hasSufficientRest(away_team, format_date(new_time), matchdays, team_schedules)) and
                       (new_time - base_time) / 86400 < 7 do
                    new_time = new_time + 86400
                end
                local new_date = format_date(new_time)
                matches[j].matchDate = new_date
                table.insert(team_schedules[home_team], new_date)
                table.insert(team_schedules[away_team], new_date)
            end
        end
    end

    self:insertMatchToFixtures(self:getAllMatches(matchdays), "League", leagueID)
    return matchdays
end

function Fixtures:addMatch(home, away, matchDate, matchType, matchday, leagueID)
    local matchData = sessionVars.get("MatchData") or {}
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    leagueMatchData[leagueID] = leagueMatchData[leagueID] or {}

    local convertedDate = convertToMMDDYY(matchDate)
    if not convertedDate then
        print("Skipping match addition due to invalid date: " .. tostring(matchDate))
        return
    end

    local matchEntry = {
        homeID = home,
        awayID = away,
        date = convertedDate,
        matchType = matchType,
        matchday = matchday,
    }

    matchData[#matchData + 1] = matchEntry
    leagueMatchData[leagueID][#leagueMatchData[leagueID] + 1] = matchEntry

    sessionVars.set("MatchData", matchData)
    sessionVars.set("LeagueMatchData", leagueMatchData)
end

function Fixtures:generateSchedule(teams, mode, startYear, leagueID)
    local shuffledTeams = self:shuffleTeams(teams)
    local matchdays
    if mode == "manual" then
        if not manualFixtures or #manualFixtures == 0 then
            error("Manual mode requires a non-empty manualFixtures table")
        end
        matchdays = self:generateManualFixturesWithDates(manualFixtures, startYear, leagueID)
    elseif mode == "automatic" then
        matchdays = self:generateAutomaticFixturesWithDates(shuffledTeams, startYear, leagueID)
    elseif mode == "AI" then
        matchdays = self:generateAIfixtures(shuffledTeams, startYear, leagueID)
    else
        error("Invalid mode: must be 'manual', 'automatic', or 'AI'")
    end
    return matchdays
end

function Fixtures:getAllMatches(matchdays)
    local allMatches = {}
    local matchIndex = 1
    for matchdayIndex = 1, #matchdays do
        local matchday = matchdays[matchdayIndex]
        for j = 1, #matchday.matches do
            local match = matchday.matches[j]
            allMatches[matchIndex] = {
                home = match.home,
                away = match.away,
                matchDate = match.matchDate,
                matchday = matchdayIndex
            }
            matchIndex = matchIndex + 1
        end
    end
    return allMatches
end

function Fixtures:insertMatchToFixtures(matchTable, matchType, leagueID)
    local matchData = sessionVars.get("MatchData") or {}
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    leagueMatchData[leagueID] = leagueMatchData[leagueID] or {}

    local numMatches = #matchTable
    local leagueMatches = leagueMatchData[leagueID]
    local currentSize = #leagueMatches
    local newSize = currentSize + numMatches

    local leagueMatchesSave = {}

    for i = currentSize + 1, newSize do
        leagueMatches[i] = nil
    end

    local function mmddyy_to_doy(dateStr)
        if type(dateStr) ~= "string" or #dateStr ~= 6 then
            return nil
        end

        local month = tonumber(dateStr:sub(1,2))
        local day   = tonumber(dateStr:sub(3,4))
        local yy    = tonumber(dateStr:sub(5,6))

        if not (month and day and yy) then
            return nil
        end

        local year = 2000 + yy   -- 00→2000, 25→2025, etc.

        -- os.time will validate the date (handles leap years)
        local time = os.time({year = year, month = month, day = day})
        if not time then
            return nil
        end

        -- os.date("*t", time).yday → 1..366
        return os.date("*t", time).yday
    end

    local matchDataIndex   = #matchData + 1
    local leagueMatchIndex = currentSize + 1

    for i = 1, numMatches do
        local match = matchTable[i]
        local convertedDate = convertToMMDDYY(match.matchDate)

        if not convertedDate then
            print("Skipping match insertion due to invalid date: " .. tostring(match.matchDate))
        else
            local matchEntry = {
                homeID    = match.home,
                awayID    = match.away,
                date      = convertedDate,        
                matchType = matchType,
                matchday  = match.matchday,
                leagueID  = leagueID
            }

            -- Short-key version for saving + date as day-of-year number
            local doy = mmddyy_to_doy(convertedDate)

            local matchEntrySave = {
                h  = match.home,
                a  = match.away,
                d  = doy or 0,           -- 0 = invalid/fallback (or you can skip entry)
              --matchType = matchType,
                mD = match.matchday,
                lD = leagueID
            }

            matchData[matchDataIndex]       = matchEntry
            leagueMatches[leagueMatchIndex] = matchEntry

            leagueMatchesSave[leagueMatchIndex] = matchEntrySave

            matchDataIndex   = matchDataIndex   + 1
            leagueMatchIndex = leagueMatchIndex + 1
        end
    end

    sessionVars.set("MatchData", matchData)
    sessionVars.set("LeagueMatchData", leagueMatchData)

    --self.save:saveProgress(leagueMatches, "_NmatchData" .. "[" .. tostring(leagueID) .. "]")
end

function Fixtures:getLeagueMatchData(leagueID)
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    return leagueMatchData[leagueID] or {}
end

function Fixtures:resetMatchData()
  sessionVars.set("MatchData", {})
end

return Fixtures 
-- Brain.lua
-- Core logic model for LEAGUE DAVUNPES
local sessionVars = ...
local Brain = {}
Brain.__index = Brain

-- ── Finance configuration ─────────────────────────────────────────────────────
-- Per-league budget profile: min/max define the strength-scaled range;
-- leagueBonus is a flat prestige addition applied to every team in that league.
local LEAGUE_FINANCE = {
    -- Tier 1: elite European leagues
    [13]  = { min = 20000000, max = 250000000, leagueBonus = 10000000 },  -- Premier League
    [53]  = { min = 15000000, max = 200000000, leagueBonus =  8000000 },  -- La Liga
    [19]  = { min = 12000000, max = 180000000, leagueBonus =  7000000 },  -- Bundesliga
    [31]  = { min = 10000000, max = 160000000, leagueBonus =  6000000 },  -- Serie A
    [16]  = { min = 10000000, max = 150000000, leagueBonus =  5000000 },  -- Ligue 1
    -- Tier 2: solid mid-major leagues
    [4]   = { min =  8000000, max = 100000000, leagueBonus =  3000000 },  -- Pro League
    [7]   = { min =  5000000, max =  60000000, leagueBonus =  2000000 },  -- Serie A (other)
    [10]  = { min =  8000000, max =  90000000, leagueBonus =  3000000 },  -- Eredivisie
    [39]  = { min =  5000000, max =  60000000, leagueBonus =  2000000 },  -- MLS
    [50]  = { min =  5000000, max =  60000000, leagueBonus =  2000000 },  -- Premiership
    [68]  = { min =  7000000, max =  80000000, leagueBonus =  2500000 },  -- Süper Lig
    [308] = { min =  7000000, max =  80000000, leagueBonus =  2500000 },  -- Primeira Liga
    [350] = { min =  5000000, max =  60000000, leagueBonus =  2000000 },  -- Pro League 2
    -- Tier 3: second divisions of the elite leagues
    [14]  = { min =  3000000, max =  40000000, leagueBonus =  1000000 },  -- Championship
    [17]  = { min =  2000000, max =  25000000, leagueBonus =   500000 },  -- Ligue 2
    [20]  = { min =  2000000, max =  30000000, leagueBonus =   500000 },  -- Bundesliga 2
    [32]  = { min =  2000000, max =  25000000, leagueBonus =   500000 },  -- Serie B
    [54]  = { min =  2000000, max =  30000000, leagueBonus =   500000 },  -- Segunda
    -- Tier 4: lower divisions
    [60]  = { min =  1000000, max =  15000000, leagueBonus =        0 },  -- League One
}

local DEFAULT_FINANCE = { min = 10000000, max = 100000000, leagueBonus = 0 }
local CHAMPION_BONUS  = 15000000   -- budget reward for last season's league winner
local MIN_RATING      = 660
local MAX_RATING      = 1010
local ROUND_INCREMENT = 500000
-- ─────────────────────────────────────────────────────────────────────────────

function Brain:new(init)
    local o = init or {}
    setmetatable(o, self)
    o.TeamRatingsCache = o.TeamRatingsCache or {}
    o.TeamFunds        = o.TeamFunds or {}
    o.gameMode         = o.gameMode or "CareerMode"
    return o
end

-- captureChampions
-- Reads current standings to record which team topped each tracked league.
-- Must be called BEFORE promotion/relegation reshuffles LeagueTeams.
-- Returns: { [teamID] = true }  (set for O(1) lookup in calculateTeamFunds)
function Brain:captureChampions(TeamStats)
    local leagueTeams = sessionVars.get("LeagueTeams") or {}
    local champions   = {}
    for leagueID in pairs(LEAGUE_FINANCE) do
        if leagueTeams[leagueID] then
            local championID = TeamStats:getTeamStatByPosition(1, leagueID)
            if championID then
                champions[championID] = true
            end
        end
    end
    return champions
end

-- buildFinanceContext
-- Maps every team to the league it will play in next season (call AFTER
-- promotion/relegation is applied) and attaches the captured champion set.
-- champions: result of captureChampions, or {} for the very first season.
-- Returns: { teamLeague = { [teamID] = leagueID }, champions = { [teamID] = true } }
function Brain:buildFinanceContext(champions)
    local leagueTeams = sessionVars.get("LeagueTeams") or {}
    local teamLeague  = {}
    for leagueID, teams in pairs(leagueTeams) do
        if LEAGUE_FINANCE[leagueID] then
            for _, teamID in ipairs(teams) do
                teamLeague[teamID] = leagueID
            end
        end
    end
    return { teamLeague = teamLeague, champions = champions or {} }
end

-- buildInitialFinanceContext
-- Convenience wrapper for the very first season where no standings exist yet.
-- Reads league assignments from the freshly populated TeamCachedData.
function Brain:buildInitialFinanceContext()
    local cached     = sessionVars.get("TeamCachedData") or {}
    local teamLeague = {}
    for teamID, data in pairs(cached) do
        if data.league then
            teamLeague[teamID] = data.league
        end
    end
    return { teamLeague = teamLeague, champions = {} }
end

-- calculateTeamFunds
-- Derives transfer budget from squad strength, scaled by the team's league
-- tier and bumped for any team that won its league the previous season.
--
-- squad   : player array (single-team mode only)
-- input   : teamID (single) or array of teamIDs (batch)
-- isBatch : boolean
-- ctx     : financeContext from buildFinanceContext / buildInitialFinanceContext.
--           Pass nil to fall back to DEFAULT_FINANCE with no champion bonuses.
function Brain:calculateTeamFunds(squad, input, isBatch, ctx)
    -- 1. Collect starting-XI rating totals
    local teamRatings = {}
    if isBatch then
        for _, teamID in ipairs(input) do
            local lineup = getCachedTeamPlayers(teamID)
            local total  = 0
            if lineup and #lineup >= 11 then
                for i = 1, 11 do total = total + (lineup[i].rating or 0) end
            end
            teamRatings[teamID] = total
        end
    else
        local total  = 0
        local lineup = squad
        if lineup and #lineup >= 11 then
            for i = 1, 11 do total = total + (lineup[i].rating or 0) end
        end
        teamRatings[input] = total
    end

    -- 2. Unpack context (safe-default to empty tables when ctx is absent)
    local champions  = ctx and ctx.champions  or {}
    local teamLeague = ctx and ctx.teamLeague or {}

    -- 3. Compute budget for each team
    local TeamFunds = {}
    for teamID, rating in pairs(teamRatings) do
        local leagueID = teamLeague[teamID]
        local profile  = (leagueID and LEAGUE_FINANCE[leagueID]) or DEFAULT_FINANCE

        -- a) Strength-scaled component (quadratic curve inside league's range)
        local normalized = math.max(0, math.min(1, (rating - MIN_RATING) / (MAX_RATING - MIN_RATING)))
        local raw        = profile.min + (normalized ^ 2) * (profile.max - profile.min)

        -- b) League prestige bonus (flat, same for every team in the league)
        raw = raw + profile.leagueBonus

        -- c) Champion bonus (flat, awarded to last season's title winner)
        if champions[teamID] then
            raw = raw + CHAMPION_BONUS
        end

        -- d) Round to nearest increment and clamp within sane bounds
        local funds = math.ceil(raw / ROUND_INCREMENT) * ROUND_INCREMENT
        TeamFunds[teamID] = math.max(profile.min, math.min(profile.max + CHAMPION_BONUS, funds))
    end

    return isBatch and TeamFunds or TeamFunds[input]
end

return Brain
local dep = {...}

local Brain, Processor, Save, Savegame, Squads,
      glInstancePasser, Timer, sessionVars,
      Fixtures, CareerModeLeagues, LoadSave, Modes =
      dep[1] or {},
      dep[2] or {},
      dep[3] or {},
      dep[4] or {},
      dep[5] or {},
      dep[6] or {},
      dep[7] or {},
      dep[8] or {},
      dep[9] or {},
      dep[10] or {},
      dep[11] or {},
      dep[12] or {}
local TeamSelect = {}
local TeamList = {}
local getTeamPls = nil
local getLeagueTms = nil

TeamListData = {}

local function deepCopy(orig)
    local copy = {}
    for k, v in pairs(orig) do
        if type(v) == "table" then
            copy[k] = deepCopy(v)
        else
            copy[k] = v
        end
    end
    return copy
end

local function debugTable(tbl, name)
end

local function reformatMatchDates(matchDates, globalDate)
    local reformattedDates = {}
    local day, month, year = globalDate:match("(%d+)/(%d+)/(%d+)")
    month = tonumber(month)
    year = tonumber(year)
    local oldYear, newYear
    if month >= 7 and month <= 12 then
        oldYear = year
        newYear = year + 1
    else
        oldYear = year - 1
        newYear = year
    end

    for i = 1, #matchDates do
        local date = matchDates[i]
        local dateStr = tostring(date)
        if #dateStr == 3 then
            dateStr = "0" .. dateStr
        end
        local matchMonth, matchDay = dateStr:match("(%d%d)(%d%d)")
        matchMonth = tonumber(matchMonth)
        local reformattedDate
        if month >= 7 and month <= 12 then
            if matchMonth >= 7 and matchMonth <= 12 then
                reformattedDate = dateStr .. string.format("%02d", oldYear)
            else
                reformattedDate = dateStr .. string.format("%02d", newYear)
            end
        else
            if matchMonth >= 1 and matchMonth <= 6 then
                reformattedDate = dateStr .. string.format("%02d", newYear)
            else
                reformattedDate = dateStr .. string.format("%02d", oldYear)
            end
        end
        reformattedDates[i] = reformattedDate
    end
    return reformattedDates
end

local function populateMatchData(schedule, reformattedDates, leagueID)
    local matchData = sessionVars.get("MatchData") or {}
    local leagueMatchData = sessionVars.get("LeagueMatchData") or {}
    leagueMatchData[leagueID] = leagueMatchData[leagueID] or {}
    local matchDataIndex = #matchData + 1
    local leagueMatchIndex = #leagueMatchData[leagueID] + 1
    local dateIndex = 1
    for i = 1, #schedule do
        local matchday = schedule[i]
        for j = 1, #matchday do
            local fixture = matchday[j]
            local matchEntry = {
                homeID = fixture[1],
                awayID = fixture[2],
                matchDate = reformattedDates[dateIndex],
                matchType = "League"
            }
            matchData[matchDataIndex] = matchEntry
            leagueMatchData[leagueID][leagueMatchIndex] = matchEntry
            matchDataIndex = matchDataIndex + 1
            leagueMatchIndex = leagueMatchIndex + 1
        end
        dateIndex = dateIndex + 1
    end
    sessionVars.set("MatchData", matchData)
    sessionVars.set("LeagueMatchData", leagueMatchData)
end

function TeamSelect:new(init)
    local o = init or {}
    setmetatable(o, self)
    self.__index = self
    o.services = {
        SquadManagementService = o.api("SquadMgtService"),
        TeamService = o.api("TeamService"),
        TacticsService = o.api("TacticsService")
    }
    o.loadmode = sessionVars.get("loadcareer") or false
    
    if sessionVars.get("CareerMode") and not(o.loadmode) then
      currentSelectedTeamID = sessionVars.get("currentSelectedTeamID")
      GLOBAL_DATE_PLACEHOLDER = sessionVars.get("GLOBAL_DATE_PLACEHOLDER")
      GLOBAL_FUNDS = sessionVars.get("GLOBAL_FUNDS")
      o.nav.Event(nil, "evt_team_select")
      return o
    end
    
    o.Modes = Modes:new({nav = o.nav, loc = o.loc, api = o.api})
    o.loadSave = LoadSave:new({Save = Save, sessionVars = sessionVars, CareerModeLeagues = CareerModeLeagues, services = o.services})
    getTeamPls = o.services.SquadManagementService.GetCurrentPlayerLineup
    getLeagueTms = o.services.TeamService.GetTeams
    o.savegame = Savegame:new({api = o.api, Timer = Timer})
    o.savegame:openBrowser()
    o.squads = Squads:new({services = o.services})
    o.brain = Brain:new({squads = o.squads})
    o.processor = Processor:new({api = o.api, save = o.savegame})
    o.fixtures = Fixtures:new({save = o.savegame})
    o.test = "Instance Passed Successfully"
    o.allTeams = {}
    o.overlayTimer = nil
    o.initTimer = nil
    o.progress = 0
    o.loadingbar = nil
    o.progressDelayTimers = {}
    o.firstTime = not (sessionVars.get("CareerMode"))
    o.im.Subscribe("bnd_test", function()
        o.im.Publish("bnd_test", "It Stores State")
    end)
    

    o.nav.Event(nil, "evt_show_overlay", {vvm = "/flows/mainflow/gamemodes/Liga/Screens/LoadingScreen.vvm", data = {getInstance = function(inst) o.loadingbar = inst end}})

    o.overlayTimer = Timer:new({
        id = "overlayTimer",
        interval = 2,
        reps = 1,
        onTimerComplete = function()
            o.overlayTimer = nil
            o.initTimer = Timer:new({
                id = "initTimer",
                interval = 1,
                reps = 1,
                onTimerComplete = function()             
                    o:startInitialization(currentSelectedTeamID)
                    o.initTimer = nil
                end
            })
            o.initTimer:start()
        end
    })
    o.overlayTimer:start()
    glInstancePasser:getInstance(o)
    return o
end

function TeamSelect:publishProgress(nextStepCallback)
    if self.loadingbar then
        self.loadingbar.im.Publish("bnd_progress", self.progress)
    end
    if nextStepCallback then
        local timer = Timer:new({
            id = "progressDelay_" .. self.progress,
            interval = 0.5,
            reps = 1,
            onTimerComplete = function()
                nextStepCallback()
                for i, t in ipairs(self.progressDelayTimers) do
                    if t.id == timer.id then
                        table.remove(self.progressDelayTimers, i)
                        break
                    end
                end
            end
        })
        table.insert(self.progressDelayTimers, timer)
        timer:start()
    end
end

function TeamSelect:startInitialization(teamId)
    local steps = {}
    local stepIndex = 1

    steps[1] = function()
        if self.firstTime then
            local shortlistedPlayers = {}
            sessionVars.set("currentSelectedTeamID", currentSelectedTeamID)
            sessionVars.set("GLOBAL_DATE_PLACEHOLDER", "15/07/25")
            yellowCardRecords, redCardRecords, TeamFunds, injuryRecords, redCardMatchCount, injuryRecoveryDate, GOALS, matchdayLoaded, transferredPlayers = {}, {}, {}, {}, {}, {}, {}, {}, {}
            transferHistory = {}           
            local loanedPlayers = {}
            newSession = "yes"
            sessionVars.set("loanedPlayers", loanedPlayers)
            sessionVars.set("shortlistedPlayers", shortlistedPlayers)
            sessionVars.set("redMatchCount", {})
            sessionVars.set("PlayerGoals", {})
            sessionVars.set("transferCount", 0)
            sessionVars.set("isSuspended", {})
            sessionVars.set("notListed", {})
            sessionVars.set("loanListed", {})
            sessionVars.set("transferListed", {})
            sessionVars.set("notFirstTime", {})
            sessionVars.set("tempSave", {})
            sessionVars.set("MatchData", {})
		    sessionVars.set("LeagueMatchData", {})
        end
        self.progress = 80
        self:publishProgress(function()
            stepIndex = stepIndex + 1
            if steps[stepIndex] then steps[stepIndex]() end
        end)
    end

    steps[2] = function()       
        self.processor:cacheAllTeamPlayers()        
        self.progress = 160
        self:publishProgress(function()
            stepIndex = stepIndex + 1
            if steps[stepIndex] then steps[stepIndex]() end
        end)
    end

    steps[3] = function()
        if self.firstTime then
            local allTeams = sessionVars.get("CareerModeTeams") or {} 
            local ctx = self.brain:buildInitialFinanceContext()
            sessionVars.set("GLOBAL_FUNDS", ((not self.loadmode and sessionVars.get("InCareerMode")) and (self.brain:calculateTeamFunds(nil, allTeams, true, ctx)) or {}))
            if (not self.loadmode) then
            local day, month, year = sessionVars.get("GLOBAL_DATE_PLACEHOLDER"):match("(%d%d)/(%d%d)/(%d%d)")
            day, month, year = tonumber(day), tonumber(month), tonumber(year)          
            local startYear = 2000 + year
            local leagueTeams = sessionVars.get("LeagueTeams") or {}
            local userLeagueID = sessionVars.get("currentUserLeagueID") 
            local leagueMatchData = {}
            local matchData = {}
            local idx = 0
            if (sessionVars.get("InTourneyMode")) and (not(self.loadmode)) then
            local teams = { 241,243,481,461,483,240,1,5,9,10,11,18,69,65,66,219,73,32,22,21,34,112172,1831,175,38,39,110374,44,45,46,47,48,52,245,1906,246 }
              sessionVars.set("GLOBAL_DATE_PLACEHOLDER", "10/09/25")
              
              self.Modes:initializeMode("UCL", startYear, teams, self.api)
            elseif sessionVars.get("InCareerMode") then
              for i = 1, #CareerModeLeagues do
                  local leagueID = CareerModeLeagues[i]               
                  local teams = leagueTeams[leagueID]
                  if leagueID ~= userLeagueID then
                    self.fixtures:generateSchedule(teams, "AI", startYear, leagueID)
                  else
                    self.fixtures:generateSchedule(teams, "automatic", startYear, leagueID)
                  end
                
                                  
                --self.savegame:saveProgress(sessionVars.get("MatchData"))
              end
            end
          end
        end
        self.progress = 240
        self:publishProgress(function()
            stepIndex = stepIndex + 1
            if steps[stepIndex] then steps[stepIndex]() end
        end)
    end

    steps[4] = function()
            
            
        self.progress = 320
        self:publishProgress(function()
            stepIndex = stepIndex + 1
            if steps[stepIndex] then steps[stepIndex]() end
        end)
    end

    steps[5] = function()
        if (self.loadmode) then
          self.loadSave:loadSavedGame()
        end
        sessionVars.set("loadcareer", nil)
        currentSelectedTeamID = sessionVars.get("currentSelectedTeamID")
        GLOBAL_DATE_PLACEHOLDER = sessionVars.get("GLOBAL_DATE_PLACEHOLDER")
        GLOBAL_FUNDS = sessionVars.get("GLOBAL_FUNDS")
        isSuspended = sessionVars.get("isSuspended")
        self.nav.Event(nil, "evt_team_select")
        self.nav.Event(nil, "evt_hide_overlay", {})        
    end

    steps[1]()
end

local function swapPlayersInTeam(players, cardIdToSwap)
			    if #players == 0 then return {} end
			    
			    local swapIdx, swapPos, foundIdx
			    for i, player in ipairs(players) do
			        if player.CARD_ID == cardIdToSwap then swapIdx, swapPos = i, player.position break end
			    end
			    if not swapIdx then return {} end
			    
			    for i = 12, #players do
			        if players[i].position == swapPos then
			            foundIdx = i			            			            
			        end
			    end   
			  return swapIdx, (foundIdx or 12)
			end

function transferPlayer(playerID, sourceTeamID, targetTeamID, isLoan, loanDuration)
local TeamCachedData = sessionVars.get("TeamCachedData")
local notFirstTime= sessionVars.get("notFirstTime")
local transferOffers = sessionVars.get("transferOffers") or {}
if transferredPlayers[playerID] then
return
end

if not notFirstTime[playerID] then
  notFirstTime[playerID] = sourceTeamID
end

sessionVars.set("notFirstTime", notFirstTime)

-- Get source team players (lineup + bench/reserves)  
local sourceTeamPlayers = getCachedTeamPlayers(sourceTeamID)
if not sourceTeamPlayers or #sourceTeamPlayers == 0 then  
    error("No players found for source teamID " .. sourceTeamID)  
end  

-- Swap players for user-controlled team  
if sourceTeamID == currentSelectedTeamID then  
    local swapSuccess = swapPlayersInTeam(sourceTeamPlayers, playerID)  
end  

-- Find the player being transferred  
local playerToTransfer, playerIndex = nil, nil  
for index = 1, #sourceTeamPlayers do  
    local player = sourceTeamPlayers[index]  
    if player.CARD_ID == playerID then  
        playerToTransfer = player  
        playerIndex = index  
        break  
    end  
end  
if not playerToTransfer then  
    return  
end  

if playerIndex <= 11 then
  local oldIdx, newIdx = swapPlayersInTeam(sourceTeamPlayers, playerID)
  sourceTeamPlayers[oldIdx], sourceTeamPlayers[newIdx] = sourceTeamPlayers[newIdx], sourceTeamPlayers[oldIdx]
  playerIndex = newIdx
end

local soldPlayerPosition = playerToTransfer.position  

-- Remove sold player  
table.remove(sourceTeamPlayers, playerIndex)  

-- Update source team lineup  
TeamCachedData[sourceTeamID].players = sourceTeamPlayers  

-- Target team update  
local targetTeamPlayers = getCachedTeamPlayers(targetTeamID)
if not targetTeamPlayers or #targetTeamPlayers == 0 then  
    targetTeamPlayers = {}  
end  
playerToTransfer.teamID = targetTeamID  
targetTeamPlayers[#targetTeamPlayers + 1] = playerToTransfer  
TeamCachedData[targetTeamID].players = targetTeamPlayers  

-- Update local reference for active team  
if targetTeamID == teamId then  
    players = targetTeamPlayers  
end  
if sourceTeamID == teamId then  
    players = sourceTeamPlayers  
end  
local transferCount = sessionVars.get("transferCount")
-- Add to transfer history  
transferHistory[#transferHistory + 1] = {  
    Player = playerID,  
    oldTeam = sessionVars.get("notFirstTime")[playerID] or sourceTeamID,  
    newTeam = targetTeamID,  
}  
if isLoan then
transferHistory[#transferHistory].isLoan = loanDuration
end

sessionVars.set("transferCount", (transferCount + 1))

-- Mark player as transferred  
transferredPlayers[playerID] = true  

-- Handle loaning  
if isLoan then   
    local loanedPlayers = sessionVars.get("loanedPlayers") or {}
    loanedPlayers[playerID] = {duration = loanDuration, mainTeam = sourceTeamID, loanTeam = targetTeamID}  
    sessionVars.set("loanedPlayers", loanedPlayers)  
end  

-- Save updated cached data  
sessionVars.set("TeamCachedData", TeamCachedData)
transferOffers[playerID] = nil
sessionVars.set("transferOffers", transferOffers)

end                      
            
            function revertLoansByDuration(duration)
    local TeamCachedData = sessionVars.get("TeamCachedData")
    local loanedPlayers = sessionVars.get("loanedPlayers") or {}

    if not loanedPlayers then
        return
    end

    for playerID, loanData in pairs(loanedPlayers) do
        if loanData.duration == duration then
            local mainTeamID = loanData.mainTeam
            local loanTeamID = loanData.loanTeam

            local loanTeamPlayers = getCachedTeamPlayers(loanTeamID)
            local playerToRevert, playerIndex = nil, nil

            if loanTeamPlayers then
                for index = 1, #loanTeamPlayers do
                    if loanTeamPlayers[index].CARD_ID == playerID then
                        playerToRevert = loanTeamPlayers[index]
                        playerIndex = index
                        break
                    end
                end
            end

            if playerToRevert then
                table.remove(loanTeamPlayers, playerIndex)
                local updatedLoanTeamPlayerIDs = {}
                for i = 1, #loanTeamPlayers do
                    updatedLoanTeamPlayerIDs[i] = loanTeamPlayers[i].CARD_ID
                end
                TeamCachedData[loanTeamID].players = loanTeamPlayers

                local mainTeamPlayers = getCachedTeamPlayers(mainTeamID)
                if not mainTeamPlayers then
                    mainTeamPlayers = {}
                end
                playerToRevert.teamID = mainTeamID
                mainTeamPlayers[#mainTeamPlayers + 1] = playerToRevert
                local updatedMainTeamPlayerIDs = {}
                for i = 1, #mainTeamPlayers do
                    updatedMainTeamPlayerIDs[i] = mainTeamPlayers[i].CARD_ID
                end
                TeamCachedData[mainTeamID].players = mainTeamPlayers

                -- ✅ Only wipe history and loan record if the player was actually moved
                for i = #transferHistory, 1, -1 do
                    local record = transferHistory[i]
                    if record.Player == playerID and record.isLoan then
                        table.remove(transferHistory, i)
                        break
                    end
                end

                loanedPlayers[playerID] = nil
                transferredPlayers[playerID] = nil
            end
        end
    end

    sessionVars.set("loanedPlayers", loanedPlayers)
    sessionVars.set("TeamCachedData", TeamCachedData)
end

            function releasePlayer(playerID, sourceTeamID)
                local TeamCachedData = sessionVars.get("TeamCachedData")
                local swapPlayer = false
                local sourceTeamPlayers = self.services.SquadManagementService.GetCurrentPlayerLineup(0, sourceTeamID, 0)
                if not sourceTeamPlayers or #sourceTeamPlayers == 0 then
                    error("No players found for source teamID " .. sourceTeamID)
                end

                if sourceTeamID == currentSelectedTeamID then
                    for i = 1, #sourceTeamPlayers do
                        if sourceTeamPlayers[i].CARD_ID == playerID then
                            if i <= 11 then
                                swapPlayer = true
                            end
                        end
                    end
                    if swapPlayer then
                        local swapSuccess = swapPlayersInTeam(sourceTeamPlayers, playerID)
                    end
                end

                local playerToRelease, playerIndex = nil, nil
                for index = 1, #sourceTeamPlayers do
                    local player = sourceTeamPlayers[index]
                    if player.CARD_ID == playerID then
                        playerToRelease = player
                        playerIndex = index
                        break
                    end
                end

                if not playerToRelease then
                    return false
                end

                table.remove(sourceTeamPlayers, playerIndex)
                local updatedSourceTeamPlayerIDs = {}
                for i = 1, #sourceTeamPlayers do
                    local player = sourceTeamPlayers[i]
                    if player then
                        updatedSourceTeamPlayerIDs[i] = player.CARD_ID
                    end
                end
                self.services.SquadManagementService.SetCurrentPlayerLineup(0, sourceTeamID, 0, 0, updatedSourceTeamPlayerIDs)
                TeamCachedData[sourceTeamID].players = sourceTeamPlayers

                if sourceTeamID == teamId then
                    players = sourceTeamPlayers
                end

                playerToRelease.teamID = nil
                transferredPlayers[playerID] = true
                sessionVars.set("TeamCachedData", TeamCachedData)
                return true
            end          

function TeamSelect:test()
    self.nav.Event(nil, "evt_back")
end

function TeamSelect:generateLigaGrouping()
    
end

function getCachedTeamPlayers(teamID)
    local TeamCachedData = sessionVars.get("TeamCachedData")
    return TeamCachedData[teamID] and TeamCachedData[teamID].players or false
end

function updateTeamLeague(leagueID, teamID)
  local TeamCachedData = sessionVars.get("TeamCachedData")
  TeamCachedData[teamID].league = leagueID
end

function getTeamLeague(teamID)
    local TeamCachedData = sessionVars.get("TeamCachedData")
    return TeamCachedData[teamID] and TeamCachedData[teamID].league or 1
end

function TeamSelect:update(elapsedTime)
    if self.overlayTimer then
        self.overlayTimer:update(elapsedTime)
    end
    if self.initTimer then
        self.initTimer:update(elapsedTime)
    end
    for i = 1, #self.progressDelayTimers do
        self.progressDelayTimers[i]:update(elapsedTime)
    end
end

function TeamSelect:finalize()
    if self.overlayTimer then
        self.overlayTimer:finalize()
        self.overlayTimer = nil
    end
    if self.initTimer then
        self.initTimer:finalize()
        self.initTimer = nil
    end
    for i = 1, #self.progressDelayTimers do
        self.progressDelayTimers[i]:finalize()
    end
    self.progressDelayTimers = {}
    self.im.Unsubscribe("bnd_progress")
end

return TeamSelect
-- LEAGUE BY DAVUNPES --
-- REMODIFIED BY DAVUNPES --
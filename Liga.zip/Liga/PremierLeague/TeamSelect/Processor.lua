-- Processor.lua
local sessionVars, Timer, CareerModeLeagues, TeamData = ...
local Processor = {}
local additionalLeagues= {}

local BASE_LEAGUES = CareerModeLeagues
local extraLeagues = {}

local function addExtraLeague(leagueID)
    extraLeagues[#extraLeagues + 1] = leagueID
    additionalLeagues[leagueID] = true
end

local function deepCopy(orig, copies)
    copies = copies or {}
    local orig_type = type(orig)
    local copy

    if orig_type == 'table' then
        if copies[orig] then
            return copies[orig]
        end

        copy = {}
        copies[orig] = copy

        for k, v in pairs(orig) do
            copy[deepCopy(k, copies)] = deepCopy(v, copies)
        end

        local mt = getmetatable(orig)
        if mt then
            setmetatable(copy, deepCopy(mt, copies))
        end
    else
        copy = orig
    end

    return copy
end

function Processor:new(init)
    local o = init or {}
    setmetatable(o, self)
    self.__index = self

    o.api = init.api
    o.save = init.save
    o.services = {
        SquadManagementService = o.api("SquadMgtService"),
        TeamService = o.api("TeamService"),
        CountryService = o.api("CountryService")
    }

    local getPlayerLineup = o.services.SquadManagementService.GetCurrentPlayerLineup
    local getLeagueTeams = o.services.TeamService.GetTeams

    o.TeamData = TeamData:new({api = o.api})
    o.allTeams = {}
	
    function o:cacheAllTeamPlayers()
        --addExtraLeague(2271)
        addExtraLeague(76)
        addExtraLeague(41)
        addExtraLeague(1)

        local cachedData = {}
        local fifaSquad = {}
        local leagueTeamsMap = {}
        local allTeamIDs = {}
        local teamCounter = 1

        local allLeagues = {}
        for _, id in ipairs(BASE_LEAGUES) do
            allLeagues[#allLeagues + 1] = id
        end
        for _, id in ipairs(extraLeagues) do
            allLeagues[#allLeagues + 1] = id
        end

        local existingFifaSquad = sessionVars.get("fifaSquad", true)
        local isFirstCache = not existingFifaSquad or next(existingFifaSquad) == nil

        for _, leagueID in ipairs(allLeagues) do
            local teams = getLeagueTeams(leagueID, 0, 0, false)
            if teams and #teams > 0 then

                local leagueTeamList = nil
                if not additionalLeagues[leagueID] then
                    leagueTeamsMap[leagueID] = {}
                    leagueTeamList = leagueTeamsMap[leagueID]
                end

                self.TeamData:updateTeamsStrength(leagueID)

                for _, team in ipairs(teams) do
                    local finalLeagueID = leagueID
                    if sessionVars.get("InTourneyMode") then
                        finalLeagueID = 2236
                    end

                    if team.id == currentSelectedTeamID then
                        sessionVars.set("currentUserLeagueID", finalLeagueID)
                    end

                    local players
                    if isFirstCache then
                        players = getPlayerLineup(0, team.id, 0) or {}
                        fifaSquad[team.id] = {players = deepCopy(players)}
                    else
                        players = deepCopy((existingFifaSquad[team.id] or {}).players or {})
                    end

                    if leagueTeamList then
                        leagueTeamList[#leagueTeamList + 1] = team.id

                        allTeamIDs[teamCounter] = team.id
                        teamCounter = teamCounter + 1
                    end

                    cachedData[team.id] = {
                        players = players,
                        league = finalLeagueID
                    }
                end
            end
        end

        local userLeagueID = sessionVars.get("currentUserLeagueID") or allLeagues[1] or 0
        local userTeamList = leagueTeamsMap[userLeagueID] or {}

        sessionVars.set("TeamList", userTeamList)
        sessionVars.set("LeagueTeams", leagueTeamsMap)
        sessionVars.set("TeamCachedData", cachedData)

        if isFirstCache then
            sessionVars.set("fifaSquad", fifaSquad, true)
        end

        sessionVars.set("CareerModeTeams", allTeamIDs)
        self.allTeams = allTeamIDs
    end

    function o:cacheTeamPlayers(teamID)
        local players = getPlayerLineup(0, teamID, 0) or {}
        local cached = sessionVars.get("TeamCachedData") or {}
        cached[teamID] = {players = players}
        sessionVars.set("TeamCachedData", cached)
    end

    function o:update(elapsedTime)
        if self.startupTimer then
            self.startupTimer:update(elapsedTime)
        end
    end

    function o:finalize()
        if self.startupTimer then
            self.startupTimer:finalize()
            self.startupTimer = nil
        end
    end

    return o
end

return Processor
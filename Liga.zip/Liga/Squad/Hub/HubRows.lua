local Timer, FCPopup, sessionVars, Squads = ...

local function formatStat(val)
  local col = ""
  if type(val) == "number" then
    local int = val
    if int < 50 then
      col = "0xFF2F00"
    elseif int < 70 then
      col = "0xFFFF00"
    elseif int < 79 then
      col = "0x006400"
    else
      col = "0x00FF00"
    end
  elseif type(val) == "string" then
    if val == "Happy" or val == "Very Happy" then
      col = "0x00FF00"
    elseif val == "Normal" then
      col = "0xFFFF00"
    else
      col = "0xFF2F00"
    end
  end
  return col or "0xFFFFFF"
end

local function formatHeight(cm)
  local totalInches = cm / 2.54
  local feet = math.floor(totalInches / 12)
  local inches = math.floor(totalInches % 12 + 0.5)
  return string.format("%d'%d\"", feet, inches)
end

local function indexOf(tbl, value)
  for i, v in ipairs(tbl) do
    if v == value then
      return i
    end
  end
  return nil
end

local HubRows = {}
local rowField = {"position", "head", "name", "ovr", "role"}
local colorField = {"pos", "name", "ovr", "role"}
local panelAttributes = {"position", "opened"}
local panelPositions = {30, 82, 134, 186, 238, 290, 342, 342, 342}
local playerRolesTable = {"Crucial", "Important", "Rotation", "Sporadic", "Prospect"}
local PlayerListData = {}
local ROW_COUNT = 9
local FIELD_COUNT = 5
local COLOR_FIELD_COUNT = 4
local ACTIONS_BTN_COUNT = 6
local displayType = nil
local transferOffers = sessionVars.get("transferOffers") or {}
-- player stats
local userLeagueID = sessionVars.get("currentUserLeagueID") or {}
local playerGoals = sessionVars.get("PlayerGoals") or {}
local leagueGoals = playerGoals[userLeagueID] or {}

-- Define position order for sorting
local positionOrder = {
    "GK", "RB", "RWB", "CB", "LB", "LWB", "CDM", "RM", "CM", "LM", "CAM", "ST", "CF", "LF", "RF"
}
local positionIndex = {}
for i, pos in ipairs(positionOrder) do
    positionIndex[pos] = i
end

function HubRows:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.services = { SquadManagementService = o.api("SquadMgtService") }
  o.teamID = o.teamID or currentSelectedTeamID -- Use provided teamID or default
  o.selectedRow = 1      -- Selected row index (1 to totalPlayers)
  o.selectedPlayer = nil
  o.startIndex = 1       -- First player index in visible window
  o.totalPlayers = 0     -- Total players in roster
  o.rowData = {}         -- Preallocated row data (9 rows x 6 fields)
  o.cursorData = {}      -- Preallocated cursor states (9 booleans)
  o.cursorHeight = 70    -- Fixed cursor height (always 70)
  o.panelposition = 0
  o.selectedPanelBtn = 1
  o.currentTab = "status"
  o.panelvisible = false
  o.panelData = {o.panelposition, o.panelvisible}
  o.FCPopup = FCPopup:new({nav = o.nav})
  o.cursorMarginTop = 0  -- Dynamic cursor marginTop
  o.targetMarginTop = 0  -- Target cursor marginTop for animation
  o.cursorTimer = nil    -- Timer for cursor animation
  o.rowPublishTimer = nil -- Timer for staggered row publishing
  o.bounceTimer = nil
  o.renderPauseTimer = nil
  o.actionsViewActive = false -- Tracks if actions view (with cleared rows) is active
  o.swipeY = 0
  o.sortField = 1
  o.sortDirection = "asc"
  o.lastSortField = nil
  o.initTimer = nil
  o.initialized = false
  o.isInitialLoad = true

  -- Preallocate rowData and cursorData
  for i = 1, ROW_COUNT do
    o.rowData[i] = { "", {name="$Head",id=0}, "", "", "", "", {form = 1, type = 0}, 0}
    o.cursorData[i] = false
  end

  -- Smart binding registration
  local bindings = {}
  local bindingCount = 0
  for i = 1, ROW_COUNT do
    for j = 1, FIELD_COUNT do
      bindingCount = bindingCount + 1
      bindings[bindingCount] = "bnd_row"..rowField[j]..i
    end
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "bnd_rowselected"..i
    for j = 1, COLOR_FIELD_COUNT do
      bindingCount = bindingCount + 1
      bindings[bindingCount] = "bnd_"..colorField[j].."color"..i
    end
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "bnd_rowvisible"..i
  end
  bindingCount = bindingCount + 1
  bindings[bindingCount] = "bnd_rowcursor_height"
  bindingCount = bindingCount + 1
  bindings[bindingCount] = "bnd_rowcursor_marginTop"
  bindingCount = bindingCount + 1
  bindings[bindingCount] = "bnd_rowcursorvisible"
  for i = 1, 2 do
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "bnd_panel"..panelAttributes[i]
  end
  for i = 1, 9 do
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "formOne".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "formTwo".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "formTwoType".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "formThree".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "formThreeType".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "moraleOne".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "moraleTwo".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "moraleThree".. i
    bindingCount = bindingCount + 1
    bindings[bindingCount] = "moraleFour".. i
  end
  bindingCount = bindingCount + 1
  bindings[bindingCount] = "isRowEmpty"

  for i = 1, bindingCount do
    o.im.Subscribe(bindings[i], function() o:publishPending() end)
  end

  -- Precompute all publish keys to avoid runtime string concat
  o.publishKeys = {
    rowFields = {},
    selected = {},
    colors = {},
    visible = {},
    formOne = {},
    formTwo = {},
    formTwoType = {},
    formThree = {},
    formThreeType = {},
    moraleOne = {},
    moraleTwo = {},
    moraleThree = {},
    moraleFour = {},
  }
  for i = 1, ROW_COUNT do
    o.publishKeys.rowFields[i] = {}
    for j = 1, FIELD_COUNT do
      o.publishKeys.rowFields[i][j] = "bnd_row"..rowField[j]..i
    end
    o.publishKeys.selected[i] = "bnd_rowselected"..i
    o.publishKeys.colors[i] = {}
    for j = 1, COLOR_FIELD_COUNT do
      o.publishKeys.colors[i][j] = "bnd_"..colorField[j].."color"..i
    end
    o.publishKeys.visible[i] = "bnd_rowvisible"..i
    o.publishKeys.formOne[i] = "formOne"..i
    o.publishKeys.formTwo[i] = "formTwo"..i
    o.publishKeys.formTwoType[i] = "formTwoType"..i
    o.publishKeys.formThree[i] = "formThree"..i
    o.publishKeys.formThreeType[i] = "formThreeType"..i
    o.publishKeys.moraleOne[i] = "moraleOne"..i
    o.publishKeys.moraleTwo[i] = "moraleTwo"..i
    o.publishKeys.moraleThree[i] = "moraleThree"..i
    o.publishKeys.moraleFour[i] = "moraleFour"..i
  end
  o.publishKeys.cursorHeight = "bnd_rowcursor_height"
  o.publishKeys.cursorMarginTop = "bnd_rowcursor_marginTop"
  o.publishKeys.cursorVisible = "bnd_rowcursorvisible"
  o.publishKeys.panelPosition = "bnd_panelposition"
  o.publishKeys.panelOpened = "bnd_panelopened"
  o.im.Subscribe("onStatus", function() o.im.Publish("onStatus", true) end)
  o.im.Subscribe("onStats", function() o.im.Publish("onStats", false) end)

  o.im.RegisterAction("act_scrollbtn1", function() o:rowAction(1) end)
  o.im.RegisterAction("act_sort", function() o:sortRows() end)
  o.im.RegisterAction("toStats", function() o:toggleTab("stats") end)
  o.im.RegisterAction("toStatus", function() o:toggleTab("status") end)
  o.im.RegisterAction("act_scrollbtn2", function() o:rowAction(2) end)
  o.im.RegisterAction("act_actions", function() o:showActionsEvent() end)
  o.im.RegisterDataAction("bnd_swipeRow", "act_swipeRow", function(bindingName, actionName, panEvent)
    local swipeY = panEvent.panY  
    o:swipeRow(swipeY * -1) 
  end)

  for i = 1, ROW_COUNT do
    o.im.RegisterAction("act_row"..i, function() o:rowClickEvent(i) end)
  end
  for i = 1, FIELD_COUNT do
    o.im.RegisterAction("act_sort"..i, function() o:sortRowsBy(i) end)
  end
  
  o:setupPanel()

  o:publishLoadingState()

  o.initTimer = Timer:new({
    id = "initTimer",
    interval = 0.2,
    reps = 1,
    onTimerComplete = function()
      o.initialized = true
      o:Init()
      o:updatePlayerState()
      local renderPauseTimer = Timer:new({
        id = "renderPauseTimer",
        interval = 0.1,
        reps = 1,
        onTimerComplete = function()
          local cp = PlayerListData[o.selectedRow]
          local energy = 100
          local sharpness = 100
          local morale_str = "Normal"
          if cp.morale == 1 then
            morale_str = "Very Happy"
          elseif cp.morale == 2 then
            morale_str = "Happy"
          elseif cp.morale == 3 then
            morale_str = "Normal"
          else
            morale_str = "Unhappy"
          end
          o.im.Subscribe("bnd_player_rating", function() o.im.Publish("bnd_player_rating", cp.rating) end)
          o.im.Subscribe("ratinginfocol", function() o.im.Publish("ratinginfocol", formatStat(cp.rating)) end)
          o.im.Subscribe("bnd_player_position", function() o.im.Publish("bnd_player_position", cp.position) end)
          o.im.Subscribe("bnd_player_name", function() o.im.Publish("bnd_player_name", tostring(cp.playerName))end)
          o.im.Subscribe("bnd_player_country", function() o.im.Publish("bnd_player_country", { name = "$Flag128x128", id = cp.nationalityID }) end)
          o.im.Subscribe("ageinfo", function() o.im.Publish("ageinfo", GetPlayerAge(cp.CARD_ID)) end)
          o.im.Subscribe("WHinfo", function() o.im.Publish("WHinfo", formatHeight(GetPlayerData("height", cp.CARD_ID)) .. "/" .. GetPlayerData("weight", cp.CARD_ID) .. " lbs") end)
          o.im.Subscribe("preffootinfo", function() o.im.Publish("preffootinfo", GetPlayerData("prefFoot", cp.CARD_ID) == 1 and "Right" or "Left") end)
          o.im.Subscribe("statusinfo", function() o.im.Publish("statusinfo", (transferredPlayers[cp.CARD_ID] and (transferredPlayers[cp.CARD_ID].isLoan and "Player is currently on loan" or "Joined this season")) or "Has been here for quite awhile") end) 
          o.im.Subscribe("roleinfo", function() o.im.Publish("roleinfo", cp.role) end)
          o.im.Subscribe("forminfo", function() o.im.Publish("forminfo", "Normal") end)
          o.im.Subscribe("availableinfo", function() o.im.Publish("availableinfo", "Match Fit") end)
          o.im.Subscribe("energyinfo", function() o.im.Publish("energyinfo", energy) end)
          o.im.Subscribe("energyinfocol", function() o.im.Publish("energyinfocol", formatStat(energy)) end)
          o.im.Subscribe("sharpnessinfo", function() o.im.Publish("sharpnessinfo", sharpness) end)
          o.im.Subscribe("sharpnessinfocol", function() o.im.Publish("sharpnessinfocol", formatStat(sharpness)) end)
          o.im.Subscribe("moraleinfo", function() o.im.Publish("moraleinfo", morale_str) end)
          o.im.Subscribe("moraleinfocol", function() o.im.Publish("moraleinfocol", formatStat(morale_str)) end)
          o:setupInfoPanel()
          o:publishPending()
          o.isInitialLoad = false
          o.renderPauseTimer = nil
        end
      })
      o.renderPauseTimer = renderPauseTimer
      renderPauseTimer:start()
      o.initTimer = nil
    end
  })
  o.initTimer:start()
  return o
end

function HubRows:toggleTab(tab)
  if tab == self.currentTab then
    return
  end
  
  if tab == "stats" then
    self.im.Publish("onStats", true)
    self.im.Publish("onStatus", false)
  elseif tab == "status" then
    self.im.Publish("onStats", false)
    self.im.Publish("onStatus", true)
  end
  self.currentTab = tab
  self:cacheRowData()
  self:publishPending(tab)
end

function HubRows:setupInfoPanel(mode)
  local cp = PlayerListData[self.selectedRow] -- selected player
  local energy = 100
  local sharpness = 100
  local morale_str = "Normal"
  
  if cp.morale == 1 then
    morale_str = "Very Happy"
  elseif cp.morale == 2 then
    morale_str = "Happy"
  elseif cp.morale == 3 then
    morale_str = "Normal"
  else
    morale_str = "Unhappy"
  end
  
  if mode == "refresh" then
  else
self.im.Publish("bnd_player_rating", cp.rating) 
self.im.Publish("ratinginfocol", formatStat(cp.rating)) 
self.im.Publish("bnd_player_position", cp.position) 
self.im.Publish("bnd_player_name", cp.playerName)
self.im.Publish("bnd_player_country", { name = "$Flag128x128", id = cp.nationalityID }) 
self.im.Publish("ageinfo", GetPlayerAge(cp.CARD_ID)) 
self.im.Publish("WHinfo", formatHeight(GetPlayerData("height", cp.CARD_ID)) .. "/" .. GetPlayerData("weight", cp.CARD_ID) .. " lbs") 
self.im.Publish("preffootinfo", GetPlayerData("prefFoot", cp.CARD_ID) == 1 and "Right" or "Left") 
self.im.Publish("statusinfo", (transferredPlayers[cp.CARD_ID] and (transferredPlayers[cp.CARD_ID].isLoan and "Player is currently on loan" or "Joined this season")) or "Has been here for quite awhile")
self.im.Publish("roleinfo", cp.role) 
self.im.Publish("forminfo", "Normal") 
self.im.Publish("availableinfo", "Match Fit") 
self.im.Publish("energyinfo", energy) 
self.im.Publish("energyinfocol", formatStat(energy)) 
self.im.Publish("sharpnessinfo", sharpness) 
self.im.Publish("sharpnessinfocol", formatStat(sharpness)) 
self.im.Publish("moraleinfo", morale_str) 
self.im.Publish("moraleinfocol", formatStat(morale_str)) 
  end
end
  
function HubRows:publishLoadingState()
  local Publish = self.im.Publish
  local keys = self.publishKeys

  -- Publish blank state for all rows immediately
  for i = 1, ROW_COUNT do
    for j = 1, FIELD_COUNT do
      Publish(keys.rowFields[i][j], "")
    end
    Publish(keys.selected[i], false)
    for j = 1, COLOR_FIELD_COUNT do
      Publish(keys.colors[i][j], "0xFFFFFF")
    end
    Publish(keys.visible[i], false)
    Publish(keys.formOne[i], false)
    Publish(keys.formTwo[i], false)
    Publish(keys.formTwoType[i], 0)
    Publish(keys.formThree[i], false)
    Publish(keys.formThreeType[i], 0)
    Publish(keys.moraleOne[i], false)
    Publish(keys.moraleTwo[i], false)
    Publish(keys.moraleThree[i], false)
    Publish(keys.moraleFour[i], false)
  end

  -- Hide cursor and panel during loading
  Publish(keys.cursorVisible, false)
  Publish(keys.panelOpened, false)
end

function HubRows:Init()
    local lineup = Squads.getCachedTeamPlayers(self.teamID)
    local n = #lineup
    self.totalPlayers = n
    PlayerListData = {}
    local math_random = math.random
    for i = 1, n do
        local _form = math_random(15)
        local form = _form < 6 and 1 or _form > 10 and 2 or 3
        local _formtype = math_random(15)
        local formtype = _formtype < 6 and 1 or _formtype > 10 and 2 or 3
        local _morale = math_random(20)
        local morale = 1
        if _morale > 15 then
            morale = 4
        elseif _morale < 6 then
            morale = 1
        elseif _morale < 16 and _morale > 9 then
            morale = 3
        else
            morale = 2
        end
        PlayerListData[i] = {
            position = lineup[i].position or "EM",
            CARD_ID = lineup[i].CARD_ID,
            playerName = lineup[i].playerName or "No name",
            rating = lineup[i].rating or 100,
            nationalityID = lineup[i].nationalityID,
            role = playerRolesTable[math_random(#playerRolesTable)] or "Normal", -- Assign role from playerRolesTable
            form = {form = form, type = formtype},
            morale = morale
        }
    end

    -- Sort by position on initialization
    table.sort(PlayerListData, function(a, b)
        local posA = positionIndex[a.position] or 999
        local posB = positionIndex[b.position] or 999
        return posA < posB
    end)

    self:cacheRowData()
    self:cacheCursorData()
    self:calculateCursorMarginTop()
    -- targetMarginTop is now set directly in calculateCursorMarginTop, no need for redundant assignment here
end

function HubRows:swipeRow(Y)
  if not self.actionsViewActive then
    local math_floor = math.floor
    local jump = Y > 0 and 30 or -30
    local maxStart = (self.totalPlayers - ROW_COUNT) * 60
    self.swipeY = self.swipeY + Y + jump
    self.swipeY = self.swipeY < 1 and 0 or (self.swipeY > maxStart and maxStart or self.swipeY)
    local swipeIdx = (math_floor((self.swipeY/60)) + 1) or 1
    self.startIndex = swipeIdx
    self:cacheRowData()
    self:cacheCursorData()
    self:calculateCursorMarginTop()
    self:animateCursor()
    self:updatePlayerState()
  end
end

function HubRows:setupPanel()
  for i = 1, 7 do 
    self.im.RegisterAction("action"..i, function() self:panelBtnAction(i) end)
  end
  for i = 1, 7 do
    self.im.Subscribe("btntextcolor" ..i, function() self.im.Publish("btntextcolor" ..i, i ~= self.selectedPanelBtn and "0xFFFFFF" or "0x000000") end)
  end
  for i = 1, 7 do
    self.im.Subscribe("btntext" ..i, function() self:setupPanelBtns(i) end)
  end
  
  local X, Y = self.selectedBtnConfig(self.selectedPanelBtn)
  self.im.Subscribe("selectedbtnX", function() self.im.Publish("selectedbtnX", X) end)
  self.im.Subscribe("selectedbtnY", function() self.im.Publish("selectedbtnY", Y) end)
end

function HubRows:setupPanelBtns(id)
  local transferListed = sessionVars.get("transferListed") or {}
  local notListed = sessionVars.get("notListed") or {}
  local loanListed = sessionVars.get("loanListed") or {}
  
  if id == 1 then
    self.im.Publish("btntext" ..id, transferListed[self.selectedPlayer.CARD_ID] and "Remove from Transfer List" or "Add to Transfer List")
  elseif id == 2 then
    self.im.Publish("btntext" ..id, loanListed[self.selectedPlayer.CARD_ID] and "Remove from Loan List" or "Add to Loan List")
  elseif id == 3 then
    self.im.Publish("btntext" ..id, transferOffers[self.selectedPlayer.CARD_ID] and "View Offer(s)" or (notListed[self.selectedPlayer.CARD_ID] and "Unblock Offers" or "Block Offers"))
  elseif id == 4 then
    self.im.Publish("btntext" ..id, "Team Sheets")
  elseif id == 5 then
    self.im.Publish("btntext" ..id, "Team Management")
  elseif id == 6 then
    self.im.Publish("btntext" ..id, "Release")
  end
end

function HubRows:displayConfirmationMsg(message, evt, callbck, error)
  local buttonData = error and {"Back"} or {"Yes", "No"}
  self.FCPopup:getResponse(message, buttonData, function(clickResponse)
    if clickResponse == 1 then
      if callbck then
        callbck()
        return
      end
      if error then
      else
        self.nav.Event(nil, evt)
      end
    end
  end)
end

function HubRows.selectedBtnConfig(btnId)
  local X = {40, 210, 385}
  local Y = {15, 50, 85}
  if btnId <= 3 then
    return X[1], Y[btnId]
  elseif btnId > 3 and btnId <= 5 then
    return X[2], Y[btnId - 3]
  elseif btnId > 5 and btnId <= 7 then
    return X[3], Y[btnId - 5]
  end
  
  return X[1], Y[1]
end

function HubRows:panelBtnAction(btnId)
  local transferListed = sessionVars.get("transferListed") or {}
  local notListed = sessionVars.get("notListed") or {}
  local loanListed = sessionVars.get("loanListed") or {}
  if btnId == self.selectedPanelBtn then
    if btnId == 1 then
      if transferListed[self.selectedPlayer.CARD_ID] then
        transferListed[self.selectedPlayer.CARD_ID] = nil
        sessionVars.set("transferListed", transferListed)
      else
        transferListed[self.selectedPlayer.CARD_ID] = true
        sessionVars.set("transferListed", transferListed)
      end
    elseif btnId == 2 then
      if loanListed[self.selectedPlayer.CARD_ID] then
        loanListed[self.selectedPlayer.CARD_ID] = nil
        sessionVars.set("loanListed", loanListed)
      else
        loanListed[self.selectedPlayer.CARD_ID] = true
        sessionVars.set("loanListed", loanListed)
      end      
    elseif btnId == 3 then
      if not transferOffers[self.selectedPlayer.CARD_ID] then
        if notListed[self.selectedPlayer.CARD_ID] then
          notListed[self.selectedPlayer.CARD_ID] = nil
          sessionVars.set("notListed", notListed)
        else
          notListed[self.selectedPlayer.CARD_ID] = true
          sessionVars.set("notListed", notListed)
        end
      else
        currentHubTab = "receivedOffers" -- used in TransferHub script to get initial tab and cleared after use
        self.nav.Event(nil, "evt_transferhub")
      end
    elseif btnId == 4 then
      
    elseif btnId == 5 then
      sessionVars.set("hubId", self.selectedPlayer.CARD_ID)
      self.nav.Event(nil, "evt_squad")
    elseif btnId == 6 then
      local msg = ""
      if #PlayerListData <= 25 then
        msg = "Action cannot be completed due to size of squad."
        self:displayConfirmationMsg(msg, nil, nil, true)
      else
        msg = "Are you sure you want to release " .. self.selectedPlayer.playerName .. " , The action cannot be undone once completed."
        self:displayConfirmationMsg(msg, nil, function()
          releasePlayer(self.selectedPlayer.CARD_ID, self.teamID)
          self.actionsViewActive = false
          self.panelData[2] = false
          table.remove(PlayerListData, self.selectedRow)
          self.totalPlayers = #PlayerListData
          if self.selectedRow > self.totalPlayers then
            self.selectedRow = math.max(1, self.totalPlayers)
          end
          local maxStart = math.max(1, self.totalPlayers - ROW_COUNT + 1)
          if self.startIndex > maxStart then
            self.startIndex = maxStart
          end
          self:cacheRowData()
          self:cacheCursorData()
          self:calculateCursorMarginTop()
          self:animateCursor()
          self:updatePlayerState()
          self:setupInfoPanel()
          self:publishPending()
        end)
      end
    end
    self:setupPanelBtns(btnId)
  return
  end
    
  self.selectedPanelBtn = btnId
  local X, Y = self.selectedBtnConfig(self.selectedPanelBtn)
  for i = 1, 7 do
    self.im.Publish("btntextcolor" ..i, i ~= btnId and "0xFFFFFF" or "0x000000")
  end
  self.im.Publish("selectedbtnX", X)
  self.im.Publish("selectedbtnY", Y)
end

function HubRows:updatePlayerState()
  self.selectedPlayer = PlayerListData[self.selectedRow]
end

function HubRows:sortRowsBy(idx)
    self.sortField = idx
    self:sortRows()
end

function HubRows:sortRows()
    local rowField = {"position", "name", "ovr", "role", "form", "morale"}
    local field = rowField[self.sortField]
    local isDescending = self.sortDirection == "desc"

    -- Toggle sort direction if same field
    if self.lastSortField == field then
        self.sortDirection = isDescending and "asc" or "desc"
    else
        self.sortDirection = "desc" -- Default to descending on first click
        self.lastSortField = field
    end

    table.sort(PlayerListData, function(a, b)
        local valA, valB

        if field == "position" then
            valA = positionIndex[a.position] or 999
            valB = positionIndex[b.position] or 999
        elseif field == "name" then
            valA = a.playerName:lower()
            valB = b.playerName:lower()
        elseif field == "ovr" then
            valA = tonumber(a.rating) or 0
            valB = tonumber(b.rating) or 0
        elseif field == "role" then -- can be goal of the currentTab is stats
            valA = self.currentTab == "status" and (indexOf(playerRolesTable, a.role) or 999) or (leagueGoals[a.CARD_ID] or 0)
            valB = self.currentTab == "status" and (indexOf(playerRolesTable, b.role) or 999) or (leagueGoals[b.CARD_ID] or 0)
        elseif field == "form" then
            valA = tonumber(a.form.form)
            valB = tonumber(b.form.form)
            -- Secondary sort by form type if form values are equal
            if valA == valB then
                valA = tonumber(a.form.type)
                valB = tonumber(b.form.type)
            end
        elseif field == "morale" then
            valA = tonumber(a.morale)
            valB = tonumber(b.morale)
        end

        if self.sortDirection == "asc" then
            return valA < valB
        else
            return valA > valB
        end
    end)

    self:cacheRowData()
    self:cacheCursorData()
    self:calculateCursorMarginTop()
    self:animateCursor()
    self:updatePlayerState()
    self:publishPending()
end

function HubRows:cacheRowData() 
  if self.actionsViewActive then
    local relativeRowIdx = self.selectedRow - self.startIndex + 1
    local clearRow1, clearRow2, clearRow3

    if self.selectedRow >= self.totalPlayers - 2 then
      clearRow1 = ROW_COUNT - 2
      clearRow2 = ROW_COUNT - 1
      clearRow3 = ROW_COUNT
    else
      clearRow1 = relativeRowIdx + 1
      clearRow2 = relativeRowIdx + 2
      clearRow3 = relativeRowIdx + 3
    end

    local playerOffset = 0
    for i = 1, ROW_COUNT do
      local row = self.rowData[i]
      if i == clearRow1 or i == clearRow2 or i == clearRow3 then
        row[1] = ""
        row[2].id = nil
        row[3] = ""
        row[4] = ""
        row[5] = ""
        row[6] = {} -- form1 is normal form2 is either good or bad based on type 1- is up, 2 - down, form 3 is either above satisfied, below satisfied 1 and 2 respectively 
        row[7] = 0
        playerOffset = playerOffset + 1
      else
        local idx = self.startIndex + i - 1 - playerOffset
        if idx <= self.totalPlayers and idx >= 1 then
          local p = PlayerListData[idx]
          row[1] = p.position
          row[2].id = p.CARD_ID
          row[3] = p.playerName
          row[4] = self.currentTab == "status" and p.rating or 0
          row[5] = self.currentTab == "status" and p.role or (leagueGoals[p.CARD_ID] or 0)
          row[6] = p.form
          row[7] = p.morale
        else
          row[1] = ""
          row[2].id = nil
          row[3] = ""
          row[4] = ""
          row[5] = ""
          row[6] = {} -- form1 is normal form2 is either good or bad based on type 1- is up, 2 - down
          row[7] = 0
        end
      end
    end
  else
    for i = 1, ROW_COUNT do
      local idx = self.startIndex + i - 1
      local row = self.rowData[i]
      if idx <= self.totalPlayers and idx >= 1 then
        local p = PlayerListData[idx]
        row[1] = p.position
        row[2].id = p.CARD_ID
        row[3] = p.playerName
        row[4] = self.currentTab == "status" and p.rating or 0
        row[5] = self.currentTab == "status" and p.role or (leagueGoals[p.CARD_ID] or 0)
        row[6] = p.form
        row[7] = p.morale
      else
        row[1] = ""
        row[2].id = nil
        row[3] = ""
        row[4] = ""
        row[5] = ""
        row[6] = {} -- form1 is normal form2 is either good or bad based on type 1- is up, 2 - down
        row[7] = 0
      end
    end
  end
end

function HubRows:cacheCursorData()
  for i = 1, ROW_COUNT do
    self.cursorData[i] = i == self.selectedRow - self.startIndex + 1
  end
end

function HubRows:calculateCursorMarginTop()
  if self.totalPlayers <= 1 then
    self.targetMarginTop = 0
    return
  end
  local math_max = math.max
  local maxMarginTop = 370
  local maxStart = math_max(1, self.totalPlayers - ROW_COUNT + 1)
  self.targetMarginTop = maxMarginTop * (self.startIndex - 1) / (maxStart - 1)
end

function HubRows:rowClickEvent(rowIdx)
  if rowIdx < 1 or rowIdx > ROW_COUNT then
    return
  end

  local newSelectedRow = self.startIndex + rowIdx - 1
  if newSelectedRow > self.totalPlayers or newSelectedRow < 1 then
    return
  end

  if self.actionsViewActive then
    if newSelectedRow == self.selectedRow then
      self:showActionsEvent()
    end
    return
  end

  if newSelectedRow == self.selectedRow then
    self:showActionsEvent()
    for i = 1, ACTIONS_BTN_COUNT do -- refreshes btn displays for each new clicked player
      self:setupPanelBtns(i)
    end
    return
  end

  local oldStart = self.startIndex
  self.selectedRow = newSelectedRow

  local viewLastRow = self.startIndex + ROW_COUNT - 1
  if self.selectedRow < self.startIndex then
    self.startIndex = self.selectedRow
  elseif self.selectedRow > viewLastRow then
    self.startIndex = self.selectedRow - ROW_COUNT + 1
  end

  local maxStart = self.totalPlayers - ROW_COUNT + 1
  maxStart = maxStart < 1 and 1 or maxStart
  if self.startIndex < 1 then
    self.startIndex = 1
  elseif self.startIndex > maxStart then
    self.startIndex = maxStart
  end

  if oldStart ~= self.startIndex then
    self:cacheRowData()
  end
  self:cacheCursorData()
  self:calculateCursorMarginTop()
  self:animateCursor()
  self:updatePlayerState()
  self:setupInfoPanel()
end

function HubRows:showActionsEvent()
  self.actionsViewActive = not self.actionsViewActive
  local relativeRowIdx = self.selectedRow - self.startIndex + 1

  if self.actionsViewActive then
    local math_max = math.max
    if self.selectedRow >= self.totalPlayers - 2 then
      self.startIndex = math_max(1, self.selectedRow - 5)
    elseif relativeRowIdx > ROW_COUNT - 3 then
      self.startIndex = self.selectedRow - (ROW_COUNT - 4)
    end
    relativeRowIdx = self.selectedRow - self.startIndex + 1
    self.panelData[1] = panelPositions[relativeRowIdx]
    self.panelData[2] = true
  else
    local viewLastRow = self.startIndex + ROW_COUNT - 1
    if self.selectedRow < self.startIndex then
      self.startIndex = self.selectedRow
    elseif self.selectedRow > viewLastRow then
      self.startIndex = self.selectedRow - ROW_COUNT + 1
    end
    local maxStart = self.totalPlayers - ROW_COUNT + 1
    maxStart = maxStart < 1 and 1 or maxStart
    if self.startIndex < 1 then
      self.startIndex = 1
    elseif self.startIndex > maxStart then
      self.startIndex = maxStart
    end
    self.panelData[2] = false
  end

  self:cacheRowData()
  self:cacheCursorData()
  self:calculateCursorMarginTop()
  self:animateCursor()
  self:updatePlayerState()
end

function HubRows:rowAction(btn)
  local oldStart = self.startIndex
  local maxStart = self.totalPlayers - ROW_COUNT + 1
  maxStart = maxStart < 1 and 1 or maxStart

  if btn == 2 then -- Scroll down
    if self.selectedRow < self.totalPlayers then
      self.selectedRow = self.selectedRow + 1
      local viewLastRow = self.startIndex + ROW_COUNT - 1
      local math_max = math.max
      if self.actionsViewActive then
        if self.selectedRow >= self.totalPlayers - 2 then
          self.startIndex = math_max(1, self.selectedRow - 5)
        elseif self.selectedRow - self.startIndex + 1 > ROW_COUNT - 3 then
          self.startIndex = self.selectedRow - (ROW_COUNT - 4)
        end
      elseif self.selectedRow == viewLastRow and self.selectedRow < self.totalPlayers then
        self:cacheCursorData()
        self:calculateCursorMarginTop()
        self:animateCursor()
        if self.bounceTimer then
          self.bounceTimer:finalize()
          self.bounceTimer = nil
        end
        self.bounceTimer = Timer:new({
          id = "bounceTimer",
          interval = 0.08,
          reps = 1,
          onTimerComplete = function()
            self.startIndex = self.startIndex + 1
            self.selectedRow = self.startIndex + ROW_COUNT - 2
            self:cacheRowData()
            self:cacheCursorData()
            self:calculateCursorMarginTop()
            self:animateCursor()
            self.bounceTimer = nil
          end
        })
        self.bounceTimer:start()
        return
      elseif self.selectedRow > viewLastRow and self.startIndex < maxStart then
        self.startIndex = self.startIndex + 1
      end
    end
  else -- Scroll up
    if self.selectedRow > 1 then
      self.selectedRow = self.selectedRow - 1
      local math_max = math.max
      if self.actionsViewActive and self.selectedRow >= self.totalPlayers - 2 then
        self.startIndex = math_max(1, self.selectedRow - 5)
      elseif self.selectedRow < self.startIndex and self.startIndex > 1 then
        self.startIndex = self.startIndex - 1
      end
    end
  end

  local needsUpdate = oldStart ~= self.startIndex
  if needsUpdate then
    self:cacheRowData()
  end
  self:cacheCursorData()
  self:calculateCursorMarginTop()
  self:animateCursor()
  self:updatePlayerState()
end

function HubRows:formatForm(tbl, target)
  if target == "form" then
    if tbl.form == 1 then 
      return true
    else
      return false
    end
  elseif target == "formtype" then
    if tbl.type == 1 then
      return 0
    elseif tbl.type == 2 then
      return 100
    else
      return 0
    end
  end
  return 0
end

function HubRows:publishPending(type)
  local Publish = self.im.Publish
  local keys = self.publishKeys
  
  if not self.initialized then
    return
  end
  
  Publish("isRowEmpty", (self.totalPlayers == 0 or not self.totalPlayers))

  -- Publish non-row elements first for immediate display
  Publish(keys.cursorHeight, self.cursorHeight)
  Publish(keys.cursorMarginTop, self.cursorMarginTop)
  Publish(keys.cursorVisible, not self.actionsViewActive)
  Publish(keys.panelPosition, self.panelData[1])
  Publish(keys.panelOpened, self.panelData[2])

  -- Calculate clear rows once if needed
  local clearRow1, clearRow2, clearRow3
  if self.actionsViewActive then
    local relativeRowIdx = self.selectedRow - self.startIndex + 1
    if self.selectedRow >= self.totalPlayers - 2 then
      clearRow1 = ROW_COUNT - 2
      clearRow2 = ROW_COUNT - 1
      clearRow3 = ROW_COUNT
    else
      clearRow1 = relativeRowIdx + 1
      clearRow2 = relativeRowIdx + 2
      clearRow3 = relativeRowIdx + 3
    end
  end

  -- Stop any existing row publish timer
  if self.rowPublishTimer then
    self.rowPublishTimer:finalize()
    self.rowPublishTimer = nil
  end

  -- Function to publish a single row's data (now includes visibility check)
  local function publishSingleRow(i)
    local row = self.rowData[i]
    for j = 1, FIELD_COUNT do
      local value = row[j]
      Publish(keys.rowFields[i][j], value)
    end
    if row[6] and row[6].form then
      local formType = self:formatForm(row[6], "formtype")
      Publish(keys.formOne[i], row[6].form == 1)
      Publish(keys.formTwo[i], row[6].form == 2)
      Publish(keys.formTwoType[i], formType)
      Publish(keys.formThree[i], row[6].form == 3)
      Publish(keys.formThreeType[i], formType)
    else
      Publish(keys.formOne[i], false)
      Publish(keys.formTwo[i], false)
      Publish(keys.formTwoType[i], 0)
      Publish(keys.formThree[i], false)
      Publish(keys.formThreeType[i], 0)
    end
    if row[7] > 0 then
      Publish(keys.moraleOne[i], row[7] == 1)
      Publish(keys.moraleTwo[i], row[7] == 2)
      Publish(keys.moraleThree[i], row[7] == 3)
      Publish(keys.moraleFour[i], row[7] == 4)
    else
      Publish(keys.moraleOne[i], false)
      Publish(keys.moraleTwo[i], false)
      Publish(keys.moraleThree[i], false)
      Publish(keys.moraleFour[i], false)
    end
    Publish(keys.selected[i], self.cursorData[i])
    for j = 1, COLOR_FIELD_COUNT do
      local color
      if colorField[j] == "ovr" and row[4] ~= "" then
        local rating = tonumber(row[4]) or 0
        if rating < 70 then
          color = "0xFFFF00" -- Yellow
        elseif rating <= 79 then
          color = "0x006400" -- Dark green
        else
          color = "0x00FF00" -- Bright green
        end
      else
        color = "0xFFFFFF" -- White
      end
      Publish(keys.colors[i][j], self.currentTab == "status" and color or "0xFFFFFF")
    end
    local isVisible = not self.actionsViewActive or (i ~= clearRow1 and i ~= clearRow2 and i ~= clearRow3)
    Publish(keys.visible[i], isVisible)
  end

  local interval = 0.02  -- Small delay between rows (adjust as needed)

  if self.isInitialLoad then
    -- Publish first row immediately
    publishSingleRow(1)
    -- Then stagger the remaining rows
    local currentRow = 2
    local function publishRowStep()
      if currentRow > ROW_COUNT then
        self.rowPublishTimer = nil
        return
      end
      publishSingleRow(currentRow)
      currentRow = currentRow + 1
      if currentRow <= ROW_COUNT then
        self.rowPublishTimer = Timer:new({
          id = "rowPublish_" .. currentRow,
          interval = interval,
          reps = 1,
          onTimerComplete = function()
            self.rowPublishTimer = nil
            publishRowStep()
          end
        })
        self.rowPublishTimer:start()
      end
    end
    if currentRow <= ROW_COUNT then
      publishRowStep()
    end
  else
    -- Immediate publishing for all rows
    for i = 1, ROW_COUNT do
      publishSingleRow(i)
    end
  end
end

function HubRows:animateCursor()
  if self.cursorTimer then
    self.cursorTimer:finalize()
    self.cursorTimer = nil
  end

  local math_abs = math.abs
  local math_floor = math.floor
  local startMarginTop = self.cursorMarginTop
  local endMarginTop = self.targetMarginTop
  local duration = 0.1
  local stepInterval = 0.025
  local steps = math_floor(duration / stepInterval)
  local stepSize = (endMarginTop - startMarginTop) / steps

  local function animateStep(step)
    if step > steps then
      self.cursorMarginTop = endMarginTop
      self:publishPending()
      self.cursorTimer = nil
      return
    end

    self.cursorMarginTop = startMarginTop + stepSize * step
    self:publishPending()

    self.cursorTimer = Timer:new({
      id = "cursorTimer_"..step,
      interval = stepInterval,
      reps = 1,
      onTimerComplete = function()
        self.cursorTimer = nil
        animateStep(step + 1)
      end
    })
    self.cursorTimer:start()
  end

  if math_abs(endMarginTop - startMarginTop) > 0.01 then
    animateStep(1)
  else
    self.cursorMarginTop = endMarginTop
    self:publishPending()
  end
end

function HubRows:update(elapsedTime)
  if self.initTimer then
    self.initTimer:update(elapsedTime)
  end
  if self.cursorTimer then
    self.cursorTimer:update(elapsedTime)
  end
  if self.rowPublishTimer then
    self.rowPublishTimer:update(elapsedTime)
  end
  if self.bounceTimer then
    self.bounceTimer:update(elapsedTime)
  end
  if self.renderPauseTimer then
    self.renderPauseTimer:update(elapsedTime)
  end
end

function HubRows:finalize()
  if self.initTimer then
    self.initTimer:finalize()
    self.initTimer = nil
  end
  if self.cursorTimer then
    self.cursorTimer:finalize()
    self.cursorTimer = nil
  end
  if self.rowPublishTimer then
    self.rowPublishTimer:finalize()
    self.rowPublishTimer = nil
  end
  if self.bounceTimer then
    self.bounceTimer:finalize()
    self.bounceTimer = nil
  end
  if self.renderPauseTimer then
    self.renderPauseTimer:finalize()
    self.renderPauseTimer = nil
  end
  local Unsubscribe = self.im.Unsubscribe
  for i = 1, ROW_COUNT do
    for j = 1, FIELD_COUNT do
      Unsubscribe("bnd_row"..rowField[j]..i)
    end
    Unsubscribe("bnd_rowselected"..i)
    for j = 1, COLOR_FIELD_COUNT do
      Unsubscribe("bnd_"..colorField[j].."color"..i)
    end
    Unsubscribe("bnd_rowvisible"..i)
    Unsubscribe("formOne"..i)
    Unsubscribe("formTwo"..i)
    Unsubscribe("formTwoType"..i)
    Unsubscribe("formThree"..i)
    Unsubscribe("formThreeType"..i)
    Unsubscribe("moraleOne"..i)
    Unsubscribe("moraleTwo"..i)
    Unsubscribe("moraleThree"..i)
    Unsubscribe("moraleFour"..i)
  end
  Unsubscribe("bnd_rowcursor_height")
  Unsubscribe("bnd_rowcursor_marginTop")
  Unsubscribe("bnd_rowcursorvisible")
  for i = 1, 2 do
    Unsubscribe("bnd_panel"..panelAttributes[i])
  end
  Unsubscribe("act_scrollbtn1")
  Unsubscribe("act_scrollbtn2")
  Unsubscribe("act_actions")
  for i = 1, ROW_COUNT do
    Unsubscribe("act_row"..i)
  end
end

return HubRows
local SelectionModel = {}

-- ── Constructor ───────────────────────────────────────────────────────────────

function SelectionModel:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.Config                  = init.Config
  o.highlightedPlayerIndex  = init.highlightedPlayerIndex
  o.selectedPlayers         = {}
  o.highlightedPlayer       = nil

  -- Derive initial highlighted player from index
  if o.Config and o.Config.PLAYER_RANGES and o.highlightedPlayerIndex then
    local startCount = o.Config.PLAYER_RANGES.starting.count
    if o.highlightedPlayerIndex <= startCount then
      o.highlightedPlayer = {
        index = o.highlightedPlayerIndex,
        type  = "starting",
        sheetIndex = o.highlightedPlayerIndex,
      }
    else
      local subIdx = o.highlightedPlayerIndex - startCount
      o.highlightedPlayer = {
        index      = subIdx,
        type       = "subres",
        sheetIndex = o.Config.PLAYER_RANGES.subres.start + subIdx - 1,
      }
    end
  elseif o.Config and o.Config.PLAYER_RANGES and o.Config.PLAYER_RANGES.subres then
    o.highlightedPlayer = {
      index = 1, type = "subres",
      sheetIndex = o.Config.PLAYER_RANGES.subres.start,
    }
  end
  return o
end

-- ── Default highlighted state builder ────────────────────────────────────────

function SelectionModel:_defaultHighlight()
  local cfg = self.Config
  if not cfg or not cfg.PLAYER_RANGES then return nil end
  local idx = self.highlightedPlayerIndex
  if idx then
    local startCount = cfg.PLAYER_RANGES.starting.count
    if idx <= startCount then
      return { index = idx, type = "starting", sheetIndex = idx }
    end
    local subIdx = idx - startCount
    return { index = subIdx, type = "subres",
             sheetIndex = cfg.PLAYER_RANGES.subres.start + subIdx - 1 }
  end
  if cfg.PLAYER_RANGES.subres then
    return { index = 1, type = "subres", sheetIndex = cfg.PLAYER_RANGES.subres.start }
  end
  return nil
end

-- ── Select / highlight logic ──────────────────────────────────────────────────

function SelectionModel:selectPlayer(playerIndex, ptype, sheetIndex)
  local sel = self.selectedPlayers

  -- Tap on already-selected → deselect, restore highlight
  for i = 1, #sel do
    if sel[i].sheetIndex == sheetIndex then
      local desel = sel[i]
      table.remove(sel, i)
      self.highlightedPlayer = {
        index = desel.index, type = desel.type, sheetIndex = desel.sheetIndex
      }
      return false
    end
  end

  local highlighted = self.highlightedPlayer
  if highlighted and highlighted.sheetIndex == sheetIndex then
    -- Confirm highlighted → move to selected
    if #sel >= 2 then table.remove(sel, 1) end
    sel[#sel + 1] = { index = playerIndex, type = ptype, sheetIndex = sheetIndex }
    self.highlightedPlayer = nil
  else
    -- New tap: just highlight
    if #sel == 0 then
      self.highlightedPlayer = { index = playerIndex, type = ptype, sheetIndex = sheetIndex }
    elseif #sel == 1 and not self:isPlayerSelected(sheetIndex) then
      self.highlightedPlayer = { index = playerIndex, type = ptype, sheetIndex = sheetIndex }
    end
  end

  return #sel == 2
end

-- ── Queries ───────────────────────────────────────────────────────────────────

function SelectionModel:getSelectedPlayers()
  return self.selectedPlayers[1], self.selectedPlayers[2]
end

function SelectionModel:getHighlightedPlayer()
  return self.highlightedPlayer
end

function SelectionModel:isPlayerSelected(sheetIndex)
  local sel = self.selectedPlayers
  for i = 1, #sel do
    if sel[i].sheetIndex == sheetIndex then return true end
  end
  return false
end

function SelectionModel:isPlayerHighlighted(sheetIndex)
  if self:isPlayerSelected(sheetIndex) then return true end
  local h = self.highlightedPlayer
  return h and h.sheetIndex == sheetIndex or false
end

-- ── Clear ─────────────────────────────────────────────────────────────────────

function SelectionModel:clearSelections()
  local last = self.selectedPlayers[2]
  self.selectedPlayers = {}
  if last then
    self.highlightedPlayer = {
      index = last.index, type = last.type, sheetIndex = last.sheetIndex
    }
  else
    self.highlightedPlayer = self:_defaultHighlight()
  end
end

-- ── Teardown ──────────────────────────────────────────────────────────────────

function SelectionModel:finalize()
  self.selectedPlayers   = nil
  self.highlightedPlayer = nil
end

return SelectionModel

local SquadModel = {}

-- ── Module upvalues (avoids global lookups on every call) ─────────────────────
local math_floor = math.floor
local math_ceil  = math.ceil
local math_max   = math.max

-- Per-module-instance live state (one squad screen active at a time)
local sheetPlayers = {}

-- ── Constructor ───────────────────────────────────────────────────────────────

function SquadModel:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index  = self
  o.Config      = init.Config
  o.Squads      = init.Squads
  o.playerById  = {}
  o.scrollOffset    = init.scrollOffset or 0
  o.numSets         = 2
  o.maxScrollOffset = 1
  o.lastHash        = nil

  -- Seed sheetPlayers from cached team
  local cached = o.Squads.getCachedTeamPlayers(currentSelectedTeamID)
  sheetPlayers = {}
  for i = 1, #cached do
    sheetPlayers[i] = cached[i].CARD_ID
  end
  return o
end

-- ── Change-detection hash ─────────────────────────────────────────────────────

local function computeHash(players)
  local h, n = 0, #players
  for i = 1, n do h = h + (players[i] or 0) * i end
  return h
end

-- ── Sync: reconcile local sheet with live roster (no service write-back) ──────
-- Replaces TeamManagementModel.loadSheets() logic.
-- Adds newly-signed players, removes transferred-out players from the local
-- sheet order without ever calling SetCurrentPlayerLineup — so no in-session
-- swap state is clobbered by an external event.

function SquadModel:syncWithLiveLineup(teamID, sheetPlayers)
  local live = self.Squads.getCachedTeamPlayers(teamID)
  if not live or #live == 0 then return end

  -- Build O(1) lookup of live roster
  local liveSet, liveN = {}, #live
  for i = 1, liveN do
    local p = live[i]
    if p and p.CARD_ID then liveSet[p.CARD_ID] = true end
  end

  -- Retain ordering: keep only players still in the live roster
  local kept, keptN = {}, 0
  for i = 1, #sheetPlayers do
    local cid = sheetPlayers[i]
    if cid and liveSet[cid] then
      keptN = keptN + 1
      kept[keptN] = cid
    end
  end

  -- Append any live players missing from the sheet (e.g. new signing)
  local keptSet = {}
  for i = 1, keptN do keptSet[kept[i]] = true end
  for i = 1, liveN do
    local p = live[i]
    if p and p.CARD_ID and not keptSet[p.CARD_ID] then
      keptN = keptN + 1
      kept[keptN] = p.CARD_ID
    end
  end
  
  
  self.lastHash = nil  -- invalidate cache so updateSquadData() rebuilds
  return kept
end

-- ── Rebuild playerById lookup; called after any roster/formation change ────────

function SquadModel:updateSquadData()
  if not sheetPlayers then return false end
  local h = computeHash(sheetPlayers)
  if self.lastHash == h then return false end
  self.lastHash = h

  -- Index ALL cached players so subs beyond visible window are still found
  local cached  = self.Squads.getCachedTeamPlayers(currentSelectedTeamID)
  local byId    = {}
  for i = 1, #cached do
    local p = cached[i]
    if p and p.CARD_ID then byId[p.CARD_ID] = p end
  end
  self.playerById = byId

  local startCount     = self.Config.PLAYER_RANGES.starting.count
  local totalSubs      = #sheetPlayers - startCount
  self.numSets         = math_max(1, math_ceil(totalSubs / 4))
  -- +2 extra scroll slots for the expanded panel rows
  self.maxScrollOffset = math_max(0, math_ceil(totalSubs / 4) - 4 + 2)
  if self.scrollOffset > self.maxScrollOffset then
    self.scrollOffset = self.maxScrollOffset
  end
  return true
end

-- ── Mutation ──────────────────────────────────────────────────────────────────

function SquadModel:setPlayers(players)
  if not players then return end
  sheetPlayers  = {}
  for i = 1, #players do sheetPlayers[i] = players[i] end
  self.lastHash     = nil
  self.scrollOffset = 0
end

function SquadModel:swapPlayers(idx1, idx2)
  local n = #sheetPlayers
  if idx1 >= 1 and idx2 >= 1 and idx1 <= n and idx2 <= n then
    sheetPlayers[idx1], sheetPlayers[idx2] = sheetPlayers[idx2], sheetPlayers[idx1]
  end
end

-- ── Scroll ────────────────────────────────────────────────────────────────────

function SquadModel:scrollSubPanel(btn)
  local off = self.scrollOffset
  if btn == 2 and off < self.maxScrollOffset then
    self.scrollOffset = off + 1; return true
  elseif btn == 1 and off > 0 then
    self.scrollOffset = off - 1; return true
  end
  return false
end

function SquadModel:setOffset(v) self.scrollOffset = v end

-- ── Index resolution ──────────────────────────────────────────────────────────

function SquadModel:getSheetIndex(playerIndex, ptype)
  if not sheetPlayers then return nil end
  local range = self.Config.PLAYER_RANGES[ptype]
  if not range then return nil end
  if ptype == "starting" then
    if playerIndex <= range.count then return playerIndex end
  else  -- subres
    if playerIndex <= 16 then
      local effOff   = self.scrollOffset > 2 and self.scrollOffset - 2 or 0
      local rowIdx   = math_floor((playerIndex - 1) / 4) * 4
      local sheetIdx = range.start + effOff * 4 + (playerIndex - 1 - rowIdx) + rowIdx
      if sheetIdx <= #sheetPlayers then return sheetIdx end
    end
  end
  return nil
end

-- ── Accessors ─────────────────────────────────────────────────────────────────

function SquadModel:getPlayers()            return sheetPlayers             end
function SquadModel:getPlayerById(id)       return self.playerById[id]      end
function SquadModel:getScrollOffset()       return self.scrollOffset        end
function SquadModel:getMaxScrollOffset()    return self.maxScrollOffset     end
function SquadModel:getNumSets()            return self.numSets             end

function SquadModel:getPlayerBySheetIndex(idx)
  if not sheetPlayers or idx < 1 or idx > #sheetPlayers then return nil end
  return self.playerById[sheetPlayers[idx]]
end

-- ── Teardown ──────────────────────────────────────────────────────────────────

function SquadModel:finalize()
  self.playerById = nil
  sheetPlayers    = {}
end

return SquadModel

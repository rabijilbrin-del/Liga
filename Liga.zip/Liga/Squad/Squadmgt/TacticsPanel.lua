local TacticsPanel = {}

function TacticsPanel:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index        = self
  o.uiModel           = init.uiModel
  o.config            = init.Config
  o.im                = init.im
  o.currentFormationIdx = 1
  o.formation         = init.getFormation
  o.setFormation      = init.setFormation
  return o
end

function TacticsPanel:displayFormation()
  self.im.Publish("bnd_formationname", self.config.FORMATION_INFO[self.formation()])
end

function TacticsPanel:getFormationIdx()
  local formations = self.config.FORMATION_IDS
  local current    = self.formation()
  for i = 1, #formations do
    if formations[i] == current then return i end
  end
  return 1
end

function TacticsPanel:toggleFormation(btnId)
  local formations = self.config.FORMATION_IDS
  local maxIdx     = #formations
  self.currentFormationIdx = self:getFormationIdx()

  if btnId == 1 then
    if self.currentFormationIdx > 1 then
      self.currentFormationIdx = self.currentFormationIdx - 1
      self.setFormation(formations[self.currentFormationIdx])
    end
  elseif btnId == 2 then
    if self.currentFormationIdx < maxIdx then
      self.currentFormationIdx = self.currentFormationIdx + 1
    else
      self.currentFormationIdx = 1
    end
    self.setFormation(formations[self.currentFormationIdx])
  end

  self:displayFormation()
end

return TacticsPanel

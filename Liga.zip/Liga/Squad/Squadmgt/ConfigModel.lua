local ConfigModel = {}

function ConfigModel:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.Config = init.Config
  return o
end

function ConfigModel:getPlayerRanges()
  return self.Config.PLAYER_RANGES
end

function ConfigModel:getFormationPositions(formationID)
  return self.Config.FORMATION_POSITIONS["formation" .. tostring(formationID)] or {}
end

return ConfigModel

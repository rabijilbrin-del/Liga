-- config.lua

local Config = {}

-- Constants
Config.PLAYER_RANGES = {
  starting = { start = 1, count = 11 }, -- Players 1-11
  subres = { start = 12, count = 16 }    -- Players 12-19
}

Config.FORMATION_INFO = {
    [1] = "3-4-1-2",
    [3] = "3-4-2-1",
    [5] = "3-4-3",
    [7] = "3-5-2",
    [9] = "4-1-2-1-2",
    [11] = "4-2-3-1",
    [13] = "4-2-2-2",
    [15] = "4-3-1-2",
    [17] = "4-3-2-1",
    [19] = "4-3-3",
    [21] = "4-4-1-1",
    [23] = "4-4-2",
    [25] = "4-5-1",
    [27] = "5-2-1-2",
    [29] = "5-2-2-1",
    [31] = "5-3-2",
    [33] = "5-4-1",
    [41] = "4-1-4-1",
    [43] = "4-1-3-2",
    [61] = "3-5-1-1",
    [63] = "3-1-4-2",
    [65] = "4-2-4"
}

Config.FORMATION_IDS = {1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 41, 43, 61, 63, 65}
Config.FORMATION_POSITIONS = {
  formation19 = { -- 4-3-3
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 140, left = 200 },    -- Head2: Right-back
    { top = 150, left = 70 },    -- Head3: Center-back right
    { top = 150, left = -70 },   -- Head4: Center-back left
    { top = 140, left = -200 },   -- Head5: Left-back
    { top = 70, left = 90 },     -- Head6: Right midfielder
    { top = 105, left = 0 },       -- Head7: Central midfielder
    { top = 70, left = -90 },    -- Head8: Left midfielder
    { top = 0, left = 210 },    -- Head9: Right winger
    { top = -10, left = 0 },      -- Head10: Striker
    { top = 0, left = -210 }    -- Head11: Left winger
  },
  formation21 = { -- 4-4-1-1
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 140, left = 200 },    -- Head2: Right-back
    { top = 150, left = 70 },    -- Head3: Center-back right
    { top = 150, left = -70 },   -- Head4: Center-back left
    { top = 140, left = -200 },   -- Head5: Left-back
    { top = 70, left = 210 },     -- Head6: Right midfielder
    { top = 85, left = 70 },     -- Head7: Central midfielder right
    { top = 85, left = -70 },    -- Head8: Central midfielder left
    { top = 70, left = -210 },    -- Head9: Left midfielder
    { top = 50, left = 0 },      -- Head10: Attacking midfielder
    { top = -10, left = 0 }      -- Head11: Striker
  },
  formation11 = { -- 4-2-3-1
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 140, left = 200 },    -- Head2: Right-back
    { top = 150, left = 70 },    -- Head3: Center-back right
    { top = 150, left = -70 },   -- Head4: Center-back left
    { top = 140, left = -200 },   -- Head5: Left-back
    { top = 100, left = 70 },     -- Head6: Central midfielder right
    { top = 100, left = -70 },    -- Head7: Central midfielder left
    { top = 30, left = 210 },    -- Head8: Right winger
    { top = 30, left = 0 },      -- Head9: Attacking midfielder
    { top = 30, left = -210 },   -- Head10: Left winger
    { top = -10, left = 0 }      -- Head11: Striker
  },
  formation23 = { -- 4-4-2
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 140, left = 200 },    -- Head2: Right-back
    { top = 150, left = 70 },    -- Head3: Center-back right
    { top = 150, left = -70 },   -- Head4: Center-back left
    { top = 140, left = -200 },   -- Head5: Left-back
    { top = 60, left = 210 },     -- Head6: Right midfielder
    { top = 70, left = 80 },     -- Head7: Central midfielder right
    { top = 70, left = -80 },    -- Head8: Central midfielder left
    { top = 60, left = -210 },    -- Head9: Left midfielder
    { top = -10, left = 60 },    -- Head10: Striker right
    { top = -10, left = -60 }    -- Head11: Striker left
  },
  formation25 = { -- 4-5-1
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 140, left = 200 },    -- Head2: Right-back
    { top = 150, left = 70 },    -- Head3: Center-back right
    { top = 150, left = -70 },   -- Head4: Center-back left
    { top = 140, left = -200 },   -- Head5: Left-back
    { top = 50, left = 210 },     -- Head6: Right midfielder
    { top = 60, left = 90 },     -- Head7: Central midfielder right
    { top = 70, left = 0 },       -- Head8: Central midfielder
    { top = 60, left = -90 },    -- Head9: Central midfielder left
    { top = 50, left = -210 },    -- Head10: Left midfielder
    { top = -10, left = 0 }       -- Head11: Striker
  },
  formation27 = { -- 5-2-1-2
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 130, left = 200 },    -- Head2: Right wing-back
    { top = 150, left = 90 },    -- Head3: Center-back right
    { top = 150, left = 0 },      -- Head4: Center-back
    { top = 150, left = -90 },   -- Head5: Center-back left
    { top = 130, left = -200 },   -- Head6: Left wing-back
    { top = 90, left = 70 },     -- Head7: Central midfielder right
    { top = 90, left = -70 },    -- Head8: Central midfielder left
    { top = 30, left = 0 },      -- Head9: Attacking midfielder
    { top = -10, left = 60 },   -- Head10: Striker right
    { top = -10, left = -60 }   -- Head11: Striker left
  },
  formation29 = { -- 5-2-2-1
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 130, left = 200 },    -- Head2: Right wing-back
    { top = 150, left = 90 },    -- Head3: Center-back right
    { top = 150, left = 0 },      -- Head4: Center-back
    { top = 150, left = -90 },   -- Head5: Center-back left
    { top = 130, left = -200 },   -- Head6: Left wing-back
    { top = 90, left = 70 },     -- Head7: Central midfielder right
    { top = 90, left = -70 },    -- Head8: Central midfielder left
    { top = 20, left = 130 },    -- Head9: Attacking midfielder right
    { top = 20, left = -130 },   -- Head10: Attacking midfielder left
    { top = -10, left = 0 }      -- Head11: Striker
  },
  formation31 = { -- 5-3-2
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 130, left = 200 },    -- Head2: Right wing-back
    { top = 150, left = 90 },    -- Head3: Center-back right
    { top = 150, left = 0 },      -- Head4: Center-back
    { top = 150, left = -90 },   -- Head5: Center-back left
    { top = 130, left = -200 },   -- Head6: Left wing-back
    { top = 70, left = 90 },     -- Head7: Right midfielder
    { top = 105, left = 0 },       -- Head8: Central midfielder
    { top = 70, left = -90 },    -- Head9: Left midfielder
    { top = -10, left = 60 },    -- Head10: Striker right
    { top = -10, left = -60 }    -- Head11: Striker left
  },
  formation33 = { -- 5-4-1
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 130, left = 200 },    -- Head2: Right wing-back
    { top = 150, left = 90 },    -- Head3: Center-back right
    { top = 150, left = 0 },      -- Head4: Center-back
    { top = 150, left = -90 },   -- Head5: Center-back left
    { top = 130, left = -200 },   -- Head6: Left wing-back
    { top = 50, left = 210 },     -- Head7: Right midfielder
    { top = 70, left = 80 },     -- Head8: Central midfielder right
    { top = 70, left = -80 },    -- Head9: Central midfielder left
    { top = 50, left = -210 },    -- Head10: Left midfielder
    { top = -10, left = 0 }       -- Head11: Striker
  },
  formation41 = { -- 4-1-4-1
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 140, left = 200 },    -- Head2: Right-back
    { top = 150, left = 70 },    -- Head3: Center-back right
    { top = 150, left = -70 },   -- Head4: Center-back left
    { top = 140, left = -200 },   -- Head5: Left-back
    { top = 105, left = 0 },      -- Head6: Defensive midfielder
    { top = 70, left = 210 },     -- Head7: Right midfielder
    { top = 70, left = 70 },     -- Head8: Central midfielder right
    { top = 70, left = -70 },    -- Head9: Central midfielder left
    { top = 70, left = -210 },    -- Head10: Left midfielder
    { top = -10, left = 0 }       -- Head11: Striker
  },
  formation43 = { -- 4-1-3-2
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 140, left = 200 },    -- Head2: Right-back
    { top = 150, left = 70 },    -- Head3: Center-back right
    { top = 150, left = -70 },   -- Head4: Center-back left
    { top = 140, left = -200 },   -- Head5: Left-back
    { top = 105, left = 0 },      -- Head6: Defensive midfielder
    { top = 65, left = 100 },     -- Head7: Central midfielder right
    { top = 65, left = 0 },       -- Head8: Central midfielder
    { top = 65, left = -100 },    -- Head9: Central midfielder left
    { top = -10, left = 60 },    -- Head10: Striker right
    { top = -10, left = -60 }    -- Head11: Striker left
  },
  formation61 = { -- 3-5-1-1
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 150, left = 100 },    -- Head2: Center-back right
    { top = 150, left = 0 },      -- Head3: Center-back
    { top = 150, left = -100 },   -- Head4: Center-back left
    { top = 60, left = 210 },     -- Head5: Right wing-back
    { top = 70, left = 80 },     -- Head6: Central midfielder right
    { top = 90, left = 0 },       -- Head7: Central midfielder
    { top = 70, left = -80 },    -- Head8: Central midfielder left
    { top = 60, left = -210 },    -- Head9: Left wing-back
    { top = 45, left = 0 },      -- Head10: Attacking midfielder
    { top = -10, left = 0 }      -- Head11: Striker
  },
  formation63 = { -- 3-1-4-2
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 150, left = 100 },    -- Head2: Center-back right
    { top = 150, left = 0 },      -- Head3: Center-back
    { top = 150, left = -100 },   -- Head4: Center-back left
    { top = 105, left = 0 },      -- Head5: Defensive midfielder
    { top = 50, left = 210 },     -- Head6: Right midfielder
    { top = 65, left = 70 },     -- Head7: Central midfielder right
    { top = 65, left = -70 },    -- Head8: Central midfielder left
    { top = 50, left = -210 },    -- Head9: Left midfielder
    { top = -10, left = 60 },    -- Head10: Striker right
    { top = -10, left = -60 }    -- Head11: Striker left
  },
  formation65 = { -- 4-2-4
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 140, left = 200 },    -- Head2: Right-back
    { top = 150, left = 70 },    -- Head3: Center-back right
    { top = 150, left = -70 },   -- Head4: Center-back left
    { top = 140, left = -200 },   -- Head5: Left-back
    { top = 65, left = 70 },     -- Head6: Central midfielder right
    { top = 65, left = -70 },    -- Head7: Central midfielder left
    { top = 20, left = 210 },    -- Head8: Right winger
    { top = -10, left = 60 },    -- Head9: Striker right
    { top = -10, left = -60 },   -- Head10: Striker left
    { top = 20, left = -210 }    -- Head11: Left winger
  },
  formation1 = { -- 3-4-1-2
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 150, left = 100 },    -- Head2: Center-back right
    { top = 150, left = 0 },      -- Head3: Center-back
    { top = 150, left = -100 },   -- Head4: Center-back left
    { top = 60, left = 210 },     -- Head5: Right midfielder
    { top = 100, left = 70 },     -- Head6: Central midfielder right
    { top = 100, left = -70 },    -- Head7: Central midfielder left
    { top = 60, left = -210 },    -- Head8: Left midfielder
    { top = 30, left = 0 },      -- Head9: Attacking midfielder
    { top = -10, left = 70 },   -- Head10: Striker right
    { top = -10, left = -70 }   -- Head11: Striker left
  },
  formation3 = { -- 3-4-2-1
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 150, left = 100 },    -- Head2: Center-back right
    { top = 150, left = 0 },      -- Head3: Center-back
    { top = 150, left = -100 },   -- Head4: Center-back left
    { top = 60, left = 210 },     -- Head5: Right midfielder
    { top = 100, left = 70 },     -- Head6: Central midfielder right
    { top = 100, left = -70 },    -- Head7: Central midfielder left
    { top = 60, left = -210 },    -- Head8: Left midfielder
    { top = 20, left = 70 },    -- Head9: Attacking midfielder right
    { top = 20, left = -70 },   -- Head10: Attacking midfielder left
    { top = -10, left = 0 }      -- Head11: Striker
  },
  formation5 = { -- 3-4-3
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 150, left = 100 },    -- Head2: Center-back right
    { top = 150, left = 0 },      -- Head3: Center-back
    { top = 150, left = -100 },   -- Head4: Center-back left
    { top = 50, left = 210 },     -- Head5: Right midfielder
    { top = 60, left = 70 },     -- Head6: Central midfielder right
    { top = 60, left = -70 },    -- Head7: Central midfielder left
    { top = 50, left = -210 },    -- Head8: Left midfielder
    { top = 10, left = 160 },    -- Head9: Right winger
    { top = -10, left = 0 },      -- Head10: Striker
    { top = 10, left = -160 }    -- Head11: Left winger
  },
  formation7 = { -- 3-5-2
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 150, left = 100 },    -- Head2: Center-back right
    { top = 150, left = 0 },      -- Head3: Center-back
    { top = 150, left = -100 },   -- Head4: Center-back left
    { top = 60, left = 210 },     -- Head5: Right wing-back
    { top = 60, left = 140 },     -- Head6: Central midfielder right
    { top = 60, left = 0 },       -- Head7: Central midfielder
    { top = 60, left = -140 },    -- Head8: Central midfielder left
    { top = 60, left = -210 },    -- Head9: Left wing-back
    { top = -10, left = 70 },    -- Head10: Striker right
    { top = -10, left = -70 }    -- Head11: Striker left
  },
  formation9 = { -- 4-1-2-1-2
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 140, left = 200 },    -- Head2: Right-back
    { top = 150, left = 70 },    -- Head3: Center-back right
    { top = 150, left = -70 },   -- Head4: Center-back left
    { top = 140, left = -200 },   -- Head5: Left-back
    { top = 105, left = 0 },      -- Head6: Defensive midfielder
    { top = 70, left = 70 },     -- Head7: Central midfielder right
    { top = 70, left = -70 },    -- Head8: Central midfielder left
    { top = 30, left = 0 },      -- Head9: Attacking midfielder
    { top = -10, left = 70 },   -- Head10: Striker right
    { top = -10, left = -70 }   -- Head11: Striker left
  },
  formation13 = { -- 4-2-2-2
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 140, left = 200 },    -- Head2: Right-back
    { top = 150, left = 70 },    -- Head3: Center-back right
    { top = 150, left = -70 },   -- Head4: Center-back left
    { top = 140, left = -200 },   -- Head5: Left-back
    { top = 100, left = 70 },     -- Head6: Central midfielder right
    { top = 100, left = -70 },    -- Head7: Central midfielder left
    { top = 50, left = 90 },    -- Head8: Attacking midfielder right
    { top = 50, left = -90 },   -- Head9: Attacking midfielder left
    { top = -10, left = 60 },   -- Head10: Striker right
    { top = -10, left = -60 }   -- Head11: Striker left
  },
  formation15 = { -- 4-3-1-2
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 140, left = 200 },    -- Head2: Right-back
    { top = 150, left = 70 },    -- Head3: Center-back right
    { top = 150, left = -70 },   -- Head4: Center-back left
    { top = 140, left = -200 },   -- Head5: Left-back
    { top = 60, left = 140 },     -- Head6: Central midfielder right
    { top = 80, left = 0 },       -- Head7: Central midfielder
    { top = 60, left = -140 },    -- Head8: Central midfielder left
    { top = 30, left = 0 },      -- Head9: Attacking midfielder
    { top = -10, left = 70 },   -- Head10: Striker right
    { top = -10, left = -70 }   -- Head11: Striker left
  },
  formation17 = { -- 4-3-2-1
    { top = 200, left = 0 },      -- Head1: Goalkeeper
    { top = 140, left = 200 },    -- Head2: Right-back
    { top = 150, left = 70 },    -- Head3: Center-back right
    { top = 150, left = -70 },   -- Head4: Center-back left
    { top = 140, left = -200 },   -- Head5: Left-back
    { top = 70, left = 120 },     -- Head6: Central midfielder right
    { top = 90, left = 0 },       -- Head7: Central midfielder
    { top = 70, left = -120 },    -- Head8: Central midfielder left
    { top = 40, left = 210 },    -- Head9: Attacking midfielder right
    { top = 40, left = -210 },   -- Head10: Attacking midfielder left
    { top = -10, left = 0 }      -- Head11: Striker
  }
}

return Config
local UIModel = {}

-- ────────────────────────────────────────────────────────────────────────────
-- Module-level upvalues
-- ────────────────────────────────────────────────────────────────────────────
local publish          -- set in :new() from im.Publish
local math_floor = math.floor
local math_max   = math.max
local math_min   = math.min
local math_ceil  = math.ceil

-- ── Pre-built binding-name string tables (eliminates runtime concatenation) ──

-- Sub player bindings (1..16)
local BND_HEAD    = {}; for i=1,16 do BND_HEAD[i]    = "bnd_head"    ..i end
local BND_NAME    = {}; for i=1,16 do BND_NAME[i]    = "bnd_name"    ..i end
local BND_POS     = {}; for i=1,16 do BND_POS[i]     = "bnd_pos"     ..i end
local BND_OVR     = {}; for i=1,16 do BND_OVR[i]     = "bnd_ovr"     ..i end
local BND_POSICON = {}; for i=1,16 do BND_POSICON[i]  = "bnd_posIcon" ..i end
local BND_VALID   = {}; for i=1,16 do BND_VALID[i]   = "bnd_validSub"..i end
local BND_SNAM_FC = {}; for i=1,16 do BND_SNAM_FC[i] = "bnd_namefontcolor"..i end
local BND_SPOS_FC = {}; for i=1,16 do BND_SPOS_FC[i] = "bnd_posfontcolor" ..i end
local BND_SOVR_FC = {}; for i=1,16 do BND_SOVR_FC[i] = "bnd_ovrfontcolor" ..i end
local BND_SELSR   = {}; for i=1,16 do BND_SELSR[i]   = "bnd_selectedsubres"   ..i end
local BND_HILSR   = {}; for i=1,16 do BND_HILSR[i]   = "bnd_highlightedsubres"..i end
local BND_SUBSTAM = {}; for i=1,16 do BND_SUBSTAM[i] = "bnd_sub"..i.."stamina"      end
local BND_SUBSCO  = {}; for i=1,16 do BND_SUBSCO[i]  = "bnd_sub"..i.."staminacolor" end

-- Starting XI bindings (1..11)
local BND_XIHEAD  = {}; for i=1,11 do BND_XIHEAD[i]  = "bnd_starting"    ..i end
local BND_XINAME  = {}; for i=1,11 do BND_XINAME[i]  = "bnd_startingname"..i end
local BND_XIPOS   = {}; for i=1,11 do BND_XIPOS[i]   = "bnd_startingpos" ..i end
local BND_XIOVR   = {}; for i=1,11 do BND_XIOVR[i]   = "bnd_startingovr" ..i end
local BND_XITOP   = {}; for i=1,11 do BND_XITOP[i]   = "bnd_posTop"      ..i end
local BND_XILEFT  = {}; for i=1,11 do BND_XILEFT[i]  = "bnd_posLeft"     ..i end
local BND_XISEL   = {}; for i=1,11 do BND_XISEL[i]   = "bnd_selected"    ..i end
local BND_XIHIL   = {}; for i=1,11 do BND_XIHIL[i]   = "bnd_highlighted" ..i end
local BND_XINC    = {}; for i=1,11 do BND_XINC[i]     = "bnd_startingnamecolor"..i end
local BND_XIINJ   = {}; for i=1,11 do BND_XIINJ[i]   = "bnd_isInj"       ..i end
local BND_XIRC    = {}; for i=1,11 do BND_XIRC[i]    = "bnd_isRc"        ..i end
local BND_PLSTAM  = {}; for i=1,11 do BND_PLSTAM[i]  = "bnd_pl"..i.."stamina"      end
local BND_PLSCO   = {}; for i=1,11 do BND_PLSCO[i]   = "bnd_pl"..i.."staminacolor" end

-- Row bindings (1..4)
local BND_ROWX    = {}; for i=1,4 do BND_ROWX[i] = "bnd_subresrow"..i.."X" end
local BND_ROWY    = {}; for i=1,4 do BND_ROWY[i] = "bnd_subresrow"..i.."Y" end

-- Attrib bindings (1..8 right/left, 1..10 comparison)
local BND_RATTRIB = {}; for i=1,8  do BND_RATTRIB[i] = "bnd_rightplayerattrib"..i end
local BND_LATTRIB = {}; for i=1,8  do BND_LATTRIB[i] = "bnd_leftplayerattrib" ..i end
local BND_RVAL    = {}; for i=1,8  do BND_RVAL[i]    = "bnd_rightplayerattribvalue"..i end
local BND_LVAL    = {}; for i=1,8  do BND_LVAL[i]    = "bnd_leftplayerattribvalue" ..i end
local BND_RVALFC  = {}; for i=1,8  do BND_RVALFC[i]  = "bnd_rightplayerattribvaluecolor"..i end
local BND_LVALFC  = {}; for i=1,16 do BND_LVALFC[i]  = "bnd_leftplayerattribvaluecolor" ..i end
local BND_CATTR   = {}; for i=1,10 do BND_CATTR[i]   = "bnd_comparisonattrib"..i end
local BND_C1VAL   = {}; for i=1,10 do BND_C1VAL[i]   = "bnd_comparisonplayer1attribvalue"..i end
local BND_C2VAL   = {}; for i=1,10 do BND_C2VAL[i]   = "bnd_comparisonplayer2attribvalue"..i end
local BND_C1FC    = {}; for i=1,10 do BND_C1FC[i]    = "bnd_comparisonplayer1attribvaluecolor"..i end
local BND_C2FC    = {}; for i=1,10 do BND_C2FC[i]    = "bnd_comparisonplayer2attribvaluecolor"..i end

-- ── Sub panel X-axis config (scrollOffset → column positions) ─────────────────
local X_CONFIG = {
  [0] = {210, 300},
  [1] = {120, 210, 300},
  [2] = {10, 100, 190, 300},
  [3] = {10, 100, 220, 300},
  [4] = {10, 120, 210, 300},
  [5] = {30, 120, 210, 300},
}

-- Static stamina values (all players start at 100 per match; extend with service call if available)
local STAMINA_DEFAULT = 100

-- ── Attrib field lists ────────────────────────────────────────────────────────
local ATTRIB_RIGHT    = {"Age","Pace","Shooting","Passing","Dribbling","Defending","Physical","Weight"}
local ATTRIB_RIGHT_GK = {"Age","Diving","Handling","Kicking","Reflexes","Speed","Positioning","Weight"}
local ATTRIB_LEFT     = {"Fitness","Sharpness","Morale","Foot","Accelrtn. Type","Role","Focus","Height"}
local ATTRIB_FULL     = {
  "Name","OVR","Fitness","Sharpness","Morale","Current Position","Position(s)",
  "Pace","Shooting","Passing","Dribbling","Defending","Physical","Height","Foot","Weight"
}
local ATTRIB_FULL_GK  = {
  "Name","OVR","Fitness","Sharpness","Morale","Current Position","Position(s)",
  "Diving","Handling","Kicking","Reflexes","Speed","Positioning","Height","Foot","Weight"
}
local STAT_NORMAL = {"Pac","Sho","Pas","Dri","Def","Phy"}
local STAT_GK     = {"Div","Han","Kic","Ref","Spe","Pos"}

-- ── Colour constants ─────────────────────────────────────────────────────────
local COL_WHITE    = "0xFFFFFF"
local COL_BLACK    = "0x000000"
local COL_GREEN    = "0xFF0DCB54"
local COL_YELLOW   = "0xF2C94C"
local COL_RED      = "0xEB5757"
local COL_BRGREEN  = "0x00FF00"
local COL_GK       = "0xFFA429"
local COL_DEF      = "0xD6D231"
local COL_MID      = "0x50A94D"
local COL_ATT      = "0x008DFF"
local HEAD_NIL     = { name = "$Head", id = nil }
local HEAD_EMPTY   = { name = "$Head", id = 0   }
local FLAG_NIL     = { name = "$Flag128x128", id = nil }

-- ── Helpers ──────────────────────────────────────────────────────────────────

local function shortenName(name)
  if not name then return nil end
  local d = name:find("%. ")
  if d then return name:sub(d + 2) end
  local s = name:find(" ")
  if s then return name:sub(s + 1) end
  return name
end

local function positionColor(pos)
  if not pos then return nil end
  if pos == "GK" then return COL_GK end
  if pos=="CB" or pos=="LB" or pos=="RB" or pos=="RWB" or pos=="LWB"
     or pos=="LCB" or pos=="RCB" then return COL_DEF end
  if pos=="RM" or pos=="LM" or pos=="CM" or pos=="CDM" or pos=="CAM" then return COL_MID end
  if pos=="CF" or pos=="ST" or pos=="LS" or pos=="RS" or pos=="LW"
     or pos=="RW" or pos=="LF" or pos=="RF" then return COL_ATT end
  return nil
end

local function staminaBar(stype, stamina)
  stamina = stamina or STAMINA_DEFAULT
  if stype == "sub" then
    return (stamina / 100) * 145
  elseif stype == "xi" then
    return (stamina / 100) * 70
  end
  -- color
  if stamina >= 75 then return COL_GREEN
  elseif stamina > 35 then return COL_YELLOW
  else return COL_RED end
end

local function attribColor(data)
  if type(data) == "string" then
    if data == "Excellent" then return "0x22EB00"
    elseif data == "Good"  then return "0x20A500"
    elseif data == "Content" then return "0xE1DE00"
    elseif data == "Bad"   then return "0xDD0000"
    else return COL_WHITE end
  else
    return (data and data <= 40) and "0xDD0000" or COL_WHITE
  end
end

local function formatHeight(cm)
  if not cm or cm == 0 then return "-" end
  local tot  = cm / 2.54
  local feet = math_floor(tot / 12)
  local inch  = math_floor(tot % 12 + 0.5)
  return feet .. "'" .. inch .. '"'
end

-- Safe wrappers for game APIs that may not exist in all contexts
local function safeGetPlayerData(key, cardId)
  if GetPlayerData then return GetPlayerData(key, cardId) end
  return nil
end
local function safeGetPlayerAge(cardId)
  if GetPlayerAge then return tostring(GetPlayerAge(cardId)) end
  return "-"
end

-- ── Constructor ───────────────────────────────────────────────────────────────

function UIModel:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.Config              = init.Config
  o.im                  = init.im
  o.isDirty             = true
  o.displayType         = "single"
  o.comparisonScrollOffset = 1
  o.screenMode          = init.screenMode
  o.formation           = init.getFormation
  o.switchDisplayAnim   = init.switchDisplayAnim
  o.substituteCount     = 9  -- updated dynamically in cacheSubData
  -- Stage-runner state
  o._stages    = nil
  o._stageIdx  = nil
  o._stageTimer = nil
  o._Timer     = nil

  publish = o.im.Publish

  o.eventManager   = o.api("EventManagerService")
  o.eventHandlerId = o.eventManager.RegisterHandler(function() publish = nil end)

  -- Preallocate sub cache (avoids per-frame table creation)
  o.subData = {}
  for i = 1, 16 do
    o.subData[i] = { head = { name = "$Head", id = nil }, name = nil, pos = nil, ovr = nil, posIcon = nil }
  end

  return o
end

-- ── Dirty flag ────────────────────────────────────────────────────────────────

function UIModel:markDirty()
  self.isDirty = true
  -- Cancel any in-flight progressive load; full publishPanel will take over
  if self._stageTimer then
    self._stageTimer:finalize()
    self._stageTimer = nil
  end
  self._stages   = nil
  self._stageIdx = nil
end

-- ── Sub panel row config (dynamic) ───────────────────────────────────────────

function UIModel:_rowConfig(squadModel)
  local off        = squadModel:getScrollOffset()
  local panH       = off == 1 and 300 or (off >= 2 and 420 or 230)
  local numRows    = off == 1 and 3   or (off >= 2 and 4   or 2)
  local totalSubs  = math_min(self.substituteCount, 16)
  local rowsNeeded = math_ceil(totalSubs / 4)
  numRows = math_max(rowsNeeded, math_min(numRows, 4))
  local rowH   = math_max(25, math_min(panH / (numRows + 1), 50))
  local baseY  = 125
  local maxY   = 223
  local factor = off / 5
  local rowpos = {}
  for i = 1, numRows do
    local base = baseY + (i - 1) * rowH
    rowpos[i]  = math_max(baseY, math_min(base + factor * (maxY - baseY), maxY))
  end
  return rowpos, rowH, numRows, panH
end

-- ── Cache sub slot data ───────────────────────────────────────────────────────

function UIModel:cacheSubData(squadModel)
  local sp = squadModel:getPlayers()
  if not sp then return end

  local off      = squadModel:getScrollOffset()
  local effOff   = off > 2 and off - 2 or 0
  local startIdx = self.Config.PLAYER_RANGES.subres.start + effOff * 4
  local subData  = self.subData
  local maxSet   = 0

  for i = 1, 16 do
    local rowIdx  = math_floor((i - 1) / 4) * 4
    local pIdx    = startIdx + (i - 1 - rowIdx) + rowIdx
    local slot    = subData[i]
    if pIdx <= #sp then
      local cid = sp[pIdx]
      local p   = squadModel:getPlayerById(cid)
      if p then
        slot.head.id = cid
        slot.name    = shortenName(p.playerName)
        slot.pos     = p.position
        slot.ovr     = p.rating
        slot.posIcon = positionColor(p.position)
        if i > maxSet then maxSet = i end
      else
        slot.head.id = 0
        slot.name = ""; slot.pos = ""; slot.ovr = 0; slot.posIcon = COL_WHITE
      end
    else
      slot.head.id = nil; slot.name = nil; slot.pos = nil
      slot.ovr = nil; slot.posIcon = nil
    end
  end

  self.substituteCount = #sp - self.Config.PLAYER_RANGES.starting.count
end

-- ════════════════════════════════════════════════════════════════════════════
-- PROGRESSIVE STAGED LOADER
-- ════════════════════════════════════════════════════════════════════════════

-- Sequential stage runner: fires each stage fn, then starts a timer for the next
function UIModel:_runStage()
  local stages = self._stages
  local idx    = self._stageIdx
  if not stages or not idx or idx > #stages then
    self._stages    = nil
    self._stageIdx  = nil
    self._stageTimer = nil
    return
  end

  local stage = stages[idx]
  self._stageIdx = idx + 1
  stage.fn(self)  -- execute this stage synchronously

  if self._stageIdx <= #stages then
    local delay = stage.nextDelay or 0
    local timer = self._Timer:new({
      id = "uistage_" .. idx,
      interval = delay,
      reps = 1,
      onTimerComplete = function() self:_runStage() end
    })
    self._stageTimer = timer
    timer:start()
  else
    self._stages     = nil
    self._stageIdx   = nil
    self._stageTimer = nil
    self.isDirty     = false  -- progressive load complete; full repaints need markDirty
  end
end

-- Entry point called from Squad:new after updateSquadData
-- Timer class is passed in (keeps UIModel decoupled)
function UIModel:startProgressiveLoad(squadModel, selectionModel, tacticsPanel, Timer)
  if not publish then return end
  self._Timer    = Timer
  self._stageIdx = 1

  -- Cache sub data once upfront (cheap: just reads playerById)
  self:cacheSubData(squadModel)

  local ui  = self
  self._stages = {
    -- ── Stage 0 (sync): XI text — names, OVR, pos, formation ─────────────
    {
      nextDelay = 0,
      fn = function(_)
        ui:_publishXIText(squadModel)
      end
    },
    -- ── Stage 1 (next tick): first 8 sub names/OVR/pos ───────────────────
    {
      nextDelay = 0,
      fn = function(_)
        ui:_publishSubsText(squadModel, 1, 8)
      end
    },
    -- ── Stage 2 (16ms): next 8 subs + sub panel structure ────────────────
    {
      nextDelay = 0.016,
      fn = function(_)
        ui:_publishSubsText(squadModel, 9, 16)
        ui:publishSubResPanel(squadModel)
      end
    },
    -- ── Stage 3 (16ms): valid-sub flags + selection + font colors ─────────
    {
      nextDelay = 0.016,
      fn = function(_)
        ui:_publishValidSubs(squadModel)
        ui:publishFontColors(squadModel, selectionModel)
        ui:publishSelectionBindings(squadModel, selectionModel)
        tacticsPanel:displayFormation()
      end
    },
    -- ── Stage 4 (33ms): XI head images (expensive renderer calls) ─────────
    {
      nextDelay = 0.033,
      fn = function(_)
        ui:_publishXIHeads(squadModel)
      end
    },
    -- ── Stage 5 (33ms): sub head images + completion ──────────────────────
    {
      nextDelay = 0,
      fn = function(_)
        ui:_publishSubHeads()
      end
    },
  }

  self:_runStage()  -- kick off stage 0 immediately (synchronous)
end

-- Update method — Squad:update must call this to tick the stage timer
function UIModel:update(elapsedTime)
  if self._stageTimer then
    self._stageTimer:update(elapsedTime)
  end
end

-- ── Stage implementations ─────────────────────────────────────────────────────

-- Stage 0: XI player text (no heads) + formation positions
function UIModel:_publishXIText(squadModel)
  if not publish then return end
  local sp        = squadModel:getPlayers()
  if not sp then return end

  local rowpos, rowH, _, _ = self:_rowConfig(squadModel)
  publish("bnd_rowpos",    rowpos[1] or 125)
  publish("bnd_rowheight", rowH)

  local byId      = squadModel.playerById
  local startCount = self.Config.PLAYER_RANGES.starting.count
  local formation  = self.Config.FORMATION_POSITIONS["formation" .. tostring(self.formation())]

  for i = 1, startCount do
    local cid = sp[i]
    local p   = byId[cid]
    if p then
      publish(BND_XINAME[i], shortenName(p.playerName))
      publish(BND_XIPOS[i],  p.position)
      publish(BND_XIOVR[i],  p.rating)
    else
      publish(BND_XINAME[i], nil)
      publish(BND_XIPOS[i],  nil)
      publish(BND_XIOVR[i],  nil)
    end
  end

  if formation then
    for i = 1, #formation do
      publish(BND_XITOP[i],  formation[i].top)
      publish(BND_XILEFT[i], formation[i].left)
    end
  end
end

-- Stage 1 & 2: sub text (name/pos/OVR) for slots lo..hi
function UIModel:_publishSubsText(squadModel, lo, hi)
  if not publish then return end
  local subData = self.subData
  local sp      = squadModel:getPlayers()
  if not sp then return end

  for i = lo, hi do
    local slot = subData[i]
    publish(BND_NAME[i],    slot.name)
    publish(BND_POS[i],     slot.pos)
    publish(BND_OVR[i],     slot.ovr)
    publish(BND_POSICON[i], slot.posIcon)
  end
end

-- Stage 3a: valid-sub visibility flags
function UIModel:_publishValidSubs(squadModel)
  if not publish then return end
  local sp     = squadModel:getPlayers()
  if not sp then return end
  local byId   = squadModel.playerById
  local off    = squadModel:getScrollOffset()
  local effOff = off > 2 and off - 2 or 0
  local start  = self.Config.PLAYER_RANGES.subres.start + effOff * 4
  local n      = #sp

  for i = 1, 16 do
    local rowIdx = math_floor((i - 1) / 4) * 4
    local pIdx   = start + (i - 1 - rowIdx) + rowIdx
    local valid  = pIdx <= n and byId[sp[pIdx]] ~= nil
    publish(BND_VALID[i], valid)
  end
end

-- Stage 4: XI head images only
function UIModel:_publishXIHeads(squadModel)
  if not publish then return end
  local sp         = squadModel:getPlayers()
  if not sp then return end
  local startCount = self.Config.PLAYER_RANGES.starting.count
  local byId       = squadModel.playerById

  for i = 1, startCount do
    local cid = sp[i]
    local p   = byId[cid]
    if p then
      publish(BND_XIHEAD[i], { name = "$Head", id = cid })
      -- stamina alongside (cheap, already loaded)
      publish(BND_PLSTAM[i], staminaBar("xi",  STAMINA_DEFAULT))
      publish(BND_PLSCO[i],  staminaBar("color", STAMINA_DEFAULT))
      publish(BND_XIINJ[i],  isSuspended and isSuspended[cid] == 2 or false)
      publish(BND_XIRC[i],   isSuspended and isSuspended[cid] == 1 or false)
    else
      publish(BND_XIHEAD[i], HEAD_NIL)
    end
  end
end

-- Stage 5: sub head images only
function UIModel:_publishSubHeads()
  if not publish then return end
  local subData = self.subData
  for i = 1, 16 do
    local slot = subData[i]
    local cid  = slot.head.id
    if cid ~= nil then
      publish(BND_HEAD[i],   slot.head)
      publish(BND_SUBSTAM[i], staminaBar("sub",   STAMINA_DEFAULT))
      publish(BND_SUBSCO[i],  staminaBar("color", STAMINA_DEFAULT))
    end
  end
end

-- ════════════════════════════════════════════════════════════════════════════
-- FULL REPAINT (post-load, triggered by markDirty → publishPanel)
-- ════════════════════════════════════════════════════════════════════════════

function UIModel:publishPanel(squadModel)
  local sp = squadModel:getPlayers()
  if not sp or not self.isDirty or not publish then return end

  -- Row config
  local rowpos, rowH, _, _ = self:_rowConfig(squadModel)
  publish("bnd_rowpos",    rowpos[1] or 125)
  publish("bnd_rowheight", rowH)

  -- Re-cache sub data
  self:cacheSubData(squadModel)
  self:publishSubResPanel(squadModel)
  self:_publishValidSubs(squadModel)

  -- Subs: full publish (text + heads)
  local subData = self.subData
  for i = 1, 16 do
    local slot = subData[i]
    local cid  = slot.head.id
    publish(BND_HEAD[i],    slot.head)
    publish(BND_NAME[i],    slot.name)
    publish(BND_POS[i],     slot.pos)
    publish(BND_OVR[i],     slot.ovr)
    publish(BND_POSICON[i], slot.posIcon)
    publish(BND_SUBSTAM[i], staminaBar("sub",   STAMINA_DEFAULT))
    publish(BND_SUBSCO[i],  staminaBar("color", STAMINA_DEFAULT))
  end

  -- Starting XI
  local byId       = squadModel.playerById
  local startCount = self.Config.PLAYER_RANGES.starting.count
  for i = 1, startCount do
    local cid = sp[i]
    local p   = byId[cid]
    if p then
      publish(BND_XIHEAD[i], { name = "$Head", id = cid })
      publish(BND_XINAME[i], shortenName(p.playerName))
      publish(BND_XIPOS[i],  p.position)
      publish(BND_XIOVR[i],  p.rating)
      publish(BND_PLSTAM[i], staminaBar("xi",    STAMINA_DEFAULT))
      publish(BND_PLSCO[i],  staminaBar("color", STAMINA_DEFAULT))
      publish(BND_XIINJ[i],  isSuspended and isSuspended[cid] == 2 or false)
      publish(BND_XIRC[i],   isSuspended and isSuspended[cid] == 1 or false)
    else
      publish(BND_XIHEAD[i], HEAD_NIL)
      publish(BND_XINAME[i], nil); publish(BND_XIPOS[i], nil); publish(BND_XIOVR[i], nil)
    end
  end

  -- Formation positions
  local formation = self.Config.FORMATION_POSITIONS["formation" .. tostring(self.formation())]
  if formation then
    for i = 1, #formation do
      publish(BND_XITOP[i],  formation[i].top)
      publish(BND_XILEFT[i], formation[i].left)
    end
  end

  self.isDirty = false
end

-- ── Sub-res panel (scrolling drawer layout) ───────────────────────────────────

function UIModel:publishSubResPanel(squadModel)
  if not publish then return end
  local off   = squadModel:getScrollOffset()
  local xcfg  = X_CONFIG[off] or X_CONFIG[0]
  local rowpos, _, numRows, panH = self:_rowConfig(squadModel)
  local subCnt = self.substituteCount

  publish("bnd_mainXIclarity",  off == 0 and 1 or 0.4)
  publish("bnd_subresrow1extra", off >= 1)
  publish("bnd_subresrow2extra", off >= 2)
  publish("bnd_subressubslabel", off < 3)
  publish("bnd_subresreslabel",  off >= 2 and off < 6)
  publish("bnd_subrespanelheight", panH)

  for i = 1, numRows do
    publish(BND_ROWX[i], xcfg[i])
    publish(BND_ROWY[i], rowpos[i])
  end

  if off == 0 then
    publish("bnd_subressubslabelY", -150)
  elseif off == 1 then
    publish("bnd_subressubslabelY", -65)
  elseif off == 2 then
    publish("bnd_subressubslabelY", 50)
    publish("bnd_subresreslabelY",  subCnt < 9 and -160 or -250)
  elseif off == 3 then
    publish("bnd_subresreslabelY",  subCnt < 9 and -70  or -160)
  elseif off == 4 then
    publish("bnd_subresreslabelY",  subCnt < 9 and 50   or -70)
  elseif off == 5 then
    publish("bnd_subresreslabelY",  50)
  end
end

-- ── Font colors (highlight-aware) ────────────────────────────────────────────

function UIModel:publishFontColors(squadModel, selectionModel)
  if not publish then return end
  local highlighted = selectionModel:getHighlightedPlayer()
  local sp          = squadModel:getPlayers()
  if not sp then return end

  local off      = squadModel:getScrollOffset()
  local effOff   = off > 2 and off - 2 or 0
  local subStart = self.Config.PLAYER_RANGES.subres.start + effOff * 4

  for i = 1, 16 do
    local rowIdx   = math_floor((i - 1) / 4) * 4
    local pIdx     = subStart + (i - 1 - rowIdx) + rowIdx
    local isHil    = highlighted and highlighted.type == "subres"
                     and highlighted.sheetIndex == pIdx
    local fc = isHil and COL_BLACK or COL_WHITE
    publish(BND_SNAM_FC[i], fc)
    publish(BND_SPOS_FC[i], fc)
    publish(BND_SOVR_FC[i], fc)
  end

  for i = 1, 11 do
    local isHil = highlighted and highlighted.type == "starting" and highlighted.index == i
    publish(BND_XINC[i], isHil and COL_BLACK or COL_WHITE)
  end
end

-- ── Selection state (highlight / selected indicators) ─────────────────────────

function UIModel:publishSelectionBindings(squadModel, selectionModel)
  if not publish then return end
  local sp = squadModel:getPlayers()
  if not sp then return end

  local off      = squadModel:getScrollOffset()
  local effOff   = off > 2 and off - 2 or 0
  local subStart = self.Config.PLAYER_RANGES.subres.start + effOff * 4
  local startCount = self.Config.PLAYER_RANGES.starting.count
  local highlighted = selectionModel:getHighlightedPlayer()

  -- Starting XI selection + highlight
  for i = 1, startCount do
    local isSel = selectionModel:isPlayerSelected(i)
    local isHil = selectionModel:isPlayerHighlighted(i)
    publish(BND_XISEL[i], isSel)
    publish(BND_XIHIL[i], isHil)
    publish(BND_XINC[i],  isHil and COL_BLACK or COL_WHITE)
  end

  -- Sub/reserve selection + highlight
  local visMap  = {}
  local n       = #sp
  local hilVis  = false

  for i = 1, 16 do
    local rowIdx = math_floor((i - 1) / 4) * 4
    local pIdx   = subStart + (i - 1 - rowIdx) + rowIdx
    local isSel, isHil = false, false
    if pIdx <= n then
      visMap[i]  = pIdx
      isSel = selectionModel:isPlayerSelected(pIdx)
      isHil = highlighted and highlighted.sheetIndex == pIdx
              and selectionModel:isPlayerHighlighted(pIdx)
      if isHil then hilVis = true end
    end
    publish(BND_SELSR[i],   isSel)
    publish(BND_HILSR[i],   isHil)
    local fc = isHil and COL_BLACK or COL_WHITE
    publish(BND_SNAM_FC[i], fc)
    publish(BND_SPOS_FC[i], fc)
    publish(BND_SOVR_FC[i], fc)
  end

  -- If highlighted sub is not in the visible window, clear all highlights
  if highlighted and highlighted.type == "subres" and not hilVis then
    for i = 1, 16 do
      publish(BND_HILSR[i],   false)
      publish(BND_SNAM_FC[i], COL_WHITE)
      publish(BND_SPOS_FC[i], COL_WHITE)
      publish(BND_SOVR_FC[i], COL_WHITE)
    end
  end

  -- Determine display mode and animate panel transition if changed
  local sel1, sel2 = selectionModel:getSelectedPlayers()
  local dispType   = (sel1 and highlighted and sel1 ~= highlighted) and "double" or "single"
  local needAnim   = dispType ~= self.displayType
  if needAnim then
    self.switchDisplayAnim(1)
    self.displayType = dispType
  end
  self:displayInfoPanel(dispType, squadModel, selectionModel)
  if needAnim then self.switchDisplayAnim(2) end
end

-- ── Sheet panel ───────────────────────────────────────────────────────────────

function UIModel:publishSheetPanel(idx, id, currIdx, show)
  if not publish then return end
  if not show then publish("bnd_displaysheets", false); return end

  local name = id and ("SHEET " .. tostring(currIdx)) or "New"
  publish("bnd_sheetname",    name .. (idx == currIdx and " (CURRENT)" or ""))
  publish("bnd_sheetinfo",    self.Config.FORMATION_INFO[id] or "")
  publish("bnd_currentSheet", { name = "$AHIconFormation", id = id or 0 })
  publish("bnd_displaysheets", true)
end

-- ── Player info panel (single / comparison) ───────────────────────────────────

function UIModel:publishSelectedHead(squadModel, selectionModel)
  if not publish then return end
  local sp = squadModel:getPlayers()
  if not sp then return end

  local highlighted = selectionModel:getHighlightedPlayer()
  local sel1, sel2  = selectionModel:getSelectedPlayers()
  local show        = { highlighted or sel1, sel2 }

  for i = 1, 2 do
    local s = show[i]
    if s then
      local cid = sp[s.sheetIndex]
      local p   = squadModel:getPlayerById(cid)
      if p then
        publish("bnd_selectedhead"   .. i, { name = "$Head", id = cid })
        publish("bnd_playername"     .. i, shortenName(p.playerName))
        publish("bnd_playernationality" .. i, { name = "$Flag128x128", id = p.nationalityID })
        publish("bnd_playerposition" .. i, p.position)
        publish("bnd_playerrating"   .. i, p.rating)
      else
        publish("bnd_selectedhead"   .. i, HEAD_NIL)
        publish("bnd_playername"     .. i, nil)
        publish("bnd_playernationality" .. i, FLAG_NIL)
        publish("bnd_playerposition" .. i, nil)
        publish("bnd_playerrating"   .. i, nil)
      end
    else
      publish("bnd_selectedhead"      .. i, HEAD_NIL)
      publish("bnd_playername"        .. i, nil)
      publish("bnd_playernationality" .. i, FLAG_NIL)
      publish("bnd_playerposition"    .. i, nil)
      publish("bnd_playerrating"      .. i, nil)
    end
  end

  -- Re-publish selection states
  local startCount = self.Config.PLAYER_RANGES.starting.count
  for i = 1, startCount do
    publish(BND_XISEL[i], selectionModel:isPlayerSelected(i))
    publish(BND_XIHIL[i], selectionModel:isPlayerHighlighted(i))
    publish(BND_XINC[i],  selectionModel:isPlayerHighlighted(i) and COL_BLACK or COL_WHITE)
  end

  local sp        = squadModel:getPlayers()
  local off       = squadModel:getScrollOffset()
  local effOff    = off > 2 and off - 2 or 0
  local subStart  = self.Config.PLAYER_RANGES.subres.start + effOff * 4
  local n         = #sp
  for i = 1, 16 do
    local rowIdx = math_floor((i - 1) / 4) * 4
    local pIdx   = subStart + (i - 1 - rowIdx) + rowIdx
    local isSel, isHil = false, false
    if pIdx <= n then
      isSel = selectionModel:isPlayerSelected(pIdx)
      isHil = selectionModel:isPlayerHighlighted(pIdx)
    end
    publish(BND_SELSR[i],   isSel)
    publish(BND_HILSR[i],   isHil)
    local fc = isHil and COL_BLACK or COL_WHITE
    publish(BND_SNAM_FC[i], fc)
    publish(BND_SPOS_FC[i], fc)
    publish(BND_SOVR_FC[i], fc)
  end
end

-- ── Info panel (single player / comparison) ───────────────────────────────────

function UIModel:displayInfoPanel(ptype, squadModel, selectionModel)
  if not publish then return end
  local sp = squadModel:getPlayers()
  if not sp then return end

  local highlighted = selectionModel:getHighlightedPlayer()
  local sel1, sel2  = selectionModel:getSelectedPlayers()

  if ptype == "single" then
    publish("bnd_playerpanelvisible",           true)
    publish("bnd_playercomparisonpanelvisible", false)

    local target = highlighted or sel1
    if not target then return end
    local cid = sp[target.sheetIndex]
    local p   = squadModel:getPlayerById(cid)
    if not p then return end

    local isGK  = p.position == "GK"
    local rAttrib = isGK and ATTRIB_RIGHT_GK or ATTRIB_RIGHT
    local foot  = safeGetPlayerData("prefFoot", cid)
    local ht    = safeGetPlayerData("height", cid)
    local wt    = safeGetPlayerData("weight", cid)

    local playerData = {
      [1] = 100, [2] = 100, [3] = "Content",
      [4] = foot == 1 and "Right" or "Left",
      [5] = "Controlled", [6] = "-", [7] = "-",
      [8] = formatHeight(ht),
      [9]  = safeGetPlayerAge(cid),
      [10] = p.stat1, [11] = p.stat2, [12] = p.stat3,
      [13] = p.stat4, [14] = p.stat5, [15] = p.stat6,
      [16] = wt,
    }

    publish("bnd_selectedhead1",       { name = "$Head", id = cid })
    publish("bnd_playername1",         shortenName(p.playerName))
    publish("bnd_playernationality1",  { name = "$Flag128x128", id = p.nationalityID })
    publish("bnd_playerposition1",     p.position)
    publish("bnd_playerrating1",       p.rating)

    for n = 1, 8 do
      publish(BND_RATTRIB[n], rAttrib[n])
      publish(BND_LATTRIB[n], ATTRIB_LEFT[n])
      publish(BND_RVAL[n],    playerData[8 + n])
      publish(BND_LVAL[n],    playerData[n])
      publish(BND_RVALFC[n],  attribColor(playerData[8 + n]))
      publish(BND_LVALFC[n],  attribColor(playerData[n]))
    end

  elseif ptype == "double" then
    publish("bnd_playerpanelvisible",           false)
    publish("bnd_playercomparisonpanelvisible", true)

    local show = { sel1, highlighted }
    if not show[1] or not show[2] then return end

    local cid1 = sp[show[1].sheetIndex]
    local cid2 = sp[show[2].sheetIndex]
    local p1   = squadModel:getPlayerById(cid1)
    local p2   = squadModel:getPlayerById(cid2)
    if not p1 or not p2 then return end

    local isGK1 = p1.position == "GK"
    local isGK2 = p2.position == "GK"

    -- Select attribute list
    local attribField
    if isGK1 and isGK2 then
      attribField = ATTRIB_FULL_GK
    elseif not isGK1 and not isGK2 then
      attribField = ATTRIB_FULL
    else
      attribField = {
        "Name","OVR","Fitness","Sharpness","Morale","Current Position","Position(s)"
      }
      for i = 1, 6 do
        local lbl = isGK1 and (STAT_GK[i] .. "/" .. STAT_NORMAL[i])
                           or  (STAT_NORMAL[i] .. "/" .. STAT_GK[i])
        attribField[7 + i] = lbl
      end
      attribField[14] = "Height"; attribField[15] = "Foot"; attribField[16] = "Weight"
    end

    local maxOff    = 16 - 10 + 1
    local scrOff    = self.comparisonScrollOffset
    local cursorPos = ((scrOff - 1) / (maxOff - 1)) * 100
    publish("bnd_comparisonrowpos", cursorPos)

    for n = 1, 10 do
      local ai = scrOff + n - 1
      publish(BND_CATTR[n], ai <= #attribField and attribField[ai] or nil)
    end

    local players = { p1, p2 }
    local cids    = { cid1, cid2 }
    local isGKs   = { isGK1, isGK2 }

    for pi = 1, 2 do
      local p   = players[pi]
      local cid = cids[pi]
      local isGK = isGKs[pi]
      local ht  = safeGetPlayerData("height", cid)
      local wt  = safeGetPlayerData("weight", cid)
      local foot = safeGetPlayerData("prefFoot", cid)

      local pData = {
        [1] = p.playerName, [2] = p.rating,
        [3] = 100, [4] = 100, [5] = "Content",
        [6] = p.position,   [7] = p.position,
        [8] = p.stat1,  [9] = p.stat2,  [10] = p.stat3,
        [11] = p.stat4, [12] = p.stat5, [13] = p.stat6,
        [14] = formatHeight(ht),
        [15] = foot == 1 and "Right" or "Left",
        [16] = wt,
      }

      publish("bnd_selectedhead" .. pi, { name = "$Head", id = cid })
      publish("bnd_playerrating" .. pi, p.rating)

      local other     = players[3 - pi]
      local otherData = {
        [8] = other.stat1,  [9] = other.stat2,  [10] = other.stat3,
        [11] = other.stat4, [12] = other.stat5, [13] = other.stat6,
        [14] = safeGetPlayerData("height", cids[3 - pi]) or 0,
        [16] = safeGetPlayerData("weight", cids[3 - pi]) or 0,
      }

      local bndVal = pi == 1 and BND_C1VAL or BND_C2VAL
      local bndFC  = pi == 1 and BND_C1FC  or BND_C2FC
      local sameType = isGK1 == isGK2

      for n = 1, 10 do
        local ai  = scrOff + n - 1
        if ai <= #attribField then
          publish(bndVal[n], pData[ai])
          local col = COL_WHITE
          if sameType and ai >= 8 and (ai <= 14 or ai == 16) then
            local tv = tonumber(pData[ai])
            local ov = tonumber(otherData[ai])
            if tv and ov then
              col = tv > ov and COL_BRGREEN or COL_WHITE
            end
          else
            col = attribColor(pData[ai])
          end
          publish(bndFC[n], col)
        else
          publish(bndVal[n], nil)
          publish(bndFC[n],  nil)
        end
      end
    end
  end
end

-- ── Validation helper (used by legacy full-panel path) ────────────────────────

function UIModel:validateSubsDisplay(squadModel)
  self:_publishValidSubs(squadModel)
end

-- ── Teardown ──────────────────────────────────────────────────────────────────

function UIModel:finalize()
  if self._stageTimer then
    self._stageTimer:finalize()
    self._stageTimer = nil
  end
  self.subData = nil
  publish      = nil
  self         = nil
  UIModel      = nil
end

return UIModel

local Config, SquadModel, Squads, SelectionModel, UIModel, ConfigModel, TacticsPanel, FCPopup, sessionVars, UIManager, Timer, Sheets = ...

local Squad = {}

-- ── Module-level upvalues ─────────────────────────────────────────────────────
local subscribe, registerAction, publish
local math_floor = math.floor
local math_max   = math.max
local math_min   = math.min

-- ── Pre-computed constants ────────────────────────────────────────────────────
local FADE_STEPS = math_max(1, math_floor(0.5 / 0.016))   -- ~31 at 60fps

-- ── Helpers ───────────────────────────────────────────────────────────────────

local function getPlayerIdxByID(playerID)
  local squad = getCachedTeamPlayers(currentSelectedTeamID)
  for i = 1, #squad do
    if squad[i].CARD_ID == playerID then return i end
  end
  return Config.PLAYER_RANGES.starting.count
end

-- ── Unified alpha fade (in or out) ───────────────────────────────────────────
-- fromA / toA are numbers in [0,1]; callback fires on completion.

local function startFade(self, fromA, toA, callback)
  if self.alphaTimer then
    self.alphaTimer:finalize()
    self.alphaTimer = nil
  end
  self.isAlphaAnimating = true
  local steps = FADE_STEPS
  local pub   = publish  -- capture upvalue once

  local function step(n)
    if not self.isAlphaAnimating then
      self.alphaTimer = nil
      if callback then callback() end
      return
    end
    if n > steps then
      self.alphaTimer       = nil
      self.isAlphaAnimating = false
      pub("bnd_alpha", toA)
      if callback then callback() end
      return
    end
    local t   = n / steps
    local ea  = 1 - (1 - t) * (1 - t)   -- quadratic ease-out
    pub("bnd_alpha", math_floor((fromA + (toA - fromA) * ea) * 100 + 0.5) * 0.01)
    self.alphaTimer = Timer:new({
      id = "fade_" .. n, interval = 0.016, reps = 1,
      onTimerComplete = function() step(n + 1) end
    })
    self.alphaTimer:start()
  end

  -- Start on next tick so caller stack unwinds first
  self.alphaTimer = Timer:new({
    id = "fade_start", interval = 0, reps = 1,
    onTimerComplete = function()
      if self.isAlphaAnimating then step(1)
      else
        self.alphaTimer = nil
        if callback then callback() end
      end
    end
  })
  self.alphaTimer:start()
end

-- ── Constructor ───────────────────────────────────────────────────────────────

function Squad:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  initTheme(o.im)

  -- Services
  o.services = {
    settingsService       = o.api("SettingsService"),
    TacticsService        = o.api("TacticsService"),
    SquadManagementService = o.api("SquadMgtService"),
  }
  o.currentOptions = o.services.settingsService.GetCurrentOptions()

  -- ── State ────────────────────────────────────────────────────────────────
  o.sheetIdx            = sessionVars.get("sheetIdx") or 1
  o.currSheetIdx        = o.sheetIdx
  o.sheetToggle         = false
  o.formationID         = o.services.TacticsService.GetFormation(0, currentSelectedTeamID)
  o.formationChanged    = false
  o.currentFormationID  = o.formationID
  o.isAlphaAnimating    = false
  o.alphaTimer          = nil
  o.swipeSubY           = 0
  o.swipeComparisonY    = 0
  o.debugPlayer         = 1
  o.valueDebug          = 1

  -- ── Config model ─────────────────────────────────────────────────────────
  o.configModel = ConfigModel:new({ Config = Config })

  -- ── Highlighted player + scroll offset ───────────────────────────────────
  local hubId = sessionVars.get("hubId")
  o.highlightedPlayerIndex = (hubId and getPlayerIdxByID(hubId))
                             or Config.PLAYER_RANGES.starting.count
  local scrollOffset = o:calculateScrollOffset(o.highlightedPlayerIndex)

  -- ── Squad model ───────────────────────────────────────────────────────────
  o.squadModel = SquadModel:new({
    Config = Config, Squads = Squads,
    scrollOffset = scrollOffset, nav = o.nav,
  })

  -- Reconcile local sheet with live roster (add/remove without service write)
  for i = 1, 4 do
    local sheetData = sessionVars.get("sheetData")
    if sheetData and sheetData[i] then
      sheetData[i].players = o.squadModel:syncWithLiveLineup(currentSelectedTeamID, sheetData[i].players)
    end
  end
  

  -- Restore saved sheet (preserves swap order from previous visit)
  local savedSheetData = sessionVars.get("sheetData")
  if savedSheetData then
    local savedSheet = savedSheetData[o.sheetIdx]
    if savedSheet and savedSheet.players and #savedSheet.players > 0 then
      o.squadModel:setPlayers(savedSheet.players)
      if savedSheet.fID then
        o.formationID        = savedSheet.fID
        o.currentFormationID = savedSheet.fID
      end
    end
  end

  -- ── Selection model ───────────────────────────────────────────────────────
  o.selectionModel = SelectionModel:new({
    Config = Config,
    highlightedPlayerIndex = o.highlightedPlayerIndex,
  })

  -- ── UI model ──────────────────────────────────────────────────────────────
  o.uiModel = UIModel:new({
    Config            = Config,
    im                = o.im,
    formationID       = o.formationID,
    screenMode        = "career",
    getFormation      = function() return o:getFormation() end,
    switchDisplayAnim = function(stage) o:switchPanelAnim(stage) end,
    api               = init.api,
    init              = init,
  })

  -- ── Tactics panel ─────────────────────────────────────────────────────────
  o.TacticsPanel = TacticsPanel:new({
    uiModel      = o.uiModel,
    im           = o.im,
    Config       = Config,
    getFormation = function() return o:getFormation() end,
    setFormation = function(id, mode) o:formationChange(id, mode) end,
  })

  o.FCPopup         = FCPopup:new({ nav = o.nav })
  o.debugPlayerAxis = Config.FORMATION_POSITIONS["formation" .. tostring(o.formationID)] or {}

  -- Wire im shortcuts
  subscribe      = o.im.Subscribe
  registerAction = o.im.RegisterAction
  publish        = o.im.Publish

  o:setupBindings()
  o:setupActions()

  -- Prepare data then kick off staged UI load
  -- (screen opens after :new() returns; stage 0 publishes text immediately)
  o.squadModel:updateSquadData()
  o.uiModel:markDirty()
  o.uiModel:startProgressiveLoad(o.squadModel, o.selectionModel, o.TacticsPanel, Timer)

  return o
end

-- ── Update (called by engine each frame) ──────────────────────────────────────

function Squad:update(elapsedTime)
  if self.alphaTimer then
    self.alphaTimer:update(elapsedTime)
  end
  -- Tick UIModel's stage timer so progressive loading advances
  self.uiModel:update(elapsedTime)
end

-- ── Scroll offset calculator ──────────────────────────────────────────────────

function Squad:calculateScrollOffset(playerIndex)
  local ranges       = self.configModel:getPlayerRanges()
  local startCount   = ranges.starting.count
  local subCount     = ranges.subres.count
  local perSet       = 4

  if playerIndex <= startCount then return 0 end

  local subIdx    = playerIndex - startCount
  local effOff    = math_floor((subIdx - 1) / perSet)
  local maxOff    = math_max(0, math.ceil(subCount / perSet) - 1)
  if effOff > 2 then effOff = effOff - 2 end
  return math_min(effOff, maxOff)
end

-- ── Bindings setup ────────────────────────────────────────────────────────────

function Squad:setupBindings()
  local ui  = self.uiModel
  local sq  = self.squadModel
  local sel = self.selectionModel

  -- Bulk-subscribe helper
  local function subN(prefix, count, suffix, cb)
    local suf = suffix or ""
    for i = 1, count do
      subscribe(prefix .. ((count > 1) and i or "") .. suf, cb)
    end
  end

  local function onPanel()     ui:publishPanel(sq) end
  local function onSub()       ui:publishSubResPanel(sq) end
  local function onSelection() ui:publishSelectionBindings(sq, sel) end
  local function onHead()      ui:publishSelectedHead(sq, sel) end
  local function onFonts()     ui:publishFontColors(sq, sel) end
  local function onSheet()
    ui:publishSheetPanel(self.sheetIdx, self:getSheetFormationID(), self.currSheetIdx, self.sheetToggle)
  end

  -- Panel bindings
  subN("bnd_head",        16, nil,   onPanel)
  subN("bnd_name",        16, nil,   onPanel)
  subN("bnd_pos",         16, nil,   onPanel)
  subN("bnd_ovr",         16, nil,   onPanel)
  subN("bnd_posIcon",     16, nil,   onPanel)
  subN("bnd_validSub",    16, nil,   onPanel)
  subN("bnd_starting",    11, nil,   onPanel)
  subN("bnd_sub",         16, "stamina",      onPanel)
  subN("bnd_sub",         16, "staminacolor", onPanel)
  subN("bnd_pl",          11, "stamina",      onPanel)
  subN("bnd_pl",          11, "staminacolor", onPanel)
  subN("bnd_startingname", 11, nil,  onPanel)
  subN("bnd_startingpos",  11, nil,  onPanel)
  subN("bnd_startingovr",  11, nil,  onPanel)
  subN("bnd_posTop",       11, nil,  onPanel)
  subN("bnd_posLeft",      11, nil,  onPanel)
  subN("bnd_isInj",        11, nil,  onPanel)
  subN("bnd_isRc",         11, nil,  onPanel)

  -- Selection bindings
  subN("bnd_selected",           11, nil, onSelection)
  subN("bnd_highlighted",        11, nil, onSelection)
  subN("bnd_selectedsubres",     16, nil, onSelection)
  subN("bnd_highlightedsubres",  16, nil, onSelection)

  -- Font colors
  subN("bnd_ovrfontcolor",        16, nil, onFonts)
  subN("bnd_posfontcolor",        16, nil, onFonts)
  subN("bnd_namefontcolor",       16, nil, onFonts)
  subN("bnd_startingnamecolor",   11, nil, onFonts)

  -- Attrib panel
  subN("bnd_rightplayerattribvalue",      16, nil, onHead)
  subN("bnd_leftplayerattribvalue",       16, nil, onHead)
  subN("bnd_rightplayerattrib",           16, nil, onHead)
  subN("bnd_leftplayerattrib",            16, nil, onHead)
  subN("bnd_rightplayerattribvaluecolor", 16, nil, onHead)
  subN("bnd_leftplayerattribvaluecolor",   3, nil, onHead)

  -- Comparison panel
  subN("bnd_comparisonattrib",                10, nil, onSelection)
  subN("bnd_comparisonplayer1attribvalue",    10, nil, onSelection)
  subN("bnd_comparisonplayer2attribvalue",    10, nil, onSelection)
  subN("bnd_comparisonplayer1attribvaluecolor", 10, nil, onSelection)
  subN("bnd_comparisonplayer2attribvaluecolor", 10, nil, onSelection)

  -- Sub-res drawer
  subN("bnd_subresrow", 4, "X",     onSub)
  subN("bnd_subresrow", 2, "extra", onSub)

  -- Sheet panel
  subscribe("bnd_currentSheet",   onSheet)
  subscribe("bnd_sheetname",      onSheet)
  subscribe("bnd_sheetinfo",      onSheet)
  subscribe("bnd_displaysheets",  function()
    ui:publishSheetPanel(self.sheetIdx, self:getSheetFormationID(),
                         self.currSheetIdx, self.sheetToggle)
  end)

  -- Misc
  subscribe("bnd_formationname",                  function() self.TacticsPanel:displayFormation() end)
  subscribe("bnd_playerpanelvisible",             onSelection)
  subscribe("bnd_playercomparisonpanelvisible",   onSelection)
  subscribe("bnd_selectedhead1",                  onHead)
  subscribe("bnd_selectedhead2",                  onHead)
  subscribe("bnd_playername1",                    onHead)
  subscribe("bnd_playernationality1",             onHead)
  subscribe("bnd_playerposition1",               onHead)
  subscribe("bnd_playername2",                    onHead)
  subscribe("bnd_playernationality2",             onHead)
  subscribe("bnd_playerposition2",               onHead)
  subscribe("bnd_playerrating1",                  onHead)
  subscribe("bnd_playerrating2",                  onHead)
  subscribe("bnd_rowpos",                         onPanel)
  subscribe("bnd_rowheight",                      onPanel)
  subscribe("bnd_subrespanelheight",              onSub)
  subscribe("bnd_subressubslabel",                onSub)
  subscribe("bnd_subressubslabelY",               onSub)
  subscribe("bnd_subresreslabel",                 onSub)
  subscribe("bnd_subresreslabelY",                onSub)
  subscribe("bnd_mainXIclarity",                  onSub)
  subscribe("bnd_comparisonrowpos",               onSelection)
  subscribe("currentPlayerEdit",                  function() self:squadDebug() end)
  subscribe("currentPlayerEditX",                 function() self:squadDebug() end)
  subscribe("currentPlayerEditY",                 function() self:squadDebug() end)
  subscribe("currentValue",                       function() self:squadDebug() end)
  subscribe("bnd_alpha",                          function() publish("bnd_alpha", 1) end)
end

-- ── Actions setup ─────────────────────────────────────────────────────────────

function Squad:setupActions()
  local ranges = self.configModel:getPlayerRanges()

  for i = 1, ranges.starting.count do
    local idx = i
    registerAction("act_player" .. i, function()
      self:onSelect(idx, "starting")
    end)
  end

  for i = 1, ranges.subres.count do
    local idx = i
    registerAction("act_subres" .. i, function()
      self:onSelect(idx, "subres")
    end)
  end

  for i = 1, 2 do
    local idx = i
    registerAction("act_scrollbtn" .. i, function()
      self:scrollBtn(idx)
    end)
  end

  for i = 1, 8 do
    local idx = i
    registerAction("debugAction" .. i, function()
      self:debugEvts(idx)
    end)
  end

  for i = 1, 2 do
    local idx = i
    registerAction("act_scrollinfo" .. i, function()
      self:scrollComparison(self.swipeComparisonY)
    end)
  end

  for i = 1, 2 do
    local idx = i
    registerAction("act_toggleformation" .. i, function()
      self.TacticsPanel:toggleFormation(idx)
    end)
  end

  registerAction("act_confirm", function()
    self:displayConfirmationMsg()
  end)

  registerAction("act_confirmTactics", function()
    self:displayTacticsConfirmation()
  end)

  registerAction("act_togglesheets", function()
    self.sheetToggle = not self.sheetToggle
    self.uiModel:publishSheetPanel(self.sheetIdx, self:getSheetFormationID(),
                                   self.currSheetIdx, self.sheetToggle)
  end)

  registerAction("selectSheet", function()
    self:doSelectSheet()
  end)

  registerAction("act_toggleSheetright", function() self:toggleSheet(1)  end)
  registerAction("act_toggleSheetleft",  function() self:toggleSheet(-1) end)

  self.im.RegisterDataAction("bnd_swipeSubs", "act_swipeSubs", function(_, _, panEvent)
    local panY = panEvent.panY * -1
    local Y    = panY > 0 and 50 or -50
    self.swipeSubY = math_max(0, self.swipeSubY + panY + Y)
    if self.swipeSubY > 0 then self:subsDrawerAction(self.swipeSubY) end
  end)

  self.im.RegisterDataAction("bnd_swipePlayerComparison", "act_swipePlayerComparison",
    function(_, _, panEvent)
      local panY = panEvent.panY * -1
      local Y    = panY > 0 and 30 or -30
      self.swipeComparisonY = math_max(0, self.swipeComparisonY + panY + Y)
      if self.swipeComparisonY > 0 then self:scrollComparison(self.swipeComparisonY) end
    end)

  self.im.RegisterDataAction("bnd_dragCursorComparison", "act_dragCursorComparison",
    function(_, _, panEvent)
      local panY = panEvent.panY
      local Y    = panY > 0 and 30 or -30
      self.swipeComparisonY = math_max(0, self.swipeComparisonY + panY + Y)
      if self.swipeComparisonY > 0 then self:scrollComparison(self.swipeComparisonY) end
    end)

  self.nav.AddActionHandler("killScreen", false, nil, function()
    self:finalize()
  end)
end

-- ── Sheet operations ──────────────────────────────────────────────────────────

function Squad:doSelectSheet()
  local sheetData    = sessionVars.get("sheetData")
  local TeamCachedData = sessionVars.get("TeamCachedData")

  if not sheetData then
    sheetData = {}
    sheetData[1] = { players = self.squadModel:getPlayers(), fID = self.formationID }
    if self.currSheetIdx ~= 1 then
      sheetData[self.currSheetIdx] = { players = self.squadModel:getPlayers(), fID = self.formationID }
    end
  else
    sheetData[self.sheetIdx] = { players = self.squadModel:getPlayers(), fID = self:getFormation() }
    if not sheetData[self.currSheetIdx] then
      local src = sheetData[self.sheetIdx]
      sheetData[self.currSheetIdx] = {
        players = src and src.players or self.squadModel:getPlayers(),
        fID     = src and src.fID    or self:getFormation(),
      }
    end
  end

  local targetSheet = sheetData[self.currSheetIdx]

  -- Load target sheet player order into SquadModel
  self.squadModel:setPlayers(targetSheet.players)

  -- Apply target formation
  local targetFID = targetSheet.fID
  if targetFID then
    self.formationID        = targetFID
    self.formationChanged   = false
    self.currentFormationID = targetFID
    self.debugPlayerAxis    = Config.FORMATION_POSITIONS["formation" .. tostring(targetFID)] or {}
    self.TacticsPanel:displayFormation()
  end

  -- Sync service lineup (required so GetCurrentPlayerLineup stays consistent)
  self.services.SquadManagementService.SetCurrentPlayerLineup(
    0, currentSelectedTeamID, 0, 0, targetSheet.players)
  local updatedPlayers = self.services.SquadManagementService.GetCurrentPlayerLineup(
    0, currentSelectedTeamID, 0)
  if TeamCachedData and TeamCachedData[currentSelectedTeamID] then
    TeamCachedData[currentSelectedTeamID].players = updatedPlayers
    sessionVars.set("TeamCachedData", TeamCachedData)
  end

  sessionVars.set("sheetIdx",  self.currSheetIdx)
  sessionVars.set("sheetData", sheetData)
  self.sheetIdx = self.currSheetIdx

  -- Rebuild data and refresh UI
  self.squadModel:updateSquadData()
  self.uiModel:markDirty()
  self.selectionModel:clearSelections()
  self.uiModel:publishPanel(self.squadModel)
  self.uiModel:publishSelectionBindings(self.squadModel, self.selectionModel)
  self.uiModel:publishSheetPanel(self.sheetIdx, targetFID, self.currSheetIdx, true)
end

function Squad:toggleSheet(dir)
  local sheetData = sessionVars.get("sheetData") or {}
  local count = 0
  for _ in pairs(sheetData) do count = count + 1 end
  local existing = math_max(count, 1)
  local maxIdx   = math_min(existing + 1, 4)

  self.currSheetIdx = self.currSheetIdx + dir
  if self.currSheetIdx < 1 then
    self.currSheetIdx = maxIdx
  elseif self.currSheetIdx > maxIdx then
    self.currSheetIdx = 1
  end

  self.uiModel:publishSheetPanel(self.sheetIdx, self:getSheetFormationID(),
                                  self.currSheetIdx, true)
end

function Squad:getSheetFormationID()
  local sheetData = sessionVars.get("sheetData") or {}
  local sheet = sheetData[self.currSheetIdx]
  return (sheet and sheet.fID)
      or (self.currSheetIdx == 1 and self.formationID)
      or nil
end

-- ── Player selection / swap ───────────────────────────────────────────────────

function Squad:onSelect(playerIndex, ptype)
  local sheetIndex  = self.squadModel:getSheetIndex(playerIndex, ptype)
  local swapOccurred = self.selectionModel:selectPlayer(playerIndex, ptype, sheetIndex)
  if swapOccurred then
    local s1, s2 = self.selectionModel:getSelectedPlayers()
    self.squadModel:swapPlayers(s1.sheetIndex, s2.sheetIndex)
    self.selectionModel:clearSelections()
    self.squadModel:updateSquadData()
    self.uiModel:markDirty()
    self:saveSquad()
    self.uiModel:publishPanel(self.squadModel)
  end
  self.uiModel:publishSelectionBindings(self.squadModel, self.selectionModel)
end

-- ── Save squad to service + session ──────────────────────────────────────────

function Squad:saveSquad()
  local sheetPlayers   = self.squadModel:getPlayers()
  local TeamCachedData = sessionVars.get("TeamCachedData")
  local sheetData      = sessionVars.get("sheetData")

  self.services.SquadManagementService.SetCurrentPlayerLineup(
    0, currentSelectedTeamID, 0, 0, sheetPlayers)
  local players = self.services.SquadManagementService.GetCurrentPlayerLineup(
    0, currentSelectedTeamID, 0)
  if TeamCachedData and TeamCachedData[currentSelectedTeamID] then
    TeamCachedData[currentSelectedTeamID].players = players
    sessionVars.set("TeamCachedData", TeamCachedData)
  end
  
  local obj = Squads.getBaseCachedTeamPlayers(currentSelectedTeamID)
  local playerIDs = {}
  for k = 1, #obj do
    playerIDs[k] = obj[k].CARD_ID
  end
 self.services.SquadManagementService.SetCurrentPlayerLineup(0, currentSelectedTeamID, 0, 0, playerIDs)

  if not sheetData then
    sessionVars.set("currentPlayersID", sheetPlayers)
  else
    sheetData[self.currSheetIdx] = { players = self.squadModel:getPlayers(), fID = self:getFormation() }
    sessionVars.set("sheetData", sheetData)
    sessionVars.set("sheetIdx",  self.currSheetIdx)
  end
end

-- ── Formation ─────────────────────────────────────────────────────────────────

function Squad:getFormation()
  return self.formationChanged and self.currentFormationID or self.formationID
end

function Squad:formationChange(id, mode)
  mode = mode or 1
  if mode == 2 then
    self.services.TacticsService.SetFormation(0, currentSelectedTeamID, id)
    self.formationID = id
  end
  self.formationChanged    = true
  self.currentFormationID  = id
  self.debugPlayerAxis     = Config.FORMATION_POSITIONS["formation" .. tostring(id)] or {}
  self.squadModel:updateSquadData()
  self.uiModel:markDirty()
  self.uiModel:publishPanel(self.squadModel)
  self.TacticsPanel:displayFormation()

  local sheetData = sessionVars.get("sheetData")
  if sheetData and sheetData[self.currSheetIdx] then
    sheetData[self.currSheetIdx].fID = id
    sessionVars.set("sheetData", sheetData)
  end
end

function Squad:defaultFormation()
  self.formationChanged = false
end

-- ── Panel switch animation ────────────────────────────────────────────────────

function Squad:switchPanelAnim(stage)
  if stage == 1 then
    startFade(self, 1, 0, nil)
  else
    startFade(self, 0, 1, nil)
  end
end

-- ── Scroll ────────────────────────────────────────────────────────────────────

function Squad:scrollBtn(btn)
  if self.squadModel:scrollSubPanel(btn) then
    self.uiModel:cacheSubData(self.squadModel)
    self.uiModel:markDirty()
    self.uiModel:publishPanel(self.squadModel)
    self.uiModel:publishSubResPanel(self.squadModel)
    self.uiModel:publishSelectionBindings(self.squadModel, self.selectionModel)
  end
end

function Squad:subsDrawerAction(Y)
  local offset    = math_floor(Y / 100)
  local maxOffset = self.squadModel:getMaxScrollOffset()
  if offset <= maxOffset then
    self.squadModel:setOffset(offset)
    self.uiModel:cacheSubData(self.squadModel)
    self.uiModel:markDirty()
    self.uiModel:publishPanel(self.squadModel)
    self.uiModel:publishSubResPanel(self.squadModel)
    self.uiModel:publishSelectionBindings(self.squadModel, self.selectionModel)
  else
    self.swipeSubY = maxOffset * 100
  end
end

function Squad:scrollComparison(Y)
  local offset   = math_max(1, math_floor(Y / 60))
  local maxOff   = (16 - 10 + 2) * 60
  if self.swipeComparisonY <= maxOff then
    self.uiModel.comparisonScrollOffset = offset
  end
  local cursorPos = ((self.uiModel.comparisonScrollOffset - 1) / (maxOff - 1)) * 100
  publish("bnd_comparisonrowpos", cursorPos)
  self.uiModel:displayInfoPanel("double", self.squadModel, self.selectionModel)
  self.swipeComparisonY = math_min(self.swipeComparisonY, maxOff)
end

-- ── Confirmation dialogs ──────────────────────────────────────────────────────

function Squad:displayConfirmationMsg()
  self.FCPopup:getResponse("Do you want to advance into tactics editing?",
    {"Yes", "No"}, function(r)
      if r == 1 then self.nav.Event(nil, "evt_TacticsEditor") end
    end)
end

function Squad:displayTacticsConfirmation()
  if self.currentFormationID == self.formationID then
    self.nav.Event(nil, "evt_toSquad")
    return
  end
  self.FCPopup:getResponse(
    "Leaving without saving can cause unsaved work not to be saved, Do you want to save tactics change?",
    {"Yes", "No"}, function(r)
      if r == 1 then
        self.nav.Event(nil, "evt_toSquad")
        self:formationChange(self.currentFormationID, 2)
      elseif r == 2 then
        self.nav.Event(nil, "evt_toSquad")
        self:defaultFormation()
      end
    end)
end

-- ── Auto squad picker ─────────────────────────────────────────────────────────

function Squad:pickSquad(teamID, strength)
  local benchSize = 7
  local players   = self.services.SquadManagementService.GetCurrentPlayerLineup(0, teamID, 0)
  local byPos, posOrder = {}, {}

  for i = 1, #players do
    local p   = players[i]
    local pos = p.position
    if not byPos[pos] then byPos[pos] = {}; posOrder[#posOrder + 1] = pos end
    byPos[pos][#byPos[pos] + 1] = p
  end

  for _, pos in ipairs(posOrder) do
    table.sort(byPos[pos], function(a, b) return a.rating > b.rating end)
  end

  local posCounts = {}
  for _, pos in ipairs(posOrder) do posCounts[pos] = #byPos[pos] end

  local function pickIdx(pos, mode)
    local count = posCounts[pos]
    if count == 0 then return nil end
    local list, totalW, weights = byPos[pos], 0, {}
    for i = 1, count do
      local r = list[i].rating
      local w = mode == "strong" and math.exp((r - 60) * 0.2)
             or mode == "weak"   and math.exp((100 - r) * 0.2)
             or 1.0
      weights[i] = w; totalW = totalW + w
    end
    local rnd, cum = math.random() * totalW, 0
    for i = 1, count do
      cum = cum + weights[i]
      if rnd <= cum then return i end
    end
    return 1
  end

  local function removeAt(pos, idx)
    if not idx then return end
    local list  = byPos[pos]
    local count = posCounts[pos]
    for i = idx, count - 1 do list[i] = list[i + 1] end
    list[count] = nil; posCounts[pos] = count - 1
  end

  local startMode = strength == "strong" and "strong"
                 or strength == "weak"   and "weak"
                 or "balanced"
  local benchMode = "strong"

  local function selectPlayers(startSlot, count, mode, out)
    for i = 1, count do
      local orig = players[startSlot + i - 1]
      if orig then
        local pos   = orig.position
        local pi    = pickIdx(pos, mode)
        local chosen = pi and byPos[pos][pi] or orig
        out[#out + 1] = chosen
        removeAt(pos, pi)
      end
    end
  end

  local starting11, bench = {}, {}
  selectPlayers(1,  11,        startMode, starting11)
  selectPlayers(12, benchSize, benchMode, bench)

  local finalSquad, idx = {}, 1
  for _, p in ipairs(starting11) do finalSquad[idx] = p.CARD_ID; idx = idx + 1 end
  for _, p in ipairs(bench)      do finalSquad[idx] = p.CARD_ID; idx = idx + 1 end
  for _, pos in ipairs(posOrder) do
    local list = byPos[pos]
    for i = 1, posCounts[pos] do finalSquad[idx] = list[i].CARD_ID; idx = idx + 1 end
  end

  local TeamCachedData = sessionVars.get("TeamCachedData")
  self.services.SquadManagementService.SetCurrentPlayerLineup(0, teamID, 0, 0, finalSquad)
  local updated = self.services.SquadManagementService.GetCurrentPlayerLineup(0, teamID, 0)
  if TeamCachedData and TeamCachedData[teamID] then
    TeamCachedData[teamID].players = updated
    sessionVars.set("TeamCachedData", TeamCachedData)
  end
end

-- ── Debug helpers ─────────────────────────────────────────────────────────────

function Squad:debugEvts(btn)
  local axis = self.debugPlayerAxis
  if not axis or type(axis) ~= "table" then return end
  local pidx = self.debugPlayer

  if     btn == 1 and pidx > 1        then self:squadDebug(pidx - 1)
  elseif btn == 2 and pidx < #axis    then self:squadDebug(pidx + 1)
  elseif btn == 3 then axis[pidx].left  = axis[pidx].left  - self.valueDebug; self:squadDebug(axis)
  elseif btn == 4 and axis[pidx] then  axis[pidx].left  = axis[pidx].left  + self.valueDebug; self:squadDebug(axis)
  elseif btn == 5 then axis[pidx].top   = axis[pidx].top   - self.valueDebug; self:squadDebug(axis)
  elseif btn == 6 and axis[pidx] then  axis[pidx].top   = axis[pidx].top   + self.valueDebug; self:squadDebug(axis)
  elseif btn == 7 then self.valueDebug = math_max(0, self.valueDebug - 1); self:squadDebug()
  elseif btn == 8 then self.valueDebug = self.valueDebug + 1;              self:squadDebug()
  end
end

function Squad:squadDebug(data)
  local pidx = self.debugPlayer
  if data then
    if type(data) == "number" then
      pidx = data; self.debugPlayer = pidx
    elseif type(data) == "table" then
      for i = 1, 11 do
        if data[i] then
          publish("bnd_posTop"  .. i, data[i].top)
          publish("bnd_posLeft" .. i, data[i].left)
        end
      end
    end
  end
  local axis = self.debugPlayerAxis
  if axis and axis[pidx] then
    publish("currentPlayerEdit",  "player " .. pidx)
    publish("currentPlayerEditX", axis[pidx].left or 0)
    publish("currentPlayerEditY", axis[pidx].top  or 0)
    publish("currentValue",       self.valueDebug or 1)
  else
    publish("currentPlayerEdit",  "invalid player " .. pidx)
    publish("currentPlayerEditX", 0)
    publish("currentPlayerEditY", 0)
  end
end

-- ── Teardown ──────────────────────────────────────────────────────────────────

function Squad:finalize()
  sessionVars.set("currentFormationID", self:getFormation())
  self.squadModel:finalize()
  self.selectionModel:finalize()
  self.uiModel:finalize()
  self.configModel = nil
  sessionVars.set("hubIdx", nil)
  self  = nil
  Squad = nil
end

return Squad

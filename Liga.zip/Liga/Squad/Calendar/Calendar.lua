local SelectLeagueTeam = {}

-- Required bindings
local bnd_player_index = "bnd_player_index"
local bnd_player_list = "bnd_player_list"
local BND_SELECTED_LEAGUE_NAME = "bnd_selected_league_name"
local BND_LEAGUE_OVERLAY_VISIBLE = "bnd_league_overlay_visible"
local BND_LEAGUE_CREST = "bnd_league_crest"
local BND_DEFAULT_CELL_DATA = "bnd_default_cell_data"
local bnd_player_list_INDEX = "bnd_player_list_index"
local ACT_SELECT_LEAGUE = "act_select_league"
local ACT_SELECTOR_CANCEL = "act_selector_cancel"
local ACT_CHANGE = "act_change"
local ACT_TOSHORTLIST = "act_toshortlist"
local ACT_REMOVE = "act_remove"
local NUM_COLUMNS = 4

function SelectLeagueTeam:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  initTheme(o.im)
  o.services = {SquadManagementService = o.api("SquadMgtService"), TeamService = o.api("TeamService")}  
  -- Ensure nav is set, with a loud fallback if missing
  o.nav = init and init.nav or { Event = function(_, event, data) print("Fallback Nav Event Triggered: " .. event .. ", Data: " .. tostring(data)) end }
  if not init or not init.nav then print("WARNING: self.nav not provided in init, using fallback!") end
  o.playerIndex = 1
  o:getPlayers()
  o:registerBindings()
  o.im.Subscribe(BND_LEAGUE_CREST, function()
    o:publishPlayerHead()
  end)
  o.im.Subscribe(bnd_player_list_INDEX, function()
    o:publishPlayerIndex()
  end)
  o.defaultCellData = {
    label = "",
    image = {},
    id = -1
  }
  o.im.Subscribe(BND_DEFAULT_CELL_DATA, function()
    o.im.Publish(BND_DEFAULT_CELL_DATA, o.defaultCellData)
  end)
  o.im.RegisterAction(ACT_SELECTOR_CANCEL, function()
    o:onSelectorCancel()
  end)
  -- Grid selection action: Only updates selection, no popup
  o.im.RegisterDataAction(bnd_player_list_INDEX, ACT_CHANGE, function(bindingName, actionName, index)
    index = index + 1
    print("GRID CLICK DETECTED! Binding: " .. bindingName .. ", Action: " .. actionName .. ", New index: " .. index)
    if o.playersDataToPublish.data[o.playerIndex] then
      o.playersDataToPublish.data[o.playerIndex].selected = false
    end
    if o.playersDataToPublish.data[index] then
      o.playersDataToPublish.data[index].selected = true
      o.playersDataToPublish.index = index
      o:setSelectedPlayerIndex(index)
      o.im.Refresh(bnd_player_list)
      o:publishPlayerHead()
      print("Grid selection updated to player: " .. o.playersDataToPublish.data[index].label)
    else
      print("Index " .. index .. " out of bounds! Total players: " .. #o.playersDataToPublish.data)
    end
  end)
  -- Confirmation action: Triggers popup when selection is finalized
  o.im.RegisterDataAction(bnd_player_index, ACT_CHANGE, function(bindingName, actionName, index)
    print("CONFIRMATION DETECTED! Binding: " .. bindingName .. ", Action: " .. actionName .. ", Index: " .. index)
    o:toggleSelectorVisibility(false)
    o:setSelectedPlayerIndex(index)
    o:showWelcomePopup()
    o:publishPlayerInfo()
    o.im.ChangeActionState(ACT_SELECT_LEAGUE, o.im.GetActionState("VALID"))
    print("Selection finalized for player: " .. o.playersDataToPublish.data[index].label)
  end)
  o.im.RegisterAction(ACT_TOSHORTLIST, function(actionName, data)
    o:sendToShortlist()
  end)
  o.im.RegisterAction(ACT_REMOVE, function(actionName, data)
    o:removeFromScoutlist()
  end)
  -- Add a test action to manually trigger the popup for debugging
  o.im.RegisterAction("test_popup", function()
    print("Manual test_popup triggered!")
    o:showWelcomePopup()
    o:publishPlayerInfo()
  end)
  return o
end

function SelectLeagueTeam:daysLeftInTransferWindow(dateStr)
  -- Default to current date if no date provided
  dateStr = dateStr or "15/03/25"  -- Placeholder for March 15, 2025

  -- Parse the input date (DD/MM/YY)
  local day, month, year = dateStr:match("(%d%d)/(%d%d)/(%d%d)")
  if not day then
    print("[daysLeftInTransferWindow] Error: Invalid date format. Expected DD/MM/YY")
    return 0  -- Default fallback
  end

  day, month, year = tonumber(day), tonumber(month), tonumber(year)
  local fullYear = 2000 + year  -- Convert YY to YYYY (e.g., 25 → 2025)

  -- Convert date to day of year (approximate, no leap years)
  local daysInMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
  local currentDayOfYear = day
  for i = 1, month - 1 do
    currentDayOfYear = currentDayOfYear + daysInMonth[i]
  end

  -- Calculate day of year for transfer deadlines
  local summerDeadlineDay = 242  -- 30/08: 31(Jan) + 28(Feb) + 31(Mar) + 30(Apr) + 31(May) + 30(Jun) + 31(Jul) + 30(Aug) = 242
  local winterDeadlineDay = 30   -- 30/01: 30 days

  -- Adjust deadlines to the correct year
  local summerYear, winterYear
  if currentDayOfYear <= summerDeadlineDay then
    summerYear = fullYear  -- Summer window of the same year
    winterYear = fullYear  -- Winter window of the next year (if after Jan 30)
  else
    summerYear = fullYear + 1  -- Next summer
    winterYear = fullYear      -- Current winter (if before Jan 30) or next winter
  end

  -- Calculate absolute days to summer deadline
  local daysToSummer
  if fullYear == summerYear then
    daysToSummer = summerDeadlineDay - currentDayOfYear
  else
    daysToSummer = (365 - currentDayOfYear) + summerDeadlineDay + (summerYear - fullYear - 1) * 365
  end

  -- Calculate absolute days to winter deadline
  local daysToWinter
  if currentDayOfYear <= winterDeadlineDay then
    daysToWinter = winterDeadlineDay - currentDayOfYear
  else
    daysToWinter = (365 - currentDayOfYear) + winterDeadlineDay + (winterYear == fullYear and 0 or 365)
  end

  -- Ensure non-negative values (shouldn't happen, but for safety)
  daysToSummer = math.max(0, daysToSummer)
  daysToWinter = math.max(0, daysToWinter)

  -- Return the smaller distance as days left
  local daysLeft = math.min(daysToSummer, daysToWinter)
  return daysLeft
end

function SelectLeagueTeam:cacheTeamPlayers(teamID)
    local players = self.services.SquadManagementService.GetCurrentPlayerLineup(0, teamID, 0)
    TeamPlayerCache[teamID] = players or {}
end
function SelectLeagueTeam:publishPlayerInfo()
  local playerTeam = (self.playersDataToPublish.data[self.playerIndex]).image.teamID
  self:cacheTeamPlayers(playerTeam)
  local cardID = (self.playersDataToPublish.data[self.playerIndex]).image.id  -- Get the current player's CARD_ID
  local playerInfo = getPlayerInfo(cardID, playerTeam)  -- Use cardID instead of 239085
  local playerRating = playerInfo and playerInfo.rating
  local playerPosition = playerInfo and playerInfo.position
  local Index = playerInfo and playerInfo.index
  local repCount = playerReplacementCount(playerTeam, playerPosition)
  local days = self:daysLeftInTransferWindow(GLOBAL_DATE_PLACEHOLDER)
  local playervalue, minvalue = computeTransferValue(GetPlayerAge(cardID), playerRating, playerPosition, Index, repCount, days)
  statsInfo = { statsname1 = "Pace", statsname2 = "Shooting", statsname3 = "Passing", statsname4 = "Dribbling", statsname5 = "Defending", statsname6 = "Physical", statsnamegk1 = "Diving", statsnamegk2 = "Handling", statsnamegk3 = "Kicking", statsnamegk4 = "Reflexes", statsnamegk5 = "Speed", statsnamegk6 = "Positioning"}
  
  -- Debug output
  print("Computed values - Final: " .. tostring(playervalue) .. ", Min: " .. tostring(latestvalue))
  
    self.im.Publish("bnd_playervalue", "€" .. self.loc.LocalizeInteger(minvalue) .. "  –  " ..  "€" .. self.loc.LocalizeInteger(playervalue))
  for i = 1, 6 do
    self.im.Publish("bnd_player_stat"..i, ":  " .. playerInfo["stats"..i])
  end
  for i = 1, 6 do
    if playerInfo.position == "GK" then
      self.im.Publish("bnd_player_statname"..i, statsInfo["statsnamegk"..i])
    else
      self.im.Publish("bnd_player_statname"..i, statsInfo["statsname"..i])
    end
  end
  playerhead = { name = "$Head", id = cardID}
  playerteamcrest = { name = "$Crest", id = playerInfo.teamID}
  self.im.Publish("bnd_playerhead", playerhead)
  self.im.Publish("bnd_playerteamcrest", playerteamcrest)
  self.im.Publish("bnd_playername", playerInfo.name)
  self.im.Publish("bnd_playerteam", self.loc.LocalizeString("TeamName_Abbr15_" .. playerInfo.teamID))
  self.im.Publish("bnd_playerrating", playerInfo.rating)
  self.im.Publish("bnd_scoutcomment", "player scouting is still in progress")
  self.im.Publish("bnd_goalscount", GOALS[cardID] or 0)
  -- Refresh UI (if needed, depending on your framework)
end
function SelectLeagueTeam:getPlayers()
    local gridData = {}
local alternateBG = false
local GRIDS_PER_SET = 35 -- Each month gets its own set of 35 grids

-- Get the current year from GLOBAL_DATE_PLACEHOLDER (e.g., "19/03/25")
local dateStr = GLOBAL_DATE_PLACEHOLDER -- Assuming this returns "DD/MM/YY"
local day, month, year = dateStr:match("(%d%d)/(%d%d)/(%d%d)") -- Extract DD, MM, YY
year = tonumber(year)
if year then
    year = 2000 + year -- Convert YY to YYYY (e.g., 25 -> 2025)
else
    year = 2025 -- Fallback to 2025 if parsing fails
end

-- Function to check if it's a leap year
local function isLeapYear(y)
    return (y % 4 == 0 and y % 100 ~= 0) or (y % 400 == 0)
end

-- Define days in each month from August to July, adjusting February for leap year
local monthDays = {
    {month = "August", days = 31, mm = "08"},
    {month = "September", days = 30, mm = "09"},
    {month = "October", days = 31, mm = "10"},
    {month = "November", days = 30, mm = "11"},
    {month = "December", days = 31, mm = "12"},
    {month = "January", days = 31, mm = "01"},
    {month = "February", days = isLeapYear(year) and 29 or 28, mm = "02"},
    {month = "March", days = 31, mm = "03"},
    {month = "April", days = 30, mm = "04"},
    {month = "May", days = 31, mm = "05"},
    {month = "June", days = 30, mm = "06"},
    {month = "July", days = 31, mm = "07"}
}

-- Hash table of excluded dates in MMDD format (e.g., "0923" for September 23)
local excludedDates = {
    ["0923"] = true, -- September 23
    ["1225"] = true, -- December 25
    ["0101"] = true  -- January 1
}

-- Generate grid with all dates, each month in its own 35-grid set
local itemCount = 1
for _, monthInfo in ipairs(monthDays) do
    -- Add the actual month days
    for day = 1, monthInfo.days do
        local dateKey = monthInfo.mm .. string.format("%02d", day) -- e.g., "0923"
        local isCrest = excludedDates[dateKey] or false
        table.insert(gridData, {
            label = isCrest and "TeamCrest" or (monthInfo.month .. " " .. day .. " " .. year),
            id = itemCount,
            selected = (itemCount == 1), -- August 1 selected by default
            alternateBackground = alternateBG,
            image = isCrest and {
                name = "$Crest",
                id = 9
            } or nil
        })
        itemCount = itemCount + 1
    end

    -- Fill remaining grids up to 35 with counting numbers
    local remainingGrids = GRIDS_PER_SET - monthInfo.days
    for fill = 1, remainingGrids do
        table.insert(gridData, {
            label = tostring(fill),
            id = itemCount,
            selected = false,
            alternateBackground = alternateBG
        })
        itemCount = itemCount + 1
    end

    -- Toggle alternate background for each new row (assuming 7 columns per row)
    if itemCount % 7 == 0 then
        alternateBG = not alternateBG
    end
end

self.playersDataToPublish = {
    index = 1,
    data = gridData
}

print("Grid data to publish: " .. tostring(#gridData) .. " items")
print("Year used: " .. year .. (isLeapYear(year) and " (Leap Year)" or " (Non-Leap Year)"))
for i, item in ipairs(gridData) do
    local imgInfo = item.image and ("Image: " .. item.image.name .. ", ID: " .. item.image.id) or "No Image"
    print("Item " .. i .. ": " .. item.label .. ", Selected: " .. tostring(item.selected) .. ", " .. imgInfo)
end

self.im.Refresh(bnd_player_list)
end
  
function SelectLeagueTeam:registerBindings()
  self.im.Subscribe(bnd_player_list, function()
    print("Publishing to bnd_player_list: " .. tostring(#self.playersDataToPublish.data) .. " players")
    self.im.Publish(bnd_player_list, self.playersDataToPublish)
  end)
  self.isSelectorVisible = false
  self.im.Subscribe(BND_LEAGUE_OVERLAY_VISIBLE, function()
    self.im.Publish(BND_LEAGUE_OVERLAY_VISIBLE, self.isSelectorVisible)
  end)
  self.im.Subscribe(BND_SELECTED_LEAGUE_NAME, function()
    local name = self.playersDataToPublish.data[self.playerIndex] and self.playersDataToPublish.data[self.playerIndex].label or "No Player"
    print("Publishing selected player name: " .. name)
    self.im.Publish(BND_SELECTED_LEAGUE_NAME, name)
  end)
  self.im.RegisterAction(ACT_SELECT_LEAGUE, function()
    self.im.ChangeActionState(ACT_SELECT_LEAGUE, self.im.GetActionState("INVALID"))
    self:toggleSelectorVisibility(true)
    print("Selector opened")
  end)
end

function SelectLeagueTeam:setSelectedPlayerIndex(index)
  self.playerIndex = index
  self.im.Refresh(BND_SELECTED_LEAGUE_NAME)
  self:publishPlayerHead()
  print("Selected player index set to: " .. index)
end

function SelectLeagueTeam:publishPlayerHead()
  local player = self.playersDataToPublish.data[self.playerIndex]
  if player then
    local playerHead = {
      name = "$Head",
      id = player.image.id
    }
    print("Publishing player head for CARD_ID: " .. playerHead.id)
    self.im.Publish(BND_LEAGUE_CREST, playerHead)
  end
end

function SelectLeagueTeam:publishPlayerIndex()
  self.im.Publish(bnd_player_list_INDEX, self.playerIndex)
  print("Published player index: " .. self.playerIndex)
end

function SelectLeagueTeam:showWelcomePopup()
  local buttonYes = {
    icon = "$FooterIconNo",
    label = "View Squad",
    clickEvents = {"evt_hide_popup"}
  }
  local popupData = {
    title = "WELCOME MR MANAGER",
    message = "You have being appointed as new Head Coach, \n View your squad.",
    buttons = {buttonYes}
  }
  print("SHOWING WELCOME POPUP NOW!")
  self.nav.Event(nil, "evt_show_popup", popupData)
end

function SelectLeagueTeam:noSuccess()
  local buttonYes = {
    icon = "$FooterIconNo",
    label = "View Squad",
    clickEvents = {"evt_hide_popup", "evt_back"}
  }
  local popupData = {
    title = "",
    message = "No players matching your criterias were found",
    buttons = {buttonYes}
  }
  self.nav.Event(nil, "evt_show_popup", popupData)
end

function SelectLeagueTeam:toggleSelectorVisibility(visible)
  if self.isSelectorVisible ~= visible then
    self.isSelectorVisible = visible
    self.im.Refresh(BND_LEAGUE_OVERLAY_VISIBLE)
    print("Selector visibility toggled to: " .. tostring(visible))
  end
end

function SelectLeagueTeam:onSelectorCancel()
  if self.isSelectorVisible then
    self:toggleSelectorVisibility(false)
    print("Selector cancelled")
  end
  self.im.ChangeActionState(ACT_SELECT_LEAGUE, self.im.GetActionState("VALID"))
end

function SelectLeagueTeam:finalize()
  self.im.Unsubscribe(bnd_player_list)
  self.im.Unsubscribe(BND_SELECTED_LEAGUE_NAME)
  self.im.Unsubscribe(BND_LEAGUE_OVERLAY_VISIBLE)
  self.im.Unsubscribe(BND_LEAGUE_CREST)
  self.im.Unsubscribe(bnd_player_list_INDEX)
  self.im.Unsubscribe(BND_DEFAULT_CELL_DATA)
  self.im.UnregisterDataAction(bnd_player_list_INDEX, ACT_CHANGE)
  self.im.UnregisterDataAction(bnd_player_index, ACT_CHANGE)
  self.im.UnregisterAction(ACT_SELECTOR_CANCEL)
  self.im.UnregisterAction(ACT_SELECT_LEAGUE)
  self.im.UnregisterAction("test_popup")
  print("Finalized SelectLeagueTeam")
end

return SelectLeagueTeam